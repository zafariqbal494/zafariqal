package com.cobrax.vpn.state

import android.content.Context
import com.cobrax.vpn.model.*
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class StateManager private constructor(private val context: Context) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    // SupervisorJob ensures one failed child (e.g. a missed log emit) never cancels the whole scope
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    var config: AppConfig = AppConfig()
        private set

    var currentUserState: UserState = UserState()
        private set

    // Runtime-only tracking caches — ConcurrentHashMap is safe for concurrent reads/writes without mutex
    val issueWinAmounts = ConcurrentHashMap<String, Double>()
    val issueWinApplied = ConcurrentHashMap<String, Boolean>()
    val issueDesiredBetType = ConcurrentHashMap<String, String>()
    var lastWithdrawalAmount: Double = 0.0
    var lastWithdrawalType: Int = 23

    // Log flow for real-time UI display — replay=50 so late subscribers see recent history
    private val _logsFlow = MutableSharedFlow<ProxyLogItem>(replay = 50, extraBufferCapacity = 100)
    val logsFlow: SharedFlow<ProxyLogItem> = _logsFlow.asSharedFlow()

    // Coroutine-friendly Mutex — never blocks threads, only suspends coroutines
    private val mutex = Mutex()

    // Background job for periodically checking and resolving pending withdrawals
    private var withdrawalTimerJob: Job? = null

    init {
        loadConfig()
        restoreLastUser()
    }

    companion object {
        @Volatile
        private var instance: StateManager? = null

        fun getInstance(context: Context): StateManager {
            return instance ?: synchronized(this) {
                instance ?: StateManager(context.applicationContext).also { instance = it }
            }
        }

        fun round2(value: Double): Double {
            return BigDecimal(value).setScale(2, RoundingMode.HALF_UP).toDouble()
        }
    }

    // Non-suspend: emit is thread-safe and non-blocking from any context
    fun log(tag: String, message: String, isInterception: Boolean = false, isError: Boolean = false) {
        val item = ProxyLogItem(
            timestamp = System.currentTimeMillis(),
            tag = tag,
            message = message,
            isInterception = isInterception,
            isError = isError
        )
        scope.launch {
            _logsFlow.emit(item)
        }
    }

    // ── Config ──────────────────────────────────────────────────────────────

    private fun loadConfig() {
        try {
            val configFile = File(context.filesDir, "app_config.json")
            if (configFile.exists()) {
                val json = configFile.readText()
                config = gson.fromJson(json, AppConfig::class.java) ?: AppConfig()
            } else {
                config = AppConfig()
                saveConfigInternal()
            }
        } catch (e: Exception) {
            log("Config", "Error loading config: ${e.message}", isError = true)
        }
    }

    private fun saveConfigInternal() {
        try {
            val configFile = File(context.filesDir, "app_config.json")
            configFile.writeText(gson.toJson(config))
        } catch (e: Exception) {
            log("Config", "Error saving config: ${e.message}", isError = true)
        }
    }

    suspend fun saveConfig() {
        mutex.withLock {
            saveConfigInternal()
            log("Config", "Configuration saved.")
        }
    }

    suspend fun updateConfig(updateBlock: (AppConfig) -> Unit) {
        mutex.withLock {
            updateBlock(config)
            saveConfigInternal()
        }
    }

    // ── User State ───────────────────────────────────────────────────────────

    private fun restoreLastUser() {
        try {
            val lastUserFile = File(context.filesDir, "last_user.txt")
            val userName = if (lastUserFile.exists()) lastUserFile.readText().trim() else "default_user"
            switchUserInternal(if (userName.isNotEmpty()) userName else "default_user")
        } catch (e: Exception) {
            log("State", "Error restoring last user: ${e.message}", isError = true)
            switchUserInternal("default_user")
        }
    }

    // Non-suspend version for use inside mutex.withLock{} blocks (already locked)
    private fun switchUserInternal(userName: String) {
        val cleanUserName = userName.trim()
        if (currentUserState.userName != cleanUserName && currentUserState.userName.isNotEmpty()) {
            saveStateInternal()
            log("State", "Switched user: ${currentUserState.userName} -> $cleanUserName")
        }
        try {
            File(context.filesDir, "last_user.txt").writeText(cleanUserName)
        } catch (_: Exception) {}

        synchronized(this) {
            withdrawalTimerJob?.cancel()
            withdrawalTimerJob = null
        }

        loadStateInternal(cleanUserName)
    }

    suspend fun switchUser(userName: String) {
        mutex.withLock {
            switchUserInternal(userName)
        }
    }

    private fun loadStateInternal(userName: String) {
        val stateFile = File(context.filesDir, "fiddler_state_${userName}.json")
        if (stateFile.exists()) {
            try {
                val json = stateFile.readText()
                currentUserState = gson.fromJson(json, UserState::class.java)
                    ?: UserState(userName = userName)
                log(
                    "State",
                    "Loaded state for user: $userName. Balance: ${currentUserState.localBalance}, " +
                    "Issues: ${currentUserState.modifiedIssues.size}, " +
                    "Withdrawals: ${currentUserState.fakeWithdrawals.size}"
                )
            } catch (e: Exception) {
                log("State", "Error reading state for $userName: ${e.message}. Using defaults.", isError = true)
                currentUserState = UserState(userName = userName, localBalance = config.defaultBalance)
            }
        } else {
            currentUserState = UserState(userName = userName, localBalance = config.defaultBalance)
            saveStateInternal()
            log("State", "Created new state for user: $userName with balance: ${config.defaultBalance}")
        }

        // Reset runtime caches and repopulate bet type from persistent bet contexts
        issueWinAmounts.clear()
        issueWinApplied.clear()
        issueDesiredBetType.clear()
        for ((issueKey, ctx) in currentUserState.betContexts) {
            val bc = ctx.betContent
            when {
                bc.contains("_Big")   -> issueDesiredBetType[issueKey] = "big"
                bc.contains("_Small") -> issueDesiredBetType[issueKey] = "small"
            }
        }

        // Start background timer if there are any unresolved pending withdrawals
        startWithdrawalTimerIfNeeded()
    }

    suspend fun saveState() {
        mutex.withLock { saveStateInternal() }
    }

    private fun saveStateInternal() {
        if (currentUserState.userName.isEmpty()) return
        try {
            currentUserState.lastUpdated = System.currentTimeMillis()
            val stateFile = File(context.filesDir, "fiddler_state_${currentUserState.userName}.json")
            stateFile.writeText(gson.toJson(currentUserState))
        } catch (e: Exception) {
            log("State", "Error saving state: ${e.message}", isError = true)
        }
    }

    // ── Balance Operations ────────────────────────────────────────────────────

    suspend fun deductBalance(amount: Double): Double {
        return mutex.withLock {
            val newBal = round2(currentUserState.localBalance - amount)
            currentUserState.localBalance = newBal
            saveStateInternal()
            newBal
        }
    }

    suspend fun creditBalance(amount: Double): Double {
        return mutex.withLock {
            val newBal = round2(currentUserState.localBalance + amount)
            currentUserState.localBalance = newBal
            saveStateInternal()
            newBal
        }
    }

    suspend fun setBalance(amount: Double) {
        mutex.withLock {
            currentUserState.localBalance = round2(amount)
            saveStateInternal()
            log("State", "Simulated balance set to: ${currentUserState.localBalance}")
        }
    }

    // ── Bet & Issue Records ───────────────────────────────────────────────────

    suspend fun recordBet(issueNumber: String, betContext: BetContext, betType: String, potentialWin: Double) {
        mutex.withLock {
            currentUserState.betContexts[issueNumber] = betContext
            if (betType.isNotEmpty()) issueDesiredBetType[issueNumber] = betType
            issueWinAmounts[issueNumber] = potentialWin
            issueWinApplied.remove(issueNumber)
            saveStateInternal()
        }
    }

    suspend fun recordModifiedIssue(issueNumber: String, number: String, color: String) {
        mutex.withLock {
            currentUserState.modifiedIssues[issueNumber] = ModifiedIssue(number = number, color = color)
            saveStateInternal()
        }
    }

    // ── Withdrawal Records ────────────────────────────────────────────────────

    suspend fun recordFakeWithdrawal(withdrawal: FakeWithdrawal) {
        mutex.withLock {
            currentUserState.fakeWithdrawals.add(0, withdrawal)
            saveStateInternal()
        }
        startWithdrawalTimerIfNeeded()
    }

    /**
     * Starts a background coroutine timer that checks every 30 seconds
     * to see if any pending withdrawal delays have finished.
     * Automatically stops when all pending withdrawals are resolved.
     */
    fun startWithdrawalTimerIfNeeded() {
        synchronized(this) {
            if (withdrawalTimerJob?.isActive == true) return
            val hasPending = currentUserState.fakeWithdrawals.any { it.state == 0 }
            if (!hasPending) return

            withdrawalTimerJob = scope.launch {
                // Check immediately first — withdrawals may have already expired
                // (e.g. app was restarted while a timer was running).
                // Then wait 30s between each subsequent check.
                while (true) {
                    val hasPendingLeft = updatePendingWithdrawals()
                    if (!hasPendingLeft) break
                    delay(30_000) // wait 30 seconds before checking again
                }
            }
        }
    }

    /**
     * Checks all pending withdrawals (state == 0).
     * If the delay timer has expired:
     * - Wrong password: state -> 2 (Rejected), refunds balance back to localBalance.
     * - Correct password: state -> 1 (Success).
     *
     * Returns true if there are still pending withdrawals (state == 0) remaining.
     */
    suspend fun updatePendingWithdrawals(): Boolean {
        return mutex.withLock {
            val now = System.currentTimeMillis()
            var stateChanged = false

            for (wd in currentUserState.fakeWithdrawals) {
                if (wd.state == 0) {
                    val targetDelay = if (wd.delayMinutes > 0) wd.delayMinutes else config.withdrawalMinDelayMinutes
                    val delayMs = (targetDelay * 60 * 1000).toLong()
                    if (now - wd.creationTimeMs >= delayMs) {
                        if (wd.isWrongPassword) {
                            wd.state = 2 // Rejected
                            wd.remark = "technical issue."
                            wd.artificialMessage = "technical issue."
                            val refundAmt = wd.price.toDoubleOrNull() ?: 0.0
                            if (refundAmt > 0) {
                                // Credit inside mutex — call internal version directly
                                val newBal = round2(currentUserState.localBalance + refundAmt)
                                currentUserState.localBalance = newBal
                                log("Withdrawal", "Withdrawal ${wd.withdrawNumber} REJECTED (state:2). Refunded $refundAmt. Balance: $newBal", isInterception = true)
                            } else {
                                log("Withdrawal", "Withdrawal ${wd.withdrawNumber} REJECTED (state:2): technical issue.", isInterception = true)
                            }
                        } else {
                            wd.state = 1 // Success
                            wd.remark = ""
                            wd.artificialMessage = "Your withdrawal is being processed."
                            log("Withdrawal", "Withdrawal ${wd.withdrawNumber} successful after ${String.format(Locale.US, "%.1f", targetDelay)} minutes.", isInterception = true)
                        }
                        stateChanged = true
                    }
                }
            }
            if (stateChanged) saveStateInternal()
            currentUserState.fakeWithdrawals.any { it.state == 0 }
        }
    }
}
