package com.cobrax.vpn.proxy

import android.content.Context
import android.net.VpnService
import com.cobrax.vpn.cert.CertificateAuthority
import com.cobrax.vpn.rules.RuleEngine
import com.cobrax.vpn.state.StateManager
import io.netty.bootstrap.Bootstrap
import io.netty.bootstrap.ServerBootstrap
import io.netty.buffer.Unpooled
import io.netty.channel.*
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.SocketChannel
import io.netty.channel.socket.nio.NioServerSocketChannel
import io.netty.channel.socket.nio.NioSocketChannel
import io.netty.handler.codec.http.*
import io.netty.handler.ssl.SslContextBuilder
import io.netty.handler.ssl.util.InsecureTrustManagerFactory
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

// ════════════════════════════════════════════════════════════════════════════
// MitmProxyServer — Embedded Netty MITM proxy on 127.0.0.1:8877
// ════════════════════════════════════════════════════════════════════════════

class MitmProxyServer(
    context: Context,
    val port: Int = 8877,
    private val vpnService: VpnService? = null
) {
    private val stateManager  = StateManager.getInstance(context)
    private val certAuthority = CertificateAuthority.getInstance(context)
    private val ruleEngine    = RuleEngine(stateManager)

    private var bossGroup: EventLoopGroup?   = null
    private var workerGroup: EventLoopGroup? = null
    private var serverChannel: Channel?      = null
    private val isRunning = AtomicBoolean(false)

    fun start() {
        if (isRunning.get()) return

        bossGroup  = NioEventLoopGroup(1)
        workerGroup = NioEventLoopGroup(4)

        try {
            val b = ServerBootstrap()
            b.group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel::class.java)
                .childHandler(object : ChannelInitializer<SocketChannel>() {
                    override fun initChannel(ch: SocketChannel) {
                        ch.pipeline().addLast("httpCodec",   HttpServerCodec())
                        ch.pipeline().addLast("aggregator",  HttpObjectAggregator(10 * 1024 * 1024))
                        ch.pipeline().addLast("mitmHandler", MitmFrontendHandler(vpnService, certAuthority, ruleEngine, stateManager))
                    }
                })
                .option(ChannelOption.SO_BACKLOG, 128)
                .childOption(ChannelOption.SO_KEEPALIVE, true)

            val future = b.bind(InetSocketAddress("127.0.0.1", port)).sync()
            serverChannel = future.channel()
            isRunning.set(true)
            stateManager.log("Proxy", "Local Netty MITM Proxy active on 127.0.0.1:$port")
        } catch (e: Exception) {
            stateManager.log("Proxy", "Failed to start MITM Proxy: ${e.message}", isError = true)
            stop()
        }
    }

    fun stop() {
        if (!isRunning.get()) return
        try {
            serverChannel?.close()?.sync()
            bossGroup?.shutdownGracefully()
            workerGroup?.shutdownGracefully()
            isRunning.set(false)
            stateManager.log("Proxy", "Local Netty MITM Proxy stopped.")
        } catch (e: Exception) {
            stateManager.log("Proxy", "Error stopping proxy: ${e.message}", isError = true)
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// MitmFrontendHandler — Client-side handler: manages CONNECT + HTTP requests
// ════════════════════════════════════════════════════════════════════════════

class MitmFrontendHandler(
    private val vpnService: VpnService?,
    private val certAuthority: CertificateAuthority,
    private val ruleEngine: RuleEngine,
    private val stateManager: StateManager
) : SimpleChannelInboundHandler<FullHttpRequest>() {

    private var remoteChannel: Channel? = null
    private val pendingOutboundRequests = ConcurrentLinkedQueue<FullHttpRequest>()
    private val isConnecting = AtomicBoolean(false)
    private var isHttps      = false
    private var targetHost   = ""
    private var targetPort   = 80
    private val sessionAttrs = ConcurrentHashMap<String, String>()

    // Each frontend handler has its own scope for processing requests.
    // SupervisorJob ensures one failed request does not cancel handling of others.
    private val handlerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun channelRead0(clientCtx: ChannelHandlerContext, request: FullHttpRequest) {
        if (request.method() == HttpMethod.CONNECT) {
            handleConnectRequest(clientCtx, request)
        } else {
            handleHttpRequest(clientCtx, request)
        }
    }

    private fun handleConnectRequest(clientCtx: ChannelHandlerContext, request: FullHttpRequest) {
        isHttps = true
        val hostPort = request.uri().split(":")
        targetHost = hostPort[0]
        targetPort = if (hostPort.size > 1) hostPort[1].toIntOrNull() ?: 443 else 443

        stateManager.log("CONNECT", "Intercepted HTTPS CONNECT -> $targetHost:$targetPort", isInterception = true)

        // Remove HTTP codecs — we will reply raw, then install SSL + new codecs
        clientCtx.channel().pipeline().remove("httpCodec")
        clientCtx.channel().pipeline().remove("aggregator")
        clientCtx.writeAndFlush(
            io.netty.buffer.Unpooled.copiedBuffer(
                "HTTP/1.1 200 Connection Established\r\n\r\n",
                java.nio.charset.StandardCharsets.US_ASCII
            )
        ).addListener { f ->
            if (f.isSuccess) {
                try {
                    val sslContext = certAuthority.getOrCreateSslContext(targetHost)
                    val sslHandler = sslContext.newHandler(clientCtx.alloc())
                    val pipeline   = clientCtx.channel().pipeline()
                    pipeline.addBefore("mitmHandler", "ssl",        sslHandler)
                    pipeline.addBefore("mitmHandler", "httpCodec",  HttpServerCodec())
                    pipeline.addBefore("mitmHandler", "aggregator", HttpObjectAggregator(10 * 1024 * 1024))
                    stateManager.log("SSL", "TLS MITM active for $targetHost:$targetPort", isInterception = true)
                } catch (e: Exception) {
                    stateManager.log("SSL", "SSL Context error for $targetHost: ${e.message}", isError = true)
                    clientCtx.close()
                }
            } else {
                clientCtx.close()
            }
        }
    }

    private fun handleHttpRequest(clientCtx: ChannelHandlerContext, request: FullHttpRequest) {
        if (targetHost.isEmpty()) {
            val hostHeader = request.headers().get(HttpHeaderNames.HOST)
            if (hostHeader != null) {
                val hp = hostHeader.split(":")
                targetHost = hp[0]
                targetPort = if (hp.size > 1) hp[1].toIntOrNull() ?: 80 else 80
            }
        }

        stateManager.log("HTTP", "Incoming Request -> ${request.method().name()} ${request.uri()}")

        // We need TWO retain references BEFORE launching the coroutine.
        //
        // SimpleChannelInboundHandler auto-releases `request` when channelRead0() returns,
        // which happens immediately after handlerScope.launch{} is called (non-blocking).
        // Any access to the original `request` inside the coroutine body will crash with
        // IllegalReferenceCountException: refCnt: 0
        //
        // reqForProcess — passed to processRequest, released in finally block
        // reqForForward — passed to connectAndForward, its lifecycle is then owned by
        //                 forwardToRemote → enqueueRequest → RemoteResponseHandler.finally
        val reqForProcess = request.retainedDuplicate()
        val reqForForward = request.retainedDuplicate()

        handlerScope.launch {
            try {
                ruleEngine.processRequest(reqForProcess, sessionAttrs)
            } catch (e: Exception) {
                stateManager.log("Proxy", "processRequest error: ${e.message}", isError = true)
            } finally {
                reqForProcess.release()
            }
            connectAndForward(clientCtx, reqForForward)
        }
    }


    private fun connectAndForward(clientCtx: ChannelHandlerContext, request: FullHttpRequest) {
        val existingRemote = remoteChannel
        if (existingRemote != null && existingRemote.isActive) {
            forwardToRemote(existingRemote, request)
            return
        }

        pendingOutboundRequests.offer(request)

        if (isConnecting.compareAndSet(false, true)) {
            val b = Bootstrap()
            b.group(clientCtx.channel().eventLoop())
                .channel(NioSocketChannel::class.java)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000)
                .option(ChannelOption.SO_KEEPALIVE, true)
                .handler(object : ChannelInitializer<SocketChannel>() {
                    override fun initChannel(ch: SocketChannel) {
                        // Protect outgoing socket from Android VPN routing loop
                        try {
                            val method = io.netty.channel.nio.AbstractNioChannel::class.java.getDeclaredMethod("javaChannel")
                            method.isAccessible = true
                            val nioChannel = method.invoke(ch) as? java.nio.channels.SocketChannel
                            nioChannel?.socket()?.let { sock -> vpnService?.protect(sock) }
                        } catch (e: Exception) {
                            stateManager.log("Proxy", "Socket protect note: ${e.message}")
                        }

                        if (isHttps) {
                            val clientSslCtx = SslContextBuilder.forClient()
                                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                                .build()
                            ch.pipeline().addLast("ssl", clientSslCtx.newHandler(ch.alloc(), targetHost, targetPort))
                        }
                        ch.pipeline().addLast("httpClientCodec", HttpClientCodec())
                        ch.pipeline().addLast("aggregator",      HttpObjectAggregator(10 * 1024 * 1024))
                        ch.pipeline().addLast("remoteHandler",   RemoteResponseHandler(clientCtx, ruleEngine, stateManager, sessionAttrs, targetHost))
                    }
                })

            b.connect(targetHost, targetPort).addListener(ChannelFutureListener { future ->
                isConnecting.set(false)
                if (future.isSuccess) {
                    remoteChannel = future.channel()
                    stateManager.log("Proxy", "Connected to remote $targetHost:$targetPort")
                    while (true) {
                        val req = pendingOutboundRequests.poll() ?: break
                        forwardToRemote(remoteChannel!!, req)
                    }
                } else {
                    stateManager.log("Proxy", "Failed to connect to $targetHost:$targetPort -> ${future.cause()?.message}", isError = true)
                    while (true) {
                        val req = pendingOutboundRequests.poll() ?: break
                        try { req.release() } catch (_: Exception) {}
                    }
                    sendBadGateway(clientCtx)
                }
            })
        }
    }

    private fun forwardToRemote(remoteChan: Channel, request: FullHttpRequest) {
        val handler = remoteChan.pipeline().get(RemoteResponseHandler::class.java)
        handler?.enqueueRequest(request)

        val reqToSend = request.retainedDuplicate()
        val hostHeaderValue = if ((isHttps && targetPort == 443) || (!isHttps && targetPort == 80))
            targetHost else "$targetHost:$targetPort"
        reqToSend.headers().set(HttpHeaderNames.HOST, hostHeaderValue)
        reqToSend.headers().remove("Proxy-Connection")
        reqToSend.headers().set(HttpHeaderNames.ACCEPT_ENCODING, "identity")

        if (!isHttps && reqToSend.uri().startsWith("http://")) {
            val idx = reqToSend.uri().indexOf('/', 7)
            if (idx != -1) reqToSend.uri = reqToSend.uri().substring(idx)
        }

        if (reqToSend.content().readableBytes() > 0) {
            HttpUtil.setContentLength(reqToSend, reqToSend.content().readableBytes().toLong())
        }

        stateManager.log("Proxy", "Forwarded ${reqToSend.method().name()} ${reqToSend.uri()} to $targetHost:$targetPort")
        remoteChan.writeAndFlush(reqToSend)
    }

    private fun sendBadGateway(clientCtx: ChannelHandlerContext) {
        val errorJson = """{"code": 502, "msg": "Bad Gateway - CobraX VPN proxy unable to connect to $targetHost"}"""
        val bytes     = errorJson.toByteArray(StandardCharsets.UTF_8)
        val response  = DefaultFullHttpResponse(
            HttpVersion.HTTP_1_1,
            HttpResponseStatus.BAD_GATEWAY,
            Unpooled.wrappedBuffer(bytes)
        )
        response.headers().set(HttpHeaderNames.CONTENT_TYPE,   "application/json")
        response.headers().set(HttpHeaderNames.CONTENT_LENGTH, bytes.size)
        clientCtx.channel().writeAndFlush(response).addListener(ChannelFutureListener.CLOSE)
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        handlerScope.cancel()
        remoteChannel?.close()
        super.channelInactive(ctx)
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        stateManager.log("Proxy", "Client exception ($targetHost): ${cause.message}")
        ctx.close()
        remoteChannel?.close()
    }
}

// ════════════════════════════════════════════════════════════════════════════
// RemoteResponseHandler — Upstream handler: receives server responses,
// calls RuleEngine.processResponse (suspend) from its own CoroutineScope,
// then writes the (possibly modified) response back to the client.
//
// KEY INVARIANT: Netty I/O thread is NEVER blocked. All suspend work runs
// on Dispatchers.IO; the final write back uses eventLoop().execute{} to
// ensure the write happens on the correct Netty EventLoop thread.
// ════════════════════════════════════════════════════════════════════════════

class RemoteResponseHandler(
    private val clientCtx: ChannelHandlerContext,
    private val ruleEngine: RuleEngine,
    private val stateManager: StateManager,
    private val sessionAttrs: MutableMap<String, String>,
    private val host: String
) : SimpleChannelInboundHandler<FullHttpResponse>() {

    private val pendingRequests = ConcurrentLinkedQueue<FullHttpRequest>()

    // SupervisorJob: one failed response handler never cancels others in flight
    private val handlerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun enqueueRequest(req: FullHttpRequest) {
        pendingRequests.offer(req)
    }

    override fun channelRead0(ctx: ChannelHandlerContext, response: FullHttpResponse) {
        val origReq = pendingRequests.poll()

        // Retain both buffers before crossing the coroutine boundary.
        // They will be released in the finally block after the write completes.
        val retainedResponse = response.retain()
        val retainedRequest  = origReq?.retainedDuplicate()

        handlerScope.launch {
            try {
                if (retainedRequest != null) {
                    stateManager.log("HTTP", "Processing Response -> ${retainedRequest.uri()} (${retainedResponse.status().code()})")
                    // suspend call — safe, never blocks the Netty I/O thread
                    ruleEngine.processResponse(retainedRequest, retainedResponse, sessionAttrs)
                } else {
                    stateManager.log("HTTP", "Received Response (${retainedResponse.status().code()})")
                }

                // Normalize headers so the client browser/app decodes correctly
                retainedResponse.headers().remove(HttpHeaderNames.TRANSFER_ENCODING)
                retainedResponse.headers().remove(HttpHeaderNames.CONTENT_ENCODING)

                val statusCode = retainedResponse.status().code()
                if (statusCode != 204 && statusCode != 304 && statusCode !in 100..199) {
                    HttpUtil.setContentLength(retainedResponse, retainedResponse.content().readableBytes().toLong())
                } else {
                    retainedResponse.headers().remove(HttpHeaderNames.CONTENT_LENGTH)
                }

                // Write MUST happen on the Netty EventLoop thread — use execute{} to schedule it
                clientCtx.channel().eventLoop().execute {
                    clientCtx.channel().writeAndFlush(retainedResponse).addListener { f ->
                        if (!f.isSuccess) {
                            stateManager.log("Proxy", "Error sending response to client: ${f.cause()?.message}", isError = true)
                            clientCtx.close()
                        }
                    }
                }
            } catch (e: Exception) {
                stateManager.log("Proxy", "Response processing error ($host): ${e.message}", isError = true)
                try { retainedResponse.release() } catch (_: Exception) {}
                clientCtx.close()
            } finally {
                // Release the request copy regardless of outcome
                try { retainedRequest?.release() } catch (_: Exception) {}
                // Note: retainedResponse is released by Netty after writeAndFlush completes.
                // Do NOT release it here — Netty owns the buffer after writeAndFlush.
                try { origReq?.release() } catch (_: Exception) {}
            }
        }
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        handlerScope.cancel()
        // Drain and release any queued requests
        while (true) {
            val r = pendingRequests.poll() ?: break
            try { r.release() } catch (_: Exception) {}
        }
        clientCtx.close()
        super.channelInactive(ctx)
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        stateManager.log("Proxy", "Remote channel exception ($host): ${cause.message}")
        handlerScope.cancel()
        ctx.close()
        clientCtx.close()
    }
}
