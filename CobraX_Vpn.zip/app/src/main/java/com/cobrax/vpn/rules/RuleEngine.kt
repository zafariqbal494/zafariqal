package com.cobrax.vpn.rules

import com.cobrax.vpn.model.BetContext
import com.cobrax.vpn.model.FakeWithdrawal
import com.cobrax.vpn.network.RealResultFetcher
import com.cobrax.vpn.state.StateManager
import com.google.gson.JsonParser
import io.netty.buffer.Unpooled
import io.netty.handler.codec.http.*
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern
import kotlin.math.ceil
import kotlin.random.Random

class RuleEngine(private val stateManager: StateManager) {

    private val jsonDateFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("GMT+5")
    }

    private val orderDateFormatter = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("GMT+5")
    }

    // ────────────────────────────────────────────────────────────────────────
    // REQUEST PROCESSING
    // Intercepts and modifies outgoing HTTP Requests.
    // Returns true if request was flagged/modified.
    // ────────────────────────────────────────────────────────────────────────
    @Suppress("UNUSED_PARAMETER")
    suspend fun processRequest(
        request: FullHttpRequest,
        sessionAttrs: MutableMap<String, String>
    ): Boolean {
        if (!stateManager.config.enableModifications) return false

        val uri = request.uri()

        // 1. WinGoBet — deduct bet immediately from local balance
        if (uri.contains("/api/Lottery/WinGoBet") && request.method() == HttpMethod.POST) {
            try {
                val bodyStr = request.content().toString(StandardCharsets.UTF_8)
                val amountStr     = extractJsonValue(bodyStr, "amount")
                val betMultipleStr = extractJsonValue(bodyStr, "betMultiple")
                val amountVal      = amountStr?.toDoubleOrNull() ?: 0.0
                val betMultipleVal = betMultipleStr?.toDoubleOrNull() ?: 1.0
                val totalBet       = StateManager.round2(amountVal * betMultipleVal)
                val betContent     = extractJsonValue(bodyStr, "betContent")
                val issueNumber    = extractJsonValue(bodyStr, "issueNumber")

                if (issueNumber != null && betContent != null) {
                    var betType = ""
                    if (betContent.contains("_Big"))   betType = "big"
                    else if (betContent.contains("_Small")) betType = "small"

                    val timestampSec = extractJsonValue(bodyStr, "timestamp")?.toDoubleOrNull() ?: 0.0
                    val betEpochMs = if (timestampSec > 0) {
                        (timestampSec * 1000).toLong() + Random.nextLong(500, 1500)
                    } else {
                        System.currentTimeMillis()
                    }

                    val betContext = BetContext(
                        issueNumber  = issueNumber,
                        playType     = "BigSmall",
                        amount       = amountVal,
                        betMultiple  = betMultipleVal,
                        betContent   = betContent,
                        betTimeIso   = jsonDateFormatter.format(Date(betEpochMs)),
                        betTimeEpochMs = betEpochMs
                    )

                    val winAmount  = StateManager.round2(totalBet * 1.98)
                    val newBalance = stateManager.deductBalance(totalBet)  // suspend
                    stateManager.recordBet(issueNumber, betContext, betType, winAmount)  // suspend

                    stateManager.log(
                        "Request",
                        "WinGoBet Placed. Deducted $totalBet. New Balance: $newBalance. " +
                        "BetType: '$betType' for Issue: $issueNumber",
                        isInterception = true
                    )
                }
                return true
            } catch (e: Exception) {
                stateManager.log("Request", "WinGoBet Request Error: ${e.message}", isError = true)
            }
        }

        // 2. Capture withdrawal amount & payment type for later response handling
        if (uri.contains("/api/webapi/NewSetWithdrawal") && request.method() == HttpMethod.POST) {
            try {
                val bodyStr = request.content().toString(StandardCharsets.UTF_8)
                stateManager.lastWithdrawalAmount = extractJsonValue(bodyStr, "amount")?.toDoubleOrNull() ?: 0.0
                stateManager.lastWithdrawalType   = extractJsonValue(bodyStr, "type")?.toIntOrNull() ?: 23
                stateManager.log(
                    "Request",
                    "Captured withdrawal request: amount=${stateManager.lastWithdrawalAmount}, " +
                    "type=${stateManager.lastWithdrawalType}"
                )
            } catch (e: Exception) {
                stateManager.log("Request", "NewSetWithdrawal Request Error: ${e.message}", isError = true)
            }
        }

        return false
    }

    // ────────────────────────────────────────────────────────────────────────
    // RESPONSE PROCESSING
    // Intercepts and transforms incoming HTTP Responses.
    // Returns true if response was modified.
    //
    // NOTE: This is a suspend function. MitmProxyServer calls it from a
    // coroutine scope so the Netty I/O thread is NEVER blocked.
    // ────────────────────────────────────────────────────────────────────────
    @Suppress("UNUSED_PARAMETER")
    suspend fun processResponse(
        request: FullHttpRequest,
        response: FullHttpResponse,
        sessionAttrs: MutableMap<String, String>
    ): Boolean {
        val uri = request.uri()

        // ── User Detection ─────────────────────────────────────────────────
        if (uri.contains("/api/webapi/GetUserInfo")) {
            try {
                val bodyStr  = response.content().toString(StandardCharsets.UTF_8)
                val userName = extractJsonValue(bodyStr, "userName")?.trim()
                if (!userName.isNullOrEmpty()) {
                    stateManager.switchUser(userName)   // suspend
                    response.headers().set(HttpHeaderNames.CACHE_CONTROL, "no-store, no-cache, must-revalidate")
                    response.headers().set(HttpHeaderNames.PRAGMA, "no-cache")
                    stateManager.log(
                        "UserInfo",
                        "Detected user: $userName. Active balance: ${stateManager.currentUserState.localBalance}",
                        isInterception = true
                    )
                }
            } catch (e: Exception) {
                stateManager.log("UserInfo", "Error parsing GetUserInfo: ${e.message}", isError = true)
            }
            return true
        }

        if (!stateManager.config.enableModifications) return false

        // ── 1. WinGoBet Response ───────────────────────────────────────────
        if (uri.contains("/api/Lottery/WinGoBet")) {
            try {
                val originalBody = response.content().toString(StandardCharsets.UTF_8)
                val serviceTime  = extractJsonValue(originalBody, "serviceTime") ?: "0"
                val newJson = """{"code":0,"msg":"succeed","msgCode":0,"serviceTime":$serviceTime}"""
                stateManager.log("Response", "Sent WinGoBet Success JSON.", isInterception = true)
                setJsonResponse(response, newJson)
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "WinGoBet Response Error: ${e.message}", isError = true)
            }
        }

        // ── 2. GetWinLossResult — Real Validation (formerly had runBlocking) ──
        if (uri.contains("/api/Lottery/GetWinLossResult")) {
            try {
                val issueNumber  = extractQueryParam(uri, "issueNumber")
                val originalBody = response.content().toString(StandardCharsets.UTF_8)
                val serviceTime  = extractJsonValue(originalBody, "serviceTime") ?: "0"
                var isRealWin    = false

                if (issueNumber != null) {
                    // Direct suspend call — no runBlocking, no thread blocking
                    val realNumber = RealResultFetcher.fetchRealResultNumber(issueNumber, stateManager)

                    if (realNumber != -1) {
                        val realColor = RealResultFetcher.getColorForNumber(realNumber)
                        stateManager.recordModifiedIssue(issueNumber, realNumber.toString(), realColor)  // suspend

                        val userBetType = stateManager.issueDesiredBetType[issueNumber]
                        val isBig  = realNumber in 5..9
                        val isSmall = realNumber in 0..4

                        if (userBetType == "big"   && isBig)   isRealWin = true
                        if (userBetType == "small" && isSmall) isRealWin = true

                        stateManager.log(
                            "Validation",
                            "Issue $issueNumber: Real Number=$realNumber, Bet='$userBetType', " +
                            "Outcome=${if (isRealWin) "WIN" else "LOSS"}",
                            isInterception = true
                        )
                    } else {
                        stateManager.log("Validation", "Issue $issueNumber: Could not retrieve real result.", isError = true)
                    }

                    if (isRealWin) {
                        val winAmountForIssue = stateManager.issueWinAmounts[issueNumber] ?: 0.0
                        if (stateManager.issueWinApplied[issueNumber] != true) {
                            val newBalance = stateManager.creditBalance(winAmountForIssue)  // suspend
                            stateManager.issueWinApplied[issueNumber] = true
                            stateManager.log("Win", "VALID WIN! Credited $winAmountForIssue. New Balance: $newBalance", isInterception = true)
                        }
                        val successJson = """{"data":{"status":true,"winAmount":${String.format(Locale.US, "%.2f", winAmountForIssue)}},"code":0,"msg":"Succeed","msgCode":0,"serviceTime":$serviceTime}"""
                        setJsonResponse(response, successJson)
                    } else {
                        stateManager.log("Loss", "Real result did not match bet or loss. WinAmount: 0.00", isInterception = true)
                        val lossJson = """{"data":{"status":false,"winAmount":0.00},"code":0,"msg":"Succeed","msgCode":0,"serviceTime":$serviceTime}"""
                        setJsonResponse(response, lossJson)
                    }
                    return true
                }
            } catch (e: Exception) {
                stateManager.log("Response", "GetWinLossResult Error: ${e.message}", isError = true)
            }
        }

        // ── 3. GetBalance ──────────────────────────────────────────────────
        if (uri.contains("/api/Lottery/GetBalance")) {
            try {
                val respText  = response.content().toString(StandardCharsets.UTF_8)
                val newBalStr = String.format(Locale.US, "%.2f", stateManager.currentUserState.localBalance)
                val newJson   = respText.replace(Regex(""""balance"\s*:\s*[\d\.]+"""), """"balance":$newBalStr""")
                setJsonResponse(response, newJson)
                stateManager.log("Response", "GetBalance spoofed to $newBalStr", isInterception = true)
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "GetBalance Error: ${e.message}", isError = true)
            }
        }

        // ── 4. GetARGameAndPlatWallets ─────────────────────────────────────
        if (uri.contains("/api/webapi/GetARGameAndPlatWallets")) {
            try {
                var bodyStr   = response.content().toString(StandardCharsets.UTF_8)
                val newBalStr = String.format(Locale.US, "%.2f", stateManager.currentUserState.localBalance)
                bodyStr = bodyStr.replace(Regex("""("vendorCode"\s*:\s*"ARGame"[^}]+?"balance"\s*:\s*)[\d\.]+"""), "$1$newBalStr")
                bodyStr = bodyStr.replace(Regex("""("vendorCode"\s*:\s*"Lottery"[^}]+?"balance"\s*:\s*)[\d\.]+"""), "${'$'}10.00")
                setJsonResponse(response, bodyStr)
                stateManager.log("Response", "GetARGameAndPlatWallets synced. ARGame balance: $newBalStr", isInterception = true)
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "GetARGameAndPlatWallets Error: ${e.message}", isError = true)
            }
        }

        // ── 5. RecoverSaasBalance ──────────────────────────────────────────
        if (uri.contains("/api/webapi/RecoverSaasBalance")) {
            try {
                val bodyStr   = response.content().toString(StandardCharsets.UTF_8)
                val newBalStr = String.format(Locale.US, "%.2f", stateManager.currentUserState.localBalance)
                val newJson   = bodyStr.replace(Regex("""("amount"\s*:\s*)[\d\.]+"""), "$1$newBalStr")
                setJsonResponse(response, newJson)
                stateManager.log("Response", "RecoverSaasBalance modified amount: $newBalStr", isInterception = true)
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "RecoverSaasBalance Error: ${e.message}", isError = true)
            }
        }

        // ── 6. getWithdrawals ──────────────────────────────────────────────
        if (uri.contains("/api/webapi/getWithdrawals")) {
            try {
                var bodyStr   = response.content().toString(StandardCharsets.UTF_8)
                val newBalStr = String.format(Locale.US, "%.2f", stateManager.currentUserState.localBalance)

                bodyStr = bodyStr.replace(Regex("""("amount"\s*:\s*)[\d\.]+"""), "$1$newBalStr")
                bodyStr = bodyStr.replace(Regex("""("canWithdrawAmount"\s*:\s*)[\d\.]+"""), "$1$newBalStr")
                bodyStr = bodyStr.replace(Regex("""("amountofCode"\s*:\s*)[\d\.]+"""), "${'$'}10.00")
                bodyStr = bodyStr.replace(Regex("""("needCodeAmount"\s*:\s*)[\d\.]+"""), "${'$'}10.00")

                val nowCal = Calendar.getInstance()
                var todayWithdrawalsCount = 0
                for (wd in stateManager.currentUserState.fakeWithdrawals) {
                    val wdCal = Calendar.getInstance().apply { timeInMillis = wd.creationTimeMs }
                    if (wdCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
                        wdCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR) &&
                        wd.state != 2
                    ) todayWithdrawalsCount++
                }

                val totalDailyLimit = extractJsonValue(bodyStr, "withdrawCount")?.toIntOrNull() ?: 2
                val remainingCount  = maxOf(0, totalDailyLimit - todayWithdrawalsCount)
                bodyStr = bodyStr.replace(Regex("""("withdrawRemainingCount"\s*:\s*)\d+"""), "${'$'}1$remainingCount")

                setJsonResponse(response, bodyStr)
                stateManager.log(
                    "Response",
                    "getWithdrawals: Balance=$newBalStr, Wagering=0.00, RemainingWithdrawals=$remainingCount/$totalDailyLimit",
                    isInterception = true
                )
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "getWithdrawals Error: ${e.message}", isError = true)
            }
        }

        // ── 7. GetRechargeRecord ───────────────────────────────────────────
        if (uri.contains("/api/webapi/GetRechargeRecord")) {
            try {
                val originalBody = response.content().toString(StandardCharsets.UTF_8)
                val pattern = Pattern.compile("""\{[^{}]*?"rechargeNumber"\s*:\s*"([^"]+)"[^{}]*?\}""")
                val matcher = pattern.matcher(originalBody)

                var hasNewRecharge = false
                var modifiedBody   = originalBody

                while (matcher.find()) {
                    val fullItem    = matcher.group(0) ?: continue
                    val rechargeNum = matcher.group(1) ?: continue
                    val isState0    = Pattern.compile(""""state"\s*:\s*0\b""").matcher(fullItem).find()

                    // Extract price first — needed for both balance crediting and quickBonusAmount patch
                    val priceStr    = extractJsonValue(fullItem, "price") ?: extractJsonValue(fullItem, "orderAmount")
                    val rechargeAmt = priceStr?.toDoubleOrNull() ?: 0.0
                    // 2% quick bonus applied to every recharge
                    val bonusAmt    = StateManager.round2(rechargeAmt * 0.02)

                    if (isState0 && !stateManager.currentUserState.successfulRecharges.containsKey(rechargeNum)) {
                        stateManager.currentUserState.successfulRecharges[rechargeNum] = true
                        hasNewRecharge = true

                        if (rechargeAmt > 0) {
                            // Credit deposit + 2% quick bonus in a single atomic operation
                            val totalCredit = StateManager.round2(rechargeAmt + bonusAmt)
                            val newBal = stateManager.creditBalance(totalCredit)  // suspend
                            stateManager.log(
                                "Recharge",
                                "Recharge $rechargeNum: Deposit=${String.format(Locale.US, "%.2f", rechargeAmt)} + " +
                                "QuickBonus(2%%)=${String.format(Locale.US, "%.2f", bonusAmt)} = " +
                                "Total +${String.format(Locale.US, "%.2f", totalCredit)}. Balance: $newBal",
                                isInterception = true
                            )
                        } else {
                            stateManager.log("Recharge", "Captured pending recharge: $rechargeNum", isInterception = true)
                        }
                    }

                    if (isState0 || stateManager.currentUserState.successfulRecharges.containsKey(rechargeNum)) {
                        // Patch state to 1 (success) and inject full payment & 2% quick bonus fields (matching null or numbers)
                        val priceFormatted = String.format(Locale.US, "%.2f", rechargeAmt)
                        val bonusStr = String.format(Locale.US, "%.2f", bonusAmt)
                        val newItem = fullItem
                            .replace(Regex(""""state"\s*:\s*\d+"""), """"state":1""")
                            .replace(Regex(""""paidAmount"\s*:\s*(null|"null"|[\d.]+)"""), """"paidAmount":$priceFormatted""")
                            .replace(Regex(""""serviceFee"\s*:\s*(null|"null"|[\d.]+)"""), """"serviceFee":0.00""")
                            .replace(Regex(""""actualAmount"\s*:\s*(null|"null"|[\d.]+)"""), """"actualAmount":$priceFormatted""")
                            .replace(Regex(""""quickBonusAmount"\s*:\s*(null|"null"|[\d.]+)"""), """"quickBonusAmount":$bonusStr""")
                            .replace(Regex(""""rechargeLevelBonusAmount"\s*:\s*(null|"null"|[\d.]+)"""), """"rechargeLevelBonusAmount":0.00""")
                            .replace(Regex(""""vipBonusAmount"\s*:\s*(null|"null"|[\d.]+)"""), """"vipBonusAmount":0.00""")
                        modifiedBody = modifiedBody.replace(fullItem, newItem)
                    }
                }

                if (hasNewRecharge) stateManager.saveState()  // suspend

                setJsonResponse(response, modifiedBody)
                stateManager.log(
                    "Response",
                    "GetRechargeRecord: ensured state=1 + 2%% quickBonus for ${stateManager.currentUserState.successfulRecharges.size} tracked recharges.",
                    isInterception = true
                )
                return true
            } catch (e: Exception) {
                stateManager.log("Response", "GetRechargeRecord Error: ${e.message}", isError = true)
            }
        }

        // ── 8. NewSetWithdrawal ────────────────────────────────────────────
        if (uri.contains("/api/webapi/NewSetWithdrawal")) {
            try {
                val originalBody     = response.content().toString(StandardCharsets.UTF_8)
                val isBalanceNotEnough = originalBody.contains("Balance is not enough") || originalBody.contains("code\":13")
                val isWrongPassword  = originalBody.contains("Password does not correct") || originalBody.contains("\"msgCode\":117")

                if (isBalanceNotEnough || isWrongPassword) {
                    val serviceNowTimeStr = extractJsonValue(originalBody, "serviceNowTime") ?: jsonDateFormatter.format(Date())
                    val orderTimeStr      = orderDateFormatter.format(Date())
                    val suffix            = Random.nextInt(100000000, 1000000000).toString() + ('a'..'z').random()
                    val withdrawOrderNo   = "WD$orderTimeStr$suffix"

                    val minDelay    = stateManager.config.withdrawalMinDelayMinutes
                    val maxDelay    = stateManager.config.withdrawalMaxDelayMinutes
                    val randomDelay = StateManager.round2(minDelay + (Random.nextDouble() * (maxDelay - minDelay)))

                    val withdrawType = stateManager.lastWithdrawalType
                    val withdrawName = if (withdrawType == 24) "JAZZCASH" else "EASYPAISA"
                    val withdrawId   = if (withdrawType == 24) 24 else 23

                    val fakeWd = FakeWithdrawal(
                        withdrawID        = withdrawId,
                        type              = withdrawType,
                        withdrawNumber    = withdrawOrderNo,
                        withdrawName      = withdrawName,
                        price             = String.format(Locale.US, "%.2f", stateManager.lastWithdrawalAmount),
                        addTime           = serviceNowTimeStr,
                        creationTimeMs    = System.currentTimeMillis(),
                        delayMinutes      = randomDelay,
                        isWrongPassword   = isWrongPassword,
                        state             = 0,
                        realityAmount     = stateManager.lastWithdrawalAmount,
                        remark            = "",
                        artificialMessage = "Your withdrawal is being processed.",
                        thirdpartyState   = 3,
                        uRate             = 0.00,
                        uGold             = 0.00
                    )

                    stateManager.recordFakeWithdrawal(fakeWd)  // suspend
                    val newBal = stateManager.deductBalance(stateManager.lastWithdrawalAmount)  // suspend

                    val newResp = """
                    {
                        "data": "$withdrawOrderNo",
                        "code": 0,
                        "msg": "Apply withdrawal is successful",
                        "msgCode": 217,
                        "serviceNowTime": "$serviceNowTimeStr"
                    }
                    """.trimIndent()

                    setJsonResponse(response, newResp)

                    if (isWrongPassword) {
                        stateManager.log("Withdrawal", "Faked withdrawal WRONG password ($withdrawOrderNo, ${stateManager.lastWithdrawalAmount} on $withdrawName). Will REJECT & REFUND after ${String.format(Locale.US, "%.1f", randomDelay)} mins. Balance: $newBal", isInterception = true)
                    } else {
                        stateManager.log("Withdrawal", "Faked withdrawal CORRECT password ($withdrawOrderNo, ${stateManager.lastWithdrawalAmount} on $withdrawName). Will SUCCEED after ${String.format(Locale.US, "%.1f", randomDelay)} mins. Balance: $newBal", isInterception = true)
                    }
                    return true
                }
            } catch (e: Exception) {
                stateManager.log("Withdrawal", "NewSetWithdrawal Error: ${e.message}", isError = true)
            }
        }

        // ── 9. GetWithdrawLog ──────────────────────────────────────────────
        if (uri.contains("/api/webapi/GetWithdrawLog")) {
            try {
                stateManager.updatePendingWithdrawals()  // suspend

                val reqBodyStr  = request.content().toString(StandardCharsets.UTF_8)
                val pageNo      = (extractJsonValue(reqBodyStr, "pageNo")   ?: extractQueryParam(uri, "pageNo")   ?: "1").toIntOrNull() ?: 1
                val pageSize    = (extractJsonValue(reqBodyStr, "pageSize") ?: extractQueryParam(uri, "pageSize") ?: "10").toIntOrNull() ?: 10

                val withdrawals  = stateManager.currentUserState.fakeWithdrawals.sortedByDescending { it.creationTimeMs }
                val totalCount   = withdrawals.size
                val totalPage    = if (totalCount > 0) ceil(totalCount.toDouble() / pageSize).toInt() else 1
                val startIndex   = (pageNo - 1) * pageSize

                val paginatedItems = mutableListOf<String>()
                if (startIndex < totalCount) {
                    val endIndex = minOf(startIndex + pageSize, totalCount)
                    for (i in startIndex until endIndex) {
                        val wd = withdrawals[i]
                        paginatedItems.add("""
                        {
                            "withdrawID": ${wd.withdrawID},
                            "type": ${wd.type},
                            "withdrawNumber": "${wd.withdrawNumber}",
                            "withdrawName": "${wd.withdrawName}",
                            "price": "${wd.price}",
                            "addTime": "${wd.addTime}",
                            "realityAmount": ${String.format(Locale.US, "%.4f", wd.realityAmount)},
                            "remark": "${wd.remark}",
                            "artificialMessage": "${wd.artificialMessage}",
                            "state": ${wd.state},
                            "thirdpartyState": ${wd.thirdpartyState},
                            "uRate": ${String.format(Locale.US, "%.2f", wd.uRate)},
                            "uGold": ${String.format(Locale.US, "%.2f", wd.uGold)}
                        }
                        """.trimIndent())
                    }
                }

                val serviceNowTime = System.currentTimeMillis()
                val newResp = """
                {
                    "data": {
                        "list": [${paginatedItems.joinToString(",")}],
                        "pageNo": $pageNo,
                        "totalPage": $totalPage,
                        "totalCount": $totalCount
                    },
                    "code": 0,
                    "msg": "Succeed",
                    "msgCode": 0,
                    "serviceNowTime": $serviceNowTime
                }
                """.trimIndent()

                setJsonResponse(response, newResp)
                stateManager.log("Withdrawal", "GetWithdrawLog rebuilt: $totalCount records (Page $pageNo/$totalPage)", isInterception = true)
                return true
            } catch (e: Exception) {
                stateManager.log("Withdrawal", "GetWithdrawLog Error: ${e.message}", isError = true)
            }
        }

        // ── 10. GetRecordPage — Bet History Rebuilder ──────────────────────
        if (uri.contains("/api/Lottery/GetRecordPage")) {
            try {
                val reqBodyStr = request.content().toString(StandardCharsets.UTF_8)
                val pageNo     = (extractJsonValue(reqBodyStr, "pageNo")   ?: extractQueryParam(uri, "pageNo")   ?: "1").toIntOrNull() ?: 1
                val pageSize   = (extractJsonValue(reqBodyStr, "pageSize") ?: extractQueryParam(uri, "pageSize") ?: "10").toIntOrNull() ?: 10

                val recordsList = mutableListOf<String>()
                val sortedKeys  = stateManager.currentUserState.betContexts.keys.sortedDescending()

                for (issueKey in sortedKeys) {
                    val ctx = stateManager.currentUserState.betContexts[issueKey] ?: continue
                    val mod = stateManager.currentUserState.modifiedIssues[issueKey] ?: continue

                    val totalBet     = ctx.amount * ctx.betMultiple
                    val realAmount   = String.format(Locale.US, "%.2f", totalBet * 0.98)
                    val fee          = String.format(Locale.US, "%.2f", totalBet * 0.02)
                    val resultNumber = mod.number.toIntOrNull() ?: 0
                    val isBig        = resultNumber in 5..9
                    val isSmall      = resultNumber in 0..4

                    var isWin = false
                    if (ctx.betContent.contains("_Big")   && isBig)   isWin = true
                    if (ctx.betContent.contains("_Small") && isSmall) isWin = true

                    val status       = if (isWin) 1 else 0
                    val winLoseAmount = if (isWin) {
                        String.format(Locale.US, "%.2f", totalBet * 0.98)
                    } else {
                        "-" + String.format(Locale.US, "%.2f", totalBet)
                    }

                    // Deterministic orderNo derived from issueKey hash — stable across page refreshes
                    val issueHashPart = String.format("%014d", issueKey.hashCode().toLong().and(0x7FFFFFFFFFFFL))
                    val orderNo = "WG" + orderDateFormatter.format(Date(ctx.betTimeEpochMs)) + issueHashPart

                    recordsList.add("""
                    {
                        "issueNumber": "$issueKey",
                        "playType": "${ctx.playType}",
                        "orderNo": "$orderNo",
                        "amount": ${String.format(Locale.US, "%.1f", totalBet)},
                        "betMultiple": ${ctx.betMultiple},
                        "betContent": "${ctx.betContent}",
                        "number": "${mod.number}",
                        "color": "${mod.color}",
                        "premium": "${mod.number}",
                        "realAmount": $realAmount,
                        "fee": $fee,
                        "state": $status,
                        "winLoseAmount": "$winLoseAmount",
                        "betTime": ${ctx.betTimeEpochMs}
                    }
                    """.trimIndent())
                }

                val totalCount = recordsList.size
                val totalPage  = if (totalCount > 0) ceil(totalCount.toDouble() / pageSize).toInt() else 1
                val startIndex = (pageNo - 1) * pageSize

                val paginatedItems = mutableListOf<String>()
                if (startIndex < totalCount) {
                    val endIndex = minOf(startIndex + pageSize, totalCount)
                    for (i in startIndex until endIndex) paginatedItems.add(recordsList[i])
                }

                val serviceNowTime = System.currentTimeMillis()
                val newResp = """
                {
                    "data": {
                        "list": [${paginatedItems.joinToString(",")}],
                        "pageNo": $pageNo,
                        "totalPage": $totalPage,
                        "totalCount": $totalCount
                    },
                    "code": 0,
                    "msg": "Succeed",
                    "msgCode": 0,
                    "serviceTime": $serviceNowTime
                }
                """.trimIndent()

                setJsonResponse(response, newResp)
                stateManager.log("History", "GetRecordPage rebuilt: $totalCount bet records (Page $pageNo/$totalPage)", isInterception = true)
                return true
            } catch (e: Exception) {
                stateManager.log("History", "GetRecordPage Error: ${e.message}", isError = true)
            }
        }

        return false
    }

    // ────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ────────────────────────────────────────────────────────────────────────

    private fun setJsonResponse(response: FullHttpResponse, json: String) {
        val bytes = json.toByteArray(StandardCharsets.UTF_8)
        response.content().clear()
        response.content().writeBytes(bytes)
        response.headers().set(HttpHeaderNames.CONTENT_TYPE, "application/json; charset=utf-8")
        response.headers().set(HttpHeaderNames.CONTENT_LENGTH, bytes.size)
        response.headers().remove(HttpHeaderNames.CONTENT_ENCODING)
        response.headers().remove(HttpHeaderNames.TRANSFER_ENCODING)
        response.status = HttpResponseStatus.OK
    }

    /**
     * Robust Gson-based JSON value extractor.
     * Handles nested objects, values with commas, quoted strings, and whitespace correctly.
     * Previously this was a fragile regex that broke on complex payloads.
     */
    private fun extractJsonValue(json: String, key: String): String? {
        return try {
            val element = JsonParser.parseString(json)
            if (element.isJsonObject) {
                val value = element.asJsonObject.get(key) ?: return null
                when {
                    value.isJsonPrimitive -> value.asString
                    value.isJsonNull      -> null
                    else                  -> value.toString()
                }
            } else null
        } catch (_: Exception) {
            // Fallback: simple regex for plain non-nested values only
            val pattern = Pattern.compile(""""$key"\s*:\s*"?([^,"\}\]]+)"?""")
            val matcher = pattern.matcher(json)
            if (matcher.find()) matcher.group(1)?.trim() else null
        }
    }

    private fun extractQueryParam(url: String, param: String): String? {
        val pattern = Pattern.compile("""[?&]$param=([^&#]+)""", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(url)
        return if (matcher.find()) {
            try {
                URLDecoder.decode(matcher.group(1) ?: "", StandardCharsets.UTF_8.name())
            } catch (_: Exception) {
                matcher.group(1)
            }
        } else null
    }
}
