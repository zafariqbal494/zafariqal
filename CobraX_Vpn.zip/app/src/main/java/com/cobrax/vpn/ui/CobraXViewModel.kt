package com.cobrax.vpn.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cobrax.vpn.model.AppConfig
import com.cobrax.vpn.service.CobraXVpnService
import com.cobrax.vpn.state.StateManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Shared ViewModel for DashboardFragment and ConfigFragment.
 *
 * Centralizing state here means:
 * - Fragments never hold direct StateManager references (no duplicate Flow collectors on rotation).
 * - All suspend StateManager calls are launched inside viewModelScope — lifecycle-safe.
 * - Both fragments share one instance via activityViewModels<CobraXViewModel>().
 */
class CobraXViewModel(app: Application) : AndroidViewModel(app) {

    private val stateManager = StateManager.getInstance(app)

    // ── Flows exposed to the UI ──────────────────────────────────────────────

    /** Real-time proxy interception log stream */
    val logsFlow: SharedFlow<com.cobrax.vpn.model.ProxyLogItem> = stateManager.logsFlow

    /** Live VPN running state — drives button label and status indicator */
    val vpnRunning: StateFlow<Boolean> = CobraXVpnService.isVpnRunning

    // Mutable UI state updated whenever user or balance changes
    private val _currentUser    = MutableStateFlow(stateManager.currentUserState.userName)
    private val _currentBalance = MutableStateFlow(stateManager.currentUserState.localBalance)

    val currentUser:    StateFlow<String> = _currentUser.asStateFlow()
    val currentBalance: StateFlow<Double> = _currentBalance.asStateFlow()

    // ── Config Accessors ─────────────────────────────────────────────────────

    val config: AppConfig get() = stateManager.config

    // ── State Refresh ────────────────────────────────────────────────────────

    /**
     * Re-reads user/balance from StateManager and pushes updated values to UI.
     * Called after any operation that modifies the user state (log event, bet, etc.)
     */
    fun refreshUserState() {
        _currentUser.value    = stateManager.currentUserState.userName
        _currentBalance.value = stateManager.currentUserState.localBalance
    }

    // ── Config / Balance Mutations ────────────────────────────────────────────

    fun setBalance(amount: Double) {
        viewModelScope.launch {
            stateManager.setBalance(amount)
            refreshUserState()
        }
    }

    fun saveConfig(
        enableModifications: Boolean,
        minDelay: Double?,
        maxDelay: Double?
    ) {
        viewModelScope.launch {
            stateManager.updateConfig { cfg ->
                cfg.enableModifications = enableModifications
                if (minDelay != null && minDelay > 0) {
                    cfg.withdrawalMinDelayMinutes = minDelay
                }
                if (maxDelay != null && maxDelay >= (minDelay ?: cfg.withdrawalMinDelayMinutes)) {
                    cfg.withdrawalMaxDelayMinutes = maxDelay
                }
            }
        }
    }
}
