# Netty proguard rules
-dontwarn io.netty.**
-keep class io.netty.** { *; }

# Bouncy Castle
-dontwarn org.bouncycastle.**
-keep class org.bouncycastle.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class com.cobrax.vpn.model.** { *; }
