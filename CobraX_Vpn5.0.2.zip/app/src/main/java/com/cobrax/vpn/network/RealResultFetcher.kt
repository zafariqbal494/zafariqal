package com.cobrax.vpn.network

import com.cobrax.vpn.state.StateManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object RealResultFetcher {

    // Issue 8 fix: reduced from 5s to 3s per timeout — worst-case sequential fetch drops
    // from 10s to 6s. Larger connection pool (10 connections, 3-minute keepalive) improves
    // reuse across rapid back-to-back draws.
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectionPool(ConnectionPool(10, 3, TimeUnit.MINUTES))
        .build()

    suspend fun fetchRealResultNumber(issueNumber: String, stateManager: StateManager? = null): Int = withContext(Dispatchers.IO) {
        val tick = System.currentTimeMillis().toString()
        val regex = Pattern.compile("\"issueNumber\"\\s*:\\s*\"$issueNumber\"[^{}]*?\"number\"\\s*:\\s*\"?(\\d+)\"?")

        // 1. Try 30S endpoint
        val url30S = "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=10&r=$tick"
        try {
            val request30S = Request.Builder()
                .url(url30S)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(request30S).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val matcher = regex.matcher(body)
                    if (matcher.find()) {
                        val numStr = matcher.group(1)
                        val num = numStr?.toIntOrNull() ?: -1
                        stateManager?.log("Validation", "Found real result for issue $issueNumber in 30S endpoint: $num")
                        return@withContext num
                    }
                }
            }
        } catch (e: Exception) {
            stateManager?.log("Validation", "Error querying 30S result: ${e.message}", isError = true)
        }

        // 2. Try 1M endpoint as fallback
        val url1M = "https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json?pageNo=1&pageSize=10&r=$tick"
        try {
            val request1M = Request.Builder()
                .url(url1M)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(request1M).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val matcher = regex.matcher(body)
                    if (matcher.find()) {
                        val numStr = matcher.group(1)
                        val num = numStr?.toIntOrNull() ?: -1
                        stateManager?.log("Validation", "Found real result for issue $issueNumber in 1M endpoint: $num")
                        return@withContext num
                    }
                }
            }
        } catch (e: Exception) {
            stateManager?.log("Validation", "Error querying 1M result: ${e.message}", isError = true)
        }

        stateManager?.log("Validation", "Could not find result for issue $issueNumber in either endpoint.")
        return@withContext -1
    }

    fun getColorForNumber(num: Int): String {
        return when (num) {
            0 -> "red,violet"
            1, 3, 7, 9 -> "green"
            2, 4, 6, 8 -> "red"
            5 -> "green,violet"
            else -> ""
        }
    }
}
