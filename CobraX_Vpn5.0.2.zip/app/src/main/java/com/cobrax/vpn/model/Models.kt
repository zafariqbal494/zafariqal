package com.cobrax.vpn.model

import com.google.gson.annotations.SerializedName

data class AppConfig(
    @SerializedName("enableModifications")
    var enableModifications: Boolean = true,

    @SerializedName("withdrawalMinDelayMinutes")
    var withdrawalMinDelayMinutes: Double = 2.0,

    @SerializedName("withdrawalMaxDelayMinutes")
    var withdrawalMaxDelayMinutes: Double = 7.0,

    @SerializedName("defaultBalance")
    var defaultBalance: Double = 5560.00,

    @SerializedName("allowedPackageNames")
    var allowedPackageNames: List<String> = listOf(
        "com.cobrax.team",
        "com.team.cobrax",
        "com.cobrax.app",
        "com.example.gameapp",
        "com.android.chrome"
    )
)

data class UserState(
    @SerializedName("userName")
    var userName: String = "default_user",

    @SerializedName("localBalance")
    var localBalance: Double = 5560.00,

    @SerializedName("modifiedIssues")
    var modifiedIssues: HashMap<String, ModifiedIssue> = HashMap(),

    @SerializedName("betContexts")
    var betContexts: HashMap<String, BetContext> = HashMap(),

    @SerializedName("fakeWithdrawals")
    var fakeWithdrawals: ArrayList<FakeWithdrawal> = ArrayList(),

    @SerializedName("successfulRecharges")
    var successfulRecharges: HashMap<String, Boolean> = HashMap(),

    @SerializedName("lastUpdated")
    var lastUpdated: Long = System.currentTimeMillis()
)

data class ModifiedIssue(
    @SerializedName("number")
    var number: String,

    @SerializedName("color")
    var color: String
)

data class BetContext(
    @SerializedName("issueNumber")
    var issueNumber: String,

    @SerializedName("playType")
    var playType: String = "BigSmall",

    @SerializedName("amount")
    var amount: Double,

    @SerializedName("betMultiple")
    var betMultiple: Double,

    @SerializedName("betContent")
    var betContent: String,

    @SerializedName("betTimeIso")
    var betTimeIso: String,

    @SerializedName("betTimeEpochMs")
    var betTimeEpochMs: Long
)

data class FakeWithdrawal(
    @SerializedName("withdrawID")
    var withdrawID: Int,

    @SerializedName("type")
    var type: Int = 23,

    @SerializedName("withdrawNumber")
    var withdrawNumber: String,

    @SerializedName("withdrawName")
    var withdrawName: String = "EASYPAISA",

    @SerializedName("price")
    var price: String,

    @SerializedName("addTime")
    var addTime: String,

    @SerializedName("creationTimeMs")
    var creationTimeMs: Long,

    @SerializedName("delayMinutes")
    var delayMinutes: Double = 5.0,

    @SerializedName("isWrongPassword")
    var isWrongPassword: Boolean = false,

    @SerializedName("state")
    var state: Int = 0, // 0 = Pending, 1 = Success, 2 = Rejected

    @SerializedName("realityAmount")
    var realityAmount: Double,

    @SerializedName("remark")
    var remark: String = "",

    @SerializedName("artificialMessage")
    var artificialMessage: String = "Your withdrawal is being processed.",

    @SerializedName("thirdpartyState")
    var thirdpartyState: Int = 3,

    @SerializedName("uRate")
    var uRate: Double = 0.00,

    @SerializedName("uGold")
    var uGold: Double = 0.00
)

data class ProxyLogItem(
    val id: Long = System.nanoTime(),           // Unique per item — used by DiffUtil identity check
    val timestamp: Long = System.currentTimeMillis(),
    val tag: String,
    val message: String,
    val isInterception: Boolean = false,
    val isError: Boolean = false
)
