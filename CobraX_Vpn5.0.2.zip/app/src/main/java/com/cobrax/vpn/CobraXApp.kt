package com.cobrax.vpn

import android.app.Application
import android.util.Log
import com.cobrax.vpn.cert.CertificateAuthority
import com.cobrax.vpn.state.StateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CobraXApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Optimize Netty for Android — avoids sun.misc.Unsafe / /proc/sys reflection warnings
        System.setProperty("io.netty.noUnsafe",         "true")
        System.setProperty("io.netty.noPreferDirect",   "true")
        System.setProperty("io.netty.allocator.type",   "unpooled")

        // Initialize StateManager & BouncyCastle RSA Root CA in background.
        // SupervisorJob so any uncaught exception is logged rather than silently swallowed.
        // Previously: CoroutineScope(Dispatchers.IO).launch { } — exceptions were lost.
        CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            try {
                StateManager.getInstance(this@CobraXApp)
                CertificateAuthority.getInstance(this@CobraXApp)
                Log.i("CobraXApp", "StateManager & CertificateAuthority initialized successfully.")
            } catch (e: Exception) {
                Log.e("CobraXApp", "Critical initialization failure: ${e.message}", e)
                // StateManager.log is not available yet if StateManager itself failed —
                // Android Logcat is the correct fallback here.
            }
        }
    }
}
