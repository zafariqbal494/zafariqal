package com.cobrax.vpn.service

import android.net.VpnService
import com.cobrax.vpn.state.StateManager
import kotlinx.coroutines.*
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class TunToProxyBridge(
    private val vpnService: VpnService,
    private val tunFd: FileDescriptor,
    val proxyPort: Int = 8877
) {

    private val stateManager = StateManager.getInstance(vpnService)
    private val isRunning = AtomicBoolean(false)
    private var readJob: Job? = null
    private var dnsJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var dnsSocket: DatagramSocket? = null
    private var tunOutputStream: FileOutputStream? = null
    private val ipIdCounter = AtomicInteger(1000)

    private data class DnsContext(
        val clientIp: ByteArray,
        val clientPort: Int,
        val dnsServerIp: ByteArray,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val pendingDns = ConcurrentHashMap<Int, DnsContext>()

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        try {
            val sock = DatagramSocket()
            vpnService.protect(sock)
            dnsSocket = sock
            tunOutputStream = FileOutputStream(tunFd)

            dnsJob = scope.launch {
                runDnsReceiverLoop(sock)
            }

            readJob = scope.launch {
                runTunReaderLoop()
            }

            stateManager.log("VPN", "TUN-to-Proxy bridge & DNS Forwarder active.")
        } catch (e: Exception) {
            stateManager.log("VPN", "Failed to start TUN bridge: ${e.message}", isError = true)
        }
    }

    fun stop() {
        if (!isRunning.get()) return
        isRunning.set(false)

        readJob?.cancel()
        dnsJob?.cancel()

        try {
            dnsSocket?.close()
        } catch (_: Exception) {}
        dnsSocket = null

        try {
            tunOutputStream?.close()
        } catch (_: Exception) {}
        tunOutputStream = null

        pendingDns.clear()
        stateManager.log("VPN", "TUN-to-Proxy bridge stopped.")
    }

    private suspend fun runTunReaderLoop() = withContext(Dispatchers.IO) {
        val inputStream = FileInputStream(tunFd)
        val packetBuffer = ByteArray(32768)

        while (isRunning.get() && isActive) {
            try {
                val length = inputStream.read(packetBuffer)
                if (length <= 0) continue

                // Check for IPv4 packet
                val version = (packetBuffer[0].toInt() shr 4) and 0x0F
                if (version == 4 && length >= 20) {
                    val ihl = (packetBuffer[0].toInt() and 0x0F) * 4
                    val protocol = packetBuffer[9].toInt() and 0xFF

                    // UDP Packet Handling
                    if (protocol == 17 && length >= ihl + 8) {
                        val dstPort = ((packetBuffer[ihl + 2].toInt() and 0xFF) shl 8) or (packetBuffer[ihl + 3].toInt() and 0xFF)
                        if (dstPort == 53) {
                            handleOutgoingDnsPacket(packetBuffer, ihl, length)
                        } else if (dstPort == 443 || dstPort == 8443) {
                            // Instant QUIC reject -> forces Chromium / Android WebView to immediately fallback to TCP (eliminates 10s hang)
                            handleQuicReject(packetBuffer, ihl, length)
                        }
                    }
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    stateManager.log("VPN", "TUN read note: ${e.message}")
                }
            }
        }
    }

    private fun handleOutgoingDnsPacket(packet: ByteArray, ihl: Int, length: Int) {
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val srcIp = packet.copyOfRange(12, 16)
        val dstIp = packet.copyOfRange(16, 20)

        val udpPayloadOffset = ihl + 8
        val udpPayloadLen = length - udpPayloadOffset
        if (udpPayloadLen < 2) return

        // DNS Transaction ID (first 2 bytes of payload)
        val txId = ((packet[udpPayloadOffset].toInt() and 0xFF) shl 8) or (packet[udpPayloadOffset + 1].toInt() and 0xFF)

        // Store context to route response back
        pendingDns[txId] = DnsContext(
            clientIp = srcIp,
            clientPort = srcPort,
            dnsServerIp = dstIp
        )

        // Clean up old stale DNS queries if list grows
        if (pendingDns.size > 200) {
            val now = System.currentTimeMillis()
            pendingDns.entries.removeIf { now - it.value.timestamp > 5000 }
        }

        val dnsPayload = packet.copyOfRange(udpPayloadOffset, length)
        try {
            val targetDns = InetAddress.getByAddress(dstIp)
            val dgram = DatagramPacket(dnsPayload, dnsPayload.size, targetDns, 53)
            dnsSocket?.send(dgram)
        } catch (e: Exception) {
            stateManager.log("DNS", "Error forwarding DNS query: ${e.message}", isError = true)
        }
    }

    private suspend fun runDnsReceiverLoop(sock: DatagramSocket) = withContext(Dispatchers.IO) {
        val recvBuffer = ByteArray(4096)
        val recvPacket = DatagramPacket(recvBuffer, recvBuffer.size)

        while (isRunning.get() && isActive) {
            try {
                sock.receive(recvPacket)
                val replyLen = recvPacket.length
                if (replyLen < 2) continue

                val txId = ((recvBuffer[0].toInt() and 0xFF) shl 8) or (recvBuffer[1].toInt() and 0xFF)
                val ctx = pendingDns.remove(txId) ?: continue

                // Construct full IPv4 + UDP reply packet
                val ipPacket = buildIpv4UdpPacket(
                    srcIp = ctx.dnsServerIp,
                    dstIp = ctx.clientIp,
                    srcPort = 53,
                    dstPort = ctx.clientPort,
                    payload = recvBuffer.copyOf(replyLen)
                )

                synchronized(this@TunToProxyBridge) {
                    tunOutputStream?.write(ipPacket)
                    tunOutputStream?.flush()
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    stateManager.log("DNS", "DNS receive loop note: ${e.message}")
                }
            }
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val ipHeaderLen = 20
        val udpHeaderLen = 8
        val totalLength = ipHeaderLen + udpHeaderLen + payload.size
        val packet = ByteArray(totalLength)

        // ── 1. IPv4 Header ────────────────────────────
        packet[0] = 0x45.toByte() // Version 4, IHL 5 (20 bytes)
        packet[1] = 0x00.toByte() // DSCP/ECN
        packet[2] = ((totalLength shr 8) and 0xFF).toByte()
        packet[3] = (totalLength and 0xFF).toByte()

        val ipId = ipIdCounter.getAndIncrement() and 0xFFFF
        packet[4] = ((ipId shr 8) and 0xFF).toByte()
        packet[5] = (ipId and 0xFF).toByte()
        packet[6] = 0x40.toByte() // Flags: Don't Fragment
        packet[7] = 0x00.toByte()

        packet[8] = 64.toByte()   // TTL
        packet[9] = 17.toByte()   // Protocol: UDP

        packet[10] = 0x00.toByte() // Checksum placeholder
        packet[11] = 0x00.toByte()

        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        val ipChecksum = calculateChecksum(packet, 0, ipHeaderLen)
        packet[10] = ((ipChecksum shr 8) and 0xFF).toByte()
        packet[11] = (ipChecksum and 0xFF).toByte()

        // ── 2. UDP Header ─────────────────────────────
        val udpLen = udpHeaderLen + payload.size
        packet[20] = ((srcPort shr 8) and 0xFF).toByte()
        packet[21] = (srcPort and 0xFF).toByte()
        packet[22] = ((dstPort shr 8) and 0xFF).toByte()
        packet[23] = (dstPort and 0xFF).toByte()
        packet[24] = ((udpLen shr 8) and 0xFF).toByte()
        packet[25] = (udpLen and 0xFF).toByte()
        packet[26] = 0x00.toByte() // UDP Checksum optional in IPv4
        packet[27] = 0x00.toByte()

        // ── 3. Payload ────────────────────────────────
        System.arraycopy(payload, 0, packet, 28, payload.size)

        return packet
    }

    private fun handleQuicReject(packet: ByteArray, ihl: Int, length: Int) {
        val srcIp = packet.copyOfRange(12, 16)
        val dstIp = packet.copyOfRange(16, 20)

        // Generate ICMP Destination/Port Unreachable packet
        val icmpPacket = buildIcmpPortUnreachablePacket(
            srcIp = dstIp, // ICMP sender is destination host
            dstIp = srcIp, // ICMP receiver is client
            originalIpHeaderAnd8Bytes = packet.copyOfRange(0, minOf(ihl + 8, length))
        )

        try {
            synchronized(this) {
                tunOutputStream?.write(icmpPacket)
                tunOutputStream?.flush()
            }
        } catch (_: Exception) {}
    }

    private fun buildIcmpPortUnreachablePacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        originalIpHeaderAnd8Bytes: ByteArray
    ): ByteArray {
        val ipHeaderLen = 20
        val icmpHeaderLen = 8
        val totalLength = ipHeaderLen + icmpHeaderLen + originalIpHeaderAnd8Bytes.size
        val packet = ByteArray(totalLength)

        // ── 1. IPv4 Header ────────────────────────────
        packet[0] = 0x45.toByte() // Version 4, IHL 5
        packet[1] = 0x00.toByte()
        packet[2] = ((totalLength shr 8) and 0xFF).toByte()
        packet[3] = (totalLength and 0xFF).toByte()

        val ipId = ipIdCounter.getAndIncrement() and 0xFFFF
        packet[4] = ((ipId shr 8) and 0xFF).toByte()
        packet[5] = (ipId and 0xFF).toByte()
        packet[6] = 0x00.toByte()
        packet[7] = 0x00.toByte()

        packet[8] = 64.toByte()   // TTL
        packet[9] = 1.toByte()    // Protocol: ICMP (1)

        packet[10] = 0x00.toByte() // Checksum placeholder
        packet[11] = 0x00.toByte()

        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        val ipChecksum = calculateChecksum(packet, 0, ipHeaderLen)
        packet[10] = ((ipChecksum shr 8) and 0xFF).toByte()
        packet[11] = (ipChecksum and 0xFF).toByte()

        // ── 2. ICMP Header ────────────────────────────
        packet[20] = 3.toByte()    // Type: Destination Unreachable
        packet[21] = 3.toByte()    // Code: Port Unreachable
        packet[22] = 0x00.toByte() // Checksum placeholder
        packet[23] = 0x00.toByte()
        packet[24] = 0x00.toByte() // Unused (4 bytes)
        packet[25] = 0x00.toByte()
        packet[26] = 0x00.toByte()
        packet[27] = 0x00.toByte()

        // ── 3. ICMP Payload (Original IP Header + first 8 bytes of UDP) ─
        System.arraycopy(originalIpHeaderAnd8Bytes, 0, packet, 28, originalIpHeaderAnd8Bytes.size)

        val icmpChecksum = calculateChecksum(packet, 20, icmpHeaderLen + originalIpHeaderAnd8Bytes.size)
        packet[22] = ((icmpChecksum shr 8) and 0xFF).toByte()
        packet[23] = (icmpChecksum and 0xFF).toByte()

        return packet
    }

    private fun calculateChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0
        var i = offset
        while (i < offset + length) {
            val b1 = data[i].toInt() and 0xFF
            val b2 = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (b1 shl 8) or b2
            i += 2
        }
        while (sum shr 16 > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv()) and 0xFFFF
    }
}
