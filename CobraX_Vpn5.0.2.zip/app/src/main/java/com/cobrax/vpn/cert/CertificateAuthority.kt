package com.cobrax.vpn.cert

import android.content.Context
import com.cobrax.vpn.state.StateManager
import io.netty.handler.ssl.SslContext
import io.netty.handler.ssl.SslContextBuilder
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.*
import org.bouncycastle.cert.X509v3CertificateBuilder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.*
import java.security.cert.X509Certificate
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class CertificateAuthority private constructor(private val context: Context) {

    private val certsDir: File = File(context.filesDir, "certs").apply { mkdirs() }
    val caCertFile: File = File(certsDir, "CobraX_CA.crt")
    private val caKeyFile: File = File(certsDir, "CobraX_CA.key")

    private lateinit var caKeyPair: KeyPair
    lateinit var caCertificate: X509Certificate
        private set

    // Reusable pre-generated KeyPair for all intercepted domain certificates (eliminates CPU freeze)
    private lateinit var domainSharedKeyPair: KeyPair

    private val domainSslContextCache = ConcurrentHashMap<String, SslContext>()
    private val keyPairGenerator: KeyPairGenerator

    init {
        Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME)
        Security.addProvider(BouncyCastleProvider())

        keyPairGenerator = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME).apply {
            initialize(2048, SecureRandom())
        }

        loadOrCreateRootCa()

        // Pre-generate domain keypair once at startup (takes 0ms during runtime interception)
        domainSharedKeyPair = keyPairGenerator.generateKeyPair()
    }

    companion object {
        @Volatile
        private var instance: CertificateAuthority? = null

        fun getInstance(context: Context): CertificateAuthority {
            return instance ?: synchronized(this) {
                instance ?: CertificateAuthority(context.applicationContext).also { instance = it }
            }
        }
    }

    private fun loadOrCreateRootCa() {
        if (caCertFile.exists() && caKeyFile.exists()) {
            try {
                val certBytes = caCertFile.readBytes()
                val certFactory = java.security.cert.CertificateFactory.getInstance("X.509", BouncyCastleProvider.PROVIDER_NAME)
                certBytes.inputStream().use { stream ->
                    caCertificate = certFactory.generateCertificate(stream) as X509Certificate
                }

                val keyBytes = caKeyFile.readBytes()
                val keySpec = java.security.spec.PKCS8EncodedKeySpec(keyBytes)
                val keyFactory = KeyFactory.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME)
                val privateKey = keyFactory.generatePrivate(keySpec)
                caKeyPair = KeyPair(caCertificate.publicKey, privateKey)
                StateManager.getInstance(context).log("CA", "Root CA loaded from storage.")
                return
            } catch (e: Exception) {
                StateManager.getInstance(context).log("CA", "Failed to load existing CA: ${e.message}. Recreating...", isError = true)
            }
        }

        generateNewRootCa()
    }

    private fun generateNewRootCa() {
        caKeyPair = keyPairGenerator.generateKeyPair()

        val issuer = X500Name("CN=CobraX Root CA, O=CobraX, OU=Security, C=US")
        val serial = BigInteger(64, SecureRandom())
        val notBefore = Date(System.currentTimeMillis() - 24L * 60 * 60 * 1000)
        val notAfter = Date(System.currentTimeMillis() + 10L * 365 * 24 * 60 * 60 * 1000) // 10 years

        val certBuilder: X509v3CertificateBuilder = JcaX509v3CertificateBuilder(
            issuer,
            serial,
            notBefore,
            notAfter,
            issuer,
            caKeyPair.public
        )

        val extUtils = JcaX509ExtensionUtils()
        certBuilder.addExtension(Extension.basicConstraints, true, BasicConstraints(true))
        certBuilder.addExtension(Extension.keyUsage, true, KeyUsage(KeyUsage.keyCertSign or KeyUsage.cRLSign))
        certBuilder.addExtension(Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(caKeyPair.public))

        val signer = JcaContentSignerBuilder("SHA256withRSA")
            .setProvider(BouncyCastleProvider.PROVIDER_NAME)
            .build(caKeyPair.private)

        caCertificate = JcaX509CertificateConverter()
            .setProvider(BouncyCastleProvider.PROVIDER_NAME)
            .getCertificate(certBuilder.build(signer))

        // Save certificate PEM/DER
        FileOutputStream(caCertFile).use { it.write(caCertificate.encoded) }
        FileOutputStream(caKeyFile).use { it.write(caKeyPair.private.encoded) }

        StateManager.getInstance(context).log("CA", "New Root CA generated and saved to ${caCertFile.absolutePath}")
    }

    fun getOrCreateSslContext(domain: String): SslContext {
        val cleanDomain = domain.split(":")[0].trim()
        return domainSslContextCache.getOrPut(cleanDomain) {
            createDomainSslContext(cleanDomain)
        }
    }

    private fun createDomainSslContext(domain: String): SslContext {
        val issuer = org.bouncycastle.asn1.x500.X500Name.getInstance(
            org.bouncycastle.asn1.ASN1Sequence.getInstance(caCertificate.subjectX500Principal.encoded)
        )
        val subject = X500Name("CN=$domain, O=CobraX Dynamic SSL, OU=Proxy, C=US")
        val serial = BigInteger(64, SecureRandom())
        val notBefore = Date(System.currentTimeMillis() - 24L * 60 * 60 * 1000)
        val notAfter = Date(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000) // 1 year

        val certBuilder: X509v3CertificateBuilder = JcaX509v3CertificateBuilder(
            issuer,
            serial,
            notBefore,
            notAfter,
            subject,
            domainSharedKeyPair.public
        )

        val extUtils = JcaX509ExtensionUtils()
        certBuilder.addExtension(Extension.basicConstraints, false, BasicConstraints(false))
        certBuilder.addExtension(Extension.keyUsage, true, KeyUsage(KeyUsage.digitalSignature or KeyUsage.keyEncipherment))
        certBuilder.addExtension(Extension.subjectKeyIdentifier, false, extUtils.createSubjectKeyIdentifier(domainSharedKeyPair.public))
        certBuilder.addExtension(Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(caCertificate))

        // Subject Alternative Name (SAN)
        val generalNameList = mutableListOf<GeneralName>()
        if (domain.matches(Regex("""^\d+\.\d+\.\d+\.\d+$"""))) {
            generalNameList.add(GeneralName(GeneralName.iPAddress, domain))
        } else {
            generalNameList.add(GeneralName(GeneralName.dNSName, domain))
            if (!domain.startsWith("*.")) {
                generalNameList.add(GeneralName(GeneralName.dNSName, "*.$domain"))
            }
        }
        certBuilder.addExtension(Extension.subjectAlternativeName, false, GeneralNames(generalNameList.toTypedArray()))

        val signer = JcaContentSignerBuilder("SHA256withRSA")
            .setProvider(BouncyCastleProvider.PROVIDER_NAME)
            .build(caKeyPair.private)

        val domainCert = JcaX509CertificateConverter()
            .setProvider(BouncyCastleProvider.PROVIDER_NAME)
            .getCertificate(certBuilder.build(signer))

        return SslContextBuilder.forServer(domainSharedKeyPair.private, domainCert, caCertificate).build()
    }
}
