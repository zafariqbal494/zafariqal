package com.cobrax.vpn.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.cobrax.vpn.R
import com.cobrax.vpn.databinding.FragmentDashboardBinding
import com.cobrax.vpn.service.CobraXVpnService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Dashboard screen: VPN toggle, user/balance display, live log stream.
 *
 * Uses activityViewModels<CobraXViewModel>() — this means the ViewModel is
 * scoped to the Activity, so rotating the screen or switching fragments never
 * creates a new ViewModel instance. This eliminates the duplicate Flow collector
 * problem that existed when StateManager was accessed directly in onViewCreated().
 */
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    // Shared ViewModel — scoped to the Activity, not this Fragment
    private val viewModel: CobraXViewModel by activityViewModels()
    private lateinit var logAdapter: LogAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupListeners()
        observeVpnState()
        observeLogs()
        observeUserState()
    }

    private fun setupRecyclerView() {
        logAdapter = LogAdapter()
        logAdapter.onItemClickListener = { item ->
            copyToClipboard("CobraX Log Entry", "[${item.tag}] ${item.message}")
            android.widget.Toast.makeText(requireContext(), "Log copied to clipboard", android.widget.Toast.LENGTH_SHORT).show()
        }
        binding.rvLogs.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = logAdapter
        }
    }

    private fun setupListeners() {
        binding.btnToggleVpn.setOnClickListener {
            val mainActivity = activity as? MainActivity
            if (CobraXVpnService.isVpnRunning.value) {
                CobraXVpnService.stopVpn(requireContext())
            } else {
                mainActivity?.requestStartVpn()
            }
        }

        binding.tvCopyLogs.setOnClickListener {
            val logsText = logAdapter.getAllLogsFormatted()
            if (logsText.trim().isEmpty()) {
                android.widget.Toast.makeText(requireContext(), "No logs to copy", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                copyToClipboard("CobraX Interception Logs", logsText)
                android.widget.Toast.makeText(requireContext(), getString(R.string.logs_copied), android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        binding.tvClearLogs.setOnClickListener {
            logAdapter.clear()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE)
            as? android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText(label, text)
        clipboard?.setPrimaryClip(clip)
    }

    private fun observeVpnState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.vpnRunning.collectLatest { isRunning ->
                if (isRunning) {
                    binding.tvVpnStatus.text = getString(R.string.status_connected)
                    binding.tvVpnStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.connected_green))
                    binding.btnToggleVpn.text = getString(R.string.disconnect)
                    binding.btnToggleVpn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(requireContext(), R.color.disconnected_red)
                    )
                } else {
                    binding.tvVpnStatus.text = getString(R.string.status_disconnected)
                    binding.tvVpnStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.disconnected_red))
                    binding.btnToggleVpn.text = getString(R.string.connect)
                    binding.btnToggleVpn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(requireContext(), R.color.primary)
                    )
                }
            }
        }
    }

    /**
     * Collects the log stream from the ViewModel.
     * viewLifecycleOwner ensures collection is automatically cancelled when the
     * Fragment view is destroyed — preventing leaks and duplicate collectors.
     */
    private fun observeLogs() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.logsFlow.collect { logItem ->
                logAdapter.addLog(logItem)
                // Refresh user/balance display whenever a new log arrives
                viewModel.refreshUserState()
            }
        }
    }

    /**
     * Observes user name and balance StateFlows from the ViewModel.
     * These update atomically whenever StateManager mutates the user state.
     */
    private fun observeUserState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.currentUser.collect { userName ->
                if (_binding != null) {
                    binding.tvCurrentUserName.text = userName
                }
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.currentBalance.collect { balance ->
                if (_binding != null) {
                    binding.tvSimulatedBalance.text = String.format(Locale.US, "%,.2f PKR", balance)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Sync display in case balance changed while fragment was paused
        viewModel.refreshUserState()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
