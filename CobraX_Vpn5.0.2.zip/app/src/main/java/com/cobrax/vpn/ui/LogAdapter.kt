package com.cobrax.vpn.ui

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cobrax.vpn.R
import com.cobrax.vpn.databinding.ItemLogBinding
import com.cobrax.vpn.model.ProxyLogItem
import java.text.SimpleDateFormat
import java.util.*

/**
 * RecyclerView adapter for the live interception log.
 *
 * Key improvements over original:
 * 1. DiffCallback uses `item.id` (System.nanoTime) for identity — two log entries
 *    arriving within the same millisecond are now correctly treated as distinct items.
 * 2. Batch update: rapid-fire log events are coalesced into a single submitList()
 *    call every 120ms via a Handler. This prevents O(n) list copies + DiffUtil runs
 *    on every individual log event (10–30 events/sec during active interception).
 */
class LogAdapter : ListAdapter<ProxyLogItem, LogAdapter.LogViewHolder>(LogDiffCallback()) {

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)
    var onItemClickListener: ((ProxyLogItem) -> Unit)? = null

    // Internal mutable buffer — updated immediately on every addLog()
    private val logBuffer = ArrayDeque<ProxyLogItem>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var flushPending = false

    private val flushRunnable = Runnable {
        flushPending = false
        submitList(logBuffer.toList())
    }

    /**
     * Adds a log entry to the buffer and schedules a batched UI update.
     * The 120ms debounce coalesces rapid bursts (e.g. 30 logs/sec during interception)
     * into a single DiffUtil pass, eliminating RecyclerView jitter.
     */
    fun addLog(item: ProxyLogItem) {
        // Post to main thread if called from a background coroutine
        mainHandler.post {
            logBuffer.addFirst(item)
            if (logBuffer.size > 250) logBuffer.removeLast()

            if (!flushPending) {
                flushPending = true
                mainHandler.postDelayed(flushRunnable, 120)
            }
        }
    }

    fun clear() {
        mainHandler.post {
            mainHandler.removeCallbacks(flushRunnable)
            flushPending = false
            logBuffer.clear()
            submitList(emptyList())
        }
    }

    fun getAllLogsFormatted(): String {
        val sb = StringBuilder()
        // Reversed so output is oldest-first (logical timeline for export/debug)
        for (item in logBuffer.reversed()) {
            val time = timeFormatter.format(Date(item.timestamp))
            sb.append("[$time] [${item.tag}] ${item.message}\n")
        }
        return sb.toString()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
        val binding = ItemLogBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LogViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class LogViewHolder(private val binding: ItemLogBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ProxyLogItem) {
            val timeStr = timeFormatter.format(Date(item.timestamp))
            binding.tvLogTag.text     = "[${item.tag}]"
            binding.tvLogTime.text    = timeStr
            binding.tvLogMessage.text = item.message

            val context = binding.root.context
            when {
                item.isError -> {
                    binding.tvLogTag.setTextColor(ContextCompat.getColor(context, R.color.log_error))
                    binding.tvLogMessage.setTextColor(ContextCompat.getColor(context, R.color.log_error))
                }
                item.isInterception -> {
                    binding.tvLogTag.setTextColor(ContextCompat.getColor(context, R.color.log_interception))
                    binding.tvLogMessage.setTextColor(ContextCompat.getColor(context, R.color.log_success))
                }
                else -> {
                    binding.tvLogTag.setTextColor(ContextCompat.getColor(context, R.color.accent))
                    binding.tvLogMessage.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                }
            }

            binding.root.setOnClickListener {
                onItemClickListener?.invoke(item)
            }
        }
    }

    class LogDiffCallback : DiffUtil.ItemCallback<ProxyLogItem>() {
        /**
         * Uses the unique nanoTime-based `id` field added to ProxyLogItem.
         * Previously used timestamp + message — which collided when two identical
         * log events fired within the same millisecond, silently dropping one entry.
         */
        override fun areItemsTheSame(oldItem: ProxyLogItem, newItem: ProxyLogItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ProxyLogItem, newItem: ProxyLogItem): Boolean {
            return oldItem == newItem
        }
    }
}
