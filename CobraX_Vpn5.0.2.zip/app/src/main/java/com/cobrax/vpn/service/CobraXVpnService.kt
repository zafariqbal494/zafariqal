package com.cobrax.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.cobrax.vpn.R
import com.cobrax.vpn.proxy.MitmProxyServer
import com.cobrax.vpn.state.StateManager
import com.cobrax.vpn.ui.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException

class CobraXVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var proxyServer: MitmProxyServer? = null
    private var tunBridge: TunToProxyBridge? = null
    private lateinit var stateManager: StateManager

    companion object {
        const val ACTION_CONNECT = "com.cobrax.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.cobrax.vpn.ACTION_DISCONNECT"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "cobrax_vpn_channel"

        private val _isVpnRunning = MutableStateFlow(false)
        val isVpnRunning: StateFlow<Boolean> = _isVpnRunning.asStateFlow()

        fun startVpn(context: Context) {
            val intent = Intent(context, CobraXVpnService::class.java).apply {
                action = ACTION_CONNECT
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopVpn(context: Context) {
            val intent = Intent(context, CobraXVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        stateManager = StateManager.getInstance(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_DISCONNECT) {
            stopVpnInternal()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(getString(R.string.vpn_connected)))
        startVpnInternal()

        return START_STICKY
    }

    private fun startVpnInternal() {
        if (_isVpnRunning.value) return

        try {
            // 1. Start Local Netty MITM Proxy
            proxyServer = MitmProxyServer(this, 8877, vpnService = this)
            proxyServer?.start()

            // 2. Configure Android VpnService
            val builder = Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(1500)
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")

            // Configure HTTP Proxy on Android 10+ (API 29+) so Chrome & web apps route through local proxy :8877
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val proxyInfo = android.net.ProxyInfo.buildDirectProxy("127.0.0.1", 8877)
                builder.setHttpProxy(proxyInfo)
                stateManager.log("VPN", "Direct HTTP Proxy configured on 127.0.0.1:8877")
            }

            // Per-app filtering: Allow targeted apps, or fall back to Global Routing
            val allowedApps = stateManager.config.allowedPackageNames
            var hasAllowedApps = false
            for (pkg in allowedApps) {
                if (pkg == packageName) continue // Skip VPN app itself to prevent routing loops
                try {
                    packageManager.getPackageInfo(pkg, 0)
                    builder.addAllowedApplication(pkg)
                    hasAllowedApps = true
                    stateManager.log("VPN", "VPN Tunnel Filter: App added -> $pkg")
                } catch (e: PackageManager.NameNotFoundException) {
                    stateManager.log("VPN", "Package $pkg not installed on device: ${e.message}")
                } catch (e: Exception) {
                    stateManager.log("VPN", "Note on adding package $pkg: ${e.message}")
                }
            }

            // Auto-detect installed CobraX/gameapp variants if not already matched
            if (!hasAllowedApps) {
                val candidatePkgs = listOf(
                    "com.cobrax.team",
                    "com.team.cobrax",
                    "com.cobrax.app",
                    "com.example.gameapp",
                    "com.gameapp",
                    "com.android.chrome",
                    "com.sec.android.app.sbrowser",
                    "com.brave.browser"
                )
                for (pkg in candidatePkgs) {
                    if (pkg == packageName) continue
                    try {
                        packageManager.getPackageInfo(pkg, 0)
                        builder.addAllowedApplication(pkg)
                        hasAllowedApps = true
                        stateManager.log("VPN", "VPN Auto-Detected App -> $pkg")
                    } catch (_: Exception) {}
                }
            }

            // If still no specific package matched, route ALL apps except CobraX VPN itself
            if (!hasAllowedApps) {
                try {
                    builder.addDisallowedApplication(packageName)
                    stateManager.log("VPN", "Global Route Mode active (all device apps routed except CobraX VPN)")
                } catch (e: Exception) {
                    stateManager.log("VPN", "Global route note: ${e.message}")
                }
            }

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                stateManager.log("VPN", "Failed to establish VPN interface (null).", isError = true)
                stopVpnInternal()
                return
            }

            // 3. Start TUN-to-Proxy Bridge
            tunBridge = TunToProxyBridge(this, vpnInterface!!.fileDescriptor, 8877)
            tunBridge?.start()

            // 4. Bind to Underlying Physical Network (Wi-Fi / Cellular)
            registerNetworkCallback()

            _isVpnRunning.value = true
            stateManager.log("VPN", "CobraX VPN connected successfully. Interception active.", isInterception = true)
        } catch (e: Exception) {
            stateManager.log("VPN", "Error starting VPN: ${e.message}", isError = true)
            stopVpnInternal()
        }
    }

    private var connectivityManager: android.net.ConnectivityManager? = null
    private var networkCallback: android.net.ConnectivityManager.NetworkCallback? = null

    private fun registerNetworkCallback() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && connectivityManager != null) {
                val request = android.net.NetworkRequest.Builder()
                    .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                networkCallback = object : android.net.ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: android.net.Network) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                            setUnderlyingNetworks(arrayOf(network))
                            stateManager.log("VPN", "Underlying network active: $network")
                        }
                    }
                    override fun onLost(network: android.net.Network) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                            setUnderlyingNetworks(null)
                        }
                    }
                }
                connectivityManager?.registerNetworkCallback(request, networkCallback!!)
            }
        } catch (e: Exception) {
            stateManager.log("VPN", "Network callback registration note: ${e.message}")
        }
    }

    private fun unregisterNetworkCallback() {
        try {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
            networkCallback = null
        } catch (_: Exception) {}
    }

    private fun stopVpnInternal() {
        try {
            unregisterNetworkCallback()

            tunBridge?.stop()
            tunBridge = null

            proxyServer?.stop()
            proxyServer = null

            vpnInterface?.close()
            vpnInterface = null
        } catch (e: IOException) {
            stateManager.log("VPN", "Error closing VPN interface: ${e.message}", isError = true)
        } finally {
            _isVpnRunning.value = false
            stateManager.log("VPN", "CobraX VPN disconnected.")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, CobraXVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_nav_dashboard)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(statusText)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_nav_config, getString(R.string.disconnect), disconnectIntent)
            .build()
    }

    /**
     * Called when the user revokes VPN permission from the system notification tray
     * or from Android Settings. Without this, _isVpnRunning would stay true and
     * the UI button would be stuck on "STOP VPN" indefinitely.
     */
    override fun onRevoke() {
        stateManager.log("VPN", "VPN access revoked by system or user (tray/settings).")
        stopVpnInternal()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpnInternal()
        super.onDestroy()
    }
}

