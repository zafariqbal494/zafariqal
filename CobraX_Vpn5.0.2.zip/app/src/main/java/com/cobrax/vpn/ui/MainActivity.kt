package com.cobrax.vpn.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.cobrax.vpn.R
import com.cobrax.vpn.cert.CertificateAuthority
import com.cobrax.vpn.databinding.ActivityMainBinding
import com.cobrax.vpn.service.CobraXVpnService
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val dashboardFragment = DashboardFragment()
    private val configFragment = ConfigFragment()

    private val vpnPrepareLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            CobraXVpnService.startVpn(this)
        } else {
            Toast.makeText(this, "VPN permission is required to process traffic", Toast.LENGTH_SHORT).show()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        requestNotificationPermission()

        binding.btnExportCa.setOnClickListener {
            exportCaCertificate()
        }

        if (savedInstanceState == null) {
            loadFragment(dashboardFragment)
        }
    }

    private fun setupNavigation() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    loadFragment(dashboardFragment)
                    true
                }
                R.id.nav_config -> {
                    loadFragment(configFragment)
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun requestStartVpn() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPrepareLauncher.launch(prepareIntent)
        } else {
            CobraXVpnService.startVpn(this)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    fun exportCaCertificate() {
        val caAuth = CertificateAuthority.getInstance(this)
        val caFile = caAuth.caCertFile

        if (!caFile.exists()) {
            Toast.makeText(this, "CA Certificate file not found.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val certBytes = caFile.readBytes()
            val fileName = "CobraX_CA.crt"
            var savedPath = "Downloads/$fileName"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/x-x509-ca-cert")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                }

                val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(certBytes)
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                downloadsDir.mkdirs()
                val targetFile = File(downloadsDir, fileName)
                targetFile.writeBytes(certBytes)
                savedPath = targetFile.absolutePath
            }

            // Show confirmation dialog with manual installation instructions
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("CA Certificate Downloaded")
                .setMessage("Certificate saved to:\n$savedPath\n\nTo install manually on this device:\n1. Open Android Settings > Security\n2. Tap 'Encryption & credentials' > 'Install a certificate'\n3. Choose 'CA certificate' and select CobraX_CA.crt from Downloads.")
                .setPositiveButton("Open Settings") { _, _ ->
                    try {
                        startActivity(Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS))
                    } catch (_: Exception) {
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                        } catch (_: Exception) {}
                    }
                }
                .setNegativeButton("Done", null)
                .show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error saving CA certificate: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
