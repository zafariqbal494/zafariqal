package com.cobrax.vpn.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cobrax.vpn.model.AppConfig
import com.cobrax.vpn.service.CobraXVpnService
import com.cobrax.vpn.state.StateManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Shared ViewModel for DashboardFragment and ConfigFragment.
 *
 * Centralizing state here means:
 * - Fragments never hold direct StateManager references (no duplicate Flow collectors on rotation).
 * - All suspend StateManager calls are launched inside viewModelScope — lifecycle-safe.
 * - Both fragments share one instance via activityViewModels<CobraXViewModel>().
 *
 * currentUser and currentBalance are now derived from stateManager.userStateFlow,
 * which is emitted on every switchUser(), saveStateInternal(), and balance mutation.
 * This means the Dashboard updates instantly when the user switches or balance changes —
 * no manual polling or refreshUserState() calls needed.
 */
class CobraXViewModel(app: Application) : AndroidViewModel(app) {

    private val stateManager = StateManager.getInstance(app)

    // ── Flows exposed to the UI ──────────────────────────────────────────────

    /** Real-time proxy interception log stream */
    val logsFlow: SharedFlow<com.cobrax.vpn.model.ProxyLogItem> = stateManager.logsFlow

    /** Live VPN running state — drives button label and status indicator */
    val vpnRunning: StateFlow<Boolean> = CobraXVpnService.isVpnRunning

    /**
     * Reactive user ID derived from userStateFlow.
     * Automatically updates whenever StateManager switches user or saves state.
     * No manual refreshUserState() calls needed.
     */
    val currentUser: StateFlow<String> = stateManager.userStateFlow
        .map { it.userName }
        .stateIn(
            scope        = viewModelScope,
            started      = SharingStarted.Eagerly,
            initialValue = stateManager.currentUserState.userName
        )

    /**
     * Reactive balance derived from userStateFlow.
     * Updates instantly on every bet, win, withdrawal, or manual balance set.
     */
    val currentBalance: StateFlow<Double> = stateManager.userStateFlow
        .map { it.localBalance }
        .stateIn(
            scope        = viewModelScope,
            started      = SharingStarted.Eagerly,
            initialValue = stateManager.currentUserState.localBalance
        )

    // ── Config Accessors ─────────────────────────────────────────────────────

    val config: AppConfig get() = stateManager.config

    // ── State Refresh ────────────────────────────────────────────────────────

    /**
     * Kept for backward compatibility with any call sites that still invoke it.
     * Safe to call — a no-op because currentUser and currentBalance are now
     * reactive and update themselves via userStateFlow.
     */
    fun refreshUserState() {
        // No-op: userStateFlow drives currentUser and currentBalance automatically.
        // This function is intentionally left empty so existing call sites compile
        // without changes. It can be removed in a future cleanup pass.
    }

    // ── Config / Balance Mutations ────────────────────────────────────────────

    fun setBalance(amount: Double) {
        viewModelScope.launch {
            stateManager.setBalance(amount)
            // No manual refresh needed — setBalance calls saveStateInternal which
            // emits _userStateFlow, which updates currentBalance automatically.
        }
    }

    fun saveConfig(
        enableModifications: Boolean,
        minDelay: Double?,
        maxDelay: Double?
    ) {
        viewModelScope.launch {
            stateManager.updateConfig { cfg ->
                cfg.enableModifications = enableModifications
                if (minDelay != null && minDelay > 0) {
                    cfg.withdrawalMinDelayMinutes = minDelay
                }
                if (maxDelay != null && maxDelay >= (minDelay ?: cfg.withdrawalMinDelayMinutes)) {
                    cfg.withdrawalMaxDelayMinutes = maxDelay
                }
            }
        }
    }
}
