package com.cobrax.vpn.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.cobrax.vpn.databinding.FragmentConfigBinding
import java.util.Locale

/**
 * Configuration screen: enable/disable modifications, set balance, withdrawal delays, CA export.
 *
 * All StateManager mutations now go through CobraXViewModel, which launches them
 * in viewModelScope. This means:
 * - Suspend functions are safely called without blocking the UI thread.
 * - The Fragment no longer holds a direct StateManager reference.
 */
class ConfigFragment : Fragment() {

    private var _binding: FragmentConfigBinding? = null
    private val binding get() = _binding!!

    // Shared ViewModel — same instance as DashboardFragment
    private val viewModel: CobraXViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConfigBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadCurrentConfig()
        setupListeners()
    }

    private fun loadCurrentConfig() {
        val config = viewModel.config
        binding.switchEnableModifications.isChecked = config.enableModifications
        binding.etWithdrawalMinDelay.setText(String.format(Locale.US, "%.1f", config.withdrawalMinDelayMinutes))
        binding.etWithdrawalMaxDelay.setText(String.format(Locale.US, "%.1f", config.withdrawalMaxDelayMinutes))
        // Balance is read from the ViewModel's StateFlow, which always reflects current value
        binding.etCustomBalance.setText(String.format(Locale.US, "%.2f", viewModel.currentBalance.value))
    }

    private fun setupListeners() {
        binding.btnSaveConfig.setOnClickListener {
            val newBalanceStr  = binding.etCustomBalance.text?.toString()
            val newMinDelayStr = binding.etWithdrawalMinDelay.text?.toString()
            val newMaxDelayStr = binding.etWithdrawalMaxDelay.text?.toString()

            val newBalance  = newBalanceStr?.toDoubleOrNull()
            val newMinDelay = newMinDelayStr?.toDoubleOrNull()
            val newMaxDelay = newMaxDelayStr?.toDoubleOrNull()

            // ViewModel handles coroutine launch internally — no lifecycleScope needed here
            viewModel.saveConfig(
                enableModifications = binding.switchEnableModifications.isChecked,
                minDelay            = newMinDelay,
                maxDelay            = newMaxDelay
            )

            if (newBalance != null && newBalance >= 0) {
                viewModel.setBalance(newBalance)  // suspend via viewModelScope inside ViewModel
            }

            Toast.makeText(requireContext(), "Settings & Balance Saved Successfully", Toast.LENGTH_SHORT).show()
        }

        binding.btnExportCaFromConfig.setOnClickListener {
            (activity as? MainActivity)?.exportCaCertificate()
        }

        binding.btnCopySpkiHash.setOnClickListener {
            generateAndCopySpkiHash()
        }
    }

    private fun generateAndCopySpkiHash() {
        try {
            val ca          = com.cobrax.vpn.cert.CertificateAuthority.getInstance(requireContext())
            val pubKey      = ca.caCertificate.publicKey
            val spkiBytes   = pubKey.encoded
            val digest      = java.security.MessageDigest.getInstance("SHA-256").digest(spkiBytes)
            val base64Hash  = android.util.Base64.encodeToString(digest, android.util.Base64.NO_WRAP)

            binding.tvSpkiHash.text = base64Hash

            val clipboard = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                as? android.content.ClipboardManager
            clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("SPKI Hash", base64Hash))

            Toast.makeText(
                requireContext(),
                "SPKI Hash copied!\nNow open chrome://flags/#ignore-certificate-errors-spki-list and paste it",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error generating SPKI hash: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
