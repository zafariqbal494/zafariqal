# CobraX VPN — Standalone Android MITM Proxy & Rule Engine

A standalone Android VPN application designed to completely replace Fiddler for local client-side testing, game traffic inspection, simulated wallet balance management, and rule transformations for WinGo / AR-Lottery.

---

## 🏗 Architecture

```
[ Chrome / CobraX App ]
           │
           │ (Encrypted/Plain TCP HTTP/HTTPS)
           ▼
┌────────────────────────────────────────────────────────┐
│                   CobraX VPN Service                   │
│  - Android VpnService Layer                            │
│  - Per-App Filtering (Only Chrome & CobraX allowed)    │
│  - System Apps & other apps completely bypassed        │
└──────────────────────────┬─────────────────────────────┘
                           │ TUN Interface (10.0.0.2)
                           ▼
┌────────────────────────────────────────────────────────┐
│                   Local MITM Proxy                     │
│  - Embedded Netty 4.1.x Server (127.0.0.1:8877)        │
│  - Dynamic Bouncy Castle RSA 2048-bit SSL Engine       │
│  - Self-Signed Root CA Certificate Authority           │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│                     Rule Engine                        │
│  - 12 Fiddler Handlers (1:1 Migrated & Optimized)      │
│  - Real Game Draw Verification via Async OkHttp        │
│  - Multi-User State Persistence (Internal JSON)        │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
               [ Live Game Server API ]
              (draw.ar-lottery01.com)
```

---

## ⚡ Key Features (Migrated from Fiddler Script)

1. **Multi-User State Management:**
   - Automatically detects logged-in user from `/api/webapi/GetUserInfo` response.
   - Maintains separate `fiddler_state_<userName>.json` in Android internal storage.
   - Restores the last active user automatically on reboot or app start.

2. **Bet Interception (`/api/Lottery/WinGoBet`):**
   - Immediately deducts the placed bet from `localBalance`.
   - Stores bet context and timestamp.

3. **Live Win/Loss Validation (`/api/Lottery/GetWinLossResult`):**
   - Queries live draw results asynchronously via `RealResultFetcher` (supports WinGo 30S and 1M).
   - Evaluates user's bet (`Big`: numbers 5–9, `Small`: numbers 0–4).
   - If Won: credits `totalBet * 1.98` to `localBalance`, prevents duplicate crediting (`issueWinApplied`), returns `status: true`.
   - If Lost: returns `status: false, winAmount: 0.00`.

4. **Wallet & Balance Spoofing:**
   - Overrides `/api/Lottery/GetBalance`
   - Overrides `/api/webapi/GetARGameAndPlatWallets` (ARGame = `localBalance`, Lottery = `0.00`)
   - Overrides `/api/webapi/RecoverSaasBalance`
   - Overrides `/api/webapi/getWithdrawals` (`amount` & `canWithdrawAmount` = `localBalance`)
   - Overrides `/api/webapi/GetRechargeRecord` (injects fake USDT recharge matching simulated balance)

5. **Withdrawal Lifecycle Simulator:**
   - Intercepts `/api/webapi/NewSetWithdrawal`. When server returns `"Balance is not enough"`, crafts fake success response with order `WD<timestamp><random>`, deducts balance, and stores pending withdrawal (`state: 0`).
   - Intercepts `/api/webapi/GetWithdrawLog`. Automatically flips pending withdrawals to `state: 1` (Success) after `withdrawalSuccessDelayMinutes` (default: 9.0 min), sorts descending, and paginates.

6. **Bet History Rebuilder (`/api/Lottery/GetRecordPage`):**
   - Reconstructs complete sorted and paginated JSON history from local bet contexts and outcomes.

---

## 📲 How to Install & Trust the CA Certificate on Android

To allow HTTPS decryption for testing in Chrome and WebView:

1. Open **CobraX VPN** app.
2. Tap **"Export / Install CA Cert"** on the dashboard or settings.
3. Save the certificate `CobraX_CA.crt` to your device Downloads/Storage.
4. Go to **Android Settings**:
   - Navigate to: **Settings > Security > Encryption & credentials > Install a certificate > CA certificate**
   - Select the saved `CobraX_CA.crt` file.
   - Confirm with your device PIN / fingerprint.
5. In Chrome, navigate to the target site. HTTPS traffic will now be transparently intercepted and transformed by CobraX VPN.

---

## 🛠 Project Structure

```
D:\GameApp\CobraX VPN\
├── app/
│   ├── src/main/
│   │   ├── java/com/cobrax/vpn/
│   │   │   ├── CobraXApp.kt                 # Application entry point
│   │   │   ├── model/Models.kt              # Data models (UserState, BetContext, Config, etc.)
│   │   │   ├── state/StateManager.kt        # Per-user JSON persistence & balance engine
│   │   │   ├── cert/CertificateAuthority.kt # BouncyCastle Root CA & dynamic TLS cert generator
│   │   │   ├── network/RealResultFetcher.kt # Async OkHttp live draw result fetcher
│   │   │   ├── rules/RuleEngine.kt          # 12 Fiddler rules implementation
│   │   │   ├── proxy/MitmProxyServer.kt     # Netty HTTP/HTTPS CONNECT proxy server
│   │   │   ├── service/
│   │   │   │   ├── CobraXVpnService.kt      # Android VpnService & Per-app filter
│   │   │   │   └── TunToProxyBridge.kt      # TUN interface to local proxy bridge
│   │   │   └── ui/
│   │   │       ├── MainActivity.kt          # Main activity & permission flow
│   │   │       ├── DashboardFragment.kt     # VPN switch, balance display, live logs
│   │   │       ├── ConfigFragment.kt        # Rule toggles, balance override, delay settings
│   │   │       └── LogAdapter.kt            # Live RecyclerView log adapter
│   │   ├── res/                             # Layouts, themes, colors, network config
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

---

## 🚀 How to Build

Open the folder `D:\GameApp\CobraX VPN` directly in **Android Studio** (Hedgehog / Iguana / Jellyfish / Koala or newer), or build via command line:

```bash
cd "D:\GameApp\CobraX VPN"
gradlew assembleDebug
```

The compiled APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
