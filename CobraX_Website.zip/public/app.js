/**
 * CobraX — Frontend JavaScript
 * Handles:
 *  - Matrix rain canvas animation
 *  - Terminal typewriter effect
 *  - Glitch heading loops
 *  - Animated user counter
 *  - Live purchase ticker
 *  - Scroll reveal animations
 *  - Payment modal flow (channel select → create order → redirect → poll → key reveal)
 */

/* ════════════════════════════════════════════════
   1. MATRIX RAIN
════════════════════════════════════════════════ */
(function initMatrixRain() {
  const canvas = document.getElementById('matrix-canvas');
  const ctx    = canvas.getContext('2d');

  const CHARS  = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ<>[]{}|/\\';
  const FONT_SIZE = 14;
  let cols, drops;

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    cols  = Math.floor(canvas.width / FONT_SIZE);
    drops = Array(cols).fill(1);
  }

  function draw() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.font = `${FONT_SIZE}px monospace`;

    for (let i = 0; i < drops.length; i++) {
      // Random character
      const char = CHARS[Math.floor(Math.random() * CHARS.length)];

      // Leading char is bright neon, rest are dim
      if (drops[i] * FONT_SIZE < canvas.height * 0.1) {
        ctx.fillStyle = '#ffffff';
      } else if (Math.random() > 0.98) {
        ctx.fillStyle = '#FF003C';  // occasional red char
      } else {
        // Gradient from bright to dim based on position
        const alpha = Math.max(0.15, 1 - (drops[i] * FONT_SIZE / canvas.height));
        ctx.fillStyle = `rgba(0, 255, 65, ${alpha})`;
      }

      ctx.fillText(char, i * FONT_SIZE, drops[i] * FONT_SIZE);

      // Reset when off-screen, with randomness
      if (drops[i] * FONT_SIZE > canvas.height && Math.random() > 0.975) {
        drops[i] = 0;
      }
      drops[i]++;
    }
  }

  resize();
  window.addEventListener('resize', resize);
  setInterval(draw, 40); // ~25fps for matrix
})();


/* ════════════════════════════════════════════════
   2. TERMINAL TYPEWRITER
════════════════════════════════════════════════ */
(function initTerminal() {
  const container = document.getElementById('terminal-lines');
  if (!container) return;

  const getVer = () => window.CobraXLatestVersion || (document.querySelector('.dynamic-app-version')?.textContent) || 'v5.0.1';
  const lines = [
    { text: `> Initializing CobraX ${getVer()}...`, cls: 'active',  delay: 300  },
    { text: '> Establishing encrypted tunnel...', cls: '',    delay: 900  },
    { text: '> [OK] AES-256 handshake complete', cls: '',     delay: 1700 },
    { text: '> Loading prediction engine...', cls: '',        delay: 2500 },
    { text: '> [AUTH] Key validation required', cls: 'warn',  delay: 3300 },
    { text: '> 10,247 active sessions detected', cls: '',     delay: 4100 },
    { text: '> Status: OPERATIONAL ██████████ 100%', cls: 'active', delay: 4900 },
    { text: '> Awaiting authentication key...', cls: 'active', delay: 5600 },
  ];

  lines.forEach(({ text, cls, delay }) => {
    setTimeout(() => {
      const line = document.createElement('div');
      line.className = `t-line ${cls}`;
      line.style.animationDelay = '0ms';

      // Typewriter per character
      let i = 0;
      line.textContent = '';
      container.appendChild(line);

      // Scroll the terminal box
      line.parentElement.parentElement.scrollTop = line.parentElement.parentElement.scrollHeight;

      const typeInterval = setInterval(() => {
        line.textContent = text.slice(0, i + 1);
        i++;
        if (i >= text.length) {
          clearInterval(typeInterval);
          // Add cursor on last line
          if (text === lines[lines.length - 1].text) {
            const cursor = document.createElement('span');
            cursor.className = 'typewriter-cursor';
            cursor.setAttribute('aria-hidden', 'true');
            line.appendChild(cursor);
          }
        }
      }, 28);
    }, delay);
  });
})();


/* ════════════════════════════════════════════════
   3. ANIMATED USER COUNTER
════════════════════════════════════════════════ */
function animateCounter(element, target, duration) {
  if (!element) return;
  const start    = performance.now();
  const startVal = 0;

  function update(now) {
    const elapsed  = now - start;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out cubic
    const eased    = 1 - Math.pow(1 - progress, 3);
    const current  = Math.floor(startVal + (target - startVal) * eased);
    element.textContent = current.toLocaleString() + '+';
    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

// Trigger counter when visible
const mainCounter = document.getElementById('main-counter');
let counterDone   = false;
const counterObs  = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !counterDone) {
      counterDone = true;
      animateCounter(mainCounter, 10247, 2500);
    }
  });
}, { threshold: 0.5 });
if (mainCounter) counterObs.observe(mainCounter);


/* ════════════════════════════════════════════════
   4. LIVE PURCHASE TICKER
════════════════════════════════════════════════ */
(function initTicker() {
  const inner = document.getElementById('ticker-inner');
  if (!inner) return;

  const users = [
    { mask: 'User ****23', plan: '30-Day Key',  time: '2m ago',  flag: '🇵🇰' },
    { mask: 'User ****87', plan: '365-Day Key', time: '4m ago',  flag: '🇵🇰' },
    { mask: 'User ****14', plan: '90-Day Key',  time: '7m ago',  flag: '🇵🇰' },
    { mask: 'User ****56', plan: '30-Day Key',  time: '12m ago', flag: '🇵🇰' },
    { mask: 'User ****99', plan: '365-Day Key', time: '15m ago', flag: '🇵🇰' },
    { mask: 'User ****32', plan: '90-Day Key',  time: '18m ago', flag: '🇵🇰' },
    { mask: 'User ****71', plan: '30-Day Key',  time: '21m ago', flag: '🇵🇰' },
    { mask: 'User ****48', plan: '365-Day Key', time: '25m ago', flag: '🇵🇰' },
    { mask: 'User ****05', plan: '90-Day Key',  time: '29m ago', flag: '🇵🇰' },
    { mask: 'User ****63', plan: '30-Day Key',  time: '33m ago', flag: '🇵🇰' },
  ];

  function createItem({ mask, plan, time, flag }) {
    const div = document.createElement('div');
    div.className = 'ticker-item';
    div.innerHTML = `
      <span class="ticker-flag" aria-hidden="true">${flag}</span>
      <span class="ticker-user">${mask}</span>
      <span style="color: var(--text-dim)">just purchased</span>
      <span class="ticker-plan">${plan}</span>
      <span class="ticker-time">${time}</span>
    `;
    return div;
  }

  // Build the list twice for seamless infinite scroll
  [...users, ...users].forEach(u => inner.appendChild(createItem(u)));
})();


/* ════════════════════════════════════════════════
   5. SCROLL REVEAL
════════════════════════════════════════════════ */
(function initReveal() {
  const els = document.querySelectorAll('.reveal');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => obs.observe(el));
})();


/* ════════════════════════════════════════════════
   6. PAYMENT MODAL FLOW
════════════════════════════════════════════════ */

const PLAN_DATA = {
  1:  { label: '24-Hour Access', price: '$20.00', amount: '20.00' },
  30: { label: '30-Day Access',  price: '$80.00', amount: '80.00' },
};

let selectedPlan    = null;
let selectedChannel = null;
let currentOrderNo  = null;
let pollInterval    = null;
let pollAttempts    = 0;
const MAX_POLLS     = 60; // 3 minutes at 3s intervals

function openPaymentModal(plan) {
  selectedPlan    = plan;
  selectedChannel = null;
  currentOrderNo  = null;
  pollAttempts    = 0;

  // Reset UI
  showStep(1);
  resetChannelSelection();
  document.getElementById('modal-pay-btn').disabled = true;

  // Fill plan info
  const info = PLAN_DATA[plan];
  document.getElementById('modal-plan-name').textContent  = info.label;
  document.getElementById('modal-plan-price').textContent = info.price;

  // Show modal
  document.getElementById('payment-modal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closePaymentModal() {
  document.getElementById('payment-modal').classList.remove('active');
  document.body.style.overflow = '';
  stopPolling();
}

// Close on overlay click
document.getElementById('payment-modal').addEventListener('click', function(e) {
  if (e.target === this) closePaymentModal();
});

// Close on Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closePaymentModal();
});

function showStep(n) {
  document.getElementById('modal-step-1').style.display = n === 1 ? 'block' : 'none';
  document.getElementById('modal-step-2').style.display = n === 2 ? 'block' : 'none';
  document.getElementById('modal-step-3').style.display = n === 3 ? 'block' : 'none';
}

function resetChannelSelection() {
  document.querySelectorAll('.channel-btn').forEach(btn => {
    btn.classList.remove('selected');
    btn.setAttribute('aria-pressed', 'false');
  });
}

function selectChannel(channel) {
  selectedChannel = channel;
  resetChannelSelection();

  const id = channel === 'Jazzcash' ? 'channel-jazzcash' : 'channel-easypaisa';
  const btn = document.getElementById(id);
  btn.classList.add('selected');
  btn.setAttribute('aria-pressed', 'true');

  document.getElementById('modal-pay-btn').disabled = false;
}

async function initiatePayment() {
  if (!selectedPlan || !selectedChannel) return;

  const payBtn = document.getElementById('modal-pay-btn');
  payBtn.disabled = true;
  payBtn.textContent = '⏳ Creating order...';

  try {
    const res = await fetch('/api/create-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan: String(selectedPlan), channel: selectedChannel }),
    });

    const data = await res.json();

    if (!data.success) {
      showToast('❌ ' + (data.error || 'Failed to create order. Try again.'), 'error');
      payBtn.disabled   = false;
      payBtn.textContent = '⚡ PROCEED TO PAYMENT';
      return;
    }

    currentOrderNo = data.orderNo;

    // Open payment page in new tab
    window.open(data.paymentUrl, '_blank', 'noopener,noreferrer');

    // Move to step 2 (waiting)
    showStep(2);
    document.getElementById('status-text-main').textContent = 'Payment page opened in a new tab...';
    document.getElementById('status-text-hint').textContent = 'Complete payment in your wallet app, then return here';

    // Show manual check button after 10s
    setTimeout(() => {
      const checkBtn = document.getElementById('check-payment-btn');
      if (checkBtn) checkBtn.style.display = 'inline-flex';
    }, 10000);

    // Start polling
    startPolling();

  } catch (err) {
    console.error('initiatePayment error:', err);
    showToast('❌ Network error. Please check your connection.', 'error');
    payBtn.disabled   = false;
    payBtn.textContent = '⚡ PROCEED TO PAYMENT';
  }
}

function startPolling() {
  stopPolling();
  pollAttempts = 0;
  pollInterval = setInterval(pollOrderStatus, 3000);
}

function stopPolling() {
  if (pollInterval) {
    clearInterval(pollInterval);
    pollInterval = null;
  }
}

async function pollOrderStatus() {
  if (!currentOrderNo) return;

  pollAttempts++;

  // Update spinner text
  const hints = [
    'Waiting for payment confirmation...',
    'Checking payment gateway...',
    'Verifying transaction...',
    'Almost there...',
  ];
  const hintEl = document.getElementById('status-text-hint');
  if (hintEl) hintEl.textContent = hints[pollAttempts % hints.length];

  if (pollAttempts >= MAX_POLLS) {
    stopPolling();
    document.getElementById('status-text-main').textContent = 'Payment check timed out.';
    document.getElementById('status-text-hint').textContent = 'If you completed payment, contact us on Telegram with your Order ID: ' + currentOrderNo;
    return;
  }

  try {
    const res  = await fetch('/api/check-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderNo: currentOrderNo }),
    });
    const data = await res.json();

    if (!data.success) {
      // Don't stop polling on transient errors (per §1.6 spirit)
      return;
    }

    if (data.orderState === '1') {
      // SUCCESS!
      stopPolling();
      revealKey(data.key);
    } else if (data.orderState === '2') {
      // Failed
      stopPolling();
      document.getElementById('status-text-main').textContent = '❌ Payment failed or was cancelled.';
      document.getElementById('status-text-hint').textContent = 'Please try again. If amount was deducted, contact Telegram support.';
    }
    // States 0, 3 = still processing — keep polling

  } catch (err) {
    // Network error during poll — ignore and retry (per §1.6)
    console.warn('Poll error (will retry):', err);
  }
}

async function manualCheckPayment() {
  await pollOrderStatus();
}

function revealKey(key) {
  document.getElementById('key-display').textContent = key || 'KEY-ERROR';
  showStep(3);
  showToast('✅ Payment confirmed! Your key is ready.', 'success');
}

function copyKey() {
  const keyText = document.getElementById('key-display').textContent;
  const copyBtn = document.getElementById('copy-key-btn');

  navigator.clipboard.writeText(keyText).then(() => {
    copyBtn.textContent = '✅ COPIED!';
    copyBtn.classList.add('copied');
    showToast('✅ Key copied to clipboard!', 'success');
    setTimeout(() => {
      copyBtn.textContent = '📋 COPY KEY';
      copyBtn.classList.remove('copied');
    }, 2500);
  }).catch(() => {
    // Fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = keyText;
    ta.style.position = 'fixed';
    ta.style.opacity  = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { document.execCommand('copy'); } catch(e) {}
    document.body.removeChild(ta);
    copyBtn.textContent = '✅ COPIED!';
    setTimeout(() => { copyBtn.textContent = '📋 COPY KEY'; }, 2500);
  });
}


/* ════════════════════════════════════════════════
   7. TOAST NOTIFICATION
════════════════════════════════════════════════ */
let toastTimer = null;
function showToast(msg, type = 'error') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.cursor = 'pointer';
  toast.title = 'Tap to dismiss';
  toast.onclick = () => toast.classList.remove('show');

  const variant = type === 'success' ? 'success' : type === 'warn' ? 'warn' : type === 'info' ? 'info' : 'error';
  toast.className = `toast show ${variant}`;

  if (toastTimer) clearTimeout(toastTimer);
  const displayDuration = Math.max(4500, String(msg).length * 65);
  toastTimer = setTimeout(() => {
    toast.classList.remove('show');
  }, displayDuration);
}


/* ════════════════════════════════════════════════
   8. SMOOTH NAVBAR HIDE/SHOW
════════════════════════════════════════════════ */
(function initNavbar() {
  const navbar   = document.querySelector('.navbar');
  let lastScroll = 0;

  window.addEventListener('scroll', () => {
    const curr = window.scrollY;
    if (curr > 100 && curr > lastScroll) {
      navbar.style.transform = 'translateY(-100%)';
      navbar.style.transition = 'transform 0.3s';
    } else {
      navbar.style.transform = 'translateY(0)';
    }
    lastScroll = curr;
  }, { passive: true });
})();


/* ════════════════════════════════════════════════
   9. RANDOM GLITCH TRIGGER (extra spice)
════════════════════════════════════════════════ */
(function extraGlitch() {
  const glitchEl = document.getElementById('hero-glitch');
  if (!glitchEl) return;

  setInterval(() => {
    if (Math.random() > 0.7) {
      glitchEl.style.transform = `translate(${Math.random()*6-3}px, ${Math.random()*4-2}px)`;
      setTimeout(() => { glitchEl.style.transform = 'translate(0)'; }, 80);
    }
  }, 2000);
})();


/* ════════════════════════════════════════════════
   10. CHECK ORDER FROM URL (post-redirect return)
════════════════════════════════════════════════ */
(function checkReturnFromPayment() {
  const params  = new URLSearchParams(window.location.search);
  const orderNo = params.get('orderNo') || params.get('order_no') || params.get('orderno');

  if (!orderNo) return;

  // Remove query param from URL without reload
  window.history.replaceState({}, '', window.location.pathname);

  currentOrderNo = orderNo;

  // Open modal in waiting state
  document.getElementById('payment-modal').classList.add('active');
  document.body.style.overflow = 'hidden';
  showStep(2);
  document.getElementById('status-text-main').textContent = 'Verifying your payment...';
  document.getElementById('status-text-hint').textContent = 'Order: ' + orderNo;

  startPolling();
})();
