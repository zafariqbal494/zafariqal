/**
 * CobraX — Shared JavaScript
 * Auth helpers, API fetch wrapper, toast, navbar behavior
 */

'use strict';

/* ─── Plan Data ─────────────────────────────────── */
const PLAN_DATA = {
  1:  { label: '24-Hour Access', price: '$20.00', amount: '20.00', days: 1  },
  30: { label: '30-Day Access',  price: '$80.00', amount: '80.00', days: 30 },
};

/* ─── Session / Token ───────────────────────────── */
function getToken() {
  return localStorage.getItem('cbx_token') || sessionStorage.getItem('cbx_token') || null;
}

function getUser() {
  try {
    const u = localStorage.getItem('cbx_user') || sessionStorage.getItem('cbx_user');
    return u ? JSON.parse(u) : null;
  } catch { return null; }
}

function setToken(token, user, remember = true) {
  const store = remember ? localStorage : sessionStorage;
  store.setItem('cbx_token', token);
  store.setItem('cbx_user', JSON.stringify(user));
}

function clearToken() {
  ['cbx_token', 'cbx_user'].forEach(k => {
    localStorage.removeItem(k);
    sessionStorage.removeItem(k);
  });
}

function isLoggedIn() {
  return !!getToken();
}

/* ─── Redirect helpers ──────────────────────────── */
function requireAuth() {
  if (!isLoggedIn()) {
    const redirect = encodeURIComponent(window.location.pathname);
    window.location.href = `login?redirect=${redirect}`;
    return false;
  }
  return true;
}

function redirectIfLoggedIn(target = 'dashboard') {
  if (isLoggedIn()) {
    window.location.href = target;
  }
}

/* ─── API Fetch wrapper ─────────────────────────── */
async function apiFetch(url, opts = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (token) headers['X-Session-Token'] = token;
  const res = await fetch(url, { ...opts, headers });
  return res.json();
}

/* ─── Logout ────────────────────────────────────── */
async function logout() {
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } catch { /* ignore */ }
  clearToken();
  window.location.href = '/';
}

/* ─── Navbar ─────────────────────────────────────── */
function initNav() {
  const user = getUser();
  const navAuth = document.getElementById('nav-auth');

  if (navAuth) {
    if (user) {
      navAuth.innerHTML = `
        <a href="dashboard" class="btn-nav-auth" style="color:var(--neon);border:1px solid var(--border);padding:5px 12px;border-radius:4px;font-size:11px;letter-spacing:1px;">
          ⬡ ${user.username.toUpperCase()}
        </a>
        <a href="#" class="btn-nav-logout" onclick="logout();return false;" style="font-size:11px;padding:5px 8px;letter-spacing:1px;color:var(--text-dim);">
          [EXIT]
        </a>`;
    } else {
      navAuth.innerHTML = `<a href="login" class="btn-nav-auth">LOGIN</a>`;
    }
  }

  // Active link highlight (clean URLs)
  let rawPage = window.location.pathname.replace(/^\//, '').replace(/\.html$/, '');
  const currentPage = rawPage || '/';
  document.querySelectorAll('.nav-links a').forEach(a => {
    let href = (a.getAttribute('href') || '').replace(/^\//, '').replace(/\.html$/, '');
    if (!href) href = '/';
    if (href === currentPage || (currentPage === '/' && (href === '/' || href === 'index'))) {
      a.classList.add('active');
    }
  });

  // Mobile toggle
  const toggle = document.getElementById('nav-toggle');
  const links  = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      links.classList.toggle('open');
    });
    // Close on link click
    links.addEventListener('click', () => links.classList.remove('open'));
  }

  // Navbar hide on scroll down (throttled with rAF)
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    let lastY = 0;
    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const curr = window.scrollY;
          if (curr > 80 && curr > lastY) {
            navbar.classList.add('hidden');
          } else {
            navbar.classList.remove('hidden');
          }
          lastY = curr;
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }
}

/* ─── Toast ──────────────────────────────────────── */
let _toastTimer = null;
function showToast(msg, type = 'error') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.cursor = 'pointer';
  toast.title = 'Tap to dismiss';
  toast.onclick = () => toast.classList.remove('show');

  const variant = type === 'success' ? 'success' : type === 'warn' ? 'warn' : type === 'info' ? 'info' : 'error';
  toast.className = `toast show ${variant}`;

  if (_toastTimer) clearTimeout(_toastTimer);
  const displayDuration = Math.max(4500, String(msg).length * 65);
  _toastTimer = setTimeout(() => toast.classList.remove('show'), displayDuration);
}

/* ─── Scroll Reveal (IntersectionObserver) ───────── */
function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });
  els.forEach(el => obs.observe(el));
}

/* ─── Animated Counter ───────────────────────────── */
function animateCounter(el, target, duration = 2000) {
  if (!el) return;
  const start = performance.now();
  function tick(now) {
    const p = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.floor(target * eased).toLocaleString() + '+';
    if (p < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

/* ─── Copy to clipboard helper ───────────────────── */
function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '✅ COPIED!';
      btn.classList.add('copied');
      setTimeout(() => { btn.textContent = orig; btn.classList.remove('copied'); }, 2500);
    }
    showToast('✅ Copied to clipboard!', 'success');
  }).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    try { document.execCommand('copy'); } catch(e){}
    document.body.removeChild(ta);
    if (btn) { btn.textContent = '✅ COPIED!'; setTimeout(() => { btn.textContent = '📋 COPY KEY'; }, 2500); }
    showToast('✅ Copied!', 'success');
  });
}

/* ─── Date & Time formatters ─────────────────────────────── */
function fmtDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-PK', { day:'2-digit', month:'short', year:'numeric' });
}

function fmtTime(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('en-PK', { hour:'2-digit', minute:'2-digit', hour12: true });
}

function fmtDateTime(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return `${d.toLocaleDateString('en-PK', { day:'2-digit', month:'short', year:'numeric' })}, ${d.toLocaleTimeString('en-PK', { hour:'2-digit', minute:'2-digit', hour12: true })}`;
}

/* ─── Fetch and Render Dynamic Settings (Version & Telegram) ─ */
async function loadPublicSiteSettings() {
  try {
    const res = await fetch('/api/settings/public');
    const data = await res.json();
    if (!data || !data.success) return;

    // 1. Dynamic App Version (Synchronized live from Admin Panel)
    if (data.latestAppVersion) {
      const cleanVer = String(data.latestAppVersion).trim().replace(/^v/i, '');
      const ver = 'v' + cleanVer;
      window.CobraXLatestVersion = ver;
      document.querySelectorAll('.dynamic-app-version').forEach(el => {
        el.textContent = ver;
      });
      const badge = document.getElementById('site-app-version');
      if (badge) badge.textContent = ver;
      window.dispatchEvent(new CustomEvent('cobrax:version-loaded', { detail: { version: ver } }));
    }

    // 2. Dynamic Telegram Link & Handle
    const tgLink = data.telegramLink || (data.telegramAddress ? (data.telegramAddress.startsWith('http') ? data.telegramAddress : `https://${data.telegramAddress}`) : '');
    if (tgLink) {
      document.querySelectorAll('a[href*="t.me"], a.footer-tg, .dynamic-telegram-link, #telegram-link').forEach(a => {
        a.href = tgLink;
      });

      let rawHandle = tgLink.replace(/^https?:\/\/(www\.)?t\.me\//i, '').replace(/^\/+/, '').split('?')[0].split('#')[0];
      if (rawHandle) {
        const atHandle = rawHandle.startsWith('@') ? rawHandle : '@' + rawHandle;
        document.querySelectorAll('.dynamic-telegram-handle, #telegram-handle').forEach(el => {
          el.textContent = atHandle;
        });
      }
    }
    // 3. Dynamic Direct APK Download Link (Only for actual download trigger buttons, not navigation)
    const directDownloadUrl = data.updateUrl || '/api/app/download';
    document.querySelectorAll('#download-apk-btn, .direct-apk-download').forEach(a => {
      a.href = directDownloadUrl;
    });
  } catch (_) {}
}

/* ─── Referral Capture Helper ───────────────────── */
function captureReferralCode() {
  try {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref') || params.get('agent') || params.get('code') || params.get('referral');
    if (ref && ref.trim()) {
      const cleanRef = ref.trim().toUpperCase();
      sessionStorage.setItem('cbx_ref', cleanRef);
      localStorage.setItem('cbx_ref', cleanRef);
    }
  } catch (_) {}
}

function getStoredReferralCode() {
  try {
    return sessionStorage.getItem('cbx_ref') || localStorage.getItem('cbx_ref') || null;
  } catch (_) { return null; }
}

/* ─── Init on DOM ready ──────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  captureReferralCode();
  initNav();
  initReveal();
  loadPublicSiteSettings();
});
