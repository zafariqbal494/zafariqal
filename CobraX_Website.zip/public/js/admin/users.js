/**
 * CobraX Admin Panel — Users & Agents Module
 * User directory, agent referral system, modal forms, affiliate commission & stats.
 */
'use strict';

let editingAgentId = null;
let _usersCurrentPage = 1;
let _usersLimit = 25;
let _usersSearch = '';
let _usersSearchTimeout = null;

async function loadUsers() {
  const tbody = document.getElementById('users-tbody');
  if (tbody) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-dim);">Loading users...</td></tr>';
  }

  try {
    const searchInput = document.getElementById('users-search');
    if (searchInput) _usersSearch = searchInput.value.trim();

    const url = `/api/admin/users?page=${_usersCurrentPage}&limit=${_usersLimit}&search=${encodeURIComponent(_usersSearch)}`;
    const data = await adminFetch(url);
    if (!data.success) { handleAuthError(data); return; }

    // Update KPI stats cards
    if (data.stats) {
      const s = data.stats;
      const elTotal      = document.getElementById('users-stat-total');
      const elToday      = document.getElementById('users-stat-today');
      const elPaying     = document.getElementById('users-stat-paying');
      const elConversion = document.getElementById('users-stat-conversion');

      if (elTotal)      elTotal.textContent      = Number(s.totalUsers || 0).toLocaleString();
      if (elToday)      elToday.textContent      = Number(s.registeredToday || 0).toLocaleString();
      if (elPaying)     elPaying.textContent     = Number(s.payingUsers || 0).toLocaleString();
      if (elConversion) elConversion.textContent = `${s.conversionRate || 0}%`;
    }

    if (!tbody) return;
    tbody.innerHTML = '';

    const users = data.users || [];
    if (!users.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:28px;color:var(--text-dim);">No registered users found matching your search.</td></tr>';
      updateUsersPagination(0, 0, 1, 1);
      return;
    }

    const startIndex = (data.page - 1) * data.limit;
    users.forEach((u, i) => {
      const tr = document.createElement('tr');
      const paidCount = parseInt(u.paid_orders || 0, 10);
      const totalCount = parseInt(u.total_orders || 0, 10);
      const paidBadge = paidCount > 0
        ? `<span class="badge-ok" style="cursor:pointer;" onclick="viewUserOrders('${escapeHtml(u.username)}', '${escapeHtml(u.email)}')" title="Click to view ${paidCount} paid orders">${paidCount} paid</span>`
        : `<span class="badge-dim">0 paid</span>`;

      const lifetimeSpend = Number(u.total_spent_pkr || 0);
      const spendHtml = lifetimeSpend > 0
        ? `<strong style="color:var(--neon); font-family:monospace;">PKR ${lifetimeSpend.toLocaleString()}</strong>`
        : '<span style="color:var(--text-dim); font-size:11px;">PKR 0</span>';

      const dateCell = `
        <div style="color:var(--text); font-weight:600;">${fmtDate(u.created_at)}</div>
        <div style="color:var(--neon); font-size:9px; font-family:monospace; margin-top:1px;">${fmtTime(u.created_at)}</div>
      `;

      tr.innerHTML = `
        <td style="color:var(--text-dim); font-size:11px;">${startIndex + i + 1}</td>
        <td><strong style="color:var(--neon); font-family:monospace;">${escapeHtml(u.username)}</strong></td>
        <td style="color:var(--text); font-size:12px;">${escapeHtml(u.email)}</td>
        <td style="text-align:center; font-weight:600;">${totalCount}</td>
        <td style="text-align:center;">${paidBadge}</td>
        <td>${spendHtml}</td>
        <td style="font-size:10px; white-space:nowrap;">${dateCell}</td>
        <td style="text-align:right;">
          <div style="display:flex; gap:4px; justify-content:flex-end;">
            <button class="btn-xs" style="border-color:var(--neon); color:var(--neon);" onclick="viewUserOrders('${escapeHtml(u.username)}', '${escapeHtml(u.email)}')" title="View orders placed by this customer">📦 Orders</button>
            <button class="btn-xs" style="border-color:var(--yellow, #ffc107); color:var(--yellow, #ffc107);" onclick="resetUserTrial(${u.id}, '${escapeHtml(u.email)}', '${escapeHtml(u.username)}')" title="Reset 24h VIP trial eligibility">🔄 Reset Trial</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    updateUsersPagination(data.total, users.length, data.page, data.totalPages);

  } catch (err) {
    console.error('Users load error:', err);
    if (tbody) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--red);">Failed to load users directory.</td></tr>';
    }
  }
}

function updateUsersPagination(total, count, page, totalPages) {
  const infoEl = document.getElementById('users-page-info');
  const numEl  = document.getElementById('users-page-num');
  const prevBtn= document.getElementById('users-btn-prev');
  const nextBtn= document.getElementById('users-btn-next');

  const start = total === 0 ? 0 : (page - 1) * _usersLimit + 1;
  const end   = total === 0 ? 0 : Math.min(start + count - 1, total);

  if (infoEl)  infoEl.textContent = `Showing ${start}–${end} of ${total} users`;
  if (numEl)   numEl.textContent  = `Page ${page} of ${totalPages || 1}`;
  if (prevBtn) prevBtn.disabled   = page <= 1;
  if (nextBtn) nextBtn.disabled   = page >= totalPages;
}

function searchUsers() {
  if (_usersSearchTimeout) clearTimeout(_usersSearchTimeout);
  _usersSearchTimeout = setTimeout(() => {
    _usersCurrentPage = 1;
    loadUsers();
  }, 300);
}

function changeUsersPage(delta) {
  _usersCurrentPage = Math.max(1, _usersCurrentPage + delta);
  loadUsers();
}

function changeUsersLimit(newLimit) {
  _usersLimit = parseInt(newLimit, 10) || 25;
  _usersCurrentPage = 1;
  loadUsers();
}

function viewUserOrders(username, email) {
  const searchVal = email || username;
  if (typeof showPage === 'function') {
    showPage('orders');
  } else {
    window.location.hash = '#orders';
  }

  setTimeout(() => {
    const ordersSearch = document.getElementById('orders-search');
    if (ordersSearch) {
      ordersSearch.value = searchVal;
      if (typeof CobraAdmin !== 'undefined' && CobraAdmin.Orders && CobraAdmin.Orders.loadOrders) {
        CobraAdmin.Orders.loadOrders();
      }
    }
    showToast(`🔍 Filtered orders for: ${username || email}`, 'info');
  }, 100);
}

async function resetUserTrial(userId, email, username) {
  const confirmMsg = `Are you sure you want to reset 24h VIP trial eligibility for user: ${username} (${email})?\n\nThis will allow them to activate a new 24h trial code.`;
  if (!confirm(confirmMsg)) return;

  try {
    const data = await adminFetch('/api/admin/reset-trial-account', {
      method: 'POST',
      body: JSON.stringify({ user_id: userId, email })
    });

    if (data.success) {
      showToast(`✅ ${data.message || 'Trial eligibility reset successfully.'}`, 'success');
      loadUsers();
    } else {
      showToast('❌ ' + (data.error || 'Failed to reset trial.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error resetting trial.', 'error');
  }
}

let _allAgentsCache = [];
let _agentsSearchTimeout = null;

async function loadAgents() {
  const tbody = document.getElementById('agents-tbody');
  if (tbody) tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-dim);">Loading agents...</td></tr>';

  try {
    const data = await adminFetch('/api/admin/agents');
    if (!data.success) { handleAuthError(data); return; }

    const agents = data.agents || [];
    _allAgentsCache = agents;

    // Update KPI summary cards
    const totalAgents = agents.length;
    const activeAgents = agents.filter(a => a.is_active).length;
    const totalSales = agents.reduce((acc, a) => acc + parseInt(a.total_referrals || 0, 10), 0);
    const totalRevenue = agents.reduce((acc, a) => acc + parseFloat(a.total_revenue_pkr || 0), 0);

    const elTotal   = document.getElementById('agents-stat-total');
    const elActive  = document.getElementById('agents-stat-active');
    const elSales   = document.getElementById('agents-stat-sales');
    const elRevenue = document.getElementById('agents-stat-revenue');

    if (elTotal)   elTotal.textContent   = totalAgents.toLocaleString();
    if (elActive)  elActive.textContent  = activeAgents.toLocaleString();
    if (elSales)   elSales.textContent   = totalSales.toLocaleString();
    if (elRevenue) elRevenue.textContent = `PKR ${totalRevenue.toLocaleString('en-PK', { minimumFractionDigits: 2 })}`;

    renderAgentsTable();

  } catch (err) {
    console.error('Agents load error:', err);
    if (tbody) tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--red);">Failed to load agents.</td></tr>';
  }
}

function renderAgentsTable() {
  const tbody = document.getElementById('agents-tbody');
  if (!tbody) return;

  const searchInput = document.getElementById('agents-search');
  const query = (searchInput?.value || '').trim().toLowerCase();

  let filtered = _allAgentsCache;
  if (query) {
    filtered = _allAgentsCache.filter(a =>
      (a.name && a.name.toLowerCase().includes(query)) ||
      (a.code && a.code.toLowerCase().includes(query))
    );
  }

  if (!filtered.length) {
    tbody.innerHTML = query
      ? '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-dim);">No agents matching your search.</td></tr>'
      : '<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-dim);">No agents yet. Click "+ ADD AGENT" to create your first affiliate.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map((a, i) => {
    const safeName = escapeHtml(a.name);
    const safeCode = escapeHtml(a.code);
    const salesCount = parseInt(a.total_referrals || 0, 10);
    const paidReferrals = parseInt(a.paid_referrals || 0, 10);

    const salesBadge = salesCount > 0
      ? `<span class="badge-plan mono" style="cursor:pointer; font-size:11px;" onclick="viewAgentOrders('${safeCode}')" title="Click to view ${salesCount} orders placed with this referral code">📦 ${salesCount} (${paidReferrals} paid)</span>`
      : '<span class="badge-dim">0 orders</span>';

    const statusBadge = a.is_active
      ? `<span class="badge-ok" style="cursor:pointer;" onclick="toggleAgentStatus(${a.id}, '${safeCode}')" title="Click to 1-click PAUSE this affiliate">✅ Active</span>`
      : `<span class="badge-err" style="cursor:pointer;" onclick="toggleAgentStatus(${a.id}, '${safeCode}')" title="Click to 1-click ACTIVATE this affiliate">❌ Inactive</span>`;

    return `
      <tr>
        <td style="color:var(--text-dim); font-size:11px;">${i + 1}</td>
        <td><strong style="color:var(--text);">${safeName}</strong></td>
        <td>
          <span class="mono" style="color:var(--neon); cursor:pointer; font-weight:bold;" onclick="copyAgentLink('${safeCode}')" title="Click to copy promotional link">
            ${safeCode}
          </span>
        </td>
        <td style="color:var(--neon); font-weight:bold;">${parseFloat(a.discount_percent || 0)}%</td>
        <td style="text-align:center;">${salesBadge}</td>
        <td style="color:var(--neon); font-family:monospace; font-weight:bold;">PKR ${Number(a.total_revenue_pkr || 0).toLocaleString()}</td>
        <td>${statusBadge}</td>
        <td style="text-align:right;">
          <div style="display:flex; gap:4px; justify-content:flex-end; flex-wrap:wrap;">
            <button class="btn-xs" onclick="copyAgentLink('${safeCode}')" style="border-color:rgba(0,255,65,0.4); color:var(--neon);" title="Copy Buy Key referral link">🔗 Link</button>
            <button class="btn-xs" style="border-color:var(--neon); color:var(--neon);" onclick="viewAgentStats(${parseInt(a.id)})" title="View detailed referral orders and statistics">📊 Stats</button>
            <button class="btn-xs" onclick="viewAgentOrders('${safeCode}')" title="View all orders in Orders table">📦 Orders</button>
            <button class="btn-xs" onclick="openAgentModal(${parseInt(a.id)}, '${safeName}', '${safeCode}', ${parseFloat(a.discount_percent || 0)}, ${a.is_active ? 1 : 0})" title="Edit agent settings">✏ Edit</button>
            <button class="btn-xs danger" onclick="deleteAgent(${parseInt(a.id)}, '${safeCode}')" title="Delete agent">🗑 Del</button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function searchAgents() {
  if (_agentsSearchTimeout) clearTimeout(_agentsSearchTimeout);
  _agentsSearchTimeout = setTimeout(() => {
    renderAgentsTable();
  }, 200);
}

async function toggleAgentStatus(id, code) {
  try {
    const data = await adminFetch(`/api/admin/agents/${id}/toggle`, { method: 'POST' });
    if (data.success) {
      showToast(`✅ Agent ${code} is now ${data.is_active ? 'ACTIVE' : 'INACTIVE'}.`, 'success');
      loadAgents();
    } else {
      showToast('❌ ' + (data.error || 'Failed to toggle status.'), 'error');
    }
  } catch (err) {
    showToast('❌ Error toggling agent status.', 'error');
  }
}

function viewAgentOrders(code) {
  if (typeof showPage === 'function') {
    showPage('orders');
  } else {
    window.location.hash = '#orders';
  }

  setTimeout(() => {
    const ordersSearch = document.getElementById('orders-search');
    if (ordersSearch) {
      ordersSearch.value = code;
      if (typeof CobraAdmin !== 'undefined' && CobraAdmin.Orders && CobraAdmin.Orders.loadOrders) {
        CobraAdmin.Orders.loadOrders();
      }
    }
    showToast(`🔍 Filtered orders for referral code: ${code}`, 'info');
  }, 100);
}
function copyAgentLink(code) {
  const domain = window.location.origin;
  const link = `${domain}/buy-key?ref=${encodeURIComponent(code)}`;
  if (typeof copyText === 'function') copyText(link);
  showToast(`✅ Copied Referral Link: ${link}`, 'success');
}

function copyAgentLinkFromInput() {
  const input = document.getElementById('agent-link-input');
  if (input && input.value) {
    if (typeof copyText === 'function') copyText(input.value);
    showToast(`✅ Copied: ${input.value}`, 'success');
  }
}

function openAgentModal(id, name, code, discount, active) {
  editingAgentId = id || null;
  const isEdit   = !!id;

  const setVal = (field, val) => {
    const el = document.getElementById(field);
    if (el) el.value = val;
  };

  const titleEl = document.getElementById('agent-modal-title');
  if (titleEl) titleEl.textContent = isEdit ? 'EDIT AGENT' : 'ADD AGENT';

  setVal('agent-name', name || '');
  setVal('agent-code', code || '');
  setVal('agent-discount', discount !== undefined ? discount : 10);

  const errEl = document.getElementById('agent-error');
  if (errEl) errEl.textContent = '';

  const activeGroup = document.getElementById('agent-active-group');
  if (activeGroup) activeGroup.style.display = isEdit ? 'flex' : 'none';
  if (isEdit) setVal('agent-active', active !== undefined ? String(active) : '1');

  const linkGroup = document.getElementById('agent-link-group');
  const linkInput = document.getElementById('agent-link-input');
  if (linkGroup && linkInput) {
    if (isEdit && code) {
      linkGroup.style.display = 'block';
      linkInput.value = `${window.location.origin}/buy-key?ref=${encodeURIComponent(code)}`;
    } else {
      linkGroup.style.display = 'none';
      linkInput.value = '';
    }
  }

  const modal = document.getElementById('agent-modal');
  if (modal) modal.classList.add('active');
}

function closeAgentModal() {
  const modal = document.getElementById('agent-modal');
  if (modal) modal.classList.remove('active');
  editingAgentId = null;
}

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('agent-modal');
  if (modal) {
    modal.addEventListener('click', e => {
      if (e.target.id === 'agent-modal') closeAgentModal();
    });
  }
});

async function saveAgent() {
  const name     = (document.getElementById('agent-name')?.value || '').trim();
  const code     = (document.getElementById('agent-code')?.value || '').trim().toUpperCase();
  const discount = parseFloat(document.getElementById('agent-discount')?.value);
  const active   = document.getElementById('agent-active')?.value;
  const errEl    = document.getElementById('agent-error');
  const btn      = document.getElementById('agent-save-btn');

  if (errEl) errEl.textContent = '';
  if (!name || !code) { if (errEl) errEl.textContent = 'Name and code are required.'; return; }
  if (isNaN(discount) || discount < 0 || discount > 100) { if (errEl) errEl.textContent = 'Discount must be 0–100.'; return; }

  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Saving...';
  }

  try {
    let data;
    if (editingAgentId) {
      data = await adminFetch(`/api/admin/agents/${editingAgentId}`, {
        method: 'PUT',
        body: JSON.stringify({ name, code, discount_percent: discount, is_active: parseInt(active || 1) })
      });
    } else {
      data = await adminFetch('/api/admin/agents', {
        method: 'POST',
        body: JSON.stringify({ name, code, discount_percent: discount })
      });
    }

    if (!data.success) {
      if (errEl) errEl.textContent = data.error || 'Failed to save agent.';
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'SAVE AGENT';
      }
      return;
    }

    showToast('✅ Agent saved successfully!', 'success');
    closeAgentModal();
    loadAgents();
  } catch (err) {
    if (errEl) errEl.textContent = 'Network error.';
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'SAVE AGENT';
    }
  }
}

async function deleteAgent(id, code) {
  if (!confirm(`Delete agent with code ${code}? This cannot be undone.`)) return;
  try {
    const data = await adminFetch(`/api/admin/agents/${id}`, { method: 'DELETE' });
    if (data.success) { showToast('✅ Agent deleted.', 'success'); loadAgents(); }
    else showToast('❌ ' + (data.error || 'Delete failed.'), 'error');
  } catch (err) {
    showToast('❌ Network error.', 'error');
  }
}


async function viewAgentStats(id) {
  const modal = document.getElementById('agent-stats-modal');
  if (modal) modal.classList.add('active');

  const titleEl   = document.getElementById('asm-title');
  const copyBtn   = document.getElementById('asm-copy-btn');
  const statsGrid = document.getElementById('asm-stats');
  const tbody     = document.getElementById('asm-orders-tbody');

  if (titleEl)   titleEl.textContent = 'LOADING AGENT STATS...';
  if (statsGrid) statsGrid.innerHTML = '<div style="color:var(--text-dim);">Loading metrics...</div>';
  if (tbody)     tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--text-dim);">Loading referral orders...</td></tr>';

  try {
    const data = await adminFetch(`/api/admin/agents/${id}/stats`);
    if (!data.success) {
      showToast('❌ ' + (data.error || 'Could not load stats.'), 'error');
      closeAgentStatsModal();
      return;
    }

    const a = data.agent || {};
    const s = data.stats || {};
    const uses = data.uses || [];

    if (titleEl) titleEl.textContent = `📊 AGENT: ${a.name} (CODE: ${a.code})`;
    if (copyBtn) copyBtn.onclick = () => copyAgentLink(a.code);

    if (statsGrid) {
      statsGrid.innerHTML = `
        <div class="admin-stat" style="padding:10px;">
          <div class="admin-stat-label">Discount Rate</div>
          <div class="admin-stat-val" style="color:var(--neon); font-size:1.3rem;">${parseFloat(a.discount_percent || 0)}%</div>
          <div class="admin-stat-sub">Off all VIP plans</div>
        </div>
        <div class="admin-stat" style="padding:10px;">
          <div class="admin-stat-label">Paid Orders</div>
          <div class="admin-stat-val" style="color:#00e5ff; font-size:1.3rem;">${s.paid_count || s.total || 0}</div>
          <div class="admin-stat-sub">${uses.length} total attempted</div>
        </div>
        <div class="admin-stat" style="padding:10px;">
          <div class="admin-stat-label">Total Revenue</div>
          <div class="admin-stat-val" style="color:var(--neon); font-size:1.3rem;">PKR ${Number(s.revenue || 0).toLocaleString()}</div>
          <div class="admin-stat-sub">Net generated</div>
        </div>
        <div class="admin-stat" style="padding:10px;">
          <div class="admin-stat-label">Discounts Saved</div>
          <div class="admin-stat-val" style="color:#ffaa00; font-size:1.3rem;">PKR ${Number(s.total_discount_given || 0).toLocaleString()}</div>
          <div class="admin-stat-sub">Saved by customers</div>
        </div>
      `;
    }

    if (tbody) {
      if (!uses.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:16px; color:var(--text-dim);">No referral orders recorded for this agent yet.</td></tr>';
      } else {
        tbody.innerHTML = uses.map(u => {
          const isPaid = u.order_state === '1';
          const statusBadge = isPaid
            ? '<span class="badge-ok" style="font-size:9px;">✅ Paid</span>'
            : '<span class="badge-dim" style="font-size:9px;">⏳ Pending</span>';

          const keySnippet = u.auth_key
            ? `<span class="mono" style="color:var(--neon); font-size:10px;" title="${escapeHtml(u.auth_key)}">${escapeHtml(u.auth_key.slice(0, 14))}...</span>`
            : '<span style="color:var(--text-dim); font-size:10px;">—</span>';

          const custName = u.username || u.email || 'Guest';

          return `
            <tr>
              <td>
                <span class="mono" style="color:var(--neon); font-size:10px; cursor:pointer;" onclick="openOrderDetailsModal('${escapeHtml(u.order_no)}')" title="Click to inspect order details">
                  ${escapeHtml(u.order_no)}
                </span>
              </td>
              <td><span style="color:var(--text); font-size:11px;">${escapeHtml(custName)}</span></td>
              <td>${keySnippet}</td>
              <td>${statusBadge}</td>
              <td><strong style="color:var(--neon); font-family:monospace; font-size:11px;">PKR ${parseFloat(u.discounted_pkr || 0).toLocaleString()}</strong></td>
              <td style="font-size:10px; color:var(--text-dim); white-space:nowrap;">${fmtDateTime(u.created_at)}</td>
            </tr>
          `;
        }).join('');
      }
    }

  } catch (err) {
    showToast('❌ Network error loading agent details.', 'error');
    closeAgentStatsModal();
  }
}

function closeAgentStatsModal() {
  const modal = document.getElementById('agent-stats-modal');
  if (modal) modal.classList.remove('active');
}

document.addEventListener('DOMContentLoaded', () => {
  const statsModal = document.getElementById('agent-stats-modal');
  if (statsModal) {
    statsModal.addEventListener('click', e => {
      if (e.target.id === 'agent-stats-modal') closeAgentStatsModal();
    });
  }
});

window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Users = {
  loadUsers,
  searchUsers,
  changeUsersPage,
  changeUsersLimit,
  viewUserOrders,
  resetUserTrial,
  loadAgents,
  searchAgents,
  renderAgentsTable,
  toggleAgentStatus,
  viewAgentOrders,
  openAgentModal,
  closeAgentModal,
  saveAgent,
  copyAgentLink,
  copyAgentLinkFromInput,
  viewAgentStats,
  closeAgentStatsModal,
};

