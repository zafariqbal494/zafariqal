/**
 * CobraX Admin Panel — Withdrawals & Payouts Module
 * SoliPay merchant balance refresh, 3% deduction max payouts,
 * 1-click saved beneficiary accounts, ledger re-use & status tracking.
 */
'use strict';

let _soliPayBalanceCache = { availBal: 0, froBal: 0, balance: 0 };
let _allPayoutsCache = [];
let _wdSearchTimeout = null;
const SAVED_ACCOUNTS_KEY = 'cbx_saved_payout_accounts';

async function loadWithdrawals() {
  renderSavedAccounts();
  await Promise.all([
    refreshSoliPayBalance(),
    loadPayouts()
  ]);
}

async function refreshSoliPayBalance() {
  const availEl = document.getElementById('wd-bal-avail');
  const froEl   = document.getElementById('wd-bal-frozen');
  const totalEl = document.getElementById('wd-bal-total');
  const btn     = document.getElementById('btn-refresh-balance');

  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Fetching...';
  }

  try {
    const data = await adminFetch('/api/admin/payout/balance');
    if (!data.success) {
      handleAuthError(data);
      if (availEl) availEl.textContent = 'PKR 0.00';
      if (froEl) froEl.textContent   = 'PKR 0.00';
      if (totalEl) totalEl.textContent = 'PKR 0.00';
      showToast('⚠️ ' + (data.error || 'Failed to fetch SoliPay balance.'), 'warn');
      return;
    }

    _soliPayBalanceCache = {
      availBal: parseFloat(data.availBal || 0),
      froBal:   parseFloat(data.froBal || 0),
      balance:  parseFloat(data.balance || 0),
    };

    if (availEl) availEl.textContent = `PKR ${_soliPayBalanceCache.availBal.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    if (froEl) froEl.textContent   = `PKR ${_soliPayBalanceCache.froBal.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    if (totalEl) totalEl.textContent = `PKR ${_soliPayBalanceCache.balance.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    showToast('✅ SoliPay balance refreshed!', 'success');
  } catch (err) {
    console.error('refreshSoliPayBalance error:', err);
    showToast('❌ Network error querying balance.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '↻ Refresh Balance';
    }
  }
}

function onWdMethodChange() {
  const methodEl = document.getElementById('wd-method');
  if (!methodEl) return;
  const method = methodEl.value;
  const isBank = method !== 'EASYPAISA' && method !== 'JAZZCASH';
  const mobileField = document.getElementById('wd-mobile-field');
  const acctNoLabel = document.getElementById('wd-acct-no-label');
  const acctNoHint  = document.getElementById('wd-acct-no-hint');
  const acctNoInput = document.getElementById('wd-acct-no');

  if (isBank) {
    if (mobileField) mobileField.style.display = 'flex';
    if (acctNoLabel) acctNoLabel.textContent = 'Bank Account Number / IBAN';
    if (acctNoHint) acctNoHint.textContent  = 'Enter full 14–24 digit account or IBAN number.';
    if (acctNoInput) acctNoInput.placeholder = 'e.g. 01010101010101 or PKXXMEZN...';
  } else {
    if (mobileField) mobileField.style.display = 'none';
    if (acctNoLabel) acctNoLabel.textContent = `${method === 'EASYPAISA' ? 'EasyPaisa' : 'JazzCash'} Account Number`;
    if (acctNoHint) acctNoHint.textContent  = '11-digit mobile wallet number (03XXXXXXXXX).';
    if (acctNoInput) acctNoInput.placeholder = '03001234567';
  }
}

function setWdAmount(val) {
  const input = document.getElementById('wd-amount');
  if (input) {
    input.value = val;
    updateWdAmountCalculation();
  }
}

/**
 * Calculates 3% deduction from available SoliPay balance and populates full net amount
 */
function setWdMaxAmount() {
  const avail = _soliPayBalanceCache.availBal;
  if (!avail || avail <= 0) {
    showToast('⚠️ No available withdrawal balance currently. Please click Refresh Balance first.', 'warn');
    return;
  }

  // 3% gateway deduction buffer
  const feeRate = 0.03;
  const netAmount = Math.floor(avail * (1 - feeRate));
  const feeAmount = Math.round(avail * feeRate);

  const input = document.getElementById('wd-amount');
  if (input) {
    input.value = netAmount;
  }

  const hintEl = document.getElementById('wd-amount-hint');
  if (hintEl) {
    hintEl.innerHTML = `<span style="color:var(--neon); font-weight:bold;">⚡ Max Available (-3%): PKR ${netAmount.toLocaleString()}</span> <span style="color:var(--text-dim); margin-left:6px;">(Gross: PKR ${Math.floor(avail).toLocaleString()} − 3% Gateway Buffer: PKR ${feeAmount.toLocaleString()})</span>`;
  }

  showToast(`⚡ Max available set to PKR ${netAmount.toLocaleString()} (after 3% deduction of PKR ${feeAmount.toLocaleString()})`, 'info');
}

function updateWdAmountCalculation() {
  const input = document.getElementById('wd-amount');
  const hintEl = document.getElementById('wd-amount-hint');
  if (!input || !hintEl) return;
  const amt = parseFloat(input.value);
  if (isNaN(amt) || amt <= 0) {
    hintEl.textContent = 'Amount in Pakistani Rupees (PKR) to disburse from available balance.';
    hintEl.style.color = 'var(--text-dim)';
    return;
  }
  const fee = Math.round(amt * 0.03);
  const net = Math.floor(amt * 0.97);
  hintEl.innerHTML = `<span>Amount: PKR ${amt.toLocaleString()}</span> <span style="color:var(--text-dim); margin-left:8px;">| If 3% fee applies: Net is PKR ${net.toLocaleString()} (Fee: PKR ${fee.toLocaleString()})</span>`;
}

// ── Saved Beneficiary Accounts (1-Click Reuse) ────────────────────────
function getSavedAccounts() {
  try {
    const raw = localStorage.getItem(SAVED_ACCOUNTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
}

function saveAccountToList(acc) {
  if (!acc || !acc.acctNo || !acc.acctName) return;
  let list = getSavedAccounts();
  list = list.filter(a => !(a.acctNo === acc.acctNo && a.method === acc.method));
  list.unshift({
    id: 'acc_' + Date.now(),
    method: acc.method,
    acctName: acc.acctName,
    acctNo: acc.acctNo,
    mobile: acc.mobile || '',
    savedAt: new Date().toISOString()
  });
  if (list.length > 10) list = list.slice(0, 10);
  try {
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(list));
  } catch (e) {}
  renderSavedAccounts();
}

function deleteSavedAccount(id) {
  let list = getSavedAccounts();
  list = list.filter(a => a.id !== id);
  try {
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(list));
  } catch (e) {}
  renderSavedAccounts();
  showToast('Beneficiary account removed from saved list.', 'info');
}

function selectSavedAccount(id) {
  const accounts = getSavedAccounts();
  const acc = accounts.find(a => a.id === id);
  if (!acc) return;

  const methodEl = document.getElementById('wd-method');
  const nameEl   = document.getElementById('wd-acct-name');
  const noEl     = document.getElementById('wd-acct-no');
  const mobEl    = document.getElementById('wd-mobile');

  if (methodEl) methodEl.value = acc.method;
  if (nameEl)   nameEl.value   = acc.acctName;
  if (noEl)     noEl.value     = acc.acctNo;
  if (mobEl && acc.mobile) mobEl.value = acc.mobile;

  onWdMethodChange();
  renderSavedAccounts(id);
  showToast(`⚡ 1-Click filled: ${acc.acctName} (${acc.method})`, 'success');
}

function saveCurrentFormAccount() {
  const methodEl = document.getElementById('wd-method');
  const nameEl   = document.getElementById('wd-acct-name');
  const noEl     = document.getElementById('wd-acct-no');
  const mobEl    = document.getElementById('wd-mobile');

  const method   = methodEl ? methodEl.value : 'EASYPAISA';
  const acctName = nameEl ? nameEl.value.trim() : '';
  const acctNo   = noEl ? noEl.value.trim() : '';
  const mobile   = mobEl ? mobEl.value.trim() : '';

  if (!acctName || !acctNo) {
    showToast('⚠️ Please enter Account Name and Account Number first before saving.', 'warn');
    return;
  }

  saveAccountToList({ method, acctName, acctNo, mobile });
  showToast(`⭐ Saved beneficiary account: ${acctName}!`, 'success');
}

function renderSavedAccounts(activeId = null) {
  const container = document.getElementById('wd-saved-accounts-list');
  if (!container) return;
  const accounts = getSavedAccounts();
  if (accounts.length === 0) {
    container.innerHTML = `<span style="font-size:11px; color:var(--text-dim); font-style:italic;">No saved accounts yet. Fill form below and click "💾 Save Current Form As Account" or submit a payout to enable 1-click reuse.</span>`;
    return;
  }

  container.innerHTML = accounts.map(acc => {
    let icon = '🏦';
    let shortMethod = acc.method;
    if (acc.method === 'EASYPAISA') { icon = '📱'; shortMethod = 'EasyPaisa'; }
    else if (acc.method === 'JAZZCASH') { icon = '📱'; shortMethod = 'JazzCash'; }
    else {
      const methodEl = document.getElementById('wd-method');
      if (methodEl) {
        const opt = methodEl.querySelector(`option[value="${acc.method}"]`);
        if (opt) shortMethod = opt.text.replace(/^[🏦💳📱]\s*/, '').split('(')[0].trim();
      }
    }

    const maskedNo = acc.acctNo.length > 7 ? `${acc.acctNo.slice(0, 4)}...${acc.acctNo.slice(-3)}` : acc.acctNo;
    const isActive = acc.id === activeId;
    const borderStyle = isActive ? 'border-color:var(--neon); background:rgba(0,255,65,0.12);' : 'border-color:var(--border); background:rgba(0,0,0,0.5);';

    return `
      <div class="saved-acct-pill" style="display:inline-flex; align-items:center; gap:6px; border:1px solid; border-radius:6px; padding:5px 10px; font-size:11px; cursor:pointer; transition:all 0.2s ease; ${borderStyle}"
           onclick="selectSavedAccount('${escapeHtml(acc.id)}')" title="1-Click Fill Form: ${escapeHtml(acc.acctName)} (${escapeHtml(shortMethod)})">
        <span style="font-size:13px;">${icon}</span>
        <span style="color:#fff; font-weight:600;">${escapeHtml(acc.acctName)}</span>
        <span style="color:var(--neon); font-family:monospace; font-size:10px;">${escapeHtml(shortMethod)} (${escapeHtml(maskedNo)})</span>
        <button type="button" onclick="event.stopPropagation(); deleteSavedAccount('${escapeHtml(acc.id)}')"
                style="background:none; border:none; color:var(--text-dim); cursor:pointer; font-size:12px; padding:0 3px;" title="Remove this saved account">✕</button>
      </div>
    `;
  }).join('');
}

function reuseAccountFromLedger(acctCode, acctName, acctNo, mobile) {
  const methodEl = document.getElementById('wd-method');
  const nameEl   = document.getElementById('wd-acct-name');
  const noEl     = document.getElementById('wd-acct-no');
  const mobEl    = document.getElementById('wd-mobile');

  if (methodEl) methodEl.value = acctCode;
  if (nameEl)   nameEl.value   = acctName;
  if (noEl)     noEl.value     = acctNo;
  if (mobEl && mobile) mobEl.value = mobile;

  onWdMethodChange();
  saveAccountToList({ method: acctCode, acctName, acctNo, mobile });
  document.getElementById('form-withdrawal')?.scrollIntoView({ behavior: 'smooth' });
  showToast(`⚡ 1-Click loaded details for ${acctName} (${acctCode})!`, 'success');
}

async function submitWithdrawal(e) {
  if (e && e.preventDefault) e.preventDefault();

  const methodEl = document.getElementById('wd-method');
  if (!methodEl) return;
  const method   = methodEl.value;
  const acctName = (document.getElementById('wd-acct-name')?.value || '').trim();
  const acctNo   = (document.getElementById('wd-acct-no')?.value || '').trim();
  const mobile   = (document.getElementById('wd-mobile')?.value || '').trim();
  const amount   = parseFloat(document.getElementById('wd-amount')?.value);
  const msgEl    = document.getElementById('wd-form-msg');
  const btn      = document.getElementById('btn-submit-wd');

  if (isNaN(amount) || amount <= 0) {
    showToast('⚠️ Please enter a valid withdrawal amount.', 'warn');
    return;
  }
  if (!acctName) {
    showToast('⚠️ Please enter the recipient account name.', 'warn');
    return;
  }
  if (!acctNo) {
    showToast('⚠️ Please enter the account number / IBAN.', 'warn');
    return;
  }
  const isBank = method !== 'EASYPAISA' && method !== 'JAZZCASH';
  if (isBank && (!mobile || !mobile.startsWith('03'))) {
    showToast('⚠️ Valid mobile number starting with 03 is required for bank card payout.', 'warn');
    return;
  }

  const methodLabel = methodEl.options[methodEl.selectedIndex].text;
  const confirmMsg = `Are you sure you want to disburse PKR ${amount.toLocaleString()} to:\n\n• Name: ${acctName}\n• Channel: ${methodLabel}\n• Account: ${acctNo}\n\nClick OK to proceed with disbursement.`;
  if (!confirm(confirmMsg)) return;

  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Disbursing...';
  }
  if (msgEl) {
    msgEl.textContent = 'Submitting payout to SoliPay gateway...';
    msgEl.style.color = 'var(--text-dim)';
  }

  try {
    const res = await adminFetch('/api/admin/payout/create', {
      method: 'POST',
      body: JSON.stringify({
        amount,
        acctName,
        acctCode: method,
        acctNo,
        mobile: isBank ? mobile : undefined,
      })
    });

    if (res.success) {
      showToast(`✅ Withdrawal order created: ${res.orderNo}`, 'success');
      if (msgEl) {
        msgEl.textContent = `✅ Order ${res.orderNo} submitted! Status: Processing`;
        msgEl.style.color = 'var(--neon)';
      }

      // Auto-save account if checkbox checked
      const autoSave = document.getElementById('wd-auto-save')?.checked;
      if (autoSave) {
        saveAccountToList({ method, acctName, acctNo, mobile: isBank ? mobile : '' });
      }

      document.getElementById('form-withdrawal')?.reset();
      onWdMethodChange();
      await loadWithdrawals();
    } else {
      showToast('❌ ' + (res.error || 'Withdrawal failed.'), 'error');
      if (msgEl) {
        msgEl.textContent = '❌ ' + (res.error || 'Failed.');
        msgEl.style.color = 'var(--red)';
      }
    }
  } catch (err) {
    console.error('submitWithdrawal error:', err);
    showToast('❌ Network error submitting withdrawal.', 'error');
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '⚡ SUBMIT WITHDRAWAL';
    }
  }
}

async function loadPayouts() {
  const tbody = document.getElementById('payouts-tbody');
  if (!tbody) return;
  const search = (document.getElementById('wd-search')?.value || '').trim();

  try {
    const data = await adminFetch(`/api/admin/payouts?search=${encodeURIComponent(search)}`);
    if (!data.success) { handleAuthError(data); return; }

    const payouts = data.payouts || [];
    _allPayoutsCache = payouts;

    // Update stats
    if (data.stats) {
      const elWithdrawn = document.getElementById('wd-stat-total-withdrawn');
      const elPending = document.getElementById('wd-stat-pending');
      if (elWithdrawn) elWithdrawn.textContent = `PKR ${parseFloat(data.stats.totalWithdrawn || 0).toLocaleString('en-PK', { minimumFractionDigits: 2 })}`;
      if (elPending) elPending.textContent = data.stats.pendingCount || 0;
    }

    if (payouts.length === 0) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center; padding:28px; color:var(--text-dim);">No payout records found.</td></tr>';
      return;
    }

    tbody.innerHTML = payouts.map(p => {
      let statusBadge = '<span class="status-pill status-pending">⏳ Processing (0)</span>';
      if (p.status === '1') {
        statusBadge = '<span class="status-pill status-paid">✅ Success (1)</span>';
      } else if (p.status === '2' || p.status === '4') {
        statusBadge = `<span class="status-pill" style="color:var(--red);border-color:var(--red);">❌ Failed (${p.status})</span>`;
      } else if (p.status === '5') {
        statusBadge = '<span class="status-pill" style="color:#ffaa00;border-color:#ffaa00;">↩ Reversed (5)</span>';
      } else if (p.status === '6') {
        statusBadge = '<span class="status-pill status-pending">⚡ Disbursing (6)</span>';
      }

      let channelDisplay = p.acct_code;
      if (p.acct_code === 'EASYPAISA') channelDisplay = '📱 EasyPaisa';
      else if (p.acct_code === 'JAZZCASH') channelDisplay = '📱 JazzCash';
      else channelDisplay = `🏦 Bank (${escapeHtml(p.acct_code)})`;

      const errorNote = p.error_msg ? `<span style="color:var(--red);font-size:10px;">${escapeHtml(p.error_msg)}</span>` : (p.business_no ? `<span style="color:var(--text-dim);font-size:10px;">Ref: ${escapeHtml(p.business_no)}</span>` : '—');

      return `
        <tr>
          <td><span style="font-family:monospace; color:var(--neon); font-size:11px; font-weight:bold;">${escapeHtml(p.order_no)}</span></td>
          <td><strong style="color:var(--text);">${escapeHtml(p.acct_name)}</strong></td>
          <td><span style="color:var(--text-mid);">${channelDisplay}</span></td>
          <td><span style="font-family:monospace; color:var(--text);">${escapeHtml(p.acct_no)}</span></td>
          <td><strong style="color:var(--neon); font-size:13px;">PKR ${parseFloat(p.amount).toLocaleString('en-PK', { minimumFractionDigits: 2 })}</strong></td>
          <td>${statusBadge}</td>
          <td>${errorNote}</td>
          <td>
            <div style="color:var(--text); font-weight:600;">${fmtDate(p.created_at)}</div>
            <div style="color:var(--neon); font-size:9px; font-family:monospace; margin-top:1px;">${fmtTime(p.created_at)}</div>
          </td>
          <td style="text-align:right;">
            <div style="display:flex; gap:4px; justify-content:flex-end;">
              <button class="btn-xs" style="border-color:var(--neon); color:var(--neon);" onclick="reuseAccountFromLedger('${escapeHtml(p.acct_code)}', '${escapeHtml(p.acct_name)}', '${escapeHtml(p.acct_no)}', '${escapeHtml(p.mobile || '')}')" title="1-Click reuse these details in withdrawal form">⭐ Reuse</button>
              <button class="btn-xs" onclick="queryPayoutStatus('${escapeHtml(p.order_no)}', this)" title="Query latest status from gateway">↻ Status</button>
            </div>
          </td>
        </tr>`;
    }).join('');
  } catch (err) {
    console.error('loadPayouts error:', err);
  }
}

function searchPayouts() {
  if (_wdSearchTimeout) clearTimeout(_wdSearchTimeout);
  _wdSearchTimeout = setTimeout(() => loadPayouts(), 300);
}

async function queryPayoutStatus(orderNo, btn) {
  if (btn) {
    btn.disabled = true;
    btn.textContent = '...';
  }
  try {
    const data = await adminFetch('/api/admin/payout/query', {
      method: 'POST',
      body: JSON.stringify({ orderNo })
    });
    if (data.success) {
      const statusText = data.status === '1' ? 'Success (1)' : (data.status === '2' || data.status === '4' ? `Failed (${data.status})` : `Status: ${data.status}`);
      showToast(`Order ${orderNo}: ${statusText}`, data.status === '1' ? 'success' : 'warn');
      await loadWithdrawals();
    } else {
      showToast('❌ ' + (data.error || 'Query failed.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error querying order.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '↻ Status';
    }
  }
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Withdrawals = {
  loadWithdrawals,
  refreshSoliPayBalance,
  setWdAmount,
  setWdMaxAmount,
  updateWdAmountCalculation,
  getSavedAccounts,
  saveAccountToList,
  deleteSavedAccount,
  selectSavedAccount,
  saveCurrentFormAccount,
  renderSavedAccounts,
  reuseAccountFromLedger,
  submitWithdrawal,
  loadPayouts,
  searchPayouts,
  queryPayoutStatus,
};
