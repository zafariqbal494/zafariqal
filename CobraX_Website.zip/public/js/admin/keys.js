/**
 * CobraX Admin Panel — License Keys Module
 * Key generator, batch copying, key table rendering & key deletion/revocation.
 */
'use strict';

let _generatedKeysCache = [];

async function loadKeysManager() {
  await Promise.all([
    loadKeys(),
    renderKeyGenGamesList()
  ]);
}

async function renderKeyGenGamesList() {
  const container = document.getElementById('kg-games-grid');
  if (!container) return;

  let gamesList = [];
  if (typeof _adminGamesState !== 'undefined' && Array.isArray(_adminGamesState) && _adminGamesState.length > 0) {
    gamesList = _adminGamesState.map(g => g.name || g);
  } else {
    try {
      const data = await adminFetch('/api/admin/games');
      if (data.success && Array.isArray(data.games)) {
        gamesList = data.games.map(g => g.name || g);
      }
    } catch (_) {}
  }

  if (!gamesList.length) {
    gamesList = ['FantasyGems', '92Pak', '92Jeeto', 'BasantClub', '92Pkr', '92Dadu', '92Glory', '92Coco'];
  }

  container.innerHTML = gamesList.map(name => `
    <label style="display:inline-flex; align-items:center; gap:6px; font-size:11px; color:var(--text); cursor:pointer; user-select:none;">
      <input type="checkbox" class="kg-game-chk" value="${escapeHtml(name)}" style="accent-color:var(--neon); cursor:pointer;">
      <span>${escapeHtml(name)}</span>
    </label>
  `).join('');
}

async function generateManualKeys() {
  const btn = document.getElementById('btn-generate-keys');
  const plan = document.getElementById('kg-plan')?.value || '30';
  const count = document.getElementById('kg-count')?.value || '1';
  const note = document.getElementById('kg-note')?.value || '';
  const resultBox = document.getElementById('kg-result-box');
  const keysListEl = document.getElementById('kg-keys-list');
  const resultTitle = document.getElementById('kg-result-title');

  // Collect checked games
  const checkedBoxes = document.querySelectorAll('.kg-game-chk:checked');
  const selectedGames = Array.from(checkedBoxes).map(cb => cb.value);

  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Generating Keys...';
  }

  try {
    const data = await adminFetch('/api/admin/keys/generate', {
      method: 'POST',
      body: JSON.stringify({ plan, count, note, selected_games: selectedGames })
    });

    if (data.success && Array.isArray(data.keys)) {
      _generatedKeysCache = data.keys;
      const planLabel = data.plan === '1' ? '24 Hours (1 Day Trial)' : '30 Days (Cobra VIP)';
      const gamesDesc = selectedGames.length > 0 ? ` (${selectedGames.join(', ')})` : ' (All Games)';
      if (resultTitle) resultTitle.textContent = `✅ GENERATED ${data.count} KEY(S) [${planLabel}${gamesDesc}]:`;
      if (keysListEl) keysListEl.innerHTML = data.keys.map(k => `<div>🔑 <span style="color:var(--neon);font-weight:bold;">${escapeHtml(k)}</span></div>`).join('');
      if (resultBox) resultBox.style.display = 'block';
      showToast(`✅ Successfully generated ${data.count} VIP key(s)!`, 'success');
      loadKeys();
    } else {
      showToast('❌ ' + (data.error || 'Failed to generate keys.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '⚡ GENERATE KEYS NOW';
    }
  }
}

function copyGeneratedKeys() {
  if (!_generatedKeysCache.length) return;
  const text = _generatedKeysCache.join('\n');
  const btn = document.getElementById('btn-copy-all-keys');
  if (typeof copyText === 'function') copyText(text, btn);
}

async function loadKeys() {
  const tbody = document.getElementById('keys-tbody');
  if (!tbody) return;
  try {
    const data = await adminFetch('/api/admin/keys');
    if (!data.success) { handleAuthError(data); return; }

    const keys = data.keys || [];
    if (keys.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:24px; color:var(--text-dim);">No generated keys found.</td></tr>';
      return;
    }

    tbody.innerHTML = keys.map((k, idx) => {
      const isBound = !!k.device_id;
      const statusBadge = isBound
        ? '<span class="status-pill status-paid">🟢 Bound / Active</span>'
        : '<span class="status-pill status-pending" style="color:var(--text-dim);border-color:var(--border);">⚪ Unused</span>';
      const planBadge = k.duration_days == 1
        ? '<span style="color:#00e5ff;font-weight:bold;">24 Hours</span>'
        : '<span style="color:var(--neon);font-weight:bold;">30 Days</span>';

      return `
        <tr>
          <td>${idx + 1}</td>
          <td><span style="font-family:monospace; color:var(--text); font-weight:bold;">${escapeHtml(k.key)}</span></td>
          <td>${planBadge}</td>
          <td><span style="font-family:monospace; font-size:11px; color:var(--text-dim);">${escapeHtml(k.device_id || '—')}</span></td>
          <td>${statusBadge}</td>
          <td>${fmtDate(k.activated_at)}</td>
          <td>${fmtDate(k.expires_at)}</td>
          <td style="text-align:right;">
            <button class="btn-xs" style="margin-right:6px;" onclick="copyText('${escapeHtml(k.key)}', this)">📋 Copy</button>
            <button class="btn-xs danger" onclick="deleteKey(${parseInt(k.id)})">✕ Delete</button>
          </td>
        </tr>`;
    }).join('');
  } catch (err) {
    console.error('loadKeys error:', err);
  }
}

async function deleteKey(id) {
  if (!confirm('Are you sure you want to delete/revoke this VIP key?')) return;
  try {
    const data = await adminFetch('/api/admin/keys/' + id, { method: 'DELETE' });
    if (data.success) {
      showToast('✅ Key deleted successfully.', 'success');
      loadKeys();
    } else {
      showToast('❌ ' + (data.error || 'Delete failed.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error.', 'error');
  }
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Keys = {
  loadKeysManager,
  loadKeys,
  generateManualKeys,
  copyGeneratedKeys,
  deleteKey,
  renderKeyGenGamesList,
};

