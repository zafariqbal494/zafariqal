/**
 * CobraX Admin Panel — Dashboard Module
 * Real-time financial KPIs, user & telemetry tracking, dynamic plan breakdown,
 * 7-day sales volume table & live recent paid transactions feed.
 */
'use strict';

// ─── Main Dashboard Loader ────────────────────────────────────────────
async function loadDashboard() {
  try {
    const data = await adminFetch('/api/admin/dashboard');
    if (!data.success) { handleAuthError(data); return; }

    const s = data.stats;
    const setTxt = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val !== null && val !== undefined ? val : '—';
    };

    // 1. Financial KPIs
    const revToday = parseFloat(s.revenueTodayPkr || 0);
    const revYest  = parseFloat(s.revenueYesterdayPkr || 0);
    setTxt('ds-rev-today', 'PKR ' + revToday.toLocaleString('en-PK', { minimumFractionDigits: 0 }));
    
    // Revenue Delta indicator
    const revDeltaEl = document.getElementById('ds-rev-delta');
    if (revDeltaEl) {
      if (revYest === 0 && revToday > 0) {
        revDeltaEl.className = 'dash-stat-delta up';
        revDeltaEl.textContent = `▲ First sales today! (PKR ${revToday.toLocaleString()})`;
      } else if (revYest > 0) {
        const pct = Math.round(((revToday - revYest) / revYest) * 100);
        if (pct > 0) {
          revDeltaEl.className = 'dash-stat-delta up';
          revDeltaEl.textContent = `▲ +${pct}% vs yesterday (PKR ${revYest.toLocaleString()})`;
        } else if (pct < 0) {
          revDeltaEl.className = 'dash-stat-delta down';
          revDeltaEl.textContent = `▼ ${pct}% vs yesterday (PKR ${revYest.toLocaleString()})`;
        } else {
          revDeltaEl.className = 'dash-stat-delta flat';
          revDeltaEl.textContent = `● Same as yesterday (PKR ${revYest.toLocaleString()})`;
        }
      } else {
        revDeltaEl.className = 'dash-stat-delta flat';
        revDeltaEl.textContent = 'PKR confirmed today';
      }
    }

    // Orders Today & Yesterday
    const ordToday = parseInt(s.ordersToday || 0, 10);
    const ordYest  = parseInt(s.ordersYesterday || 0, 10);
    setTxt('ds-orders-today', ordToday);
    setTxt('ds-orders-yesterday', ordYest);
    const ordDeltaEl = document.getElementById('ds-orders-today-delta');
    if (ordDeltaEl) {
      const diff = ordToday - ordYest;
      if (diff > 0) {
        ordDeltaEl.style.color = 'var(--neon)';
        ordDeltaEl.textContent = `(▲ +${diff})`;
      } else if (diff < 0) {
        ordDeltaEl.style.color = 'var(--red)';
        ordDeltaEl.textContent = `(▼ ${diff})`;
      } else {
        ordDeltaEl.style.color = 'var(--text-dim)';
        ordDeltaEl.textContent = `(● 0)`;
      }
    }

    // SoliPay Gateway Float
    const spValEl = document.getElementById('ds-solipay-balance');
    const spSubEl = document.getElementById('ds-solipay-sub');
    if (data.solipayBalance) {
      if (spValEl) spValEl.textContent = 'PKR ' + Number(data.solipayBalance.availBal).toLocaleString('en-PK', { minimumFractionDigits: 2 });
      if (spSubEl) spSubEl.textContent = `Total: PKR ${Number(data.solipayBalance.balance).toLocaleString()} | Frozen: PKR ${Number(data.solipayBalance.froBal).toLocaleString()}`;
    } else {
      if (spValEl) spValEl.textContent = 'Configured';
      if (spSubEl) spSubEl.textContent = 'Click Withdrawals to query live balance';
    }

    // 2. License Metrics
    setTxt('ds-active', s.activeKeys);
    setTxt('ds-expiring-soon', s.expiringKeysSoon);

    // 3. User Metrics: Today + Total
    setTxt('ds-users-today', s.usersToday);
    setTxt('ds-users', s.totalUsers);

    // 4. App Telemetry: Today + Total Installs, Active Today
    setTxt('ds-installs-today', s.installsToday);
    setTxt('ds-installs', s.totalInstalls);
    setTxt('ds-active-today', s.activeToday);

    // 5. Dynamic Sales by Plan Breakdown
    renderPlanBreakdown(data.planBreakdown || [], s.totalOrders || 1);

    // 6. 7-Day Sales Volume Table (as it was earlier)
    renderRecentOrders(data.recentOrders || []);

    // 7. Recent Paid Transactions Feed (without order # or eye button)
    renderRecentPaidTransactions(data.latestOrders || []);

  } catch (err) {
    console.error('Dashboard load error:', err);
  }
}

// ─── Dynamic Plan Breakdown ───────────────────────────────────────────
function renderPlanBreakdown(breakdown, totalPaidOrders) {
  const container = document.getElementById('dash-plan-cards');
  if (!container) return;

  if (!breakdown.length) {
    container.innerHTML = '<div style="text-align:center; padding:16px; color:var(--text-dim);">No paid sales recorded yet.</div>';
    return;
  }

  const planTitles = {
    '1':       { label: '⚡ 24 Hours Pass',  icon: '⚡', color: 'var(--neon)' },
    '30':      { label: '👑 30-Day VIP Key', icon: '👑', color: '#ffb800' },
    'custom':  { label: '🔗 Custom Invoices',icon: '🔗', color: '#00e5ff' },
    'deposit': { label: '🎮 Game Deposits',  icon: '🎮', color: '#b24bf3' },
  };

  container.innerHTML = breakdown.map(p => {
    const info  = planTitles[String(p.plan)] || { label: `Plan ${p.plan}`, icon: '📦', color: '#fff' };
    const pct   = totalPaidOrders > 0 ? Math.round((p.count / totalPaidOrders) * 100) : 0;
    const rev   = parseFloat(p.revenue || 0);

    return `
      <div class="plan-breakdown-card" style="border-top: 2px solid ${info.color};">
        <div style="font-size:11px; font-weight:bold; color:${info.color}; text-transform:uppercase; letter-spacing:1px; margin-bottom:6px;">
          ${escapeHtml(info.label)}
        </div>
        <div class="admin-stat-val" style="font-size:1.6rem; color:#fff;">
          ${p.count} <span style="font-size:11px; color:var(--text-dim); font-weight:normal;">(${pct}%)</span>
        </div>
        <div style="font-size:11px; color:var(--text-dim); margin-top:4px;">
          PKR ${rev.toLocaleString()}
        </div>
      </div>
    `;
  }).join('');
}

// ─── 7-Day Sales Volume Table (As it was earlier) ─────────────────────
function renderRecentOrders(recentOrders) {
  const tbody = document.getElementById('dash-recent-tbody');
  if (!tbody) return;

  tbody.innerHTML = '';
  if (!recentOrders || !recentOrders.length) {
    tbody.innerHTML = '<tr><td colspan="2" style="text-align:center; padding:16px; color:var(--text-dim);">No orders in last 7 days</td></tr>';
    return;
  }

  recentOrders.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${escapeHtml(r.day)}</td><td class="admin-stat-val" style="font-size:1.1rem; color:var(--neon);">${escapeHtml(r.count)}</td>`;
    tbody.appendChild(tr);
  });
}

// ─── Recent Paid Transactions Feed (No Order # or Eye button) ─────────
function renderRecentPaidTransactions(latestOrders) {
  const tbody = document.getElementById('dash-live-paid-tbody');
  if (!tbody) return;

  if (!latestOrders || !latestOrders.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px; color:var(--text-dim);">No paid transactions recorded yet.</td></tr>';
    return;
  }

  tbody.innerHTML = latestOrders.map(o => {
    const statusBadge = '<span class="status-pill status-paid" style="font-size:10px;">✅ Paid</span>';
    const customer = o.username || (o.email ? o.email.split('@')[0] : 'Guest User');
    const planPill = o.plan === '1' ? '⚡ 24h Pass' : (o.plan === '30' ? '👑 30d VIP' : (o.plan === 'deposit' ? '🎮 Deposit' : (o.plan === 'custom' ? '🔗 Custom' : o.plan)));

    return `
      <tr>
        <td>
          <div style="font-weight:600; color:#fff; font-size:12px;">${escapeHtml(customer)}</div>
          ${o.email ? `<div style="font-size:10px; color:var(--text-dim);">${escapeHtml(o.email)}</div>` : ''}
          ${o.confirmed_at ? `<div style="font-size:9px; color:var(--neon); font-family:monospace; margin-top:2px;">${fmtDateTime(o.confirmed_at)}</div>` : ''}
        </td>
        <td>
          <span class="plan-pill" style="font-size:10px; padding:2px 8px;">${escapeHtml(planPill)}</span>
        </td>
        <td style="font-weight:bold; color:var(--neon);">
          PKR ${Number(o.amount).toLocaleString()}
        </td>
        <td style="text-align:right;">${statusBadge}</td>
      </tr>
    `;
  }).join('');
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Dashboard = {
  loadDashboard,
};
