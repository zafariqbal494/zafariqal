/**
 * CobraX Admin Panel — Custom Payment Links Module
 * Dynamic $150 invoice generator, live exchange rate preview, note template builder,
 * order cross-linking, audit protection & status lifecycle management.
 */
'use strict';

let currentExchangeRate = 280;

function updatePkrPreview() {
  const amountInput = document.getElementById('pl-amount');
  const previewEl   = document.getElementById('pl-amount-pkr-preview');
  if (!amountInput || !previewEl) return;

  const usd = parseFloat(amountInput.value) || 0;
  const pkr = Math.round(usd * currentExchangeRate * 100) / 100;
  previewEl.textContent = `≈ PKR ${pkr.toLocaleString('en-PK', { minimumFractionDigits: 2 })} (Live Rate: ${currentExchangeRate} PKR/USD)`;
}

function fillSampleTemplate() {
  const usernameEl = document.getElementById('pl-cfg-user');
  const gameNameEl = document.getElementById('pl-cfg-game');
  const gameIdEl   = document.getElementById('pl-cfg-game-id');
  const reqLevelEl = document.getElementById('pl-cfg-level');

  if (usernameEl) usernameEl.value = 'Ashraf';
  if (gameNameEl) gameNameEl.value = '92pak';
  if (gameIdEl)   gameIdEl.value   = '879784';
  if (reqLevelEl) reqLevelEl.value = '4';

  updatePaymentLinkNoteTemplate();
}

function updatePaymentLinkNoteTemplate() {
  const usernameEl = document.getElementById('pl-cfg-user');
  const gameNameEl = document.getElementById('pl-cfg-game');
  const gameIdEl   = document.getElementById('pl-cfg-game-id');
  const reqLevelEl = document.getElementById('pl-cfg-level');

  if (!usernameEl || !gameNameEl || !gameIdEl || !reqLevelEl) return;

  const username = usernameEl.value.trim();
  const gameName = gameNameEl.value.trim();
  const gameId   = gameIdEl.value.trim();
  const reqLevel = reqLevelEl.value.trim();

  const userField = document.getElementById('pl-user');
  if (userField && username) {
    userField.value = username;
  }

  if (username || gameName || gameId || reqLevel) {
    const u = username || 'Customer';
    const g = gameName || 'Game';
    const id = gameId || '-';
    const lvl = reqLevel || '-';
    const templateText = `详细说明：Hi ${u}，您申请将您的账户升级，具体信息如下：\n\n游戏：${g}\nID：${id}\n所需等级：${lvl}级\n\n请确认您是否已完成付款，以便我们为您处理账户升级申请。谢谢！`;
    const noteArea = document.getElementById('pl-note');
    if (noteArea) {
      noteArea.value = templateText;
    }
  }
}

async function loadPaymentLinks() {
  const tbody = document.getElementById('paylinks-table-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:var(--text-dim); padding:24px;">Loading payment links...</td></tr>';

  try {
    const data = await adminFetch('/api/admin/payment-links');
    if (!data.success) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:var(--red); padding:24px;">${escapeHtml(data.error || 'Failed to load links')}</td></tr>`;
      return;
    }

    if (data.exchangeRate) {
      currentExchangeRate = parseFloat(data.exchangeRate);
      updatePkrPreview();
    }

    const links = data.links || [];
    if (links.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:var(--text-dim); padding:24px;">No custom payment links created yet. Use the form above to generate your first link!</td></tr>';
      return;
    }

    tbody.innerHTML = links.map(link => {
      const isPaid = link.status === 'paid';
      const isCancelled = link.status === 'cancelled';
      const statusBadge = isPaid
        ? '<span class="badge-ok">✅ PAID</span>'
        : isCancelled
          ? '<span class="badge-err">❌ CANCELLED</span>'
          : '<span class="badge-dim" style="color:var(--yellow, #ffc107); border-color:rgba(255,193,7,0.4);">⏳ PENDING</span>';

      // Associated Order
      let orderCell = '<span class="badge-dim">—</span>';
      if (link.order_no) {
        orderCell = `<span class="badge-plan mono" style="cursor:pointer; font-size:10px; padding:2px 6px;" onclick="openOrderDetailsModal('${escapeHtml(link.order_no)}')" title="Click to inspect associated order">📦 ${escapeHtml(link.order_no)}</span>`;
      }

      // Date / Time cell
      const dateCell = `
        <div style="color:var(--text); font-weight:600;">${fmtDate(link.created_at)}</div>
        <div style="color:var(--neon); font-size:9px; font-family:monospace; margin-top:1px;">${fmtTime(link.created_at)}</div>
        ${isPaid && link.paid_at ? `<div style="color:#00e5ff; font-size:9px; margin-top:2px;" title="Paid timestamp">Paid: ${fmtTime(link.paid_at)}</div>` : ''}
      `;

      // Actions cell
      let actionsHtml = `
        <div style="display:flex; gap:4px; justify-content:flex-end; align-items:center;">
          <button class="btn btn-xs" style="border-color:var(--neon); color:var(--neon); font-size:10px; padding:3px 7px;" onclick="copyText('${escapeHtml(link.url)}', this)" title="Copy shareable checkout URL">📋 Copy</button>
      `;

      if (!isPaid && !isCancelled) {
        actionsHtml += `
          <button class="btn btn-xs" style="border-color:var(--yellow, #ffc107); color:var(--yellow, #ffc107); font-size:10px; padding:3px 7px;" onclick="cancelPaymentLink(${link.id})" title="Cancel this link to prevent payment">🚫 Cancel</button>
        `;
      }

      if (!isPaid) {
        actionsHtml += `
          <button class="btn btn-xs danger" style="font-size:10px; padding:3px 7px;" onclick="deletePaymentLink(${link.id})" title="Delete link record">🗑️ Delete</button>
        `;
      } else {
        actionsHtml += `
          <span class="badge-dim" style="font-size:9px; padding:2px 6px;" title="Paid financial invoices are locked for accounting audit">🔒 Locked</span>
        `;
      }

      actionsHtml += `</div>`;

      return `
        <tr>
          <td class="mono">
            <span style="cursor:pointer; color:var(--neon); font-weight:bold;" onclick="copyText('${escapeHtml(link.url)}', this)" title="Click to copy link URL">
              ${escapeHtml(link.link_id)}
            </span>
          </td>
          <td>
            <strong>${escapeHtml(link.title)}</strong>
            ${link.note ? `<br><small style="color:var(--text-dim); display:inline-block; max-width:240px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(link.note)}</small>` : ''}
          </td>
          <td style="font-weight:bold; color:#fff;">$${parseFloat(link.amount_usd).toFixed(2)}</td>
          <td style="color:var(--neon); font-family:monospace;">PKR ${parseFloat(link.amount_pkr).toLocaleString()}</td>
          <td>${link.user_identifier ? escapeHtml(link.user_identifier) : '<span style="color:var(--text-dim);">—</span>'}</td>
          <td>${statusBadge}</td>
          <td>${orderCell}</td>
          <td style="font-size:10px; white-space:nowrap;">${dateCell}</td>
          <td style="text-align:right;">${actionsHtml}</td>
        </tr>
      `;
    }).join('');

  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:var(--red); padding:24px;">Error loading payment links. Network failure.</td></tr>';
  }
}

async function createPaymentLink() {
  const btn = document.getElementById('btn-create-paylink');
  const title = document.getElementById('pl-title')?.value || '';
  const amount_usd = document.getElementById('pl-amount')?.value || '150';
  const user_identifier = document.getElementById('pl-user')?.value || '';
  const note = document.getElementById('pl-note')?.value || '';

  if (!amount_usd || parseFloat(amount_usd) <= 0) {
    showToast('❌ Please specify a valid USD amount.', 'error');
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ GENERATING LINK...';
  }

  try {
    const data = await adminFetch('/api/admin/payment-links/create', {
      method: 'POST',
      body: JSON.stringify({ title, amount_usd, user_identifier, note })
    });

    if (btn) {
      btn.disabled = false;
      btn.textContent = '⚡ GENERATE PAYMENT LINK';
    }

    if (!data.success) {
      showToast('❌ ' + (data.error || 'Failed to create payment link.'), 'error');
      return;
    }

    showToast('✅ Payment link generated successfully!', 'success');

    const resUrl = document.getElementById('pl-result-url');
    const resBox = document.getElementById('pl-result-box');
    if (resUrl) resUrl.value = data.url;
    if (resBox) resBox.style.display = 'block';

    loadPaymentLinks();

  } catch (err) {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '⚡ GENERATE PAYMENT LINK';
    }
    showToast('❌ Network error generating payment link.', 'error');
  }
}

async function cancelPaymentLink(id) {
  if (!confirm('Are you sure you want to CANCEL this payment link?\n\nThe customer will no longer be able to complete payment on this link.')) return;
  try {
    const data = await adminFetch(`/api/admin/payment-links/${id}/cancel`, { method: 'POST' });
    if (data.success) {
      showToast('✅ Payment link cancelled.', 'success');
      loadPaymentLinks();
    } else {
      showToast('❌ ' + (data.error || 'Cancellation failed.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error cancelling link.', 'error');
  }
}

async function deletePaymentLink(id) {
  if (!confirm('Are you sure you want to delete this custom payment link record?')) return;
  try {
    const data = await adminFetch(`/api/admin/payment-links/${id}`, { method: 'DELETE' });
    if (data.success) {
      showToast('✅ Payment link deleted.', 'success');
      loadPaymentLinks();
    } else {
      showToast('❌ ' + (data.error || 'Delete failed.'), 'error');
    }
  } catch (err) {
    showToast('❌ Error deleting link.', 'error');
  }
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Paylinks = {
  loadPaymentLinks,
  updatePkrPreview,
  fillSampleTemplate,
  updatePaymentLinkNoteTemplate,
  createPaymentLink,
  cancelPaymentLink,
  deletePaymentLink,
};
