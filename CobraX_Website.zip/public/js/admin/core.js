/**
 * CobraX Admin Panel — Core Module & Namespace Architecture
 * Handles CobraAdmin root namespace, session verification, httpOnly cookie auth,
 * hash-based SPA routing, global delegated events & base helpers.
 */
'use strict';

window.CobraAdmin = window.CobraAdmin || {};

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ─── API Client (Uses httpOnly session cookie automatically) ─────────────
async function adminFetch(url, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  const res = await fetch(url, { ...opts, headers, credentials: 'same-origin' });
  return res.json();
}

async function adminLogout() {
  try { await adminFetch('/api/admin/logout', { method: 'POST' }); } catch {}
  localStorage.removeItem('cbx_admin_token');
  sessionStorage.removeItem('cbx_admin_token');
  window.location.href = 'admin-login';
}

function handleAuthError(data) {
  if (data && data.error && (
    data.error.includes('admin session') ||
    data.error.includes('Admin auth') ||
    data.error.includes('authentication required')
  )) {
    if (typeof showToast === 'function') {
      showToast('❌ Admin session expired. Redirecting to login...', 'error');
    }
    setTimeout(() => adminLogout(), 1200);
  }
}

// ─── Hash-Based Tab Navigation ──────────────────────────────────────────
function showPage(page, updateHash = true) {
  if (!page) page = 'dashboard';
  document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.admin-nav-item').forEach(b => b.classList.remove('active'));

  const pg  = document.getElementById('page-' + page);
  const nav = document.getElementById('nav-' + page);
  if (pg)  pg.classList.add('active');
  if (nav) nav.classList.add('active');

  if (updateHash && window.location.hash !== '#' + page) {
    window.location.hash = page;
  }

  // Lazy load domain data
  if (page === 'dashboard'   && typeof loadDashboard === 'function') loadDashboard();
  if (page === 'orders'      && typeof loadOrders === 'function') loadOrders();
  if (page === 'users'       && typeof loadUsers === 'function') loadUsers();
  if (page === 'agents'      && typeof loadAgents === 'function') loadAgents();
  if (page === 'settings'    && typeof loadSettings === 'function') loadSettings();
  if (page === 'announcement'&& typeof loadAnnouncement === 'function') loadAnnouncement();
  if (page === 'push'        && typeof loadPushConfig === 'function') { loadPushConfig(); loadPushTemplates(); }
  if (page === 'maintenance' && typeof loadMaintenanceStatus === 'function') loadMaintenanceStatus();
  if (page === 'games'       && typeof loadGamesManager === 'function') loadGamesManager();
  if (page === 'version'     && typeof loadVersionSettings === 'function') loadVersionSettings();
  if (page === 'keys'        && typeof loadKeysManager === 'function') loadKeysManager();
  if (page === 'paylinks'    && typeof loadPaymentLinks === 'function') loadPaymentLinks();
  if (page === 'withdrawals' && typeof loadWithdrawals === 'function') loadWithdrawals();
}

window.addEventListener('hashchange', () => {
  const page = window.location.hash.replace('#', '') || 'dashboard';
  showPage(page, false);
});

// ─── Global Event Delegation (Decoupled DOM Architecture) ──────────────
document.addEventListener('click', (e) => {
  // Tab switching via data-tab
  const tabBtn = e.target.closest('[data-tab]');
  if (tabBtn) {
    e.preventDefault();
    const targetPage = tabBtn.getAttribute('data-tab');
    showPage(targetPage);
    return;
  }

  // Modal dismiss via data-dismiss="modal"
  const closeBtn = e.target.closest('[data-dismiss="modal"]');
  if (closeBtn) {
    e.preventDefault();
    const modal = closeBtn.closest('.admin-modal-overlay');
    if (modal) modal.classList.remove('active');
    return;
  }

  // Copy to clipboard via data-copy
  const copyBtn = e.target.closest('[data-copy]');
  if (copyBtn) {
    e.preventDefault();
    const text = copyBtn.getAttribute('data-copy');
    if (text && typeof copyText === 'function') {
      copyText(text);
    }
    return;
  }
});

// ─── Initial Auth & Page Load ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Clear any legacy client tokens
  localStorage.removeItem('cbx_admin_token');
  sessionStorage.removeItem('cbx_admin_token');

  try {
    const data = await adminFetch('/api/admin/me');
    if (!data.success) {
      window.location.href = 'admin-login';
      return;
    }

    const adminUser = data.username || 'Admin';
    const userEl = document.getElementById('admin-username-display');
    if (userEl) userEl.textContent = adminUser;

    // Restore tab from URL hash, default to dashboard
    const initialPage = window.location.hash.replace('#', '') || 'dashboard';
    showPage(initialPage, false);

  } catch (err) {
    window.location.href = 'admin-login';
  }
});

// ─── Date & Time Formatting Helpers ─────────────────────────────────────
function fmtDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-PK', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtTime(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('en-PK', { hour: '2-digit', minute: '2-digit', hour12: true });
}

function fmtDateTime(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  return `${d.toLocaleDateString('en-PK', { day: '2-digit', month: 'short', year: 'numeric' })}, ${d.toLocaleTimeString('en-PK', { hour: '2-digit', minute: '2-digit', hour12: true })}`;
}

window.fmtDate = fmtDate;
window.fmtTime = fmtTime;
window.fmtDateTime = fmtDateTime;

// Register on CobraAdmin root
CobraAdmin.Core = {
  escapeHtml,
  adminFetch,
  adminLogout,
  handleAuthError,
  showPage,
  fmtDate,
  fmtTime,
  fmtDateTime,
};

