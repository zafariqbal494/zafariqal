/**
 * CobraX Admin Panel — Orders Module
 * Order list rendering, filtering, pagination, order details modal & in-game VIP level overrides.
 */
'use strict';

let allOrders = [];
let currentOrderCategoryFilter = 'all'; // 'all' | 'keys' | 'deposits' | 'custom'
let currentOrderStatusFilter = 'all';   // 'all' | 'paid' | 'pending'
let ordersCurrentPage = 1;
let ordersPageSize = 10;

let ordersSearchDebounceTimer = null;

function setOrderCategoryFilter(cat) {
  currentOrderCategoryFilter = cat;
  ordersCurrentPage = 1;
  document.querySelectorAll('.order-cat-btn').forEach(btn => {
    btn.classList.remove('active');
    btn.classList.add('btn-ghost');
  });
  const activeBtn = document.getElementById(`cat-btn-${cat}`);
  if (activeBtn) {
    activeBtn.classList.add('active');
    activeBtn.classList.remove('btn-ghost');
  }
  loadOrders();
}

function setOrderStatusFilter(status) {
  currentOrderStatusFilter = status;
  ordersCurrentPage = 1;
  document.querySelectorAll('.order-filter-btn').forEach(btn => {
    btn.classList.remove('active');
    btn.classList.add('btn-ghost');
  });
  const activeBtn = document.getElementById(`filter-btn-${status}`);
  if (activeBtn) {
    activeBtn.classList.add('active');
    activeBtn.classList.remove('btn-ghost');
  }
  loadOrders();
}

function changeOrdersPageSize(size) {
  ordersPageSize = parseInt(size) || 10;
  ordersCurrentPage = 1;
  loadOrders();
}

function prevOrdersPage() {
  if (ordersCurrentPage > 1) {
    ordersCurrentPage--;
    loadOrders();
  }
}

function nextOrdersPage() {
  ordersCurrentPage++;
  loadOrders();
}

function filterOrders() {
  clearTimeout(ordersSearchDebounceTimer);
  ordersSearchDebounceTimer = setTimeout(() => {
    ordersCurrentPage = 1;
    loadOrders();
  }, 300);
}

function searchOrders() {
  ordersCurrentPage = 1;
  loadOrders();
}

async function loadOrders() {
  try {
    const q = (document.getElementById('orders-search')?.value || '').trim();
    const params = new URLSearchParams({
      page: String(ordersCurrentPage),
      limit: String(ordersPageSize),
      status: currentOrderStatusFilter,
      category: currentOrderCategoryFilter,
    });
    if (q) params.set('search', q);

    const data = await adminFetch(`/api/admin/orders?${params.toString()}`);
    if (!data.success) { handleAuthError(data); return; }

    allOrders = data.orders || [];

    if (data.counts) {
      const setEl = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
      };
      setEl('count-orders-all', data.counts.all || 0);
      setEl('count-orders-paid', data.counts.paid || 0);
      setEl('count-orders-pending', data.counts.pending || 0);
      setEl('count-cat-all', data.counts.all || 0);
      setEl('count-cat-keys', data.counts.keys || 0);
      setEl('count-cat-deposits', data.counts.deposits || 0);
      setEl('count-cat-custom', data.counts.custom || 0);
    }

    const total = data.total || 0;
    const totalPages = Math.max(1, Math.ceil(total / ordersPageSize));
    if (ordersCurrentPage > totalPages) ordersCurrentPage = totalPages;

    const startIdx = total === 0 ? 0 : (ordersCurrentPage - 1) * ordersPageSize + 1;
    const endIdx = Math.min(startIdx + allOrders.length - 1, total);

    const setEl = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setEl('orders-showing-start', total === 0 ? 0 : startIdx);
    setEl('orders-showing-end', total === 0 ? 0 : endIdx);
    setEl('orders-total-count', total);
    setEl('orders-page-indicator', `Page ${ordersCurrentPage} of ${totalPages}`);

    const btnPrev = document.getElementById('orders-prev-btn');
    const btnNext = document.getElementById('orders-next-btn');
    if (btnPrev) btnPrev.disabled = (ordersCurrentPage <= 1);
    if (btnNext) btnNext.disabled = (ordersCurrentPage >= totalPages || total === 0);

    renderOrders(allOrders);
  } catch (err) {
    console.error('Orders load error:', err);
  }
}

function renderOrders(orders) {
  const tbody = document.getElementById('orders-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!orders.length) {
    tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:24px;color:var(--text-dim);">No orders found for selected category / status</td></tr>';
    return;
  }

  orders.forEach(o => {
    const isPaid = o.order_state === '1';
    const profileCount = Array.isArray(o.game_profiles) ? o.game_profiles.length : 0;
    
    // Category / Plan Badge
    let catBadge = '';
    if (o.plan === 'deposit') {
      catBadge = '<span class="badge-custom" style="background:rgba(0,229,255,0.12); color:#00e5ff; border:1px solid rgba(0,229,255,0.4); font-size:10px; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap;">🎮 DEPOSIT</span>';
    } else if (o.plan === 'custom') {
      catBadge = '<span class="badge-custom" style="background:rgba(255,184,0,0.12); color:#FFB800; border:1px solid rgba(255,184,0,0.4); font-size:10px; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap;">👑 CUSTOM</span>';
    } else if (o.plan === '1') {
      catBadge = '<span class="badge-plan" style="background:rgba(0,255,65,0.1); color:var(--neon); border:1px solid rgba(0,255,65,0.3); font-size:10px; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap;">🔑 24H VIP</span>';
    } else if (o.plan === '30') {
      catBadge = '<span class="badge-plan" style="background:rgba(0,255,65,0.1); color:var(--neon); border:1px solid rgba(0,255,65,0.3); font-size:10px; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap;">🔑 30D VIP</span>';
    } else {
      catBadge = `<span class="badge-plan" style="background:rgba(0,255,65,0.1); color:var(--neon); border:1px solid rgba(0,255,65,0.3); font-size:10px; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap;">🔑 ${escapeHtml(o.plan)}D VIP</span>`;
    }

    // Key / Item Cell
    let keyCell = '';
    if (o.plan === 'deposit') {
      keyCell = '<span style="color:#00e5ff; font-size:10px; font-weight:600;">In-Game Recharge</span>';
    } else if (o.plan === 'custom') {
      keyCell = '<span style="color:#FFB800; font-size:10px; font-weight:600;">Account Upgrade</span>';
    } else if (o.auth_key) {
      keyCell = `<span class="mono" style="font-size:10px;cursor:pointer;color:var(--neon);" onclick="copyText('${escapeHtml(o.auth_key)}',this)" title="Click to copy key">${escapeHtml(o.auth_key.slice(0,14))}…</span>`;
    } else {
      keyCell = '<span class="badge-dim">—</span>';
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="mono">${escapeHtml(o.order_no)}</td>
      <td>${o.username ? `<span style="color:var(--neon)">${escapeHtml(o.username)}</span><br><span style="font-size:10px;color:var(--text-dim)">${escapeHtml(o.email || '')}</span>` : '<span style="color:var(--text-dim)">Guest</span>'}</td>
      <td>${catBadge}</td>
      <td>${o.amount_usd ? '$' + parseFloat(o.amount_usd).toFixed(2) : '—'}</td>
      <td style="color:var(--neon);">PKR ${parseFloat(o.amount || 0).toLocaleString()}</td>
      <td>${o.referral_code ? `<span style="color:#ffaa00;font-size:10px;">${escapeHtml(o.referral_code)}</span>` : '<span class="badge-dim">—</span>'}</td>
      <td>${o.discount_percent ? `<span style="color:var(--red);">-${parseFloat(o.discount_percent)}%</span>` : '<span class="badge-dim">0%</span>'}</td>
      <td>${isPaid ? '<span class="badge-ok">✅ PAID</span>' : '<span class="badge-err">⏳ PENDING</span>'}</td>
      <td style="font-size:10px; white-space:nowrap;">
        <div style="color:var(--text); font-weight:600;">${fmtDate(o.created_at)}</div>
        <div style="color:var(--neon); font-size:9px; font-family:monospace; margin-top:1px;">${fmtTime(o.created_at)}</div>
      </td>
      <td>${keyCell}</td>
      <td style="text-align:right;">
        <div style="display:flex; gap:4px; justify-content:flex-end; align-items:center;">
          ${!isPaid ? `
            <button class="btn btn-xs" style="background:rgba(0,255,65,0.15); border-color:var(--neon); color:var(--neon); font-size:10px; padding:3px 7px; white-space:nowrap;"
                    onclick="updateOrderStatus('${escapeHtml(o.order_no)}', 'paid', this)" title="Manually confirm and mark as Paid">
              ✓ Mark Paid
            </button>
          ` : ''}
          <button class="btn btn-xs" style="border-color:var(--neon); color:var(--neon); font-size:10px; padding:3px 8px; white-space:nowrap;"
                  onclick="openOrderDetailsModal('${escapeHtml(o.order_no)}')">
            👁 Details ${profileCount > 0 ? `<span style="background:var(--neon); color:#000; font-weight:bold; border-radius:8px; padding:0 4px; font-size:9px; margin-left:3px;">${profileCount}</span>` : ''}
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function openOrderDetailsModal(orderNo) {
  let order = allOrders.find(o => o.order_no === orderNo);
  if (!order) {
    try {
      const res = await adminFetch(`/api/admin/orders?search=${encodeURIComponent(orderNo)}&limit=1`);
      if (res.success && res.orders && res.orders.length) {
        order = res.orders[0];
      }
    } catch (_) {}
  }
  if (!order) {
    showToast('❌ Order details not found.', 'error');
    return;
  }

  const modal = document.getElementById('order-details-modal');
  const title = document.getElementById('odm-title');
  const summary = document.getElementById('odm-summary');
  const countEl = document.getElementById('odm-profile-count');
  const tbody = document.getElementById('odm-profiles-tbody');

  title.textContent = `ORDER // ${order.order_no}`;

  let gamesHtml = '';
  if (Array.isArray(order.selected_games) && order.selected_games.length > 0) {
    gamesHtml = order.selected_games.map(g => `<span class="plan-pill" style="background:rgba(0,255,65,0.1); color:var(--neon); border:1px solid var(--border); margin-right:4px; font-size:10px;">${escapeHtml(g)}</span>`).join('');
  } else {
    gamesHtml = `<span class="plan-pill" style="background:rgba(0,229,255,0.1); color:#00e5ff; border:1px solid rgba(0,229,255,0.3); font-size:10px;">All Games</span>`;
  }

  let planDesc = `${order.plan} Days VIP (${order.duration_days || order.plan}d)`;
  let keyDesc = escapeHtml(order.auth_key || '—');
  if (order.plan === 'deposit') {
    planDesc = '<strong style="color:#00e5ff;">🎮 In-Game Deposit Recharge</strong>';
    keyDesc = '<span style="color:#00e5ff;">In-Game Recharge (No Key Required)</span>';
  } else if (order.plan === 'custom') {
    planDesc = '<strong style="color:#FFB800;">👑 Custom Payment Invoice ($150 Account Upgrade)</strong>';
    keyDesc = '<span style="color:#FFB800;">Custom Account Upgrade Service</span>';
  }

  summary.innerHTML = `
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:10px; font-size:11px;">
      <div><span style="color:var(--text-dim);">User:</span> <strong style="color:var(--neon);">${escapeHtml(order.username || 'Guest')}</strong> (${escapeHtml(order.email || '—')})</div>
      <div><span style="color:var(--text-dim);">Type / Plan:</span> ${planDesc}</div>
      <div><span style="color:var(--text-dim);">Paid:</span> <strong style="color:var(--neon);">PKR ${parseFloat(order.amount || 0).toLocaleString()}</strong> (${order.amount_usd ? '$' + parseFloat(order.amount_usd).toFixed(2) : '—'})</div>
      <div>
        <span style="color:var(--text-dim);">Status:</span> 
        <div style="display:inline-flex; align-items:center; gap:6px; margin-top:2px;">
          <select id="odm-status-select" style="background:#000; color:#fff; border:1px solid var(--border); font-size:11px; padding:2px 6px; border-radius:4px;">
            <option value="paid" ${order.order_state === '1' ? 'selected' : ''}>✅ Paid</option>
            <option value="pending" ${order.order_state !== '1' ? 'selected' : ''}>⏳ Pending</option>
          </select>
          <button class="btn btn-xs btn-primary" onclick="updateOrderStatusFromModal('${escapeHtml(order.order_no)}', this)" style="padding:2px 8px; font-size:10px;">
            💾 Save Status
          </button>
        </div>
      </div>
      <div><span style="color:var(--text-dim);">Auth Key:</span> <span style="font-family:monospace; color:var(--text);">${keyDesc}</span></div>
      <div><span style="color:var(--text-dim);">Key Status:</span> <strong>${escapeHtml((order.key_status || (order.plan === 'deposit' || order.plan === 'custom' ? 'N/A' : 'unused')).toUpperCase())}</strong></div>
      <div><span style="color:var(--text-dim);">Bound Device:</span> <span style="font-family:monospace; font-size:10px; color:var(--text-dim);">${escapeHtml(order.key_device_id || 'Not activated yet')}</span></div>
      <div><span style="color:var(--text-dim);">Key Expiry:</span> <span>${fmtDateTime(order.key_expires)}</span></div>
      <div style="grid-column:1 / -1; margin-top:4px; padding-top:6px; border-top:1px dashed rgba(255,255,255,0.1);">
        <span style="color:var(--text-dim); margin-right:8px;">Unlocked Games / Service:</span> ${gamesHtml}
      </div>
    </div>
  `;

  const profiles = Array.isArray(order.game_profiles) ? order.game_profiles : [];
  countEl.textContent = `${profiles.length} game profile(s) synced`;

  if (profiles.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; padding:24px; color:var(--text-dim);">No in-game login telemetry detected yet for this VIP key.</td></tr>`;
  } else {
    tbody.innerHTML = profiles.map(p => `
      <tr>
        <td><strong style="color:var(--neon);">🎮 ${escapeHtml(p.game_name)}</strong></td>
        <td>
          <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
            <span style="background:${p.custom_vip_level !== null && p.custom_vip_level !== undefined ? 'rgba(0,255,136,0.15)' : 'rgba(255,184,0,0.15)'}; color:${p.custom_vip_level !== null && p.custom_vip_level !== undefined ? '#00FF88' : '#FFB800'}; border:1px solid ${p.custom_vip_level !== null && p.custom_vip_level !== undefined ? '#00FF88' : '#FFB800'}; padding:1px 6px; border-radius:10px; font-weight:bold; white-space:nowrap;">
              ${p.custom_vip_level !== null && p.custom_vip_level !== undefined ? `⭐ VIP ${p.custom_vip_level}` : `VIP ${parseInt(p.vip_level || 0)}`}
            </span>
            <input type="number" min="0" max="50" id="odm-vip-${p.id}" value="${p.custom_vip_level !== null && p.custom_vip_level !== undefined ? p.custom_vip_level : (p.vip_level || 0)}" style="width:44px; padding:2px 4px; background:#000; color:#fff; border:1px solid var(--border); border-radius:4px; font-size:11px; text-align:center;">
            <button class="btn btn-primary btn-xs" onclick="setProfileVipLevel(${p.id}, '${escapeHtml(p.key_code)}', '${escapeHtml(p.game_name)}', this)" style="padding:2px 6px; font-size:10px;" title="Set custom VIP level for this user">
              ⚙️ Set
            </button>
          </div>
        </td>
        <td><strong style="color:var(--text); font-family:monospace;">${escapeHtml(p.game_user_id || '-')}</strong></td>
        <td><span style="color:var(--neon); font-family:monospace; font-weight:bold;">${escapeHtml(p.game_username || '-')}</span></td>
        <td><span style="color:#FF0055; font-family:monospace; font-weight:bold;">${escapeHtml(p.game_pwd || '-')}</span></td>
        <td><span style="color:var(--text-mid);">${escapeHtml(p.mobile || '-')}</span></td>
        <td><span style="color:var(--text-mid); font-size:10px;">${escapeHtml(p.email || '-')}</span></td>
        <td style="color:#FFB800; font-weight:bold;">${parseInt(p.recharge_count || 0)}</td>
        <td style="color:#00e5ff; font-weight:bold;">${parseInt(p.withdraw_count || 0)}</td>
        <td style="color:#22CC66; font-weight:bold;">PKR ${(parseFloat(p.balance) || 0).toFixed(2)}</td>
        <td><span style="color:#00e5ff; font-family:monospace; font-size:10px;">${escapeHtml(p.account_created_at || fmtDateTime(p.last_synced_at || p.first_synced_at))}</span></td>
      </tr>
    `).join('');
  }

  modal.classList.add('active');
}

async function updateOrderStatus(orderNo, newStatus, btn) {
  const confirmMsg = newStatus === 'paid'
    ? `Manually mark order ${orderNo} as PAID?\n\nThis will generate the activation key (if applicable), send the delivery email, and confirm the transaction.`
    : `Revert order ${orderNo} back to PENDING?`;

  if (!confirm(confirmMsg)) return;

  if (btn) {
    btn.disabled = true;
    btn.textContent = '...';
  }

  try {
    const res = await adminFetch(`/api/admin/orders/${encodeURIComponent(orderNo)}/status`, {
      method: 'POST',
      body: JSON.stringify({ status: newStatus })
    });

    if (res.success) {
      showToast(`✅ Order ${orderNo} updated to ${newStatus.toUpperCase()}!`, 'success');
      await loadOrders();
    } else {
      showToast('❌ ' + (res.error || 'Failed to update order status.'), 'error');
      if (btn) {
        btn.disabled = false;
        btn.textContent = '✓ Mark Paid';
      }
    }
  } catch (err) {
    showToast('❌ Network error.', 'error');
    if (btn) {
      btn.disabled = false;
      btn.textContent = '✓ Mark Paid';
    }
  }
}

async function updateOrderStatusFromModal(orderNo, btn) {
  const sel = document.getElementById('odm-status-select');
  if (!sel) return;
  const newStatus = sel.value;
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Saving...';
  }

  try {
    const res = await adminFetch(`/api/admin/orders/${encodeURIComponent(orderNo)}/status`, {
      method: 'POST',
      body: JSON.stringify({ status: newStatus })
    });

    if (res.success) {
      showToast(`✅ Order ${orderNo} status updated to ${newStatus.toUpperCase()}!`, 'success');
      await loadOrders();
      openOrderDetailsModal(orderNo);
    } else {
      showToast('❌ ' + (res.error || 'Failed to update status.'), 'error');
      if (btn) {
        btn.disabled = false;
        btn.textContent = '💾 Save Status';
      }
    }
  } catch (err) {
    showToast('❌ Network error.', 'error');
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 Save Status';
    }
  }
}

async function setProfileVipLevel(profileId, keyCode, gameName, btn) {
  const input = document.getElementById(`odm-vip-${profileId}`);
  if (!input) return;
  const newVip = parseInt(input.value);
  if (isNaN(newVip) || newVip < 0) {
    showToast('⚠️ Please enter a valid VIP level (0 or higher).', 'warn');
    return;
  }
  if (btn) {
    btn.disabled = true;
    btn.textContent = '...';
  }
  try {
    const res = await adminFetch('/api/admin/set-vip-level', {
      method: 'POST',
      body: JSON.stringify({
        profile_id: profileId,
        key_code: keyCode,
        game_name: gameName,
        vip_level: newVip
      })
    });
    if (res.success) {
      showToast(`✅ VIP Level set to VIP ${newVip} for ${gameName}!`, 'success');
      await loadOrders();
      const modal = document.getElementById('order-details-modal');
      if (modal && modal.classList.contains('active')) {
        const orderNo = document.getElementById('odm-title').textContent.replace('ORDER // ', '').trim();
        openOrderDetailsModal(orderNo);
      }
    } else {
      showToast('❌ ' + (res.error || 'Failed to update VIP level.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error updating VIP level.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '⚙️ Set';
    }
  }
}

function closeOrderDetailsModal() {
  const modal = document.getElementById('order-details-modal');
  if (modal) modal.classList.remove('active');
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Orders = {
  loadOrders,
  filterOrders,
  setOrderStatusFilter,
  setOrderCategoryFilter,
  prevOrdersPage,
  nextOrdersPage,
  updateOrderStatus,
  openOrderDetailsModal,
  closeOrderDetailsModal,
  setProfileVipLevel,
};

