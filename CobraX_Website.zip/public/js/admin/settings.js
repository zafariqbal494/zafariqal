/**
 * CobraX Admin Panel — Settings & System Config Module
 * Global app settings, broadcast announcements, OneSignal push notifications & templates,
 * 1-click server maintenance mode, live games card config & version enforcement.
 */
'use strict';

// ─── Maintenance Mode ─────────────────────────────────────────────────
const MAINT_MSG_DEFAULTS = {
  push_on_title:   '⚠️ CobraX — Server Maintenance',
  push_on_msg:     "Prediction server is temporarily offline for maintenance. We'll be back shortly!",
  push_off_title:  '✅ CobraX — Server Online',
  push_off_msg:    '🟢 Prediction server is back online! WinGo 30Sec results are now live.',
  banner_on_title: '⚠️ Prediction Server Offline',
  banner_on_msg:   'Our prediction engine is currently under maintenance. Results will resume shortly. Thank you for your patience.',
};

function _applyMaintenanceUI(isOn) {
  const statusCard    = document.getElementById('maint-status-card');
  const statusLabel   = document.getElementById('maint-status-label');
  const statusVal     = document.getElementById('maint-status-val');
  const statusSub     = document.getElementById('maint-status-sub');
  const activateBtn   = document.getElementById('maint-activate-btn');
  const deactivateBtn = document.getElementById('maint-deactivate-btn');

  if (!statusCard) return;

  if (isOn) {
    statusCard.style.borderColor = 'rgba(255,50,50,0.45)';
    statusCard.style.background  = 'linear-gradient(135deg,#3a0000,#1a0000)';
    if (statusLabel) statusLabel.style.color = '#FF4444';
    if (statusVal) {
      statusVal.style.color = '#FF4444';
      statusVal.textContent = '🔴 MAINTENANCE ACTIVE';
    }
    if (statusSub) statusSub.textContent = 'Predictions hidden — push sent — banner shown';
    if (activateBtn) activateBtn.style.display = 'none';
    if (deactivateBtn) deactivateBtn.style.display = 'inline-block';
  } else {
    statusCard.style.borderColor = 'rgba(0,255,136,0.35)';
    statusCard.style.background  = 'linear-gradient(135deg,#021208,#030f08)';
    if (statusLabel) statusLabel.style.color = '#00ff88';
    if (statusVal) {
      statusVal.style.color = '#00ff88';
      statusVal.textContent = '🟢 SERVER ONLINE';
    }
    if (statusSub) statusSub.textContent = 'Predictions active — bubble visible — banner hidden';
    if (activateBtn) activateBtn.style.display = 'inline-block';
    if (deactivateBtn) deactivateBtn.style.display = 'none';
  }
}

function _populateMaintFields(cfg) {
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  set('maint-f-push-on-title',  cfg.push_on_title);
  set('maint-f-push-on-msg',    cfg.push_on_msg);
  set('maint-f-push-off-title', cfg.push_off_title);
  set('maint-f-push-off-msg',   cfg.push_off_msg);
  set('maint-f-banner-title',   cfg.banner_on_title);
  set('maint-f-banner-msg',     cfg.banner_on_msg);
}

async function loadMaintenanceStatus() {
  try {
    const data = await adminFetch('/api/admin/maintenance/config');
    if (!data.success) { handleAuthError(data); return; }
    _applyMaintenanceUI(data.maintenanceMode);
    _populateMaintFields(data);
  } catch (err) {
    console.error('Maintenance config load error:', err);
  }
}

async function saveMaintConfig() {
  const get = (id) => (document.getElementById(id)?.value || '').trim();
  const statusEl = document.getElementById('maint-save-status');

  if (statusEl) {
    statusEl.style.display = 'inline';
    statusEl.style.color = 'var(--text-dim)';
    statusEl.textContent = '⏳ Saving...';
  }

  try {
    const data = await adminFetch('/api/admin/maintenance/config', {
      method: 'PUT',
      body: JSON.stringify({
        push_on_title:   get('maint-f-push-on-title')  || MAINT_MSG_DEFAULTS.push_on_title,
        push_on_msg:     get('maint-f-push-on-msg')    || MAINT_MSG_DEFAULTS.push_on_msg,
        push_off_title:  get('maint-f-push-off-title') || MAINT_MSG_DEFAULTS.push_off_title,
        push_off_msg:    get('maint-f-push-off-msg')   || MAINT_MSG_DEFAULTS.push_off_msg,
        banner_on_title: get('maint-f-banner-title')   || MAINT_MSG_DEFAULTS.banner_on_title,
        banner_on_msg:   get('maint-f-banner-msg')     || MAINT_MSG_DEFAULTS.banner_on_msg,
      }),
    });
    if (statusEl) {
      statusEl.style.color   = data.success ? '#00FF88' : '#FF4444';
      statusEl.textContent   = data.success ? '✅ Saved!' : ('❌ ' + (data.error || 'Error'));
      setTimeout(() => { statusEl.style.display = 'none'; }, 3000);
    }
  } catch (err) {
    if (statusEl) {
      statusEl.style.color = '#FF4444';
      statusEl.textContent = '❌ Failed';
      setTimeout(() => { statusEl.style.display = 'none'; }, 3000);
    }
  }
}

function resetMaintDefaults() {
  if (!confirm('Reset all messages to default values?')) return;
  _populateMaintFields(MAINT_MSG_DEFAULTS);
  const statusEl = document.getElementById('maint-save-status');
  if (statusEl) {
    statusEl.style.display = 'inline';
    statusEl.style.color = 'var(--text-dim)';
    statusEl.textContent = '↩ Defaults loaded — click Save to apply';
    setTimeout(() => { statusEl.style.display = 'none'; }, 4000);
  }
}

async function toggleMaintenance(enable) {
  const loadingEl     = document.getElementById('maint-loading');
  const resultEl      = document.getElementById('maint-result');
  const activateBtn   = document.getElementById('maint-activate-btn');
  const deactivateBtn = document.getElementById('maint-deactivate-btn');

  const confirmMsg = enable
    ? '⚠️ This will:\n• Show red dot on all game cards\n• Show maintenance banner in app\n• Send push notification to all users\n• Hide prediction bubble\n\nProceed?'
    : '✅ This will:\n• Restore green dot on game cards\n• Clear maintenance banner\n• Send "Server Online" push notification\n• Show prediction bubble again\n\nProceed?';

  if (!confirm(confirmMsg)) return;

  if (activateBtn) activateBtn.disabled = true;
  if (deactivateBtn) deactivateBtn.disabled = true;
  if (loadingEl) { loadingEl.style.display = 'block'; }
  if (resultEl)  { resultEl.style.display  = 'none';  }

  try {
    const data = await adminFetch('/api/admin/maintenance/toggle', {
      method: 'POST',
      body: JSON.stringify({ enable }),
    });

    if (loadingEl) loadingEl.style.display = 'none';

    if (data.success) {
      _applyMaintenanceUI(data.maintenanceMode);
      if (resultEl) {
        resultEl.style.display = 'block';
        resultEl.style.color   = data.maintenanceMode ? '#FF6666' : '#00FF88';
        const pushStatus = data.pushSent ? '✅ Push notification sent to all users.' : '⚠️ Push notification could not be sent (check OneSignal settings).';
        resultEl.textContent = data.maintenanceMode
          ? `🛑 Maintenance activated. ${pushStatus}`
          : `✅ Server restored to online. ${pushStatus}`;
      }
    } else {
      if (resultEl) {
        resultEl.style.display = 'block';
        resultEl.style.color   = '#FF4444';
        resultEl.textContent   = '❌ Error: ' + (data.error || 'Unknown error');
      }
    }
  } catch (err) {
    if (loadingEl) loadingEl.style.display = 'none';
    if (resultEl)  { resultEl.style.display = 'block'; resultEl.style.color = '#FF4444'; resultEl.textContent = '❌ Request failed: ' + err.message; }
  } finally {
    if (activateBtn) activateBtn.disabled = false;
    if (deactivateBtn) deactivateBtn.disabled = false;
  }
}

// ─── Global Settings ──────────────────────────────────────────────────
async function loadSettings() {
  try {
    const data = await adminFetch('/api/admin/settings');
    if (!data.success) { handleAuthError(data); return; }

    const map = {};
    data.settings.forEach(s => { map[s.key] = s.value; });

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    set('s-rate', map.exchange_rate || '280');
    set('s-p1', map.price_1d_usd || '20.00');
    set('s-p30', map.price_30d_usd || '80.00');
    set('s-plan-1-restricted', map.plan_1_restricted || '0');
    set('s-plan-30-restricted', map.plan_30_restricted || '0');
    set('s-tg', map.telegram_link || (map.telegram_address ? (map.telegram_address.startsWith('http') ? map.telegram_address : 'https://' + map.telegram_address) : 'https://t.me/winXcobra'));
    set('s-discount-active', map.discount_active || '1');
    set('s-required-game-vip', map.required_game_vip_level || '3');
    set('s-solipay-deposit-enabled', map.solipay_deposit_enabled || '1');
    set('s-min-deposit-amount', map.min_deposit_amount || '5000');
    set('s-smtp-host', map.smtp_host || 'mail.cobrax.sbs');
    set('s-smtp-port', map.smtp_port || '465');
    set('s-smtp-user', map.smtp_user || 'info@cobrax.sbs');
    set('s-smtp-pass', map.smtp_pass || '');

  } catch (err) {
    console.error('Settings load error:', err);
  }
}

async function saveSettings() {
  const btn     = document.getElementById('save-settings-btn');
  const msgEl   = document.getElementById('settings-msg');
  if (btn) {
    btn.disabled  = true;
    btn.textContent = '⏳ Saving...';
  }
  if (msgEl) msgEl.textContent = '';

  const get = (id) => document.getElementById(id)?.value || '';

  const settings = {
    exchange_rate:          get('s-rate'),
    price_1d_usd:           get('s-p1'),
    price_30d_usd:          get('s-p30'),
    plan_1_restricted:      get('s-plan-1-restricted') || '0',
    plan_30_restricted:     get('s-plan-30-restricted') || '0',
    telegram_link:          get('s-tg'),
    discount_active:        get('s-discount-active'),
    required_game_vip_level: get('s-required-game-vip') || '3',
    solipay_deposit_enabled: get('s-solipay-deposit-enabled') || '1',
    min_deposit_amount:     get('s-min-deposit-amount') || '5000',
    smtp_host:              get('s-smtp-host') || 'mail.cobrax.sbs',
    smtp_port:              get('s-smtp-port') || '465',
    smtp_user:              get('s-smtp-user') || 'info@cobrax.sbs',
    smtp_pass:              get('s-smtp-pass') || '',
  };

  if (!settings.exchange_rate || parseFloat(settings.exchange_rate) <= 0) {
    if (msgEl) {
      msgEl.textContent = '❌ Exchange rate must be greater than 0.';
      msgEl.style.color = 'var(--red)';
    }
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 SAVE ALL SETTINGS';
    }
    return;
  }

  try {
    const data = await adminFetch('/api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify({ settings })
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = '✅ Settings saved successfully! Prices on the buy page will update within 5 minutes.';
        msgEl.style.color = 'var(--neon)';
      }
      showToast('✅ Settings saved!', 'success');
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Save failed.');
        msgEl.style.color = 'var(--red)';
      }
    }

  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 SAVE ALL SETTINGS';
    }
  }
}

// ─── Announcements ────────────────────────────────────────────────────
async function loadAnnouncement() {
  try {
    const data = await adminFetch('/api/admin/announcement');
    if (!data.success) { handleAuthError(data); return; }

    const a = data.announcement;
    const isEnabled = !!a.enabled;

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    set('ann-enabled', isEnabled ? '1' : '0');
    set('ann-title', a.title || '');
    set('ann-message', a.message || '');
    set('ann-type', a.type || 'info');
    set('ann-url', a.url || '');
    set('ann-dismissible', a.dismissible ? '1' : '0');

    const countEl  = document.getElementById('stat-ann-count');
    const statusEl = document.getElementById('stat-ann-status');
    const typeEl   = document.getElementById('stat-ann-type');
    const titleEl  = document.getElementById('stat-ann-title');

    if (countEl) {
      countEl.textContent = isEnabled ? '1 ACTIVE' : '0 ACTIVE';
      countEl.style.color = isEnabled ? 'var(--neon)' : 'var(--text-dim)';
    }
    if (statusEl) {
      statusEl.textContent = isEnabled ? '🟢 Live on Home Screen' : '⚪ Inactive / Hidden';
    }
    if (typeEl) {
      const typeMap = { info: '🔵 Info (Cyan)', warning: '🟠 Warning (Amber)', maintenance: '🔴 Maintenance (Red)' };
      typeEl.textContent = isEnabled ? (typeMap[a.type] || a.type) : '—';
    }
    if (titleEl) {
      titleEl.textContent = isEnabled ? (a.title || 'Broadcast Active') : 'None';
    }

  } catch (err) {
    console.error('Announcement load error:', err);
  }
}

async function saveAnnouncement() {
  const btn     = document.getElementById('save-ann-btn');
  const msgEl   = document.getElementById('ann-msg');
  if (btn) {
    btn.disabled  = true;
    btn.textContent = '⏳ Publishing...';
  }
  if (msgEl) msgEl.textContent = '';

  const get = (id) => (document.getElementById(id)?.value || '').trim();

  const payload = {
    enabled:     document.getElementById('ann-enabled')?.value === '1',
    title:       get('ann-title'),
    message:     get('ann-message'),
    type:        document.getElementById('ann-type')?.value || 'info',
    url:         get('ann-url'),
    dismissible: document.getElementById('ann-dismissible')?.value === '1',
  };

  try {
    const data = await adminFetch('/api/admin/announcement', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = '📢 Broadcast announcement updated live for all Flutter App users!';
        msgEl.style.color = 'var(--neon)';
      }
      showToast('📢 Broadcast updated live!', 'success');
      loadAnnouncement();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Save failed.');
        msgEl.style.color = 'var(--red)';
      }
    }

  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '📢 PUBLISH BROADCAST TO APP';
    }
  }
}

async function terminateAnnouncement() {
  if (!confirm('Are you sure you want to TERMINATE the active announcement? It will be removed from all mobile apps immediately.')) return;
  const btn   = document.getElementById('term-ann-btn');
  const msgEl = document.getElementById('ann-msg');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Terminating...';
  }
  if (msgEl) msgEl.textContent = '';

  try {
    const get = (id) => (document.getElementById(id)?.value || '').trim();
    const payload = {
      enabled:     false,
      title:       get('ann-title'),
      message:     get('ann-message'),
      type:        document.getElementById('ann-type')?.value || 'info',
      url:         get('ann-url'),
      dismissible: true,
    };

    const data = await adminFetch('/api/admin/announcement', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    if (data.success) {
      const enEl = document.getElementById('ann-enabled');
      if (enEl) enEl.value = '0';
      if (msgEl) {
        msgEl.textContent = '🛑 Broadcast announcement terminated! Removed from all Flutter mobile apps.';
        msgEl.style.color = 'var(--red)';
      }
      showToast('🛑 Announcement terminated!', 'success');
      loadAnnouncement();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Termination failed.');
        msgEl.style.color = 'var(--red)';
      }
    }
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '🛑 TERMINATE BROADCAST';
    }
  }
}

// ─── Games & Bubble Config ───────────────────────────────────────────
let _adminGamesState = [];

async function loadGamesManager() {
  try {
    const data = await adminFetch('/api/admin/games');
    if (!data.success) { handleAuthError(data); return; }

    const tgEl = document.getElementById('s-tg-bubble');
    if (tgEl) tgEl.value = data.telegramAddress || 't.me/winXcobra';
    _adminGamesState = Array.isArray(data.games) ? data.games : [];
    renderGamesTable();
  } catch (err) {
    console.error('Games load error:', err);
  }
}

function renderGamesTable() {
  const tbody = document.getElementById('games-tbody');
  if (!tbody) return;
  if (!_adminGamesState || _adminGamesState.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:24px; color:var(--text-dim);">No games configured. Click + ADD GAME CARD to add one.</td></tr>';
    return;
  }

  tbody.innerHTML = _adminGamesState.map((g, idx) => `
    <tr>
      <td>
        <input type="text" class="settings-input" style="width:100%; padding:6px 10px;" value="${escapeHtml(g.name)}"
               onchange="_adminGamesState[${idx}].name = this.value">
      </td>
      <td>
        <input type="url" class="settings-input" style="width:100%; padding:6px 10px;" value="${escapeHtml(g.url)}"
               onchange="_adminGamesState[${idx}].url = this.value">
      </td>
      <td style="text-align:right;">
        <button class="btn-xs danger" onclick="deleteGameRow(${idx})">✕ Delete</button>
      </td>
    </tr>
  `).join('');
}

function addGameRow() {
  _adminGamesState.push({ name: 'New Game', url: 'https://' });
  renderGamesTable();
}

function deleteGameRow(idx) {
  _adminGamesState.splice(idx, 1);
  renderGamesTable();
}

async function saveGamesManager() {
  const btn = document.getElementById('save-games-btn');
  const msgEl = document.getElementById('games-msg');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';
  }
  if (msgEl) msgEl.textContent = '';

  const telegramAddress = (document.getElementById('s-tg-bubble')?.value || '').trim();

  try {
    const data = await adminFetch('/api/admin/games', {
      method: 'PUT',
      body: JSON.stringify({
        telegramAddress: telegramAddress,
        games: _adminGamesState,
      }),
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = '✅ Games Cards & Telegram Handle updated live for all Flutter App users!';
        msgEl.style.color = 'var(--neon)';
      }
      showToast('✅ Games & Telegram Config saved!', 'success');
      loadGamesManager();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Save failed.');
        msgEl.style.color = 'var(--red)';
      }
    }
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 SAVE ALL GAMES & TELEGRAM CONFIG';
    }
  }
}

// ─── App Version Manager ─────────────────────────────────────────────
async function loadVersionSettings() {
  try {
    const data = await adminFetch('/api/admin/version');
    if (!data.success) { handleAuthError(data); return; }
    const minVer = data.minAppVersion || '5.0.1';
    const latestVer = data.latestAppVersion || '5.0.1';
    const forceEnabled = !!data.forceUpdateEnabled;

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    set('ver-min-version', minVer);
    set('ver-latest-version', latestVer);
    set('ver-update-url', data.updateUrl || 'https://cobrax.sbs');
    set('ver-force-enabled', forceEnabled ? '1' : '0');

    const statMin = document.getElementById('stat-min-ver');
    const statLatest = document.getElementById('stat-latest-ver');
    const statForce = document.getElementById('stat-force-status');
    if (statMin) statMin.textContent = 'v' + minVer;
    if (statLatest) statLatest.textContent = 'v' + latestVer;
    if (statForce) {
      statForce.textContent = forceEnabled ? '🔒 ENFORCED' : '🔓 DISABLED';
      statForce.style.color = forceEnabled ? 'var(--neon)' : 'var(--text-dim)';
    }
  } catch (err) {
    console.error('loadVersionSettings error:', err);
  }
}

async function saveVersionSettings() {
  const btn = document.getElementById('save-ver-btn');
  const msgEl = document.getElementById('ver-msg');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';
  }
  if (msgEl) msgEl.textContent = '';

  const minAppVersion = (document.getElementById('ver-min-version')?.value || '').trim();
  const latestAppVersion = (document.getElementById('ver-latest-version')?.value || '').trim();
  const updateUrl = (document.getElementById('ver-update-url')?.value || '').trim();
  const forceUpdateEnabled = document.getElementById('ver-force-enabled')?.value === '1';

  try {
    const data = await adminFetch('/api/admin/version', {
      method: 'PUT',
      body: JSON.stringify({
        minAppVersion,
        latestAppVersion,
        updateUrl,
        forceUpdateEnabled,
      }),
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = '✅ Version requirement updated! All outdated apps are now enforced live.';
        msgEl.style.color = 'var(--neon)';
      }
      showToast('✅ Version Settings Saved!', 'success');
      loadVersionSettings();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Save failed.');
        msgEl.style.color = 'var(--red)';
      }
    }
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 SAVE & BROADCAST VERSION REQUIREMENT';
    }
  }
}

// ─── Push Notifications (OneSignal) ───────────────────────────────────
let _pushTemplatesCache = [];

async function loadPushConfig() {
  try {
    const data = await adminFetch('/api/admin/push/config');
    if (!data.success) { handleAuthError(data); return; }

    const isConnected = data.appId && data.hasApiKey;
    const statStatus = document.getElementById('stat-push-status');
    const statSub    = document.getElementById('stat-push-sub');
    const statTitle  = document.getElementById('stat-push-title');
    const statTime   = document.getElementById('stat-push-time');

    if (statStatus) {
      statStatus.textContent = isConnected ? '🟢 CONNECTED' : '⚪ NOT CONFIGURED';
      statStatus.style.color = isConnected ? 'var(--neon)' : 'var(--text-dim)';
    }
    if (statSub) {
      statSub.textContent = isConnected ? 'Ready to broadcast' : 'App ID or API Key missing';
    }
    if (statTitle) {
      statTitle.textContent = data.lastPushTitle || 'None';
    }
    if (statTime) {
      statTime.textContent = data.lastPushTime ? 'Sent: ' + fmtDate(data.lastPushTime) : 'Never sent';
    }

    const appEl = document.getElementById('os-app-id');
    const keyEl = document.getElementById('os-api-key');
    if (appEl) appEl.value = data.appId || '';
    if (keyEl && data.hasApiKey) {
      keyEl.placeholder = '•••••••••••••••••••••••• (Configured)';
    }
  } catch (err) {
    console.error('loadPushConfig error:', err);
  }
}

async function savePushConfig() {
  const btn = document.getElementById('btn-save-os-config');
  const msgEl = document.getElementById('push-config-msg');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';
  }
  if (msgEl) msgEl.textContent = '';

  const appId = (document.getElementById('os-app-id')?.value || '').trim();
  const restApiKey = (document.getElementById('os-api-key')?.value || '').trim();

  try {
    const payload = { appId };
    if (restApiKey.length > 0) payload.restApiKey = restApiKey;

    const data = await adminFetch('/api/admin/push/config', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = '✅ OneSignal API credentials saved successfully!';
        msgEl.style.color = 'var(--neon)';
      }
      showToast('✅ OneSignal credentials saved!', 'success');
      loadPushConfig();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Save failed.');
        msgEl.style.color = 'var(--red)';
      }
    }
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '💾 SAVE ONESIGNAL CONFIGURATION';
    }
  }
}

async function sendPushNotification() {
  const btn = document.getElementById('btn-send-push');
  const msgEl = document.getElementById('push-send-msg');
  const title = (document.getElementById('push-title')?.value || '').trim();
  const message = (document.getElementById('push-message')?.value || '').trim();
  const url = (document.getElementById('push-url')?.value || '').trim();

  if (!title || !message) {
    if (msgEl) {
      msgEl.textContent = '❌ Please enter both a title and a message body.';
      msgEl.style.color = 'var(--red)';
    }
    return;
  }

  if (!confirm(`Are you sure you want to broadcast this push notification to ALL CobraX mobile users?\n\nTitle: ${title}`)) {
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ Broadcasting Push...';
  }
  if (msgEl) msgEl.textContent = '';

  try {
    const data = await adminFetch('/api/admin/push/send', {
      method: 'POST',
      body: JSON.stringify({ title, message, url }),
    });

    if (data.success) {
      if (msgEl) {
        msgEl.textContent = `🚀 Push notification broadcasted! Notification ID: ${data.id} (Recipients: ${data.recipients || 'all active'})`;
        msgEl.style.color = 'var(--neon)';
      }
      showToast('🚀 Push notification broadcasted to all users!', 'success');
      const titleEl = document.getElementById('push-title');
      const msgInput = document.getElementById('push-message');
      if (titleEl) titleEl.value = '';
      if (msgInput) msgInput.value = '';
      loadPushConfig();
    } else {
      if (msgEl) {
        msgEl.textContent = '❌ ' + (data.error || 'Failed to send push notification.');
        msgEl.style.color = 'var(--red)';
      }
      showToast('❌ ' + (data.error || 'Push send failed'), 'error');
    }
  } catch (err) {
    if (msgEl) {
      msgEl.textContent = '❌ Network error.';
      msgEl.style.color = 'var(--red)';
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '🚀 SEND PUSH NOTIFICATION TO ALL USERS';
    }
  }
}

async function loadPushTemplates() {
  const tbody = document.getElementById('push-templates-tbody');

  try {
    const data = await adminFetch('/api/admin/push/templates');
    if (!data.success) {
      if (tbody) tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:20px; color:var(--red);">Failed to load templates.</td></tr>';
      return;
    }

    _pushTemplatesCache = data.templates || [];
    renderPushTemplatesTable();
  } catch (err) {
    console.error('loadPushTemplates error:', err);
  }
}

function renderPushTemplatesTable() {
  const tbody = document.getElementById('push-templates-tbody');
  if (!tbody) return;

  if (_pushTemplatesCache.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:24px; color:var(--text-dim);">No saved templates yet. Compose a notification above and click "SAVE AS REUSABLE TEMPLATE".</td></tr>';
    return;
  }

  tbody.innerHTML = _pushTemplatesCache.map(t => {
    return `
      <tr>
        <td style="font-weight:bold; color:#fff; white-space:nowrap;">
          ${escapeHtml(t.name)}
        </td>
        <td>
          <div style="font-weight:600; color:var(--neon); font-size:12px; margin-bottom:2px;">${escapeHtml(t.title)}</div>
          <div style="font-size:11px; color:var(--text-dim); line-height:1.4;">${escapeHtml(t.message)}</div>
        </td>
        <td style="font-size:11px; font-family:monospace; color:var(--cyan, #00e5ff);">${t.url ? escapeHtml(t.url) : '<span style="color:var(--text-dim);">—</span>'}</td>
        <td style="white-space:nowrap; text-align:right;">
          <button class="btn btn-xs" onclick="applyPushTemplate('${escapeHtml(t.id)}')" style="margin-right:6px;" title="Load into composer">⚡ Use</button>
          <button class="btn btn-xs danger" onclick="deletePushTemplate('${escapeHtml(t.id)}', '${escapeHtml(t.name)}')" title="Delete template">🗑️</button>
        </td>
      </tr>
    `;
  }).join('');
}

function applyPushTemplate(tmplId) {
  const tmpl = _pushTemplatesCache.find(t => t.id === tmplId);
  if (!tmpl) return;

  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  setVal('push-title', tmpl.title || '');
  setVal('push-message', tmpl.message || '');
  setVal('push-url', tmpl.url || '');

  showToast(`⚡ Template "${tmpl.name}" loaded into composer!`, 'success');
}

function clearPushForm() {
  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  setVal('push-title', '');
  setVal('push-message', '');
  setVal('push-url', '');
}

async function promptSavePushTemplate() {
  const title = (document.getElementById('push-title')?.value || '').trim();
  const message = (document.getElementById('push-message')?.value || '').trim();
  const url = (document.getElementById('push-url')?.value || '').trim();

  if (!title || !message) {
    showToast('❌ Please fill out both Title and Message first before saving as template.', 'error');
    return;
  }

  const defaultName = title.slice(0, 25);
  const name = prompt('Enter a name for this notification template:', defaultName);
  if (!name || !name.trim()) return;

  try {
    const data = await adminFetch('/api/admin/push/templates', {
      method: 'POST',
      body: JSON.stringify({
        name: name.trim(),
        title,
        message,
        url,
      }),
    });

    if (data.success) {
      showToast(`✅ Template "${name.trim()}" saved successfully!`, 'success');
      loadPushTemplates();
    } else {
      showToast('❌ ' + (data.error || 'Failed to save template.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error saving template.', 'error');
  }
}

async function deletePushTemplate(tmplId, name) {
  if (!confirm(`Delete template "${name}"?`)) return;

  try {
    const data = await adminFetch(`/api/admin/push/templates/${encodeURIComponent(tmplId)}`, {
      method: 'DELETE',
    });

    if (data.success) {
      showToast('✅ Template deleted.', 'success');
      loadPushTemplates();
    } else {
      showToast('❌ ' + (data.error || 'Delete failed.'), 'error');
    }
  } catch (err) {
    showToast('❌ Network error deleting template.', 'error');
  }
}

// Register on CobraAdmin namespace
window.CobraAdmin = window.CobraAdmin || {};
window.CobraAdmin.Settings = {
  loadMaintenanceStatus,
  saveMaintConfig,
  resetMaintDefaults,
  toggleMaintenance,
  loadSettings,
  saveSettings,
  loadAnnouncement,
  saveAnnouncement,
  terminateAnnouncement,
  loadGamesManager,
  addGameRow,
  deleteGameRow,
  saveGamesManager,
  loadVersionSettings,
  saveVersionSettings,
  loadPushConfig,
  savePushConfig,
  sendPushNotification,
  loadPushTemplates,
  applyPushTemplate,
  clearPushForm,
  promptSavePushTemplate,
  deletePushTemplate,
};

