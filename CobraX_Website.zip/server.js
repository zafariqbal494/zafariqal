'use strict';

require('dotenv').config();
const path    = require('path');
const express = require('express');
const cors    = require('cors');

const { PORT, PUBLIC_DIR } = require('./src/config/constants');
const cleanUrlsMiddleware  = require('./src/middlewares/cleanUrls');
const cookieParser         = require('./src/middlewares/cookieParser');
const { runMigrations }    = require('./src/database/migrations');
const routes               = require('./src/routes');

const app = express();

// Trust reverse proxy (Nginx, Cloudflare, etc.)
app.set('trust proxy', 1);

// Body parser, Cookie parser & CORS
app.use(express.json());
app.use(cookieParser);
app.use(cors());

// Clean URLs Middleware (.html removal & 301 redirect)
app.use(cleanUrlsMiddleware);

// Static files with clean URLs (7 days for CSS/JS, no-cache for HTML)
app.use(express.static(PUBLIC_DIR, {
  extensions: ['html'],
  maxAge: '7d',
  etag: true,
  lastModified: true,
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
  }
}));

// Mount all modular application routes
app.use(routes);

// Dedicated 404 handler for API routes
app.all('/api/*', (req, res) => {
  res.status(404).json({ success: false, error: 'API route not found.' });
});

// SPA Fallback for web page navigation
app.get('*', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Unhandled Server Error]', err);
  if (res.headersSent) return next(err);
  return res.status(500).json({ success: false, error: 'Internal server error.' });
});

// Start Server & Run Database Migrations
app.listen(PORT, async () => {
  console.log(`CobraX Server running on port ${PORT}`);
  try {
    await runMigrations();
  } catch (err) {
    console.error('[CobraX] Error running startup migrations:', err.message);
  }
});

module.exports = app;
