# Solipay Payment Gateway — API Reference

## 1. Data Format

All requests and responses use `POST` with `JSON` body.

Standard server response format:

```json
{
  "code": 0,      // 0 = success, non-0 = failure
  "msg": "xxx",   // "success" on success, failure reason on error
  "data": {}      // actual payload (JSON object). For async notifications, only the fields inside "data" are signed.
}
```

---

## 2. Signature

For all parameters requiring a signature:

1. Take all `{key=value}` pairs and sort them in **dictionary (alphabetical) order** by key.
2. Join them with `&` to form a string `source`.
3. Append the `api_key` directly to the end of `source` (no separator).
4. `sign = MD5(source + api_key)`

**Important for async (webhook) notifications:** Do NOT hardcode which parameters to sign. The system may add/remove fields over time — always dynamically sort *all* fields present in `data` before verifying the signature. Only the fields inside `data` participate in signing.

The Api_Key is found in the merchant back office under **首页 (Home) → Api_Key**. If already set, it shows as asterisks — click reset to generate a new one. **The reset key is shown only once** — copy and store it immediately, as it will show as `*` again after refresh/re-login. Resetting requires a "security verification code" — this is your merchant account's Google Authenticator code.

### Example

Parameters to sign:
```json
{
  "merchNo": "only",
  "orderNo": "123456",
  "amount": "100.00",
  "currency": "PKR"
}
```

```
source = "amount=100.00&currency=PKR&merchNo=only&orderNo=123456"
sign = MD5(source + api_key)
```

---

## 3. Async Notifications (Webhooks)

- Both **payIn** and **payOut** support async (webhook) notifications.
- The notification URL is configured in advance in the merchant back office.
- **payIn** notifications fire only for **successful** orders.
- **payOut** notifications fire for **both success and failure**.
- Your webhook endpoint must respond with the plain string `ok` to confirm receipt — otherwise the system will retry the notification multiple times.

---

## 4. Order States

| orderState | Meaning |
|---|---|
| 0 | Initialized |
| 1 | Success |
| 2 | Failed |
| 3 | Processing |
| 4 | Closed (payOut order rejected) |
| 5 | Payment returned — payOut order succeeded, then bank later reversed it ("reversed") |
| 6 | Disbursing — payOut currently in progress |

---

## 5. PayIn (Collection) — Create Order

**URL:** `https://{domain}/api/payIn`
**Method:** `POST JSON`

### Request Parameters

| Field | Required | Type | Description |
|---|---|---|---|
| amount | Yes | String | Amount, e.g. `100.00` |
| orderNo | Yes | String(10–35) | Merchant order number |
| merchNo | Yes | String | Merchant number |
| currency | Yes | String | Currency |
| notifyUrl | No | String | Callback URL |
| outChannel | Yes | String | Collection method: `Jazzcash` / `Easypaisa` / `Jazzcash_Direct` / `Easypaisa_Direct` |
| payAccount | No | String | Payer account — **required for direct-connect mode** (Jazzcash/Easypaisa account) |
| sign | Yes | String | Signature |

### Request Example

```json
{
  "amount": "100.00",
  "orderNo": "123456",
  "merchNo": "only",
  "notifyUrl": "https://abc.com/notify",
  "sign": "fb66a23f90594e0b6d382ea881d8809f",
  "outChannel": "Jazzcash",
  "currency": "PKR"
}
```

### Response — Success

```json
{
  "msg": "success",
  "code": 0,
  "data": {
    "amount": "100.00",
    "orderNo": "123456",
    "code_url": "http://abc.com",
    "merchNo": "only",
    "sign": "2ddd056fec77842acc1f7c022a4641f6",
    "currency": "PKR"
  }
}
```
`code_url` = payment page URL to redirect the payer to.

### Response — Fail

```json
{
  "code": 500,
  "msg": "error msg"
}
```

---

## 6. PayIn — Async Notification

Fires only when an order pays successfully. Sent via `POST JSON` to the payIn notify URL configured in **首页 (Home) → 商户设置 (Merchant Settings) → payIn_notify_url**.

### Payload Example

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "realAmount": "100.00",
    "amount": "100.00",
    "businessNo": "9999999",
    "orderNo": "123456",
    "merchNo": "only",
    "sign": "2ff91e80776eaee5d68fc0cf4b4faae1",
    "orderState": "1"
  }
}
```

| Field | Description |
|---|---|
| realAmount | Actual amount paid |
| amount | Amount as originally ordered |
| businessNo | Platform order number / transaction reference |

**Your endpoint must respond with the plain string `ok`**, or the system will retry.

**Settlement note:** Settle based on the order amount (`amount`), not `realAmount`.

---

## 7. PayIn — Query Order

**URL:** `https://{domain}/api/payIn/query`
**Method:** `POST JSON`

### Request Parameters

| Field | Required | Type | Description |
|---|---|---|---|
| orderNo | Yes | String | Merchant order number |
| merchNo | Yes | String | Merchant number |
| sign | Yes | String | Signature |

### Request Example

```json
{
  "orderNo": "123456",
  "merchNo": "only",
  "sign": "0b6d3f90594e3821d8809ffb66a2ea88"
}
```

### Response — Success

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "amount": "100.00",
    "realAmount": "100.00",
    "businessNo": "9999999",
    "orderNo": "123456",
    "merchNo": "only",
    "sign": "2ff91e80776eaee5d68fc0cf4b4faae1",
    "orderState": "1"
  }
}
```

### Response — Fail

```json
{
  "code": 500,
  "msg": "error msg"
}
```

---

## 8. PayOut (Disbursement) — Create Order

**URL:** `https://{domain}/api/payOut`
**Method:** `POST JSON`

> ⚠️ **Important:** A request timeout or an empty response does **NOT** mean the order failed. Under network or server instability, timeouts or empty responses can occur even when the order was actually placed. In these cases, treat the order as **"processing"** and confirm its real status later via the query API — never assume failure from a timeout/empty response alone.

### Request Parameters

| Field | Required | Type | Description |
|---|---|---|---|
| merchNo | Yes | String | Merchant number |
| orderNo | Yes | String(10–35) | Merchant order number |
| amount | Yes | String | Amount, e.g. `900.00` |
| acctName | Yes | String | Recipient name |
| acctCode | Yes | String | Payout method: `EASYPAISA` / `JAZZCASH` / bank code (see Bank Code table below) |
| acctNo | Yes | String | Account: Easypaisa / Jazzcash number / bank card number (depending on method) |
| mobile | No | String | Mobile number — **required when paying out to a bank card**; must start with `03` |
| currency | Yes | String | Currency |
| notifyUrl | No | String | Async callback URL. A single default URL can be set in the back office; use this field if you need a dynamic/per-request URL |
| sign | Yes | String | Signature |

### Request Example

```json
{
  "amount": "100.00",
  "orderNo": "123456",
  "merchNo": "only",
  "acctCode": "JAZZCASH",
  "acctNo": "03123456789",
  "acctName": "James",
  "sign": "48418c2213eddf85f89c77471557de1a",
  "currency": "PKR"
}
```

### Response — Success

```json
{
  "code": 0,
  "msg": "代付订单已受理!",
  "data": {
    "amount": "100.00",
    "orderNo": "123456",
    "merchNo": "only",
    "orderState": "0"
  }
}
```
(`msg` translates to: "Payout order has been accepted!")

### Response — Fail

```json
{
  "code": 500,
  "msg": "error msg"
}
```

> ⚠️ **Important (repeated):** A timeout or empty response is **not** a failure. Only treat a payOut order as definitively failed when you receive a **well-formed JSON response with `code != 0`** — `msg` will explain the failure reason.

---

## 9. PayOut — Async Notification

The final payOut result is sent via `POST JSON` to the payOut notify URL configured in **首页 (Home) → 商户设置 (Merchant Settings) → payOut_notify_url**. Fires for both successful and failed orders. Only fields inside `data` are signed.

### Payload Example

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "amount": "100.00",
    "businessNo": "8888888",
    "orderNo": "123456",
    "merchNo": "only",
    "sign": "d6a7d013c500bf7addcc336cba5b5bb9",
    "orderState": "1",
    "msg": "accountNo error"
  }
}
```
`data.msg` = failure reason, present only on failed orders.

**Your endpoint must respond with the plain string `ok`**, or the system will retry.

---

## 10. PayOut — Query Order

**URL:** `https://{domain}/api/payOut/query`
**Method:** `POST JSON`

> ⚠️ **Important:** A timeout, empty response, or a response that isn't valid JSON does **NOT** mean the order failed. Treat it as "processing" and re-confirm status later.
>
> An order should only be treated as **genuinely not existing** when the response is a well-formed JSON object where **`code == 500`** AND **`msg` contains `"OrderNo not exist"`**. Confirm this behavior via testing before going live.

### Request Parameters

| Field | Required | Type | Description |
|---|---|---|---|
| merchNo | Yes | String | Merchant number |
| orderNo | Yes | String | Merchant order number |
| sign | Yes | String | Signature |

### Request Example

```json
{
  "orderNo": "123456",
  "merchNo": "only",
  "sign": "a43a19e73a2fd6cac1d85dd1dea3c5de"
}
```

### Response — Success

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "amount": "100.00",
    "businessNo": "8888888",
    "orderNo": "123456",
    "merchNo": "only",
    "sign": "d6a7d013c500bf7addcc336cba5b5bb9",
    "msg": "accountNo error",
    "orderState": "1"
  }
}
```

### Response — Fail

```json
{
  "code": 500,
  "msg": "error msg"
}
```

---

## 11. Bank Codes (for `acctCode` in PayOut)

| Code | Bank Name |
|---|---|
| 20 | ABHI FINANCE SERVICES LIMITED |
| 23 | AFT |
| 13 | AFT IBFT |
| 96 | Advans |
| 28 | Al Meezan Investment Management Limited |
| 46 | AlHabib |
| 72 | Albarka |
| 43 | Alfalah |
| 48 | Allied |
| 76 | Apna |
| 47 | Askari |
| 87 | BOK |
| 105 | BYKEA |
| 44 | BankIslami |
| 67 | Burj |
| 15 | Central Directorate of National Savings |
| 27 | Central Directorate of National Savings (CDNS) |
| 122 | Central Directorate of National Savings (CDNS) – 1IBFT IMD Addition |
| 57 | Citi |
| 56 | DubaiIslamic |
| 110 | EZ wage |
| 86 | FINCA |
| 97 | FINJA |
| 90 | FWBL |
| 52 | Faysal |
| 92 | First Microfinance Bank |
| 49 | HBL |
| 102 | HBL ASSET MANAGEMENT |
| 118 | Habib Metro Bank – Bulk 1IBFT |
| 77 | HabibMetro |
| 113 | Humrah Financial Services |
| 95 | ICBC |
| 75 | JS |
| 51 | KASB |
| 94 | KBL |
| 22 | KEENU |
| 24 | KEENU Bank |
| 14 | KEENU – IMD and 1IBFT Screen Addition |
| 115 | Keenu1 |
| 79 | MCB |
| 100 | MCB-Arif Habib |
| 91 | MIB |
| 66 | Meezan |
| 10 | MobilinkBank Pakistan |
| 99 | NAYAPAY |
| 89 | NBP |
| 98 | NBP Fund Management Limited |
| 93 | NBP1 |
| 65 | NIB |
| 88 | NRSP |
| 109 | National Bank |
| 114 | Numbers Private Limited |
| 55 | PayMax |
| 104 | PayMax1 |
| 45 | PunjabBank |
| 11 | SADAPAY |
| 64 | SCB |
| 50 | SEEDCREED Financial Services Limited |
| 30 | SIMPAISA |
| 83 | SIND |
| 71 | Samba |
| 68 | Silk |
| 73 | SindhBank |
| 61 | Soneri |
| 58 | Summit |
| 12 | TAG |
| 103 | TezPAy |
| 60 | UBL |
| 85 | UPaisa |
| 70 | Waseela |
| 1 | Waseela bank |
| 101 | ZTBL1 |
| 42 | Zarai Taraqiati Bank |

---

## 12. Merchant Balance Query

**URL:** `https://{domain}/api/balance`
**Method:** `POST JSON`

### Request Parameters

| Field | Required | Type | Description |
|---|---|---|---|
| merchNo | Yes | String | Merchant number |
| timestamp | Yes | String | Timestamp in milliseconds |
| currency | Yes | String | Currency |
| sign | Yes | String | Signature |

### Request Example

```json
{
  "currency": "PKR",
  "merchNo": "tom",
  "timestamp": "1696514427876",
  "sign": "4fff69664b1c76d3d37d852e192113a1"
}
```

### Response — Success

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "currency": "PKR",
    "balance": "8888.00",
    "availBal": "8888.00",
    "froBal": "0.0",
    "merchNo": "tom"
  }
}
```

| Field | Description |
|---|---|
| balance | Total balance |
| availBal | Available balance |
| froBal | Frozen balance |

### Response — Fail

```json
{
  "code": 500,
  "msg": "error msg"
}
```

---

## 13. Developer Implementation Checklist

- [ ] Implement MD5 signature generation (dictionary-sort all fields + append `api_key`, no separators) for outgoing requests.
- [ ] Implement signature **verification** for incoming webhooks — dynamically sort whatever fields are present in `data` (don't hardcode field lists).
- [ ] Build a `payIn_notify_url` endpoint — must return plain string `ok`.
- [ ] Build a `payOut_notify_url` endpoint — must return plain string `ok`; must handle both success and failure notifications (check `orderState`, read `data.msg` on failure).
- [ ] Configure both notify URLs in the merchant back office (首页 → 商户设置).
- [ ] Handle payOut timeouts/empty/non-JSON responses as "processing" — never mark as failed without an explicit `code != 0` JSON response (or, for query, `code==500` + `"OrderNo not exist"` in `msg`).
- [ ] Settle payIn orders using `amount`, not `realAmount`.
- [ ] Store the Api_Key securely on first reset — it will not be shown again.
