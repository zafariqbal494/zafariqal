'use strict';

const pool = require('./database');

// In-memory cache refreshed every 5 minutes
let _settingsCache   = null;
let _settingsExpiry  = 0;

async function getSettings() {
  if (_settingsCache && Date.now() < _settingsExpiry) return _settingsCache;
  const [rows] = await pool.execute('SELECT `key`, `value` FROM settings');
  const obj = {};
  rows.forEach(r => { obj[r.key] = r.value; });
  _settingsCache  = obj;
  _settingsExpiry = Date.now() + 5 * 60 * 1000; // 5 minutes
  return obj;
}

function invalidateSettingsCache() {
  _settingsCache = null;
  _settingsExpiry = 0;
}

module.exports = {
  getSettings,
  invalidateSettingsCache,
};
