'use strict';

const path = require('path');
require('dotenv').config();

const SOLIPAY_BASE  = (process.env.SOLIPAY_BASE_URL || '').replace(/\/$/, '');
const MERCH_NO      = process.env.MERCH_NO          || '';
const API_KEY       = process.env.API_KEY           || '';
const SITE_URL      = (process.env.SITE_URL || 'https://cobrax.sbs').replace(/\/$/, '');
const PORT          = process.env.PORT              || 3000;
const COBRAX_SECRET = process.env.COBRAX_APP_SECRET || '';
const BCRYPT_ROUNDS = 10;

const DOWNLOADS_DIR = path.join(__dirname, '..', '..', 'downloads');
const PUBLIC_DIR    = path.join(__dirname, '..', '..', 'public');

// Plan metadata (days, package type) — prices come from DB settings
const PLAN_META = {
  '1':  { days: 1,  label: '24 Hours', packageType: 'basic'   },
  '30': { days: 30, label: '30 Days',  packageType: 'premium' },
};

// Default supported games list (overridden if games_config is set in DB)
const DEFAULT_GAMES = [
  { name: 'FantasyGems', url: 'https://www.fantasygems.top/#/register?invitationCode=823411353692' },
  { name: '92Pak',       url: 'https://www.92pak9.com/#/register?invitationCode=482531157170' },
  { name: '92Jeeto',     url: 'https://www.92jeeto.game/#/register?invitationCode=73675681931' },
  { name: 'BasantClub',  url: 'https://www.basantgame.biz/#/register?invitationCode=311231472888' },
  { name: '92Pkr',       url: 'https://www.92pkr4.com/#/register?invitationCode=134471781459' },
  { name: '92Dadu',      url: 'https://www.92dadu33.com/#/register?invitationCode=88585727143' },
  { name: '92Glory',     url: 'https://www.92glory77.com/#/register?invitationCode=87562985857' },
  { name: '92Coco',      url: 'https://www.92coco.net/#/register?invitationCode=86416729916' }
];

module.exports = {
  SOLIPAY_BASE,
  MERCH_NO,
  API_KEY,
  SITE_URL,
  PORT,
  COBRAX_SECRET,
  BCRYPT_ROUNDS,
  DOWNLOADS_DIR,
  PUBLIC_DIR,
  PLAN_META,
  DEFAULT_GAMES,
};
