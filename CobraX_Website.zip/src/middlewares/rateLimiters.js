'use strict';

const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many attempts. Please wait 15 minutes.' },
});

const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many admin requests.' },
});

const validateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.body?.device_id || req.ip,
  message: { status: 'error', message: 'Too many attempts. Please wait 15 minutes and try again.' },
});

const orderLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many order requests. Please try again shortly.' },
});

const pingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5, // Max 5 pings per device per hour
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.body?.device_id || req.ip,
  message: { status: 'ok' }, // silently accept even on rate-limit
  skip: () => false,
});

module.exports = {
  authLimiter,
  adminLimiter,
  validateLimiter,
  orderLimiter,
  pingLimiter,
};
