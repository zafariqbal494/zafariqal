'use strict';

const pool = require('../config/database');

async function requireAuth(req, res, next) {
  const token = req.headers['x-session-token'];
  if (!token) return res.status(401).json({ success: false, error: 'Authentication required.' });
  try {
    const [rows] = await pool.execute(
      `SELECT s.user_id, s.expires_at, u.username, u.email
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token = ? LIMIT 1`,
      [token]
    );
    if (!rows.length) return res.status(401).json({ success: false, error: 'Invalid session. Please login again.' });
    if (new Date(rows[0].expires_at) < new Date()) {
      await pool.execute('DELETE FROM sessions WHERE token = ?', [token]);
      return res.status(401).json({ success: false, error: 'Session expired. Please login again.' });
    }
    req.user = rows[0];
    next();
  } catch (err) {
    console.error('[Auth] requireAuth error:', err);
    return res.status(500).json({ success: false, error: 'Server error.' });
  }
}

async function requireAdmin(req, res, next) {
  const token = req.cookies?.cbx_admin_token || req.headers['x-admin-token'];
  if (!token) return res.status(401).json({ success: false, error: 'Admin authentication required.' });
  try {
    const [rows] = await pool.execute(
      `SELECT s.admin_id, s.expires_at, a.username
       FROM admin_sessions s JOIN admins a ON a.id = s.admin_id
       WHERE s.token = ? LIMIT 1`,
      [token]
    );
    if (!rows.length) {
      if (req.cookies?.cbx_admin_token) res.clearCookie('cbx_admin_token', { path: '/' });
      return res.status(401).json({ success: false, error: 'Invalid admin session.' });
    }
    if (new Date(rows[0].expires_at) < new Date()) {
      await pool.execute('DELETE FROM admin_sessions WHERE token = ?', [token]);
      if (req.cookies?.cbx_admin_token) res.clearCookie('cbx_admin_token', { path: '/' });
      return res.status(401).json({ success: false, error: 'Admin session expired.' });
    }
    req.admin = rows[0];
    next();
  } catch (err) {
    console.error('[Admin Auth] error:', err);
    return res.status(500).json({ success: false, error: 'Server error.' });
  }
}

module.exports = {
  requireAuth,
  requireAdmin,
};
