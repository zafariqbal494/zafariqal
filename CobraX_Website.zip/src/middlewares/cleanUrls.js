'use strict';

function cleanUrlsMiddleware(req, res, next) {
  if (req.path.endsWith('.html')) {
    const cleanPath = req.path.slice(0, -5);
    const query = req.url.slice(req.path.length);
    if (cleanPath === '/index') {
      return res.redirect(301, '/' + (query ? query : ''));
    }
    if (cleanPath === '/buy') {
      return res.redirect(301, '/buy-key' + (query ? query : ''));
    }
    return res.redirect(301, cleanPath + (query ? query : ''));
  }
  if (req.path === '/buy') {
    const query = req.url.slice(req.path.length);
    return res.redirect(301, '/buy-key' + (query ? query : ''));
  }
  next();
}

module.exports = cleanUrlsMiddleware;
