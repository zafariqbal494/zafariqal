'use strict';

/**
 * Lightweight, zero-dependency cookie parser middleware.
 * Populates req.cookies with key-value pairs from req.headers.cookie.
 */
function cookieParser(req, res, next) {
  req.cookies = {};
  const cookieHeader = req.headers.cookie;

  if (cookieHeader && typeof cookieHeader === 'string') {
    const pairs = cookieHeader.split(';');
    for (let i = 0; i < pairs.length; i++) {
      const pair = pairs[i].trim();
      const eqIdx = pair.indexOf('=');
      if (eqIdx !== -1) {
        const key = pair.slice(0, eqIdx).trim();
        const val = pair.slice(eqIdx + 1).trim();
        try {
          req.cookies[key] = decodeURIComponent(val);
        } catch (_) {
          req.cookies[key] = val;
        }
      }
    }
  }

  next();
}

module.exports = cookieParser;
