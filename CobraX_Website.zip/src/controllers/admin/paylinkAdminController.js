'use strict';

const pool = require('../../config/database');
const { SITE_URL } = require('../../config/constants');
const { generateCustomLinkId } = require('../../utils/crypto');
const { getSettings } = require('../../config/settings');

// POST /api/admin/payment-links/create
async function createPaymentLink(req, res) {
  try {
    const { title, amount_usd, note, user_identifier } = req.body;

    const numAmount = parseFloat(amount_usd || '150.00');
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({ success: false, error: 'Please specify a valid USD amount (e.g. 150.00).' });
    }

    const linkTitle = (title && String(title).trim()) ? String(title).trim() : 'Account Upgrade Service';
    const linkId = generateCustomLinkId();
    const cleanNote = note ? String(note).trim() : null;
    const cleanUser = user_identifier ? String(user_identifier).trim() : null;
    const adminUser = req.admin ? req.admin.username : 'admin';

    await pool.execute(
      `INSERT INTO custom_payment_links (link_id, title, amount_usd, note, user_identifier, status, created_by)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
      [linkId, linkTitle, numAmount.toFixed(2), cleanNote, cleanUser, adminUser]
    );

    const shareUrl = `${SITE_URL}/pay?id=${linkId}`;
    console.log(`[Admin] Custom Payment Link Created: ${linkId} | $${numAmount.toFixed(2)} | Title: ${linkTitle}`);

    return res.json({
      success: true,
      link_id: linkId,
      url: shareUrl,
      title: linkTitle,
      amount_usd: numAmount.toFixed(2),
      note: cleanNote,
      user_identifier: cleanUser,
    });
  } catch (err) {
    console.error('[Admin] /payment-links/create error:', err);
    return res.json({ success: false, error: 'Server error creating payment link.' });
  }
}

// GET /api/admin/payment-links
async function getPaymentLinks(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM custom_payment_links ORDER BY created_at DESC LIMIT 200'
    );
    const s = await getSettings();
    const exchangeRate = parseFloat(s.exchange_rate || '280');

    const enriched = rows.map(r => ({
      ...r,
      amount_pkr: Math.round(parseFloat(r.amount_usd) * exchangeRate * 100) / 100,
      url: `${SITE_URL}/pay?id=${r.link_id}`
    }));

    return res.json({ success: true, links: enriched, exchangeRate });
  } catch (err) {
    console.error('[Admin] /payment-links GET error:', err);
    return res.json({ success: false, error: 'Server error loading payment links.' });
  }
}

// POST /api/admin/payment-links/:id/cancel
async function cancelPaymentLink(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) return res.json({ success: false, error: 'Invalid link ID.' });

    const [rows] = await pool.execute('SELECT * FROM custom_payment_links WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return res.json({ success: false, error: 'Payment link not found.' });

    const link = rows[0];
    if (link.status === 'paid') {
      return res.json({ success: false, error: 'Cannot cancel a link that has already been paid.' });
    }

    await pool.execute("UPDATE custom_payment_links SET status = 'cancelled' WHERE id = ? LIMIT 1", [id]);
    console.log(`[Admin] Cancelled payment link ID: ${id} (${link.link_id})`);
    return res.json({ success: true, link_id: link.link_id, status: 'cancelled' });
  } catch (err) {
    console.error('[Admin] /payment-links/:id/cancel error:', err);
    return res.json({ success: false, error: 'Server error cancelling payment link.' });
  }
}

// DELETE /api/admin/payment-links/:id
async function deletePaymentLink(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) return res.json({ success: false, error: 'Invalid link ID.' });

    const [rows] = await pool.execute('SELECT status, order_no FROM custom_payment_links WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return res.json({ success: false, error: 'Payment link not found.' });

    if (rows[0].status === 'paid') {
      return res.json({ success: false, error: 'Cannot delete a PAID payment link. It is required for financial audit records.' });
    }

    await pool.execute('DELETE FROM custom_payment_links WHERE id = ? LIMIT 1', [id]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /payment-links DELETE error:', err);
    return res.json({ success: false, error: 'Server error deleting payment link.' });
  }
}

module.exports = {
  createPaymentLink,
  getPaymentLinks,
  cancelPaymentLink,
  deletePaymentLink,
};
