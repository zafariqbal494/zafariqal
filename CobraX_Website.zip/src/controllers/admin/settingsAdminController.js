'use strict';

const pool = require('../../config/database');
const { getSettings, invalidateSettingsCache } = require('../../config/settings');
const { DEFAULT_GAMES } = require('../../config/constants');

const MAINT_DEFAULTS = {
  push_on_title:   '🛑 CobraX — Server Maintenance',
  push_on_msg:     "Prediction server is temporarily offline for maintenance. We'll be back shortly!",
  push_off_title:  '✅ CobraX — Server Online',
  push_off_msg:    '🚀 Prediction server is back online! WinGo 30Sec results are now live.',
  banner_on_title: '⚠️ Prediction Server Offline',
  banner_on_msg:   'Our prediction engine is currently under maintenance. Results will resume shortly. Thank you for your patience.',
};

// Push templates start empty — only custom templates saved by admin are listed
const DEFAULT_PUSH_TEMPLATES = [];


// GET /api/admin/settings
async function getSettingsAdmin(req, res) {
  try {
    const [rows] = await pool.execute('SELECT `key`, `value`, updated_at FROM settings ORDER BY `key`');
    const sanitizedRows = rows.map(r => ({
      key: r.key,
      value: r.key === 'onesignal_rest_api_key' ? (r.value ? '••••••••••••••••' : '') : r.value,
      updated_at: r.updated_at
    }));
    return res.json({ success: true, settings: sanitizedRows });
  } catch (err) {
    console.error('[Admin] /settings GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/settings
async function updateSettingsAdmin(req, res) {
  try {
    const { settings } = req.body;
    if (!settings || typeof settings !== 'object')
      return res.json({ success: false, error: 'Settings object required.' });

    for (const [key, value] of Object.entries(settings)) {
      if (key === 'onesignal_rest_api_key' && String(value).includes('••••')) continue;
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]);
    }
    invalidateSettingsCache();
    console.log(`[Admin] Settings updated: ${Object.keys(settings).join(', ')}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /settings PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/announcement
async function getAnnouncement(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      announcement: {
        enabled:     (s.announcement_enabled || '0') === '1',
        title:       s.announcement_title || '',
        message:     s.announcement_message || '',
        type:        s.announcement_type    || 'info',
        url:         s.announcement_url     || '',
        dismissible: (s.announcement_dismissible || '1') === '1',
      }
    });
  } catch (err) {
    console.error('[Admin] /announcement GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/announcement
async function updateAnnouncement(req, res) {
  try {
    const { enabled, title, message, type, url, dismissible } = req.body;
    const settingsUpdate = {
      announcement_enabled:     enabled ? '1' : '0',
      announcement_title:       title   || '',
      announcement_message:     message || '',
      announcement_type:        type    || 'info',
      announcement_url:         url     || '',
      announcement_dismissible: dismissible ? '1' : '0',
    };
    for (const [key, value] of Object.entries(settingsUpdate)) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]);
    }
    invalidateSettingsCache();
    console.log(`[Admin] Announcement broadcast updated: enabled=${enabled}, type=${type}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /announcement PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/games
async function getGames(req, res) {
  try {
    const s = await getSettings();
    let games = DEFAULT_GAMES;
    if (s.games_config) {
      try {
        const parsed = JSON.parse(s.games_config);
        if (Array.isArray(parsed) && parsed.length > 0) games = parsed;
      } catch (e) {}
    }
    return res.json({
      success: true,
      telegramAddress: s.telegram_address || 't.me/winXcobra',
      games: games,
    });
  } catch (err) {
    console.error('[Admin] /games GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/games
async function updateGames(req, res) {
  try {
    const { telegramAddress, games } = req.body;
    if (!Array.isArray(games) || games.length === 0) {
      return res.json({ success: false, error: 'Games list must be a non-empty array.' });
    }

    const cleanGames = games.map(g => ({
      name: String(g.name || 'Game').trim(),
      url: String(g.url || '').trim(),
    }));

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['games_config', JSON.stringify(cleanGames), JSON.stringify(cleanGames)]);

    if (telegramAddress !== undefined) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['telegram_address', String(telegramAddress).trim(), String(telegramAddress).trim()]);
    }

    invalidateSettingsCache();
    console.log(`[Admin] Games config updated: ${cleanGames.length} games`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /games PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/version
async function getVersion(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      minAppVersion: s.min_app_version || '5.0.1',
      latestAppVersion: s.latest_app_version || '5.0.1',
      updateUrl: s.update_download_url || 'https://cobrax.sbs',
      forceUpdateEnabled: (s.force_update_enabled || '1') === '1',
    });
  } catch (err) {
    console.error('[Admin] /version GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/version
async function updateVersion(req, res) {
  try {
    const { minAppVersion, latestAppVersion, updateUrl, forceUpdateEnabled } = req.body;
    const updates = {
      min_app_version: minAppVersion ? String(minAppVersion).trim() : '5.0.1',
      latest_app_version: latestAppVersion ? String(latestAppVersion).trim() : '5.0.1',
      update_download_url: updateUrl ? String(updateUrl).trim() : 'https://cobrax.sbs',
      force_update_enabled: forceUpdateEnabled ? '1' : '0',
    };

    for (const [key, value] of Object.entries(updates)) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]
      );
    }

    invalidateSettingsCache();
    console.log(`[Admin] Version settings updated: min=${updates.min_app_version}, latest=${updates.latest_app_version}, force=${updates.force_update_enabled}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /version PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/push/config
async function getPushConfig(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      appId: s.onesignal_app_id || '',
      hasApiKey: !!s.onesignal_rest_api_key,
      lastPushTitle: s.last_push_title || '',
      lastPushTime: s.last_push_time || '',
    });
  } catch (err) {
    console.error('[Push] config GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/push/config
async function updatePushConfig(req, res) {
  try {
    const { appId, restApiKey } = req.body;
    if (appId !== undefined) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['onesignal_app_id', String(appId).trim(), String(appId).trim()]
      );
    }
    if (restApiKey !== undefined && String(restApiKey).trim().length > 0) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['onesignal_rest_api_key', String(restApiKey).trim(), String(restApiKey).trim()]
      );
    }

    invalidateSettingsCache();
    console.log('[Push] OneSignal config updated by Admin');
    return res.json({ success: true });
  } catch (err) {
    console.error('[Push] config PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/push/send
async function sendPush(req, res) {
  try {
    const { title, message, url, type } = req.body;
    if (!title || !message) {
      return res.json({ success: false, error: 'Title and message are required.' });
    }

    const s = await getSettings();
    const appId = s.onesignal_app_id || process.env.ONESIGNAL_APP_ID;
    const apiKey = s.onesignal_rest_api_key || process.env.ONESIGNAL_REST_API_KEY;

    if (!appId || !apiKey) {
      return res.json({
        success: false,
        error: 'OneSignal credentials not set. Please enter your OneSignal App ID and REST API Key in the settings below.',
      });
    }

    const payload = {
      app_id: appId,
      included_segments: ['Subscribed Users', 'Total Subscriptions'],
      headings: { en: title.trim() },
      contents: { en: message.trim() },
      small_icon: 'ic_launcher',
    };

    if (url && url.trim().length > 0) {
      payload.url = url.trim();
      payload.data = { url: url.trim(), type: type || 'info' };
    }

    let cleanKey = apiKey.trim().replace(/^(Basic|Key|Bearer)\s+/i, '');
    let authHeader = `Key ${cleanKey}`;

    let response = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': authHeader,
      },
      body: JSON.stringify(payload),
    });

    let data = await response.json();

    if (!response.ok && data.error && data.error.includes('Authorization')) {
      console.log('[Push] Retrying OneSignal with Basic auth header...');
      response = await fetch('https://onesignal.com/api/v1/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': `Basic ${cleanKey}`,
        },
        body: JSON.stringify(payload),
      });
      data = await response.json();
    }

    if (response.ok && data.id) {
      console.log(`[Push] OneSignal notification sent: ID=${data.id}, Recipients=${data.recipients || 0}`);

      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['last_push_title', title.trim(), title.trim()]
      );
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['last_push_time', new Date().toISOString(), new Date().toISOString()]
      );
      invalidateSettingsCache();

      return res.json({
        success: true,
        id: data.id,
        recipients: data.recipients || 0,
      });
    } else {
      console.error('[Push] OneSignal error response:', data);
      let errMsg = (data.errors && Array.isArray(data.errors))
        ? data.errors.join(', ')
        : (data.errors || data.error || 'Failed to send notification via OneSignal.');

      if (typeof errMsg === 'string' && (errMsg.includes('not subscribed') || errMsg.includes('players are not subscribed'))) {
        errMsg = 'OneSignal connected successfully! However, 0 mobile devices are currently registered in your OneSignal App. Open the updated CobraX App on your phone once to register your device, then broadcast!';
      }

      return res.json({ success: false, error: errMsg });
    }
  } catch (err) {
    console.error('[Push] Exception:', err);
    return res.json({ success: false, error: 'Server error sending push notification.' });
  }
}

// GET /api/admin/push/templates
async function getPushTemplates(req, res) {
  try {
    const s = await getSettings();
    let templates = [];
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom)) {
          templates = custom.filter(t => !t.is_default && !t.id?.startsWith('tmpl-flash') && !t.id?.startsWith('tmpl-engine') && !t.id?.startsWith('tmpl-maintenance') && !t.id?.startsWith('tmpl-vip-renew'));
        }
      } catch (_) {}
    }
    return res.json({ success: true, templates });
  } catch (err) {
    console.error('[Push] templates GET error:', err);
    return res.json({ success: false, error: 'Server error loading templates.' });
  }
}

// POST /api/admin/push/templates
async function createPushTemplate(req, res) {
  try {
    const { name, title, message, url } = req.body;
    if (!name || !title || !message) {
      return res.json({ success: false, error: 'Template name, title, and message body are required.' });
    }

    const s = await getSettings();
    let templates = [];
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom)) {
          templates = custom.filter(t => !t.is_default && !t.id?.startsWith('tmpl-flash') && !t.id?.startsWith('tmpl-engine') && !t.id?.startsWith('tmpl-maintenance') && !t.id?.startsWith('tmpl-vip-renew'));
        }
      } catch (_) {}
    }

    const newTmpl = {
      id: `tmpl-${Date.now()}`,
      name: String(name).trim(),
      title: String(title).trim(),
      message: String(message).trim(),
      url: url ? String(url).trim() : '',
      created_at: new Date().toISOString(),
      is_default: false,
    };

    templates.unshift(newTmpl);

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['push_templates', JSON.stringify(templates), JSON.stringify(templates)]
    );
    invalidateSettingsCache();

    console.log(`[Push] Saved new push template: "${newTmpl.name}"`);
    return res.json({ success: true, template: newTmpl, templates });
  } catch (err) {
    console.error('[Push] templates POST error:', err);
    return res.json({ success: false, error: 'Server error saving template.' });
  }
}

// DELETE /api/admin/push/templates/:id
async function deletePushTemplate(req, res) {
  try {
    const tmplId = String(req.params.id || '').trim();
    if (!tmplId) return res.json({ success: false, error: 'Invalid template ID.' });

    const s = await getSettings();
    let templates = [];
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom)) {
          templates = custom.filter(t => !t.is_default && !t.id?.startsWith('tmpl-flash') && !t.id?.startsWith('tmpl-engine') && !t.id?.startsWith('tmpl-maintenance') && !t.id?.startsWith('tmpl-vip-renew'));
        }
      } catch (_) {}
    }

    templates = templates.filter(t => t.id !== tmplId);

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['push_templates', JSON.stringify(templates), JSON.stringify(templates)]
    );
    invalidateSettingsCache();

    console.log(`[Push] Deleted push template: ${tmplId}`);
    return res.json({ success: true, templates });
  } catch (err) {
    console.error('[Push] templates DELETE error:', err);
    return res.json({ success: false, error: 'Server error deleting template.' });
  }
}

// GET /api/admin/maintenance/config
async function getMaintenanceConfig(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      maintenanceMode: (s.maintenance_mode || '0') === '1',
      push_on_title:   s.maint_push_on_title   || MAINT_DEFAULTS.push_on_title,
      push_on_msg:     s.maint_push_on_msg     || MAINT_DEFAULTS.push_on_msg,
      push_off_title:  s.maint_push_off_title  || MAINT_DEFAULTS.push_off_title,
      push_off_msg:    s.maint_push_off_msg    || MAINT_DEFAULTS.push_off_msg,
      banner_on_title: s.maint_banner_on_title || MAINT_DEFAULTS.banner_on_title,
      banner_on_msg:   s.maint_banner_on_msg   || MAINT_DEFAULTS.banner_on_msg,
    });
  } catch (err) {
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/maintenance/config
async function updateMaintenanceConfig(req, res) {
  try {
    const {
      push_on_title, push_on_msg,
      push_off_title, push_off_msg,
      banner_on_title, banner_on_msg,
    } = req.body;

    const upsert = (k, v) => pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      [k, String(v), String(v)]
    );

    if (push_on_title   !== undefined) await upsert('maint_push_on_title',   push_on_title.trim()   || MAINT_DEFAULTS.push_on_title);
    if (push_on_msg     !== undefined) await upsert('maint_push_on_msg',     push_on_msg.trim()     || MAINT_DEFAULTS.push_on_msg);
    if (push_off_title  !== undefined) await upsert('maint_push_off_title',  push_off_title.trim()  || MAINT_DEFAULTS.push_off_title);
    if (push_off_msg    !== undefined) await upsert('maint_push_off_msg',    push_off_msg.trim()    || MAINT_DEFAULTS.push_off_msg);
    if (banner_on_title !== undefined) await upsert('maint_banner_on_title', banner_on_title.trim() || MAINT_DEFAULTS.banner_on_title);
    if (banner_on_msg   !== undefined) await upsert('maint_banner_on_msg',   banner_on_msg.trim()   || MAINT_DEFAULTS.banner_on_msg);

    invalidateSettingsCache();
    console.log('[Maintenance] Message templates updated by Admin');
    return res.json({ success: true });
  } catch (err) {
    console.error('[Maintenance] Config PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/maintenance/toggle
async function toggleMaintenance(req, res) {
  try {
    const { enable } = req.body;
    const isOn = enable === true;
    const flag = isOn ? '1' : '0';

    const upsert = (k, v) => pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      [k, String(v), String(v)]
    );

    await upsert('maintenance_mode', flag);

    const s = await getSettings();
    const bannerTitle = s.maint_banner_on_title || MAINT_DEFAULTS.banner_on_title;
    const bannerMsg   = s.maint_banner_on_msg   || MAINT_DEFAULTS.banner_on_msg;
    const pushTitle   = isOn
      ? (s.maint_push_on_title  || MAINT_DEFAULTS.push_on_title)
      : (s.maint_push_off_title || MAINT_DEFAULTS.push_off_title);
    const pushMessage = isOn
      ? (s.maint_push_on_msg    || MAINT_DEFAULTS.push_on_msg)
      : (s.maint_push_off_msg   || MAINT_DEFAULTS.push_off_msg);

    if (isOn) {
      await upsert('announcement_enabled',     '1');
      await upsert('announcement_type',        'maintenance');
      await upsert('announcement_title',       bannerTitle);
      await upsert('announcement_message',     bannerMsg);
      await upsert('announcement_dismissible', '0');
    } else {
      await upsert('announcement_enabled',     '0');
      await upsert('announcement_type',        'info');
      await upsert('announcement_title',       '');
      await upsert('announcement_message',     '');
      await upsert('announcement_dismissible', '1');
    }

    invalidateSettingsCache();

    let pushSent = false;
    try {
      const s2 = await getSettings();
      const appId  = s2.onesignal_app_id      || process.env.ONESIGNAL_APP_ID;
      const apiKey = s2.onesignal_rest_api_key || process.env.ONESIGNAL_REST_API_KEY;

      if (appId && apiKey) {
        const cleanKey = apiKey.trim().replace(/^(Basic|Key|Bearer)\s+/i, '');
        const notifRes = await fetch('https://onesignal.com/api/v1/notifications', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': `Key ${cleanKey}`,
          },
          body: JSON.stringify({
            app_id: appId,
            included_segments: ['Subscribed Users', 'Total Subscriptions'],
            headings: { en: pushTitle },
            contents: { en: pushMessage },
            small_icon: 'ic_stat_onesignal_default',
          }),
        });
        const notifData = await notifRes.json();
        pushSent = !!(notifRes.ok && notifData.id);
        console.log(`[Maintenance] Push ${pushSent ? 'sent' : 'failed'}`, notifData);
      }
    } catch (pushErr) {
      console.error('[Maintenance] Push error:', pushErr.message);
    }

    console.log(`[Maintenance] Mode ${isOn ? 'ACTIVATED' : 'DEACTIVATED'} by Admin`);
    return res.json({ success: true, maintenanceMode: isOn, pushSent });
  } catch (err) {
    console.error('[Maintenance] Toggle error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/maintenance/status
async function getMaintenanceStatus(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      maintenanceMode: (s.maintenance_mode || '0') === '1',
    });
  } catch (err) {
    return res.json({ success: false, error: 'Server error.' });
  }
}

module.exports = {
  getSettingsAdmin,
  updateSettingsAdmin,
  getAnnouncement,
  updateAnnouncement,
  getGames,
  updateGames,
  getVersion,
  updateVersion,
  getPushConfig,
  updatePushConfig,
  sendPush,
  getPushTemplates,
  createPushTemplate,
  deletePushTemplate,
  getMaintenanceConfig,
  updateMaintenanceConfig,
  toggleMaintenance,
  getMaintenanceStatus,
};
