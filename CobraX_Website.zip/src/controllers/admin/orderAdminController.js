'use strict';

const pool = require('../../config/database');
const { PLAN_META } = require('../../config/constants');
const { generateKey } = require('../../utils/crypto');
const { sendKeyDeliveryEmail } = require('../../utils/email');

// GET /api/admin/orders
async function getOrders(req, res) {
  try {
    const page     = Math.max(1, parseInt(req.query.page || '1'));
    const limit    = Math.min(Math.max(1, parseInt(req.query.limit || '10')), 100);
    const offset   = req.query.offset !== undefined ? Math.max(0, parseInt(req.query.offset)) : (page - 1) * limit;
    const search   = req.query.search ? String(req.query.search).trim() : '';
    const status   = req.query.status ? String(req.query.status).toLowerCase().trim() : 'all';
    const category = req.query.category ? String(req.query.category).toLowerCase().trim() : 'all';

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push(`(o.order_no LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR o.auth_key LIKE ? OR o.referral_code LIKE ? OR o.plan LIKE ?)`);
      const s = `%${search}%`;
      params.push(s, s, s, s, s, s);
    }
    if (status === 'paid' || status === '1') {
      whereClauses.push(`o.order_state = '1'`);
    } else if (status === 'pending' || status === '0') {
      whereClauses.push(`o.order_state != '1'`);
    }
    if (category === 'keys') {
      whereClauses.push(`o.plan NOT IN ('deposit', 'custom')`);
    } else if (category === 'deposits') {
      whereClauses.push(`o.plan = 'deposit'`);
    } else if (category === 'custom') {
      whereClauses.push(`o.plan = 'custom'`);
    }

    const whereSql = whereClauses.length > 0 ? ` WHERE ` + whereClauses.join(' AND ') : '';

    // Total matching records for pagination
    const countSql = `SELECT COUNT(*) AS total FROM orders o LEFT JOIN users u ON u.id = o.user_id ${whereSql}`;
    const [[{ total }]] = await pool.execute(countSql, params);

    // Global counts across entire database for filter pills
    const [[{ allCount }]]      = await pool.execute("SELECT COUNT(*) AS allCount FROM orders");
    const [[{ paidCount }]]     = await pool.execute("SELECT COUNT(*) AS paidCount FROM orders WHERE order_state = '1'");
    const [[{ pendingCount }]]  = await pool.execute("SELECT COUNT(*) AS pendingCount FROM orders WHERE order_state != '1'");
    const [[{ keysCount }]]     = await pool.execute("SELECT COUNT(*) AS keysCount FROM orders WHERE plan NOT IN ('deposit', 'custom')");
    const [[{ depositsCount }]] = await pool.execute("SELECT COUNT(*) AS depositsCount FROM orders WHERE plan = 'deposit'");
    const [[{ customCount }]]   = await pool.execute("SELECT COUNT(*) AS customCount FROM orders WHERE plan = 'custom'");

    let sql = `SELECT o.*, u.username, u.email,
                      a.expires_at AS key_expires, a.status AS key_status,
                      a.device_id AS key_device_id, a.selected_games AS key_selected_games
               FROM orders o
               LEFT JOIN users u ON u.id = o.user_id
               LEFT JOIN auth_keys a ON a.order_no = o.order_no
               ${whereSql}
               ORDER BY o.created_at DESC LIMIT ? OFFSET ?`;

    const [orders] = await pool.execute(sql, [...params, String(limit), String(offset)]);

    const keys = orders.map(o => o.auth_key).filter(Boolean);
    const userIds = orders.map(o => o.user_id).filter(Boolean);
    const deviceIds = orders.map(o => o.key_device_id).filter(Boolean);

    let allProfiles = [];
    if (keys.length > 0 || userIds.length > 0 || deviceIds.length > 0) {
      const conds = [];
      const condParams = [];
      if (keys.length > 0) {
        conds.push(`key_code IN (${keys.map(() => '?').join(',')})`);
        condParams.push(...keys);
      }
      if (userIds.length > 0) {
        conds.push(`user_id IN (${userIds.map(() => '?').join(',')})`);
        condParams.push(...userIds);
      }
      if (deviceIds.length > 0) {
        conds.push(`device_id IN (${deviceIds.map(() => '?').join(',')})`);
        condParams.push(...deviceIds);
      }
      const [profiles] = await pool.execute(
        `SELECT * FROM game_user_profiles WHERE ${conds.join(' OR ')} ORDER BY last_synced_at DESC`,
        condParams
      );
      allProfiles = profiles;
    }

    const enriched = orders.map(o => {
      let games = [];
      const rawGames = o.selected_games || o.key_selected_games;
      if (rawGames) {
        try {
          games = typeof rawGames === 'string' ? JSON.parse(rawGames) : rawGames;
        } catch (_) {}
      }
      const isKeyOrder = Boolean(o.auth_key && String(o.auth_key).trim().length > 0);

      const orderProfiles = allProfiles.filter(p => {
        if (isKeyOrder) {
          return p.key_code === o.auth_key;
        }
        if (o.key_device_id && p.device_id === o.key_device_id) return true;
        if (o.user_id && p.user_id === o.user_id) return true;
        return false;
      });

      return {
        ...o,
        selected_games: Array.isArray(games) ? games : [],
        game_profiles: orderProfiles
      };
    });

    return res.json({
      success: true,
      orders: enriched,
      total,
      page,
      limit,
      counts: {
        all: allCount,
        paid: paidCount,
        pending: pendingCount,
        keys: keysCount,
        deposits: depositsCount,
        custom: customCount,
      }
    });
  } catch (err) {
    console.error('[Admin] /orders error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/orders/:orderNo/status
async function updateOrderStatus(req, res) {
  let conn = null;
  try {
    const orderNo = String(req.params.orderNo || '').trim();
    const { status } = req.body;
    if (!orderNo || !status) {
      return res.json({ success: false, error: 'Order number and status are required.' });
    }

    const isPaid = status === 'paid' || status === '1';

    conn = await pool.getConnection();
    await conn.beginTransaction();

    const [rows] = await conn.execute('SELECT * FROM orders WHERE order_no = ? FOR UPDATE', [orderNo]);
    if (!rows.length) {
      await conn.rollback();
      return res.json({ success: false, error: 'Order not found.' });
    }
    const order = rows[0];

    if (isPaid) {
      if (order.plan === 'deposit') {
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.execute("UPDATE device_deposits SET status='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.commit();
        console.log(`[Admin] Manually marked In-Game Deposit as PAID: ${orderNo}`);
        return res.json({ success: true, orderNo, status: 'paid' });
      }

      if (order.plan === 'custom') {
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.execute("UPDATE custom_payment_links SET status='paid', paid_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.commit();
        console.log(`[Admin] Manually marked Custom Payment Link as PAID: ${orderNo}`);
        return res.json({ success: true, orderNo, status: 'paid' });
      }

      let key = order.auth_key;
      const days = order.duration_days || (PLAN_META[order.plan] ? PLAN_META[order.plan].days : 30);
      const planInfo = PLAN_META[order.plan] || { packageType: 'basic' };
      const gamesJson = order.selected_games ? (typeof order.selected_games === 'string' ? order.selected_games : JSON.stringify(order.selected_games)) : null;

      if (!key) {
        key = generateKey(days);
        await conn.execute(
          `UPDATE orders SET order_state='1', auth_key=?, confirmed_at=NOW() WHERE order_no=?`,
          [key, orderNo]
        );
        await conn.execute(
          `INSERT IGNORE INTO auth_keys (\`key\`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)`,
          [key, planInfo.packageType, days, orderNo, gamesJson]
        );
      } else {
        // Reactivate key if it was previously revoked when reverted to pending
        await conn.execute("UPDATE auth_keys SET status = (CASE WHEN activated_at IS NOT NULL THEN 'active' ELSE 'unused' END) WHERE `key` = ? AND status = 'revoked'", [key]);
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
      }

      await conn.commit();

      // Trigger Key Delivery Email
      try {
        const [uRows] = await pool.execute('SELECT u.email, u.username FROM orders o JOIN users u ON u.id = o.user_id WHERE o.order_no = ? LIMIT 1', [orderNo]);
        if (uRows.length && uRows[0].email) {
          sendKeyDeliveryEmail(uRows[0].email, uRows[0].username, orderNo, key, order.plan, days, gamesJson, order.amount).catch(() => {});
        }
      } catch (_) {}

      console.log(`[Admin] Manually marked VIP Key Order as PAID: ${orderNo} -> Key: ${key}`);
      return res.json({ success: true, orderNo, status: 'paid', key });

    } else {
      // Revert to pending & revoke associated license keys (SEC-04)
      await conn.execute("UPDATE orders SET order_state='0', confirmed_at=NULL WHERE order_no=?", [orderNo]);
      if (order.auth_key) {
        await conn.execute("UPDATE auth_keys SET status='revoked' WHERE order_no=? OR `key`=?", [orderNo, order.auth_key]);
      } else {
        await conn.execute("UPDATE auth_keys SET status='revoked' WHERE order_no=?", [orderNo]);
      }

      if (order.plan === 'deposit') {
        await conn.execute("UPDATE device_deposits SET status='0', confirmed_at=NULL WHERE order_no=?", [orderNo]);
      } else if (order.plan === 'custom') {
        await conn.execute("UPDATE custom_payment_links SET status='pending', paid_at=NULL WHERE order_no=?", [orderNo]);
      }

      await conn.commit();
      console.log(`[Admin] Manually reverted Order to PENDING and REVOKED associated keys: ${orderNo}`);
      return res.json({ success: true, orderNo, status: 'pending', keyRevoked: true });
    }

  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (_) {}
    }
    console.error('[Admin] /orders/:orderNo/status error:', err);
    return res.json({ success: false, error: 'Server error updating order status.' });
  } finally {
    if (conn) {
      conn.release();
    }
  }
}

// POST /api/admin/set-vip-level
async function setVipLevel(req, res) {
  try {
    const { profile_id, key_code, game_name, vip_level } = req.body;
    const targetVip = vip_level === null || vip_level === '' || isNaN(parseInt(vip_level)) ? null : parseInt(vip_level);

    let targetUserId = null;
    let targetGame = game_name ? String(game_name).trim() : null;
    let targetKey = key_code ? String(key_code).trim().toUpperCase() : null;

    if (profile_id) {
      const [rows] = await pool.execute('SELECT game_user_id, game_name, key_code FROM game_user_profiles WHERE id = ? LIMIT 1', [profile_id]);
      if (rows.length) {
        targetUserId = rows[0].game_user_id ? String(rows[0].game_user_id).trim() : null;
        if (!targetGame) targetGame = rows[0].game_name ? String(rows[0].game_name).trim() : null;
        if (!targetKey) targetKey = rows[0].key_code ? String(rows[0].key_code).trim().toUpperCase() : null;
      }
      await pool.execute(
        'UPDATE game_user_profiles SET custom_vip_level = ? WHERE id = ?',
        [targetVip, profile_id]
      );
    }

    if (targetKey) {
      if (targetGame) {
        await pool.execute(
          `INSERT INTO game_user_profiles (key_code, game_name, game_user_id, custom_vip_level, first_synced_at, last_synced_at)
           VALUES (?, ?, ?, ?, NOW(), NOW())
           ON DUPLICATE KEY UPDATE custom_vip_level = ?`,
          [targetKey, targetGame, targetUserId, targetVip, targetVip]
        );
      }

      try {
        const [kRows] = await pool.execute('SELECT custom_vip_levels FROM auth_keys WHERE `key` = ? LIMIT 1', [targetKey]);
        if (kRows.length) {
          let map = {};
          try {
            if (kRows[0].custom_vip_levels) map = JSON.parse(kRows[0].custom_vip_levels);
          } catch (_) {}

          delete map['default'];

          if (targetGame) {
            if (targetVip !== null) {
              map[targetGame] = { vip: targetVip, user_id: targetUserId };
            } else {
              delete map[targetGame];
            }
          }
          await pool.execute('UPDATE auth_keys SET custom_vip_levels = ? WHERE `key` = ?', [JSON.stringify(map), targetKey]);
        }
      } catch (_) {}
    } else if (!profile_id) {
      return res.status(400).json({ success: false, error: 'Profile ID or Key + Game Name is required.' });
    }

    console.log(`[Admin] Set custom VIP level for ${targetGame || targetKey || profile_id} (UserID: ${targetUserId || 'all'}) to VIP ${targetVip}`);
    return res.json({ success: true, custom_vip_level: targetVip, target_user_id: targetUserId, game_name: targetGame });
  } catch (err) {
    console.error('[Admin] /set-vip-level error:', err);
    return res.status(500).json({ success: false, error: 'Server error updating VIP level.' });
  }
}

module.exports = {
  getOrders,
  updateOrderStatus,
  setVipLevel,
};
