'use strict';

const bcrypt = require('bcrypt');
const pool   = require('../../config/database');
const { generateSessionToken } = require('../../utils/crypto');

// POST /api/admin/login
async function adminLogin(req, res) {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.json({ success: false, error: 'Credentials required.' });

    const [rows] = await pool.execute('SELECT * FROM admins WHERE username = ? LIMIT 1', [username.trim()]);
    if (!rows.length) return res.json({ success: false, error: 'Invalid credentials.' });

    const match = await bcrypt.compare(password, rows[0].password);
    if (!match) return res.json({ success: false, error: 'Invalid credentials.' });

    const token     = generateSessionToken();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    await pool.execute('INSERT INTO admin_sessions (token, admin_id, expires_at) VALUES (?, ?, ?)',
      [token, rows[0].id, expiresAt]);

    // Set secure httpOnly cookie
    res.cookie('cbx_admin_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000,
      path: '/',
    });

    console.log(`[Admin] Login: ${rows[0].username}`);
    return res.json({ success: true, token, username: rows[0].username });
  } catch (err) {
    console.error('[Admin] /login error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/logout
async function adminLogout(req, res) {
  try {
    const token = req.cookies?.cbx_admin_token || req.headers['x-admin-token'];
    if (token) {
      await pool.execute('DELETE FROM admin_sessions WHERE token = ?', [token]);
    }
    res.clearCookie('cbx_admin_token', { path: '/' });
    return res.json({ success: true });
  } catch (err) {
    res.clearCookie('cbx_admin_token', { path: '/' });
    return res.json({ success: false });
  }
}

// GET /api/admin/me
function getAdminMe(req, res) {
  return res.json({ success: true, username: req.admin ? req.admin.username : 'Admin' });
}

module.exports = {
  adminLogin,
  adminLogout,
  getAdminMe,
};
