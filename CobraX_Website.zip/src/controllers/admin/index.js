'use strict';

const authAdminController     = require('./authAdminController');
const dashboardAdminController= require('./dashboardAdminController');
const orderAdminController    = require('./orderAdminController');
const userAdminController     = require('./userAdminController');
const keyAdminController      = require('./keyAdminController');
const paylinkAdminController  = require('./paylinkAdminController');
const payoutAdminController   = require('./payoutAdminController');
const settingsAdminController = require('./settingsAdminController');

module.exports = {
  // Domain Sub-Controllers
  auth:     authAdminController,
  dashboard:dashboardAdminController,
  orders:   orderAdminController,
  users:    userAdminController,
  keys:     keyAdminController,
  paylinks: paylinkAdminController,
  payouts:  payoutAdminController,
  settings: settingsAdminController,

  // Flat re-exports for 100% backward compatibility
  ...authAdminController,
  ...dashboardAdminController,
  ...orderAdminController,
  ...userAdminController,
  ...keyAdminController,
  ...paylinkAdminController,
  ...payoutAdminController,
  ...settingsAdminController,
};
