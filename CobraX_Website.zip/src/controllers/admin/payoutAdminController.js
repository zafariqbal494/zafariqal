'use strict';

const pool = require('../../config/database');
const { SOLIPAY_BASE, MERCH_NO, API_KEY, SITE_URL } = require('../../config/constants');
const { generateSign, generatePayoutOrderNo } = require('../../utils/crypto');
const { httpPost } = require('../../utils/helpers');
const { getSettings } = require('../../config/settings');

// GET /api/admin/payout/balance
async function getPayoutBalance(req, res) {
  try {
    if (!SOLIPAY_BASE || !MERCH_NO || !API_KEY) {
      return res.json({
        success: false,
        error: 'SoliPay credentials not configured. Please check SOLIPAY_BASE_URL, MERCH_NO, and API_KEY in .env.'
      });
    }

    const timestamp = String(Date.now());
    const params = {
      currency: 'PKR',
      merchNo: MERCH_NO,
      timestamp,
    };
    const sign = generateSign(params, API_KEY);

    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/balance`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      const detail = solipayRes._message || (solipayRes._timeout ? 'Gateway Timeout' : 'Invalid JSON');
      return res.json({ success: false, error: `Could not fetch balance: ${detail}` });
    }

    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Failed to query balance from SoliPay.' });
    }

    const bData = solipayRes.data || {};
    return res.json({
      success: true,
      currency: bData.currency || 'PKR',
      balance: parseFloat(bData.balance || '0.00'),
      availBal: parseFloat(bData.availBal || '0.00'),
      froBal: parseFloat(bData.froBal || '0.00'),
      merchNo: bData.merchNo || MERCH_NO,
    });
  } catch (err) {
    console.error('[Admin Payout] Balance query exception:', err);
    return res.json({ success: false, error: 'Server error querying balance.' });
  }
}

// POST /api/admin/payout/create
async function createPayout(req, res) {
  try {
    const { amount, acctName, acctCode, acctNo, mobile } = req.body;

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({ success: false, error: 'Please enter a valid withdrawal amount.' });
    }
    if (!acctName || typeof acctName !== 'string' || !acctName.trim()) {
      return res.json({ success: false, error: 'Account title / recipient name is required.' });
    }
    if (!acctCode || typeof acctCode !== 'string' || !acctCode.trim()) {
      return res.json({ success: false, error: 'Payout channel / bank code is required.' });
    }
    if (!acctNo || typeof acctNo !== 'string' || !acctNo.trim()) {
      return res.json({ success: false, error: 'Account number / IBAN is required.' });
    }

    const cleanAcctName = acctName.trim();
    const cleanAcctCode = acctCode.trim();
    const cleanAcctNo   = acctNo.trim();
    const cleanMobile   = mobile ? String(mobile).trim() : null;

    const orderNo   = generatePayoutOrderNo();
    const notifyUrl = `${SITE_URL}/webhook/payout`;
    const amountStr = numAmount.toFixed(2);

    const params = {
      amount: amountStr,
      orderNo,
      merchNo: MERCH_NO,
      acctCode: cleanAcctCode,
      acctNo: cleanAcctNo,
      acctName: cleanAcctName,
      currency: 'PKR',
      notifyUrl,
    };
    if (cleanMobile) {
      params.mobile = cleanMobile;
    }

    const sign = generateSign(params, API_KEY);
    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payOut`, { ...params, sign });

    let initialStatus = '0';
    let errorMsg = null;
    let businessNo = null;

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      console.warn('[Admin Payout] Gateway timeout/network response during creation. Order treated as processing:', orderNo);
      errorMsg = 'Gateway response delayed (processing)';
    } else if (solipayRes.code === 0) {
      initialStatus = String(solipayRes.data?.orderState || '0');
      businessNo = solipayRes.data?.businessNo || null;
    } else {
      return res.json({
        success: false,
        error: solipayRes.msg || 'SoliPay payout rejected by gateway.',
      });
    }

    await pool.execute(
      `INSERT INTO payouts (order_no, amount, acct_name, acct_code, acct_no, mobile, currency, status, business_no, error_msg, admin_username)
       VALUES (?, ?, ?, ?, ?, ?, 'PKR', ?, ?, ?, ?)`,
      [orderNo, amountStr, cleanAcctName, cleanAcctCode, cleanAcctNo, cleanMobile, initialStatus, businessNo, errorMsg, req.admin ? req.admin.username : 'admin']
    );

    console.log(`[Admin Payout] Withdrawal initiated: ${orderNo} | PKR ${amountStr} | ${cleanAcctCode} | ${cleanAcctName} (${cleanAcctNo})`);

    return res.json({
      success: true,
      orderNo,
      amount: amountStr,
      status: initialStatus,
      message: solipayRes.msg || 'Withdrawal request submitted successfully!',
    });
  } catch (err) {
    console.error('[Admin Payout] /create exception:', err);
    return res.json({ success: false, error: 'Server error processing withdrawal.' });
  }
}

// GET /api/admin/payouts
async function getPayouts(req, res) {
  try {
    const limit  = Math.min(parseInt(req.query.limit || '100'), 500);
    const offset = parseInt(req.query.offset || '0');
    const search = req.query.search ? `%${req.query.search}%` : null;

    let sql = `SELECT * FROM payouts`;
    const params = [];
    if (search) {
      sql += ` WHERE order_no LIKE ? OR acct_name LIKE ? OR acct_no LIKE ? OR acct_code LIKE ?`;
      params.push(search, search, search, search);
    }
    sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const [payouts] = await pool.execute(sql, params);

    const [[{ total }]] = await pool.execute('SELECT COUNT(*) AS total FROM payouts');
    const [[{ totalWithdrawn }]] = await pool.execute("SELECT COALESCE(SUM(amount), 0) AS totalWithdrawn FROM payouts WHERE status = '1'");
    const [[{ pendingCount }]] = await pool.execute("SELECT COUNT(*) AS pendingCount FROM payouts WHERE status IN ('0', '3', '6')");
    const [[{ failedCount }]] = await pool.execute("SELECT COUNT(*) AS failedCount FROM payouts WHERE status IN ('2', '4')");

    return res.json({
      success: true,
      payouts,
      total,
      stats: {
        totalWithdrawn: parseFloat(totalWithdrawn || '0'),
        pendingCount: parseInt(pendingCount || '0', 10),
        failedCount: parseInt(failedCount || '0', 10),
      }
    });
  } catch (err) {
    console.error('[Admin Payout] /payouts GET error:', err);
    return res.json({ success: false, error: 'Server error loading payouts.' });
  }
}

// POST /api/admin/payout/query
async function queryPayoutStatus(req, res) {
  try {
    const { orderNo } = req.body;
    if (!orderNo) return res.json({ success: false, error: 'Missing orderNo.' });

    const [rows] = await pool.execute('SELECT * FROM payouts WHERE order_no = ? LIMIT 1', [orderNo]);
    if (!rows.length) return res.json({ success: false, error: 'Payout order not found.' });

    const stored = rows[0];

    const params = { merchNo: MERCH_NO, orderNo };
    const sign = generateSign(params, API_KEY);
    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payOut/query`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      return res.json({ success: true, status: stored.status, orderState: stored.status, message: 'Gateway query timed out, keeping current state.' });
    }

    if (solipayRes.code === 500 && typeof solipayRes.msg === 'string' && solipayRes.msg.includes('OrderNo not exist')) {
      return res.json({ success: false, error: 'Order not found on SoliPay gateway.' });
    }

    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Query failed.' });
    }

    const { orderState, businessNo, msg } = solipayRes.data || {};
    const newStatus = String(orderState !== undefined ? orderState : stored.status);

    await pool.execute(
      `UPDATE payouts
       SET status = ?,
           business_no = COALESCE(?, business_no),
           error_msg = COALESCE(?, error_msg),
           confirmed_at = (CASE WHEN ? = '1' THEN NOW() ELSE confirmed_at END)
       WHERE order_no = ?`,
      [newStatus, businessNo || null, msg || null, newStatus, orderNo]
    );

    return res.json({
      success: true,
      orderNo,
      status: newStatus,
      orderState: newStatus,
      businessNo: businessNo || stored.business_no,
      errorMsg: msg || stored.error_msg,
    });
  } catch (err) {
    console.error('[Admin Payout] /query error:', err);
    return res.json({ success: false, error: 'Server error querying payout.' });
  }
}

// GET /api/debug-gateway
async function debugGateway(req, res) {
  const s = await getSettings().catch(() => ({}));
  return res.json({
    config: {
      SOLIPAY_BASE_URL:  SOLIPAY_BASE  || 'NOT SET',
      MERCH_NO:          MERCH_NO      || 'NOT SET',
      API_KEY:           API_KEY       ? `${API_KEY.slice(0,6)}...` : 'NOT SET',
      SITE_URL:          SITE_URL      || 'NOT SET',
      exchange_rate:     s.exchange_rate || 'NOT LOADED',
      price_30d_usd:     s.price_30d_usd || 'NOT LOADED',
    },
    timestamp: new Date().toISOString()
  });
}

module.exports = {
  getPayoutBalance,
  createPayout,
  getPayouts,
  queryPayoutStatus,
  debugGateway,
};
