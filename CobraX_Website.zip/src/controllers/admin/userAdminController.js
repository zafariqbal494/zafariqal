'use strict';

const pool = require('../../config/database');

// GET /api/admin/users
async function getUsers(req, res) {
  try {
    const page   = Math.max(parseInt(req.query.page || '1', 10), 1);
    const limit  = Math.min(Math.max(parseInt(req.query.limit || '25', 10), 1), 200);
    const offset = (page - 1) * limit;
    const search = req.query.search ? String(req.query.search).trim() : null;

    let whereClause = '';
    const queryParams = [];

    if (search) {
      whereClause = 'WHERE u.username LIKE ? OR u.email LIKE ?';
      const searchPattern = `%${search}%`;
      queryParams.push(searchPattern, searchPattern);
    }

    const [users] = await pool.execute(
      `SELECT u.id, u.username, u.email, u.created_at,
              COUNT(o.order_no) AS total_orders,
              SUM(CASE WHEN o.order_state='1' THEN 1 ELSE 0 END) AS paid_orders,
              COALESCE(SUM(CASE WHEN o.order_state='1' THEN o.amount ELSE 0 END), 0) AS total_spent_pkr
       FROM users u
       LEFT JOIN orders o ON o.user_id = u.id
       ${whereClause}
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT ? OFFSET ?`,
      [...queryParams, limit, offset]
    );

    let countSql = 'SELECT COUNT(*) AS total FROM users u';
    let countParams = [];
    if (search) {
      countSql += ' WHERE u.username LIKE ? OR u.email LIKE ?';
      countParams = [`%${search}%`, `%${search}%`];
    }
    const [[{ total }]] = await pool.execute(countSql, countParams);

    // Global Statistics for KPI Cards
    const [[{ totalAll }]] = await pool.execute('SELECT COUNT(*) AS totalAll FROM users');
    const [[{ registeredToday }]] = await pool.execute('SELECT COUNT(*) AS registeredToday FROM users WHERE created_at >= CURDATE()');
    const [[{ payingUsers }]] = await pool.execute(
      `SELECT COUNT(DISTINCT user_id) AS payingUsers FROM orders WHERE order_state = '1' AND user_id IS NOT NULL`
    );

    const payingCount = parseInt(payingUsers || '0', 10);
    const totalCount = parseInt(totalAll || '0', 10);
    const conversionRate = totalCount > 0 ? ((payingCount / totalCount) * 100).toFixed(1) : '0.0';

    return res.json({
      success: true,
      users,
      page,
      limit,
      total: parseInt(total || '0', 10),
      totalPages: Math.ceil((parseInt(total || '0', 10)) / limit) || 1,
      stats: {
        totalUsers: totalCount,
        registeredToday: parseInt(registeredToday || '0', 10),
        payingUsers: payingCount,
        conversionRate,
      }
    });
  } catch (err) {
    console.error('[Admin] /users error:', err);
    return res.json({ success: false, error: 'Server error loading users.' });
  }
}

// GET /api/admin/agents
async function getAgents(req, res) {
  try {
    const [agents] = await pool.execute(
      `SELECT a.*, 
              COUNT(DISTINCT r.id) AS total_referrals,
              COUNT(DISTINCT CASE WHEN o.order_state = '1' THEN r.id END) AS paid_referrals,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN r.discounted_pkr ELSE 0 END), 0) AS total_revenue_pkr
       FROM agents a
       LEFT JOIN referral_uses r ON r.agent_id = a.id
       LEFT JOIN orders o ON o.order_no = r.order_no
       GROUP BY a.id ORDER BY a.created_at DESC`
    );
    return res.json({ success: true, agents });
  } catch (err) {
    console.error('[Admin] /agents GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/agents
async function createAgent(req, res) {
  try {
    const { name, code, discount_percent } = req.body;
    if (!name || !code) return res.json({ success: false, error: 'Name and code are required.' });
    const cleanCode = code.trim().toUpperCase().replace(/\s+/g, '');
    const discount  = parseFloat(discount_percent || '10');
    if (isNaN(discount) || discount < 0 || discount > 100)
      return res.json({ success: false, error: 'Discount must be 0–100.' });

    await pool.execute(
      'INSERT INTO agents (name, code, discount_percent) VALUES (?, ?, ?)',
      [name.trim(), cleanCode, discount]
    );
    console.log(`[Admin] Agent created: ${cleanCode}`);
    return res.json({ success: true });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.json({ success: false, error: 'Referral code already exists.' });
    console.error('[Admin] /agents POST error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/agents/:id
async function updateAgent(req, res) {
  try {
    const { name, code, discount_percent, is_active } = req.body;
    const id = parseInt(req.params.id);
    if (!name || !code) return res.json({ success: false, error: 'Name and code required.' });
    const discount = parseFloat(discount_percent || '10');
    if (isNaN(discount) || discount < 0 || discount > 100)
      return res.json({ success: false, error: 'Discount must be 0–100.' });

    await pool.execute(
      'UPDATE agents SET name=?, code=?, discount_percent=?, is_active=? WHERE id=?',
      [name.trim(), code.trim().toUpperCase(), discount, is_active ? 1 : 0, id]
    );
    return res.json({ success: true });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.json({ success: false, error: 'Referral code already exists.' });
    console.error('[Admin] /agents PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// DELETE /api/admin/agents/:id
async function deleteAgent(req, res) {
  try {
    await pool.execute('DELETE FROM agents WHERE id = ?', [parseInt(req.params.id)]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /agents DELETE error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/agents/:id/toggle
async function toggleAgent(req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id) || id <= 0) return res.json({ success: false, error: 'Invalid agent ID.' });

    const [rows] = await pool.execute('SELECT id, is_active, name, code FROM agents WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return res.json({ success: false, error: 'Agent not found.' });

    const newStatus = rows[0].is_active ? 0 : 1;
    await pool.execute('UPDATE agents SET is_active = ? WHERE id = ?', [newStatus, id]);
    console.log(`[Admin] Toggled agent ${rows[0].code} status -> ${newStatus ? 'Active' : 'Inactive'}`);
    return res.json({ success: true, is_active: newStatus });
  } catch (err) {
    console.error('[Admin] /agents/:id/toggle error:', err);
    return res.json({ success: false, error: 'Server error toggling agent.' });
  }
}

// GET /api/admin/agents/:id/stats
async function getAgentStats(req, res) {
  try {
    const id = parseInt(req.params.id);
    const [agent] = await pool.execute('SELECT * FROM agents WHERE id = ? LIMIT 1', [id]);
    if (!agent.length) return res.json({ success: false, error: 'Agent not found.' });

    const [uses] = await pool.execute(
      `SELECT r.*, o.auth_key, o.order_state, u.username, u.email
       FROM referral_uses r
       LEFT JOIN orders o ON o.order_no = r.order_no
       LEFT JOIN users u ON u.id = o.user_id
       WHERE r.agent_id = ?
       ORDER BY r.created_at DESC`,
      [id]
    );

    const [[stats]] = await pool.execute(
      `SELECT COUNT(*) AS total,
              COUNT(CASE WHEN o.order_state = '1' THEN 1 END) AS paid_count,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN r.discounted_pkr ELSE 0 END), 0) AS revenue,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN (r.original_pkr - r.discounted_pkr) ELSE 0 END), 0) AS total_discount_given
       FROM referral_uses r
       LEFT JOIN orders o ON o.order_no = r.order_no
       WHERE r.agent_id = ?`,
      [id]
    );

    return res.json({ success: true, agent: agent[0], uses, stats });
  } catch (err) {
    console.error('[Admin] /agents/stats error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/reset-trial-device
async function resetTrialDevice(req, res) {
  try {
    const { device_id } = req.body;
    if (!device_id) return res.json({ success: false, error: 'device_id is required.' });
    await pool.execute('DELETE FROM device_trial_history WHERE device_id = ?', [device_id.trim()]);
    console.log(`[Admin] Reset trial eligibility for device: ${device_id}`);
    return res.json({ success: true, message: `Device trial history cleared for ${device_id}.` });
  } catch (err) {
    console.error('[Admin] reset-trial-device error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/reset-trial-account
async function resetTrialAccount(req, res) {
  try {
    const { user_id, email } = req.body;
    let targetUserId = user_id;
    if (!targetUserId && email) {
      const [uRows] = await pool.execute('SELECT id FROM users WHERE email = ? LIMIT 1', [email.trim()]);
      if (uRows.length) targetUserId = uRows[0].id;
    }
    if (!targetUserId) return res.json({ success: false, error: 'user_id or email is required.' });

    await pool.execute("UPDATE orders SET plan = 'trial_reset' WHERE user_id = ? AND (plan = '1' OR duration_days = 1)", [targetUserId]);
    console.log(`[Admin] Reset trial order eligibility for user: ${targetUserId}`);
    return res.json({ success: true, message: `User ${targetUserId} trial eligibility reset.` });
  } catch (err) {
    console.error('[Admin] reset-trial-account error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

module.exports = {
  getUsers,
  getAgents,
  createAgent,
  updateAgent,
  toggleAgent,
  deleteAgent,
  getAgentStats,
  resetTrialDevice,
  resetTrialAccount,
};
