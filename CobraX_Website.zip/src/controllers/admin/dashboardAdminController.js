'use strict';

const pool = require('../../config/database');
const { SOLIPAY_BASE, MERCH_NO, API_KEY } = require('../../config/constants');
const { generateSign } = require('../../utils/crypto');
const { httpPost } = require('../../utils/helpers');

let _cachedSoliPayBal  = null;
let _cachedSoliPayTime = 0;

// GET /api/admin/dashboard
async function getDashboard(req, res) {
  try {
    // 1. All-Time KPIs & User metrics
    const [[{ totalOrders }]]  = await pool.execute("SELECT COUNT(*) AS totalOrders FROM orders WHERE order_state='1'");
    const [[{ totalUsers }]]   = await pool.execute('SELECT COUNT(*) AS totalUsers FROM users');
    const [[{ usersToday }]]   = await pool.execute("SELECT COUNT(*) AS usersToday FROM users WHERE created_at >= CURDATE()");
    const [[{ activeKeys }]]   = await pool.execute("SELECT COUNT(*) AS activeKeys FROM auth_keys WHERE status='active'");

    // 2. Daily Financials: Today vs Yesterday
    const [[todayStats]] = await pool.execute(
      `SELECT COUNT(*) AS ordersToday, COALESCE(SUM(amount), 0) AS revenueTodayPkr
       FROM orders 
       WHERE order_state = '1' AND confirmed_at >= CURDATE()`
    );

    const [[yesterdayStats]] = await pool.execute(
      `SELECT COUNT(*) AS ordersYesterday, COALESCE(SUM(amount), 0) AS revenueYesterdayPkr
       FROM orders 
       WHERE order_state = '1' AND confirmed_at >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND confirmed_at < CURDATE()`
    );

    // 3. License Expiration Runway (Next 48 Hours)
    const [[{ expiringKeysSoon }]] = await pool.execute(
      `SELECT COUNT(*) AS expiringKeysSoon 
       FROM auth_keys 
       WHERE status = 'active' AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 48 HOUR)`
    );

    // 4. App Telemetry (Installs Today & Total, Active Today)
    let totalInstalls = 0;
    let installsToday = 0;
    let activeToday   = 0;
    try {
      const [[ti]] = await pool.execute('SELECT COUNT(*) AS c FROM app_installs');
      totalInstalls = ti.c;
      const [[it]] = await pool.execute("SELECT COUNT(*) AS c FROM app_installs WHERE first_seen >= CURDATE()");
      installsToday = it.c;
      const [[at]] = await pool.execute("SELECT COUNT(*) AS c FROM app_installs WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
      activeToday = at.c;
    } catch (_) {}

    // 5. Dynamic Plan Breakdown (captures 1, 30, deposit, custom, etc.)
    const [planBreakdown] = await pool.execute(
      `SELECT plan, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS revenue 
       FROM orders 
       WHERE order_state = '1' 
       GROUP BY plan 
       ORDER BY count DESC`
    );

    // 6. 7-Day Sales Volume (Daily order counts)
    const [recentOrders] = await pool.execute(
      `SELECT DATE(confirmed_at) AS day, COUNT(*) AS count
       FROM orders 
       WHERE order_state = '1' AND confirmed_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
       GROUP BY DATE(confirmed_at) 
       ORDER BY day ASC`
    );

    // 7. Latest 5 Paid Live Transactions Feed
    const [latestOrders] = await pool.execute(
      `SELECT o.plan, o.amount, o.order_state, o.confirmed_at,
              u.username, u.email
       FROM orders o
       LEFT JOIN users u ON u.id = o.user_id
       WHERE o.order_state = '1'
       ORDER BY o.confirmed_at DESC, o.created_at DESC
       LIMIT 5`
    );

    // 8. SoliPay Balance Query (with 60-second in-memory caching & safe timeout)
    let solipayBalance = _cachedSoliPayBal;
    if (Date.now() - _cachedSoliPayTime > 60000 && SOLIPAY_BASE && MERCH_NO && API_KEY) {
      try {
        const timestamp = String(Date.now());
        const params = { currency: 'PKR', merchNo: MERCH_NO, timestamp };
        const sign = generateSign(params, API_KEY);
        const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/balance`, { ...params, sign });
        if (solipayRes && solipayRes.code === 0 && solipayRes.data) {
          solipayBalance = {
            currency: solipayRes.data.currency || 'PKR',
            balance:  parseFloat(solipayRes.data.balance || '0.00'),
            availBal: parseFloat(solipayRes.data.availBal || '0.00'),
            froBal:   parseFloat(solipayRes.data.froBal || '0.00'),
          };
          _cachedSoliPayBal  = solipayBalance;
          _cachedSoliPayTime = Date.now();
        }
      } catch (balErr) {
        console.warn('[Dashboard] SoliPay balance fetch error:', balErr.message);
      }
    }

    return res.json({
      success: true,
      stats: {
        totalOrders,
        totalUsers,
        usersToday:         usersToday || 0,
        activeKeys,
        totalInstalls,
        installsToday,
        activeToday,
        ordersToday:        todayStats.ordersToday || 0,
        revenueTodayPkr:    todayStats.revenueTodayPkr || 0,
        ordersYesterday:    yesterdayStats.ordersYesterday || 0,
        revenueYesterdayPkr:yesterdayStats.revenueYesterdayPkr || 0,
        expiringKeysSoon:   expiringKeysSoon || 0,
      },
      planBreakdown,
      recentOrders,
      latestOrders,
      solipayBalance,
    });
  } catch (err) {
    console.error('[Admin] /dashboard error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

module.exports = {
  getDashboard,
};
