'use strict';

const pool = require('../../config/database');
const { PLAN_META, SITE_URL } = require('../../config/constants');
const { generateKey, generateCustomLinkId } = require('../../utils/crypto');
const { getSettings } = require('../../config/settings');

// POST /api/admin/keys/generate
async function generateKeys(req, res) {
  try {
    const { plan, count, selected_games } = req.body;
    const planMeta = PLAN_META[String(plan)];
    if (!planMeta) {
      return res.json({ success: false, error: 'Invalid plan. Choose 1 (24 Hours) or 30 (30 Days).' });
    }

    const qty = Math.min(Math.max(parseInt(count) || 1, 1), 50);
    const days = planMeta.days;
    const packageType = planMeta.packageType;
    const orderNo = `ADMIN-${Date.now().toString().slice(-6)}`;

    let gamesList = [];
    if (Array.isArray(selected_games)) {
      gamesList = selected_games.map(g => String(g).trim()).filter(Boolean);
    }
    const gamesJson = gamesList.length > 0 ? JSON.stringify(gamesList) : null;

    const generated = [];
    for (let i = 0; i < qty; i++) {
      const key = generateKey(days);
      await pool.execute(
        'INSERT INTO auth_keys (`key`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)',
        [key, packageType, days, `${orderNo}-${i + 1}`, gamesJson]
      );
      generated.push(key);
    }

    console.log(`[Admin] Generated ${qty} manual keys for Plan ${plan} (${days}d) with ${gamesList.length} games`);
    return res.json({
      success: true,
      plan: String(plan),
      durationDays: days,
      packageType,
      selected_games: gamesList,
      keys: generated,
      count: generated.length,
    });
  } catch (err) {
    console.error('[Admin] /keys/generate error:', err);
    return res.json({ success: false, error: 'Server error generating keys.' });
  }
}

// GET /api/admin/keys
async function getKeys(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT id, `key`, package_type, duration_days, order_no, device_id, activated_at, expires_at, status, created_at FROM auth_keys ORDER BY id DESC LIMIT 200'
    );
    return res.json({ success: true, keys: rows });
  } catch (err) {
    console.error('[Admin] /keys GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// DELETE /api/admin/keys/:id
async function deleteKey(req, res) {
  try {
    const keyId = parseInt(req.params.id);
    if (isNaN(keyId) || keyId <= 0) return res.json({ success: false, error: 'Invalid key ID.' });

    await pool.execute('DELETE FROM auth_keys WHERE id = ? LIMIT 1', [keyId]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /keys DELETE error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/payment-links/create
async function createPaymentLink(req, res) {
  try {
    const { title, amount_usd, note, user_identifier } = req.body;

    const numAmount = parseFloat(amount_usd || '150.00');
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({ success: false, error: 'Please specify a valid USD amount (e.g. 150.00).' });
    }

    const linkTitle = (title && String(title).trim()) ? String(title).trim() : 'Account Upgrade Service';
    const linkId = generateCustomLinkId();
    const cleanNote = note ? String(note).trim() : null;
    const cleanUser = user_identifier ? String(user_identifier).trim() : null;
    const adminUser = req.admin ? req.admin.username : 'admin';

    await pool.execute(
      `INSERT INTO custom_payment_links (link_id, title, amount_usd, note, user_identifier, status, created_by)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
      [linkId, linkTitle, numAmount.toFixed(2), cleanNote, cleanUser, adminUser]
    );

    const shareUrl = `${SITE_URL}/pay?id=${linkId}`;
    console.log(`[Admin] Custom Payment Link Created: ${linkId} | $${numAmount.toFixed(2)} | Title: ${linkTitle}`);

    return res.json({
      success: true,
      link_id: linkId,
      url: shareUrl,
      title: linkTitle,
      amount_usd: numAmount.toFixed(2),
      note: cleanNote,
      user_identifier: cleanUser,
    });
  } catch (err) {
    console.error('[Admin] /payment-links/create error:', err);
    return res.json({ success: false, error: 'Server error creating payment link.' });
  }
}

// GET /api/admin/payment-links
async function getPaymentLinks(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM custom_payment_links ORDER BY created_at DESC LIMIT 200'
    );
    const s = await getSettings();
    const exchangeRate = parseFloat(s.exchange_rate || '280');

    const enriched = rows.map(r => ({
      ...r,
      amount_pkr: Math.round(parseFloat(r.amount_usd) * exchangeRate * 100) / 100,
      url: `${SITE_URL}/pay?id=${r.link_id}`
    }));

    return res.json({ success: true, links: enriched, exchangeRate });
  } catch (err) {
    console.error('[Admin] /payment-links GET error:', err);
    return res.json({ success: false, error: 'Server error loading payment links.' });
  }
}

// DELETE /api/admin/payment-links/:id
async function deletePaymentLink(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) return res.json({ success: false, error: 'Invalid link ID.' });

    await pool.execute('DELETE FROM custom_payment_links WHERE id = ? LIMIT 1', [id]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /payment-links DELETE error:', err);
    return res.json({ success: false, error: 'Server error deleting payment link.' });
  }
}

module.exports = {
  generateKeys,
  getKeys,
  deleteKey,
  createPaymentLink,
  getPaymentLinks,
  deletePaymentLink,
};
