'use strict';

const pool = require('../config/database');
const { getSettings } = require('../config/settings');
const {
  PLAN_META,
  SITE_URL,
  MERCH_NO,
  API_KEY,
  SOLIPAY_BASE,
} = require('../config/constants');
const {
  generateOrderNo,
  generateSign,
  generateKey,
} = require('../utils/crypto');
const { httpPost } = require('../utils/helpers');
const { sendOrderPendingEmail, sendKeyDeliveryEmail } = require('../utils/email');

// POST /api/create-order
async function createOrder(req, res) {
  try {
    const { plan, channel, referral_code, selected_games } = req.body;
    if (!PLAN_META[plan]) return res.json({ success: false, error: 'Invalid plan selected.' });
    const allowedChannels = ['Jazzcash', 'Easypaisa'];
    if (!allowedChannels.includes(channel)) return res.json({ success: false, error: 'Invalid payment channel.' });

    // Enforce authentication (No guest purchases allowed)
    let userId = null;
    const token = req.headers['x-session-token'];
    if (token) {
      const [sess] = await pool.execute(
        `SELECT s.user_id, s.expires_at FROM sessions s WHERE s.token = ? LIMIT 1`, [token]);
      if (sess.length && new Date(sess[0].expires_at) >= new Date()) userId = sess[0].user_id;
    }
    if (!userId) {
      return res.json({ success: false, error: 'Authentication required. Please login or register to purchase a VIP key.' });
    }

    // Trial Plan Account Limit Check (1 trial purchase per registered account)
    if (plan === '1') {
      const [existingTrialOrders] = await pool.execute(
        `SELECT id, order_no FROM orders
         WHERE user_id = ? AND (plan = '1' OR duration_days = 1) AND order_state = '1'
         LIMIT 1`,
        [userId]
      );
      if (existingTrialOrders.length > 0) {
        return res.json({
          success: false,
          code: 'TRIAL_ALREADY_PURCHASED',
          error: 'Trial Access (24-Hour) can only be purchased once per registered account. Please choose a Cobra Access Plan (30 Days) to continue.'
        });
      }
    }

    // Validate selected games
    let gamesList = [];
    if (Array.isArray(selected_games)) {
      gamesList = selected_games.map(g => String(g).trim()).filter(Boolean);
    }
    if (plan === '1') {
      if (gamesList.length !== 1) {
        return res.json({ success: false, error: 'Please select exactly 1 game for the 24-Hour Trial plan.' });
      }
    } else if (plan === '30') {
      if (gamesList.length < 1 || gamesList.length > 4) {
        return res.json({ success: false, error: 'Please select between 1 and 4 games for the 30-Day Cobra Access plan.' });
      }
    }
    const gamesJson = JSON.stringify(gamesList);

    // Load live settings (exchange rate + USD prices)
    const s = await getSettings();

    // Check if selected plan is temporarily restricted by Admin
    const isPlan1Restricted = (s.plan_1_restricted || '0') === '1';
    const isPlan30Restricted = (s.plan_30_restricted || '0') === '1';

    if ((plan === '1' && isPlan1Restricted) || (plan === '30' && isPlan30Restricted)) {
      return res.json({
        success: false,
        isCapacityFull: true,
        error: 'VIP key generation is temporarily paused due to a high volume of orders. Please try again in a few hours.',
      });
    }

    const exchangeRate = parseFloat(s.exchange_rate || '280');
    const usdPrices    = { '1': parseFloat(s.price_1d_usd || '20.00'), '30': parseFloat(s.price_30d_usd || '80.00') };
    const usdPrice     = usdPrices[plan];
    let   pkrAmount    = Math.round(usdPrice * exchangeRate * 100) / 100; // USD -> PKR
    let   discountPct  = 0;
    let   agentId      = null;

    // Referral code validation & discount
    if (referral_code && (s.discount_active || '1') === '1') {
      const code = referral_code.trim().toUpperCase();
      const [agentRows] = await pool.execute(
        'SELECT id, discount_percent FROM agents WHERE code = ? AND is_active = 1 LIMIT 1', [code]);
      if (agentRows.length) {
        agentId     = agentRows[0].id;
        discountPct = parseFloat(agentRows[0].discount_percent);
      }
    }

    const originalPkr = pkrAmount;
    if (discountPct > 0) {
      pkrAmount = Math.round(pkrAmount * (1 - discountPct / 100) * 100) / 100;
    }

    const planInfo  = PLAN_META[plan];
    const orderNo   = generateOrderNo();
    const notifyUrl = `${SITE_URL}/webhook/payin`;
    const amountStr = pkrAmount.toFixed(2);

    const params = {
      amount: amountStr, currency: 'PKR', merchNo: MERCH_NO,
      notifyUrl, orderNo, outChannel: channel
    };
    const sign = generateSign(params, API_KEY);

    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payIn`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError || solipayRes.code !== 0) {
      console.warn(`[Payment Gateway] Handled: ${solipayRes._message || (solipayRes._timeout ? 'Timeout' : solipayRes.msg || 'Error')}`);
      const tgLink = s.telegram_link || (s.telegram_address ? (s.telegram_address.startsWith('http') ? s.telegram_address : `https://${s.telegram_address}`) : 'https://t.me/winXcobra');
      return res.json({
        success: false,
        isCapacityFull: true,
        telegramUrl: tgLink,
        error: 'CobraX VIP Key generation is temporarily paused for few hours due to high order volume. Contact us on telegram to buy key.',
      });
    }

    const paymentUrl = solipayRes.data.code_url;

    // Execute order creation and referral tracking within a database transaction
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.execute(
        `INSERT INTO orders (order_no, plan, duration_days, amount, channel, user_id, order_state,
           referral_code, discount_percent, original_amount, amount_usd, selected_games)
         VALUES (?, ?, ?, ?, ?, ?, '0', ?, ?, ?, ?, ?)`,
        [orderNo, plan, planInfo.days, amountStr, channel, userId,
         agentId ? referral_code.trim().toUpperCase() : null,
         discountPct || null, discountPct > 0 ? originalPkr : null, usdPrice, gamesJson]
      );

      if (agentId) {
        await conn.execute(
          `INSERT INTO referral_uses (agent_id, order_no, plan, discount_percent, original_pkr, discounted_pkr)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [agentId, orderNo, plan, discountPct, originalPkr, pkrAmount]
        );
      }
      await conn.commit();
    } catch (txErr) {
      await conn.rollback();
      throw txErr;
    } finally {
      conn.release();
    }

    console.log(`[CobraX] Order created: ${orderNo} | Plan: ${plan} | Games: ${gamesJson} | $${usdPrice} -> PKR ${amountStr} | Discount: ${discountPct}% | User: ${userId}`);

    // Send Pending Order Email
    try {
      const [uRows] = await pool.execute('SELECT email, username FROM users WHERE id = ? LIMIT 1', [userId]);
      if (uRows.length && uRows[0].email) {
        sendOrderPendingEmail(uRows[0].email, uRows[0].username, orderNo, plan, amountStr, gamesJson, paymentUrl).catch(() => {});
      }
    } catch (_) {}

    return res.json({ success: true, orderNo, paymentUrl });

  } catch (err) {
    console.error('[CobraX] /api/create-order exception:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// GET /api/payment-link/:linkId
async function getPaymentLink(req, res) {
  try {
    const linkId = String(req.params.linkId || '').trim().toUpperCase();
    if (!linkId) return res.json({ success: false, error: 'Invalid link ID.' });

    const [rows] = await pool.execute('SELECT * FROM custom_payment_links WHERE link_id = ? LIMIT 1', [linkId]);
    if (!rows.length) return res.json({ success: false, error: 'Payment link not found.' });

    const link = rows[0];
    if (link.status === 'cancelled') {
      return res.json({ success: false, error: 'This payment link has been expired.' });
    }

    const s = await getSettings();
    const exchangeRate = parseFloat(s.exchange_rate || '280');
    const amountUsd = parseFloat(link.amount_usd || '0.00');
    const amountPkr = Math.round(amountUsd * exchangeRate * 100) / 100;

    return res.json({
      success: true,
      link_id: link.link_id,
      title: link.title,
      amount_usd: amountUsd,
      amount_pkr: amountPkr,
      exchangeRate,
      note: link.note || '',
      user_identifier: link.user_identifier || '',
      status: link.status,
      order_no: link.order_no,
      created_at: link.created_at,
      paid_at: link.paid_at,
    });
  } catch (err) {
    console.error('[Payment Link] /api/payment-link GET exception:', err);
    return res.json({ success: false, error: 'Server error loading payment link.' });
  }
}

// POST /api/payment-link/pay
async function payPaymentLink(req, res) {
  try {
    const { link_id, channel } = req.body;
    const cleanLinkId = String(link_id || '').trim().toUpperCase();
    if (!cleanLinkId) return res.json({ success: false, error: 'Missing payment link ID.' });

    const allowedChannels = ['Jazzcash', 'Easypaisa'];
    const selectedChannel = allowedChannels.includes(channel) ? channel : 'Easypaisa';

    const [rows] = await pool.execute('SELECT * FROM custom_payment_links WHERE link_id = ? LIMIT 1', [cleanLinkId]);
    if (!rows.length) return res.json({ success: false, error: 'Payment link not found.' });

    const link = rows[0];
    if (link.status === 'paid') {
      return res.json({ success: false, error: 'This payment link has already been paid.' });
    }
    if (link.status === 'cancelled') {
      return res.json({ success: false, error: 'This payment link has been expired.' });
    }

    const s = await getSettings();
    const exchangeRate = parseFloat(s.exchange_rate || '280');
    const amountUsd = parseFloat(link.amount_usd);
    const pkrAmount = Math.round(amountUsd * exchangeRate * 100) / 100;

    const orderNo = generateOrderNo();
    const notifyUrl = `${SITE_URL}/webhook/payin`;
    const amountStr = pkrAmount.toFixed(2);

    const params = {
      amount: amountStr, currency: 'PKR', merchNo: MERCH_NO,
      notifyUrl, orderNo, outChannel: selectedChannel
    };
    const sign = generateSign(params, API_KEY);

    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payIn`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError || solipayRes.code !== 0) {
      console.warn(`[Payment Gateway] Handled custom payment link error: ${solipayRes._message || solipayRes.msg || 'Error'}`);
      return res.json({
        success: false,
        error: solipayRes.msg || 'Payment gateway temporarily unavailable. Please try again shortly.',
      });
    }

    const paymentUrl = solipayRes.data.code_url;

    // Atomically insert order and update custom payment link
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.execute(
        `INSERT INTO orders (order_no, plan, duration_days, amount, channel, user_id, order_state, amount_usd)
         VALUES (?, 'custom', 0, ?, ?, NULL, '0', ?)`,
        [orderNo, amountStr, selectedChannel, amountUsd]
      );
      await conn.execute(
        `UPDATE custom_payment_links SET order_no = ? WHERE link_id = ?`,
        [orderNo, cleanLinkId]
      );
      await conn.commit();
    } catch (txErr) {
      await conn.rollback();
      throw txErr;
    } finally {
      conn.release();
    }

    console.log(`[Custom Payment Link] Initiated: ${cleanLinkId} | Order: ${orderNo} | $${amountUsd} -> PKR ${amountStr}`);
    return res.json({ success: true, orderNo, paymentUrl });
  } catch (err) {
    console.error('[Payment Link] /api/payment-link/pay exception:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// POST /api/deposit/create
async function createDeposit(req, res) {
  try {
    const { amount, channel, device_id } = req.body;
    const pkrAmount = parseFloat(amount);
    if (isNaN(pkrAmount) || pkrAmount <= 0) {
      return res.json({ success: false, error: 'Invalid deposit amount.' });
    }

    const s = await getSettings();
    if ((s.solipay_deposit_enabled || '1') === '0') {
      return res.json({
        success: false,
        disabled: true,
        error: 'SoliPay deposit gateway is currently deactivated by admin. Using default channel.',
      });
    }

    const cleanDeviceId = device_id ? String(device_id).trim() : null;

    // Check if this device has already completed a SoliPay deposit
    if (cleanDeviceId) {
      const [existingDep] = await pool.execute(
        "SELECT id FROM device_deposits WHERE device_id = ? AND status = '1' LIMIT 1",
        [cleanDeviceId]
      );
      if (existingDep.length > 0) {
        return res.json({
          success: false,
          alreadyUsed: true,
          error: 'SoliPay deposit is already completed for this device. Using default channel.',
        });
      }
    }

    const allowedChannels = ['Jazzcash', 'Easypaisa'];
    const selectedChannel = allowedChannels.includes(channel) ? channel : 'Easypaisa';

    const orderNo   = generateOrderNo();
    const notifyUrl = `${SITE_URL}/webhook/payin`;
    const amountStr = pkrAmount.toFixed(2);

    const params = {
      amount: amountStr,
      currency: 'PKR',
      merchNo: MERCH_NO,
      notifyUrl,
      orderNo,
      outChannel: selectedChannel,
    };
    const sign = generateSign(params, API_KEY);

    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payIn`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      const detail = solipayRes._message || (solipayRes._timeout ? 'Request Timeout' : 'Invalid JSON');
      return res.json({ success: false, error: `Payment gateway failed: ${detail}` });
    }
    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Payment gateway error.' });
    }

    // Atomically insert into orders and device_deposits table
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.execute(
        `INSERT INTO orders (order_no, plan, duration_days, amount, channel, user_id, order_state)
         VALUES (?, 'deposit', 0, ?, ?, NULL, '0')`,
        [orderNo, amountStr, selectedChannel]
      );
      if (cleanDeviceId) {
        await conn.execute(
          `INSERT INTO device_deposits (device_id, order_no, amount, channel, status)
           VALUES (?, ?, ?, ?, '0')
           ON DUPLICATE KEY UPDATE order_no = VALUES(order_no), amount = VALUES(amount), channel = VALUES(channel), status = '0'`,
          [cleanDeviceId, orderNo, amountStr, selectedChannel]
        );
      }
      await conn.commit();
    } catch (txErr) {
      await conn.rollback();
      throw txErr;
    } finally {
      conn.release();
    }

    const paymentUrl = solipayRes.data.code_url;
    console.log(`[Deposit] SoliPay deposit initiated: ${orderNo} | PKR ${amountStr} | Device: ${cleanDeviceId || 'unknown'}`);
    return res.json({ success: true, orderNo, paymentUrl });
  } catch (err) {
    console.error('[Deposit] /api/deposit/create exception:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// POST /api/check-order
async function checkOrder(req, res) {
  try {
    const { orderNo } = req.body;
    if (!orderNo) return res.json({ success: false, error: 'Missing orderNo.' });

    // Step 1: Quick non-locking read to quickly satisfy already confirmed orders
    const [rows] = await pool.execute('SELECT * FROM orders WHERE order_no = ? LIMIT 1', [orderNo]);
    const stored = rows[0] || null;

    if (stored && stored.order_state === '1') {
      return res.json({ success: true, orderState: '1', key: stored.auth_key });
    }

    // Step 2: Query SoliPay gateway status without holding DB locks
    const params     = { merchNo: MERCH_NO, orderNo };
    const sign       = generateSign(params, API_KEY);
    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payIn/query`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      return res.json({ success: true, orderState: '3' });
    }
    if (solipayRes.code === 500 && typeof solipayRes.msg === 'string' && solipayRes.msg.includes('OrderNo not exist')) {
      return res.json({ success: false, error: 'Order not found.' });
    }
    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Query failed.' });
    }

    const { orderState } = solipayRes.data;

    // Step 3: If gateway confirmed '1', acquire lock to prevent race conditions with /webhook/payin (SEC-03)
    if (orderState === '1') {
      let conn = null;
      let confirmedKey = null;
      let shouldSendEmail = false;
      let orderPlan = '30';
      let orderDays = 30;
      let gamesJson = null;
      let orderAmount = 0;
      let responsePayload = null;

      try {
        conn = await pool.getConnection();
        await conn.beginTransaction();

        // Lock row exclusively to serialize with webhookController
        const [lockedRows] = await conn.execute('SELECT * FROM orders WHERE order_no = ? FOR UPDATE', [orderNo]);
        const locked = lockedRows[0] || null;

        if (!locked) {
          await conn.rollback();
          return res.json({ success: false, error: 'Order not found in database.' });
        }

        // Check if concurrent thread (e.g. webhook) already confirmed this order
        if (locked.order_state === '1') {
          await conn.commit();
          return res.json({ success: true, orderState: '1', key: locked.auth_key, isCustomPayment: locked.plan === 'custom' });
        }

        orderPlan = locked.plan;
        orderDays = locked.duration_days;
        orderAmount = locked.amount;
        gamesJson = locked.selected_games ? (typeof locked.selected_games === 'string' ? locked.selected_games : JSON.stringify(locked.selected_games)) : null;

        if (locked.plan === 'deposit') {
          await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
          await conn.execute("UPDATE device_deposits SET status='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
          await conn.commit();
          console.log(`[CobraX] Deposit Confirmed atomically (query): ${orderNo}`);
          return res.json({ success: true, orderState: '1' });
        }

        if (locked.plan === 'custom') {
          await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
          await conn.execute("UPDATE custom_payment_links SET status='paid', paid_at=NOW() WHERE order_no=?", [orderNo]);
          await conn.commit();
          console.log(`[CobraX] Custom Payment Link Confirmed atomically (query): ${orderNo}`);
          return res.json({ success: true, orderState: '1', isCustomPayment: true });
        }

        const planInfo = PLAN_META[locked.plan] || { packageType: 'basic', label: '30 Days' };
        confirmedKey   = locked.auth_key || generateKey(locked.duration_days);

        await conn.execute(
          `UPDATE orders SET order_state='1', auth_key=?, confirmed_at=NOW() WHERE order_no=?`,
          [confirmedKey, orderNo]
        );
        await conn.execute(
          `INSERT IGNORE INTO auth_keys (\`key\`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)`,
          [confirmedKey, planInfo.packageType, locked.duration_days, orderNo, gamesJson]
        );

        await conn.commit();
        shouldSendEmail = true;
        responsePayload = { success: true, orderState: '1', key: confirmedKey };

        console.log(`[CobraX] Confirmed atomically (query): ${orderNo} -> ${confirmedKey} (Games: ${gamesJson})`);
      } catch (txErr) {
        if (conn) {
          try { await conn.rollback(); } catch (_) {}
        }
        throw txErr;
      } finally {
        if (conn) {
          conn.release();
        }
      }

      // Trigger Key Delivery Email safely after database commit
      if (shouldSendEmail && confirmedKey) {
        try {
          const [uRows] = await pool.execute('SELECT u.email, u.username FROM orders o JOIN users u ON u.id = o.user_id WHERE o.order_no = ? LIMIT 1', [orderNo]);
          if (uRows.length && uRows[0].email) {
            sendKeyDeliveryEmail(uRows[0].email, uRows[0].username, orderNo, confirmedKey, orderPlan, orderDays, gamesJson, orderAmount).catch(() => {});
          }
        } catch (_) {}
      }

      if (responsePayload) {
        return res.json(responsePayload);
      }
    }

    return res.json({ success: true, orderState: orderState || '3' });
  } catch (err) {
    console.error('[CobraX] /api/check-order exception:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// GET /api/get-key/:orderNo
async function getKey(req, res) {
  try {
    const [rows] = await pool.execute('SELECT * FROM orders WHERE order_no = ? LIMIT 1', [req.params.orderNo]);
    const stored = rows[0];
    if (!stored)                    return res.json({ success: false, orderState: '0' });
    if (stored.order_state === '1') return res.json({ success: true,  orderState: '1', key: stored.auth_key });
    return res.json({ success: true, orderState: stored.order_state || '0' });
  } catch (err) {
    console.error('[CobraX] /api/get-key exception:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

module.exports = {
  createOrder,
  getPaymentLink,
  payPaymentLink,
  createDeposit,
  checkOrder,
  getKey,
};
