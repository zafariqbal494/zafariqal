'use strict';

const bcrypt = require('bcrypt');
const pool = require('../config/database');
const { BCRYPT_ROUNDS } = require('../config/constants');
const { generateSessionToken } = require('../utils/crypto');
const { sendWelcomeEmail } = require('../utils/email');

// POST /api/auth/register
async function register(req, res) {
  try {
    const { username, email, password } = req.body;
    if (!username || typeof username !== 'string' || username.trim().length < 3)
      return res.json({ success: false, error: 'Username must be at least 3 characters.' });
    if (!email || !email.includes('@'))
      return res.json({ success: false, error: 'Valid email required.' });
    if (!password || password.length < 6)
      return res.json({ success: false, error: 'Password must be at least 6 characters.' });

    const cleanUsername = username.trim();
    const cleanEmail    = email.trim().toLowerCase();

    const [existing] = await pool.execute(
      'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1',
      [cleanUsername, cleanEmail]
    );
    if (existing.length)
      return res.json({ success: false, error: 'Username or email already in use.' });

    const hashed = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const [result] = await pool.execute(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [cleanUsername, cleanEmail, hashed]
    );

    const token     = generateSessionToken();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await pool.execute('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)',
      [token, result.insertId, expiresAt]);

    console.log(`[Auth] New user: ${cleanUsername}`);
    sendWelcomeEmail(cleanEmail, cleanUsername).catch(() => {});
    return res.json({ success: true, token, username: cleanUsername, email: cleanEmail });
  } catch (err) {
    console.error('[Auth] /register error:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// POST /api/auth/login
async function login(req, res) {
  try {
    const { credential, password, remember } = req.body;
    if (!credential || !password)
      return res.json({ success: false, error: 'Email/username and password are required.' });

    const clean = credential.trim().toLowerCase();
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1', [clean, clean]);
    if (!rows.length) return res.json({ success: false, error: 'Invalid credentials.' });

    const user  = rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.json({ success: false, error: 'Invalid credentials.' });

    const token     = generateSessionToken();
    const days      = remember ? 30 : 1;
    const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    await pool.execute('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)',
      [token, user.id, expiresAt]);

    console.log(`[Auth] Login: ${user.username}`);
    return res.json({ success: true, token, username: user.username, email: user.email });
  } catch (err) {
    console.error('[Auth] /login error:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// POST /api/auth/logout
async function logout(req, res) {
  try {
    await pool.execute('DELETE FROM sessions WHERE token = ?', [req.headers['x-session-token']]);
    return res.json({ success: true });
  } catch (err) {
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// GET /api/auth/me
function getMe(req, res) {
  return res.json({ success: true, username: req.user.username, email: req.user.email });
}

// GET /api/user/orders
async function getUserOrders(req, res) {
  try {
    const [orders] = await pool.execute(
      `SELECT o.order_no, o.plan, o.duration_days, o.amount, o.channel,
              o.order_state, o.auth_key, o.created_at, o.confirmed_at,
              o.referral_code, o.discount_percent, o.original_amount, o.amount_usd,
              o.selected_games,
              a.expires_at, a.status AS key_status, a.activated_at, a.selected_games AS key_selected_games
       FROM orders o
       LEFT JOIN auth_keys a ON a.order_no = o.order_no
       WHERE o.user_id = ?
       ORDER BY o.created_at DESC`,
      [req.user.user_id]
    );

    // Collect auth_keys and user_id to fetch extracted game profiles
    const keys = orders.map(o => o.auth_key).filter(Boolean);
    const userId = req.user.user_id;

    let allProfiles = [];
    if (keys.length > 0 || userId) {
      const conds = [];
      const condParams = [];
      if (keys.length > 0) {
        conds.push(`key_code IN (${keys.map(() => '?').join(',')})`);
        condParams.push(...keys);
      }
      if (userId) {
        conds.push(`user_id = ?`);
        condParams.push(userId);
      }
      const [profiles] = await pool.execute(
        `SELECT * FROM game_user_profiles WHERE ${conds.join(' OR ')} ORDER BY last_synced_at DESC`,
        condParams
      );
      allProfiles = profiles;
    }

    const enrichedOrders = orders.map(o => {
      let games = [];
      const rawGames = o.selected_games || o.key_selected_games;
      if (rawGames) {
        try {
          games = typeof rawGames === 'string' ? JSON.parse(rawGames) : rawGames;
        } catch (_) {}
      }
      const orderProfiles = allProfiles.filter(p =>
        (o.auth_key && p.key_code === o.auth_key) ||
        (p.user_id && p.user_id === userId)
      );
      return {
        ...o,
        selected_games: Array.isArray(games) ? games : [],
        game_profiles: orderProfiles
      };
    });

    return res.json({ success: true, orders: enrichedOrders });
  } catch (err) {
    console.error('[User] /orders error:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

// GET /api/user/trial-eligibility
async function getUserTrialEligibility(req, res) {
  try {
    const userId = req.user.user_id;

    // Check if user account has any confirmed 1-day trial order
    const [trialOrders] = await pool.execute(
      `SELECT id, order_no, order_state, created_at
       FROM orders
       WHERE user_id = ? AND (plan = '1' OR duration_days = 1) AND order_state = '1'
       ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );

    const hasConfirmedTrial = trialOrders.length > 0;

    return res.json({
      success: true,
      eligible: !hasConfirmedTrial,
      has_used_trial: hasConfirmedTrial,
      trial_order: hasConfirmedTrial ? trialOrders[0] : null
    });
  } catch (err) {
    console.error('[User] /trial-eligibility error:', err);
    return res.json({ success: false, error: 'Internal server error.' });
  }
}

module.exports = {
  register,
  login,
  logout,
  getMe,
  getUserOrders,
  getUserTrialEligibility,
};
