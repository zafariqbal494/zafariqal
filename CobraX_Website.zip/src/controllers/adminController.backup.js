'use strict';

const bcrypt = require('bcrypt');
const pool = require('../config/database');
const { getSettings, invalidateSettingsCache } = require('../config/settings');
const {
  PLAN_META,
  DEFAULT_GAMES,
  SITE_URL,
  MERCH_NO,
  API_KEY,
  SOLIPAY_BASE,
} = require('../config/constants');
const {
  generateSessionToken,
  generateKey,
  generateCustomLinkId,
  generatePayoutOrderNo,
  generateSign,
} = require('../utils/crypto');
const { httpPost } = require('../utils/helpers');
const { sendKeyDeliveryEmail } = require('../utils/email');

const MAINT_DEFAULTS = {
  push_on_title:   '🛑 CobraX — Server Maintenance',
  push_on_msg:     "Prediction server is temporarily offline for maintenance. We'll be back shortly!",
  push_off_title:  '✅ CobraX — Server Online',
  push_off_msg:    '🚀 Prediction server is back online! WinGo 30Sec results are now live.',
  banner_on_title: '⚠️ Prediction Server Offline',
  banner_on_msg:   'Our prediction engine is currently under maintenance. Results will resume shortly. Thank you for your patience.',
};

const DEFAULT_PUSH_TEMPLATES = [
  {
    id: 'tmpl-flash-sale',
    name: '🔥 Flash Sale Alert',
    title: '🔥 FLASH SALE: 50% Off 30-Day VIP Key!',
    message: 'Grab your CobraX VIP key today at an exclusive discount. Real-time WinGo 30Sec predictions unlocked!',
    url: 'https://cobrax.sbs/buy-key',
    is_default: true,
  },
  {
    id: 'tmpl-engine-update',
    name: '⚡ WinGo 30s Algorithm Update',
    title: '⚡ SYSTEM UPDATE: WinGo 30Sec Engine Upgraded!',
    message: 'Prediction algorithms optimized for 99.8% precision across 92Pak, FantasyGems & 92Jeeto. Open app to win!',
    url: 'https://cobrax.sbs/download',
    is_default: true,
  },
  {
    id: 'tmpl-maintenance',
    name: '🛠️ Scheduled Maintenance',
    title: '🛠️ NOTICE: Quick Server Maintenance in Progress',
    message: 'Our systems are receiving a performance tune-up. Services will be back online in 15 minutes.',
    url: 'https://cobrax.sbs',
    is_default: true,
  },
  {
    id: 'tmpl-vip-renew',
    name: '👑 VIP Key Expiry Reminder',
    title: '👑 Don\'t Miss Out: Renew Your VIP Access Today!',
    message: 'Your key is running low. Renew today to keep non-stop automated prediction overlay active.',
    url: 'https://cobrax.sbs/buy-key',
    is_default: true,
  }
];

// POST /api/admin/login
async function adminLogin(req, res) {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.json({ success: false, error: 'Credentials required.' });

    const [rows] = await pool.execute('SELECT * FROM admins WHERE username = ? LIMIT 1', [username.trim()]);
    if (!rows.length) return res.json({ success: false, error: 'Invalid credentials.' });

    const match = await bcrypt.compare(password, rows[0].password);
    if (!match) return res.json({ success: false, error: 'Invalid credentials.' });

    const token     = generateSessionToken();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    await pool.execute('INSERT INTO admin_sessions (token, admin_id, expires_at) VALUES (?, ?, ?)',
      [token, rows[0].id, expiresAt]);

    // Set secure httpOnly cookie
    res.cookie('cbx_admin_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000,
      path: '/',
    });

    console.log(`[Admin] Login: ${rows[0].username}`);
    return res.json({ success: true, token, username: rows[0].username });
  } catch (err) {
    console.error('[Admin] /login error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/logout
async function adminLogout(req, res) {
  try {
    const token = req.cookies?.cbx_admin_token || req.headers['x-admin-token'];
    if (token) {
      await pool.execute('DELETE FROM admin_sessions WHERE token = ?', [token]);
    }
    res.clearCookie('cbx_admin_token', { path: '/' });
    return res.json({ success: true });
  } catch (err) {
    res.clearCookie('cbx_admin_token', { path: '/' });
    return res.json({ success: false });
  }
}

// GET /api/admin/me
function getAdminMe(req, res) {
  return res.json({ success: true, username: req.admin.username });
}

// GET /api/admin/dashboard
async function getDashboard(req, res) {
  try {
    const [[{ totalOrders }]]  = await pool.execute("SELECT COUNT(*) AS totalOrders FROM orders WHERE order_state='1'");
    const [[{ totalUsers }]]   = await pool.execute('SELECT COUNT(*) AS totalUsers FROM users');
    const [[{ activeKeys }]]   = await pool.execute("SELECT COUNT(*) AS activeKeys FROM auth_keys WHERE status='active'");
    const [[{ expiredKeys }]]  = await pool.execute("SELECT COUNT(*) AS expiredKeys FROM auth_keys WHERE status='expired'");
    const [[{ totalRevenuePkr }]] = await pool.execute("SELECT COALESCE(SUM(amount),0) AS totalRevenuePkr FROM orders WHERE order_state='1'");
    const [[{ totalReferrals }]]  = await pool.execute('SELECT COUNT(*) AS totalReferrals FROM referral_uses');

    let totalInstalls = 0;
    let activeToday   = 0;
    let activeWeek    = 0;
    try {
      const [[ti]] = await pool.execute('SELECT COUNT(*) AS c FROM app_installs');
      totalInstalls = ti.c;
      const [[at]] = await pool.execute("SELECT COUNT(*) AS c FROM app_installs WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
      activeToday = at.c;
      const [[aw]] = await pool.execute("SELECT COUNT(*) AS c FROM app_installs WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
      activeWeek = aw.c;
    } catch (_) {}

    const [planBreakdown] = await pool.execute(
      "SELECT plan, COUNT(*) AS count FROM orders WHERE order_state='1' GROUP BY plan");

    const [recentOrders] = await pool.execute(
      `SELECT DATE(confirmed_at) AS day, COUNT(*) AS count
       FROM orders WHERE order_state='1' AND confirmed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
       GROUP BY DATE(confirmed_at) ORDER BY day ASC`);

    return res.json({
      success: true,
      stats: { totalOrders, totalUsers, activeKeys, expiredKeys, totalRevenuePkr, totalReferrals, totalInstalls, activeToday, activeWeek },
      planBreakdown,
      recentOrders,
    });
  } catch (err) {
    console.error('[Admin] /dashboard error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/orders
async function getOrders(req, res) {
  try {
    const limit  = Math.min(parseInt(req.query.limit  || '100'), 500);
    const offset = parseInt(req.query.offset || '0');
    const search = req.query.search ? `%${req.query.search}%` : null;
    const status = req.query.status ? req.query.status.toString().toLowerCase() : null;

    let sql = `SELECT o.*, u.username, u.email,
                      a.expires_at AS key_expires, a.status AS key_status,
                      a.device_id AS key_device_id, a.selected_games AS key_selected_games
               FROM orders o
               LEFT JOIN users u ON u.id = o.user_id
               LEFT JOIN auth_keys a ON a.order_no = o.order_no`;
    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push(`(o.order_no LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR o.auth_key LIKE ?)`);
      params.push(search, search, search, search);
    }
    if (status === 'paid' || status === '1') {
      whereClauses.push(`o.order_state = '1'`);
    } else if (status === 'pending' || status === '0') {
      whereClauses.push(`o.order_state != '1'`);
    }

    if (whereClauses.length > 0) {
      sql += ` WHERE ` + whereClauses.join(' AND ');
    }

    sql += ` ORDER BY o.created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const [orders]   = await pool.execute(sql, params);
    const [[{total}]] = await pool.execute("SELECT COUNT(*) AS total FROM orders");

    const keys = orders.map(o => o.auth_key).filter(Boolean);
    const userIds = orders.map(o => o.user_id).filter(Boolean);
    const deviceIds = orders.map(o => o.key_device_id).filter(Boolean);

    let allProfiles = [];
    if (keys.length > 0 || userIds.length > 0 || deviceIds.length > 0) {
      const conds = [];
      const condParams = [];
      if (keys.length > 0) {
        conds.push(`key_code IN (${keys.map(() => '?').join(',')})`);
        condParams.push(...keys);
      }
      if (userIds.length > 0) {
        conds.push(`user_id IN (${userIds.map(() => '?').join(',')})`);
        condParams.push(...userIds);
      }
      if (deviceIds.length > 0) {
        conds.push(`device_id IN (${deviceIds.map(() => '?').join(',')})`);
        condParams.push(...deviceIds);
      }
      const [profiles] = await pool.execute(
        `SELECT * FROM game_user_profiles WHERE ${conds.join(' OR ')} ORDER BY last_synced_at DESC`,
        condParams
      );
      allProfiles = profiles;
    }

    const enriched = orders.map(o => {
      let games = [];
      const rawGames = o.selected_games || o.key_selected_games;
      if (rawGames) {
        try {
          games = typeof rawGames === 'string' ? JSON.parse(rawGames) : rawGames;
        } catch (_) {}
      }
      const isKeyOrder = Boolean(o.auth_key && String(o.auth_key).trim().length > 0);

      const orderProfiles = allProfiles.filter(p => {
        if (isKeyOrder) {
          return p.key_code === o.auth_key;
        }
        if (o.key_device_id && p.device_id === o.key_device_id) return true;
        if (o.user_id && p.user_id === o.user_id) return true;
        return false;
      });

      return {
        ...o,
        selected_games: Array.isArray(games) ? games : [],
        game_profiles: orderProfiles
      };
    });

    return res.json({ success: true, orders: enriched, total });
  } catch (err) {
    console.error('[Admin] /orders error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/orders/:orderNo/status
async function updateOrderStatus(req, res) {
  let conn = null;
  try {
    const orderNo = String(req.params.orderNo || '').trim();
    const { status } = req.body;
    if (!orderNo || !status) {
      return res.json({ success: false, error: 'Order number and status are required.' });
    }

    const isPaid = status === 'paid' || status === '1';

    conn = await pool.getConnection();
    await conn.beginTransaction();

    const [rows] = await conn.execute('SELECT * FROM orders WHERE order_no = ? FOR UPDATE', [orderNo]);
    if (!rows.length) {
      await conn.rollback();
      conn.release();
      return res.json({ success: false, error: 'Order not found.' });
    }
    const order = rows[0];

    if (isPaid) {
      if (order.plan === 'deposit') {
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.execute("UPDATE device_deposits SET status='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.commit();
        console.log(`[Admin] Manually marked In-Game Deposit as PAID: ${orderNo}`);
        return res.json({ success: true, orderNo, status: 'paid' });
      }

      if (order.plan === 'custom') {
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.execute("UPDATE custom_payment_links SET status='paid', paid_at=NOW() WHERE order_no=?", [orderNo]);
        await conn.commit();
        console.log(`[Admin] Manually marked Custom Payment Link as PAID: ${orderNo}`);
        return res.json({ success: true, orderNo, status: 'paid' });
      }

      let key = order.auth_key;
      const days = order.duration_days || (PLAN_META[order.plan] ? PLAN_META[order.plan].days : 30);
      const planInfo = PLAN_META[order.plan] || { packageType: 'basic' };
      const gamesJson = order.selected_games ? (typeof order.selected_games === 'string' ? order.selected_games : JSON.stringify(order.selected_games)) : null;

      if (!key) {
        key = generateKey(days);
        await conn.execute(
          `UPDATE orders SET order_state='1', auth_key=?, confirmed_at=NOW() WHERE order_no=?`,
          [key, orderNo]
        );
        await conn.execute(
          `INSERT IGNORE INTO auth_keys (\`key\`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)`,
          [key, planInfo.packageType, days, orderNo, gamesJson]
        );
      } else {
        // Reactivate key if it was previously revoked when reverted to pending
        await conn.execute("UPDATE auth_keys SET status = (CASE WHEN activated_at IS NOT NULL THEN 'active' ELSE 'unused' END) WHERE `key` = ? AND status = 'revoked'", [key]);
        await conn.execute("UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?", [orderNo]);
      }

      await conn.commit();

      // Trigger Key Delivery Email
      try {
        const [uRows] = await pool.execute('SELECT u.email, u.username FROM orders o JOIN users u ON u.id = o.user_id WHERE o.order_no = ? LIMIT 1', [orderNo]);
        if (uRows.length && uRows[0].email) {
          sendKeyDeliveryEmail(uRows[0].email, uRows[0].username, orderNo, key, order.plan, days, gamesJson, order.amount).catch(() => {});
        }
      } catch (_) {}

      console.log(`[Admin] Manually marked VIP Key Order as PAID: ${orderNo} -> Key: ${key}`);
      return res.json({ success: true, orderNo, status: 'paid', key });

    } else {
      // Revert to pending & revoke associated license keys (SEC-04)
      await conn.execute("UPDATE orders SET order_state='0', confirmed_at=NULL WHERE order_no=?", [orderNo]);
      if (order.auth_key) {
        await conn.execute("UPDATE auth_keys SET status='revoked' WHERE order_no=? OR `key`=?", [orderNo, order.auth_key]);
      } else {
        await conn.execute("UPDATE auth_keys SET status='revoked' WHERE order_no=?", [orderNo]);
      }

      if (order.plan === 'deposit') {
        await conn.execute("UPDATE device_deposits SET status='0', confirmed_at=NULL WHERE order_no=?", [orderNo]);
      } else if (order.plan === 'custom') {
        await conn.execute("UPDATE custom_payment_links SET status='pending', paid_at=NULL WHERE order_no=?", [orderNo]);
      }

      await conn.commit();
      console.log(`[Admin] Manually reverted Order to PENDING and REVOKED associated keys: ${orderNo}`);
      return res.json({ success: true, orderNo, status: 'pending', keyRevoked: true });
    }

  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (_) {}
    }
    console.error('[Admin] /orders/:orderNo/status error:', err);
    return res.json({ success: false, error: 'Server error updating order status.' });
  } finally {
    if (conn) {
      conn.release();
    }
  }
}

// GET /api/admin/users
async function getUsers(req, res) {
  try {
    const limit  = Math.min(parseInt(req.query.limit || '100'), 500);
    const offset = parseInt(req.query.offset || '0');
    const [users]     = await pool.execute(
      `SELECT u.id, u.username, u.email, u.created_at,
              COUNT(o.order_no) AS total_orders,
              SUM(CASE WHEN o.order_state='1' THEN 1 ELSE 0 END) AS paid_orders
       FROM users u
       LEFT JOIN orders o ON o.user_id = u.id
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT ? OFFSET ?`,
      [limit, offset]);
    const [[{total}]] = await pool.execute('SELECT COUNT(*) AS total FROM users');
    return res.json({ success: true, users, total });
  } catch (err) {
    console.error('[Admin] /users error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/agents
async function getAgents(req, res) {
  try {
    const [agents] = await pool.execute(
      `SELECT a.*, 
              COUNT(DISTINCT r.id) AS total_referrals,
              COUNT(DISTINCT CASE WHEN o.order_state = '1' THEN r.id END) AS paid_referrals,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN r.discounted_pkr ELSE 0 END), 0) AS total_revenue_pkr
       FROM agents a
       LEFT JOIN referral_uses r ON r.agent_id = a.id
       LEFT JOIN orders o ON o.order_no = r.order_no
       GROUP BY a.id ORDER BY a.created_at DESC`);
    return res.json({ success: true, agents });
  } catch (err) {
    console.error('[Admin] /agents GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/agents
async function createAgent(req, res) {
  try {
    const { name, code, discount_percent } = req.body;
    if (!name || !code) return res.json({ success: false, error: 'Name and code are required.' });
    const cleanCode = code.trim().toUpperCase().replace(/\s+/g, '');
    const discount  = parseFloat(discount_percent || '10');
    if (isNaN(discount) || discount < 0 || discount > 100)
      return res.json({ success: false, error: 'Discount must be 0–100.' });

    await pool.execute(
      'INSERT INTO agents (name, code, discount_percent) VALUES (?, ?, ?)',
      [name.trim(), cleanCode, discount]);
    console.log(`[Admin] Agent created: ${cleanCode}`);
    return res.json({ success: true });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.json({ success: false, error: 'Referral code already exists.' });
    console.error('[Admin] /agents POST error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/agents/:id
async function updateAgent(req, res) {
  try {
    const { name, code, discount_percent, is_active } = req.body;
    const id = parseInt(req.params.id);
    if (!name || !code) return res.json({ success: false, error: 'Name and code required.' });
    const discount = parseFloat(discount_percent || '10');
    if (isNaN(discount) || discount < 0 || discount > 100)
      return res.json({ success: false, error: 'Discount must be 0–100.' });

    await pool.execute(
      'UPDATE agents SET name=?, code=?, discount_percent=?, is_active=? WHERE id=?',
      [name.trim(), code.trim().toUpperCase(), discount, is_active ? 1 : 0, id]);
    return res.json({ success: true });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.json({ success: false, error: 'Referral code already exists.' });
    console.error('[Admin] /agents PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// DELETE /api/admin/agents/:id
async function deleteAgent(req, res) {
  try {
    await pool.execute('DELETE FROM agents WHERE id = ?', [parseInt(req.params.id)]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /agents DELETE error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/agents/:id/stats
async function getAgentStats(req, res) {
  try {
    const id = parseInt(req.params.id);
    const [agent] = await pool.execute('SELECT * FROM agents WHERE id = ? LIMIT 1', [id]);
    if (!agent.length) return res.json({ success: false, error: 'Agent not found.' });

    const [uses] = await pool.execute(
      `SELECT r.*, o.auth_key, o.order_state, u.username, u.email
       FROM referral_uses r
       LEFT JOIN orders o ON o.order_no = r.order_no
       LEFT JOIN users u ON u.id = o.user_id
       WHERE r.agent_id = ?
       ORDER BY r.created_at DESC`,
      [id]);

    const [[stats]] = await pool.execute(
      `SELECT COUNT(*) AS total,
              COUNT(CASE WHEN o.order_state = '1' THEN 1 END) AS paid_count,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN r.discounted_pkr ELSE 0 END), 0) AS revenue,
              COALESCE(SUM(CASE WHEN o.order_state = '1' THEN (r.original_pkr - r.discounted_pkr) ELSE 0 END), 0) AS total_discount_given
       FROM referral_uses r
       LEFT JOIN orders o ON o.order_no = r.order_no
       WHERE r.agent_id = ?`,
      [id]);

    return res.json({ success: true, agent: agent[0], uses, stats });
  } catch (err) {
    console.error('[Admin] /agents/stats error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/settings
async function getSettingsAdmin(req, res) {
  try {
    const [rows] = await pool.execute('SELECT `key`, `value`, updated_at FROM settings ORDER BY `key`');
    const sanitizedRows = rows.map(r => ({
      key: r.key,
      value: r.key === 'onesignal_rest_api_key' ? (r.value ? '••••••••••••••••' : '') : r.value,
      updated_at: r.updated_at
    }));
    return res.json({ success: true, settings: sanitizedRows });
  } catch (err) {
    console.error('[Admin] /settings GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/settings
async function updateSettingsAdmin(req, res) {
  try {
    const { settings } = req.body;
    if (!settings || typeof settings !== 'object')
      return res.json({ success: false, error: 'Settings object required.' });

    for (const [key, value] of Object.entries(settings)) {
      if (key === 'onesignal_rest_api_key' && String(value).includes('••••')) continue;
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]);
    }
    invalidateSettingsCache();
    console.log(`[Admin] Settings updated: ${Object.keys(settings).join(', ')}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /settings PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/announcement
async function getAnnouncement(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      announcement: {
        enabled:     (s.announcement_enabled || '0') === '1',
        title:       s.announcement_title || '',
        message:     s.announcement_message || '',
        type:        s.announcement_type    || 'info',
        url:         s.announcement_url     || '',
        dismissible: (s.announcement_dismissible || '1') === '1',
      }
    });
  } catch (err) {
    console.error('[Admin] /announcement GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/announcement
async function updateAnnouncement(req, res) {
  try {
    const { enabled, title, message, type, url, dismissible } = req.body;
    const settingsUpdate = {
      announcement_enabled:     enabled ? '1' : '0',
      announcement_title:       title   || '',
      announcement_message:     message || '',
      announcement_type:        type    || 'info',
      announcement_url:         url     || '',
      announcement_dismissible: dismissible ? '1' : '0',
    };
    for (const [key, value] of Object.entries(settingsUpdate)) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]);
    }
    invalidateSettingsCache();
    console.log(`[Admin] Announcement broadcast updated: enabled=${enabled}, type=${type}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /announcement PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/games
async function getGames(req, res) {
  try {
    const s = await getSettings();
    let games = DEFAULT_GAMES;
    if (s.games_config) {
      try {
        const parsed = JSON.parse(s.games_config);
        if (Array.isArray(parsed) && parsed.length > 0) games = parsed;
      } catch (e) {}
    }
    return res.json({
      success: true,
      telegramAddress: s.telegram_address || 't.me/winXcobra',
      games: games,
    });
  } catch (err) {
    console.error('[Admin] /games GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/games
async function updateGames(req, res) {
  try {
    const { telegramAddress, games } = req.body;
    if (!Array.isArray(games) || games.length === 0) {
      return res.json({ success: false, error: 'Games list must be a non-empty array.' });
    }

    const cleanGames = games.map(g => ({
      name: String(g.name || 'Game').trim(),
      url: String(g.url || '').trim(),
    }));

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['games_config', JSON.stringify(cleanGames), JSON.stringify(cleanGames)]);

    if (telegramAddress !== undefined) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['telegram_address', String(telegramAddress).trim(), String(telegramAddress).trim()]);
    }

    invalidateSettingsCache();
    console.log(`[Admin] Games config updated: ${cleanGames.length} games`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /games PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/version
async function getVersion(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      minAppVersion: s.min_app_version || '5.0.1',
      latestAppVersion: s.latest_app_version || '5.0.1',
      updateUrl: s.update_download_url || 'https://cobrax.sbs',
      forceUpdateEnabled: (s.force_update_enabled || '1') === '1',
    });
  } catch (err) {
    console.error('[Admin] /version GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/version
async function updateVersion(req, res) {
  try {
    const { minAppVersion, latestAppVersion, updateUrl, forceUpdateEnabled } = req.body;
    const updates = {
      min_app_version: minAppVersion ? String(minAppVersion).trim() : '5.0.1',
      latest_app_version: latestAppVersion ? String(latestAppVersion).trim() : '5.0.1',
      update_download_url: updateUrl ? String(updateUrl).trim() : 'https://cobrax.sbs',
      force_update_enabled: forceUpdateEnabled ? '1' : '0',
    };

    for (const [key, value] of Object.entries(updates)) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        [key, String(value), String(value)]
      );
    }

    invalidateSettingsCache();
    console.log(`[Admin] Version settings updated: min=${updates.min_app_version}, latest=${updates.latest_app_version}, force=${updates.force_update_enabled}`);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /version PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/reset-trial-device
async function resetTrialDevice(req, res) {
  try {
    const { device_id } = req.body;
    if (!device_id) return res.json({ success: false, error: 'device_id is required.' });
    await pool.execute('DELETE FROM device_trial_history WHERE device_id = ?', [device_id.trim()]);
    console.log(`[Admin] Reset trial eligibility for device: ${device_id}`);
    return res.json({ success: true, message: `Device trial history cleared for ${device_id}.` });
  } catch (err) {
    console.error('[Admin] reset-trial-device error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/reset-trial-account
async function resetTrialAccount(req, res) {
  try {
    const { user_id, email } = req.body;
    let targetUserId = user_id;
    if (!targetUserId && email) {
      const [uRows] = await pool.execute('SELECT id FROM users WHERE email = ? LIMIT 1', [email.trim()]);
      if (uRows.length) targetUserId = uRows[0].id;
    }
    if (!targetUserId) return res.json({ success: false, error: 'user_id or email is required.' });

    await pool.execute("UPDATE orders SET plan = 'trial_reset' WHERE user_id = ? AND (plan = '1' OR duration_days = 1)", [targetUserId]);
    console.log(`[Admin] Reset trial order eligibility for user: ${targetUserId}`);
    return res.json({ success: true, message: `User ${targetUserId} trial eligibility reset.` });
  } catch (err) {
    console.error('[Admin] reset-trial-account error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/keys/generate
async function generateKeys(req, res) {
  try {
    const { plan, count, selected_games } = req.body;
    const planMeta = PLAN_META[String(plan)];
    if (!planMeta) {
      return res.json({ success: false, error: 'Invalid plan. Choose 1 (24 Hours) or 30 (30 Days).' });
    }

    const qty = Math.min(Math.max(parseInt(count) || 1, 1), 50);
    const days = planMeta.days;
    const packageType = planMeta.packageType;
    const orderNo = `ADMIN-${Date.now().toString().slice(-6)}`;

    let gamesList = [];
    if (Array.isArray(selected_games)) {
      gamesList = selected_games.map(g => String(g).trim()).filter(Boolean);
    }
    const gamesJson = gamesList.length > 0 ? JSON.stringify(gamesList) : null;

    const generated = [];
    for (let i = 0; i < qty; i++) {
      const key = generateKey(days);
      await pool.execute(
        'INSERT INTO auth_keys (`key`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)',
        [key, packageType, days, `${orderNo}-${i + 1}`, gamesJson]
      );
      generated.push(key);
    }

    console.log(`[Admin] Generated ${qty} manual keys for Plan ${plan} (${days}d) with ${gamesList.length} games`);
    return res.json({
      success: true,
      plan: String(plan),
      durationDays: days,
      packageType,
      selected_games: gamesList,
      keys: generated,
      count: generated.length,
    });
  } catch (err) {
    console.error('[Admin] /keys/generate error:', err);
    return res.json({ success: false, error: 'Server error generating keys.' });
  }
}

// GET /api/admin/keys
async function getKeys(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT id, `key`, package_type, duration_days, order_no, device_id, activated_at, expires_at, status, created_at FROM auth_keys ORDER BY id DESC LIMIT 200'
    );
    return res.json({ success: true, keys: rows });
  } catch (err) {
    console.error('[Admin] /keys GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// DELETE /api/admin/keys/:id
async function deleteKey(req, res) {
  try {
    const keyId = parseInt(req.params.id);
    if (isNaN(keyId) || keyId <= 0) return res.json({ success: false, error: 'Invalid key ID.' });

    await pool.execute('DELETE FROM auth_keys WHERE id = ? LIMIT 1', [keyId]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /keys DELETE error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/payment-links/create
async function createPaymentLink(req, res) {
  try {
    const { title, amount_usd, note, user_identifier } = req.body;

    const numAmount = parseFloat(amount_usd || '150.00');
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({ success: false, error: 'Please specify a valid USD amount (e.g. 150.00).' });
    }

    const linkTitle = (title && String(title).trim()) ? String(title).trim() : 'Account Upgrade Service';
    const linkId = generateCustomLinkId();
    const cleanNote = note ? String(note).trim() : null;
    const cleanUser = user_identifier ? String(user_identifier).trim() : null;
    const adminUser = req.admin ? req.admin.username : 'admin';

    await pool.execute(
      `INSERT INTO custom_payment_links (link_id, title, amount_usd, note, user_identifier, status, created_by)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
      [linkId, linkTitle, numAmount.toFixed(2), cleanNote, cleanUser, adminUser]
    );

    const shareUrl = `${SITE_URL}/pay?id=${linkId}`;
    console.log(`[Admin] Custom Payment Link Created: ${linkId} | $${numAmount.toFixed(2)} | Title: ${linkTitle}`);

    return res.json({
      success: true,
      link_id: linkId,
      url: shareUrl,
      title: linkTitle,
      amount_usd: numAmount.toFixed(2),
      note: cleanNote,
      user_identifier: cleanUser,
    });
  } catch (err) {
    console.error('[Admin] /payment-links/create error:', err);
    return res.json({ success: false, error: 'Server error creating payment link.' });
  }
}

// GET /api/admin/payment-links
async function getPaymentLinks(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM custom_payment_links ORDER BY created_at DESC LIMIT 200'
    );
    const s = await getSettings();
    const exchangeRate = parseFloat(s.exchange_rate || '280');

    const enriched = rows.map(r => ({
      ...r,
      amount_pkr: Math.round(parseFloat(r.amount_usd) * exchangeRate * 100) / 100,
      url: `${SITE_URL}/pay?id=${r.link_id}`
    }));

    return res.json({ success: true, links: enriched, exchangeRate });
  } catch (err) {
    console.error('[Admin] /payment-links GET error:', err);
    return res.json({ success: false, error: 'Server error loading payment links.' });
  }
}

// DELETE /api/admin/payment-links/:id
async function deletePaymentLink(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id <= 0) return res.json({ success: false, error: 'Invalid link ID.' });

    await pool.execute('DELETE FROM custom_payment_links WHERE id = ? LIMIT 1', [id]);
    return res.json({ success: true });
  } catch (err) {
    console.error('[Admin] /payment-links DELETE error:', err);
    return res.json({ success: false, error: 'Server error deleting payment link.' });
  }
}

// GET /api/admin/push/config
async function getPushConfig(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      appId: s.onesignal_app_id || '',
      hasApiKey: !!s.onesignal_rest_api_key,
      lastPushTitle: s.last_push_title || '',
      lastPushTime: s.last_push_time || '',
    });
  } catch (err) {
    console.error('[Push] config GET error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/push/config
async function updatePushConfig(req, res) {
  try {
    const { appId, restApiKey } = req.body;
    if (appId !== undefined) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['onesignal_app_id', String(appId).trim(), String(appId).trim()]
      );
    }
    if (restApiKey !== undefined && String(restApiKey).trim().length > 0) {
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['onesignal_rest_api_key', String(restApiKey).trim(), String(restApiKey).trim()]
      );
    }

    invalidateSettingsCache();
    console.log('[Push] OneSignal config updated by Admin');
    return res.json({ success: true });
  } catch (err) {
    console.error('[Push] config PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/push/send
async function sendPush(req, res) {
  try {
    const { title, message, url, type } = req.body;
    if (!title || !message) {
      return res.json({ success: false, error: 'Title and message are required.' });
    }

    const s = await getSettings();
    const appId = s.onesignal_app_id || process.env.ONESIGNAL_APP_ID;
    const apiKey = s.onesignal_rest_api_key || process.env.ONESIGNAL_REST_API_KEY;

    if (!appId || !apiKey) {
      return res.json({
        success: false,
        error: 'OneSignal credentials not set. Please enter your OneSignal App ID and REST API Key in the settings below.',
      });
    }

    const payload = {
      app_id: appId,
      included_segments: ['Subscribed Users', 'Total Subscriptions'],
      headings: { en: title.trim() },
      contents: { en: message.trim() },
      small_icon: 'ic_launcher',
    };

    if (url && url.trim().length > 0) {
      payload.url = url.trim();
      payload.data = { url: url.trim(), type: type || 'info' };
    }

    let cleanKey = apiKey.trim().replace(/^(Basic|Key|Bearer)\s+/i, '');
    let authHeader = `Key ${cleanKey}`;

    let response = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': authHeader,
      },
      body: JSON.stringify(payload),
    });

    let data = await response.json();

    if (!response.ok && data.error && data.error.includes('Authorization')) {
      console.log('[Push] Retrying OneSignal with Basic auth header...');
      response = await fetch('https://onesignal.com/api/v1/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': `Basic ${cleanKey}`,
        },
        body: JSON.stringify(payload),
      });
      data = await response.json();
    }

    if (response.ok && data.id) {
      console.log(`[Push] OneSignal notification sent: ID=${data.id}, Recipients=${data.recipients || 0}`);

      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['last_push_title', title.trim(), title.trim()]
      );
      await pool.execute(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
        ['last_push_time', new Date().toISOString(), new Date().toISOString()]
      );
      invalidateSettingsCache();

      return res.json({
        success: true,
        id: data.id,
        recipients: data.recipients || 0,
      });
    } else {
      console.error('[Push] OneSignal error response:', data);
      let errMsg = (data.errors && Array.isArray(data.errors))
        ? data.errors.join(', ')
        : (data.errors || data.error || 'Failed to send notification via OneSignal.');

      if (typeof errMsg === 'string' && (errMsg.includes('not subscribed') || errMsg.includes('players are not subscribed'))) {
        errMsg = 'OneSignal connected successfully! However, 0 mobile devices are currently registered in your OneSignal App. Open the updated CobraX App on your phone once to register your device, then broadcast!';
      }

      return res.json({ success: false, error: errMsg });
    }
  } catch (err) {
    console.error('[Push] Exception:', err);
    return res.json({ success: false, error: 'Server error sending push notification.' });
  }
}

// GET /api/admin/push/templates
async function getPushTemplates(req, res) {
  try {
    const s = await getSettings();
    let templates = DEFAULT_PUSH_TEMPLATES;
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom) && custom.length > 0) {
          templates = custom;
        }
      } catch (_) {}
    }
    return res.json({ success: true, templates });
  } catch (err) {
    console.error('[Push] templates GET error:', err);
    return res.json({ success: false, error: 'Server error loading templates.' });
  }
}

// POST /api/admin/push/templates
async function createPushTemplate(req, res) {
  try {
    const { name, title, message, url } = req.body;
    if (!name || !title || !message) {
      return res.json({ success: false, error: 'Template name, title, and message body are required.' });
    }

    const s = await getSettings();
    let templates = [...DEFAULT_PUSH_TEMPLATES];
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom) && custom.length > 0) templates = custom;
      } catch (_) {}
    }

    const newTmpl = {
      id: `tmpl-${Date.now()}`,
      name: String(name).trim(),
      title: String(title).trim(),
      message: String(message).trim(),
      url: url ? String(url).trim() : '',
      created_at: new Date().toISOString(),
      is_default: false,
    };

    templates.unshift(newTmpl);

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['push_templates', JSON.stringify(templates), JSON.stringify(templates)]
    );
    invalidateSettingsCache();

    console.log(`[Push] Saved new push template: "${newTmpl.name}"`);
    return res.json({ success: true, template: newTmpl, templates });
  } catch (err) {
    console.error('[Push] templates POST error:', err);
    return res.json({ success: false, error: 'Server error saving template.' });
  }
}

// DELETE /api/admin/push/templates/:id
async function deletePushTemplate(req, res) {
  try {
    const tmplId = String(req.params.id || '').trim();
    if (!tmplId) return res.json({ success: false, error: 'Invalid template ID.' });

    const s = await getSettings();
    let templates = [...DEFAULT_PUSH_TEMPLATES];
    if (s.push_templates) {
      try {
        const custom = JSON.parse(s.push_templates);
        if (Array.isArray(custom) && custom.length > 0) templates = custom;
      } catch (_) {}
    }

    templates = templates.filter(t => t.id !== tmplId);

    await pool.execute(
      'INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      ['push_templates', JSON.stringify(templates), JSON.stringify(templates)]
    );
    invalidateSettingsCache();

    console.log(`[Push] Deleted push template: ${tmplId}`);
    return res.json({ success: true, templates });
  } catch (err) {
    console.error('[Push] templates DELETE error:', err);
    return res.json({ success: false, error: 'Server error deleting template.' });
  }
}

// GET /api/admin/payout/balance
async function getPayoutBalance(req, res) {
  try {
    if (!SOLIPAY_BASE || !MERCH_NO || !API_KEY) {
      return res.json({
        success: false,
        error: 'SoliPay credentials not configured. Please check SOLIPAY_BASE_URL, MERCH_NO, and API_KEY in .env.'
      });
    }

    const timestamp = String(Date.now());
    const params = {
      currency: 'PKR',
      merchNo: MERCH_NO,
      timestamp,
    };
    const sign = generateSign(params, API_KEY);

    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/balance`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      const detail = solipayRes._message || (solipayRes._timeout ? 'Gateway Timeout' : 'Invalid JSON');
      return res.json({ success: false, error: `Could not fetch balance: ${detail}` });
    }

    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Failed to query balance from SoliPay.' });
    }

    const bData = solipayRes.data || {};
    return res.json({
      success: true,
      currency: bData.currency || 'PKR',
      balance: parseFloat(bData.balance || '0.00'),
      availBal: parseFloat(bData.availBal || '0.00'),
      froBal: parseFloat(bData.froBal || '0.00'),
      merchNo: bData.merchNo || MERCH_NO,
    });
  } catch (err) {
    console.error('[Admin Payout] Balance query exception:', err);
    return res.json({ success: false, error: 'Server error querying balance.' });
  }
}

// POST /api/admin/payout/create
async function createPayout(req, res) {
  try {
    const { amount, acctName, acctCode, acctNo, mobile } = req.body;

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({ success: false, error: 'Please enter a valid withdrawal amount.' });
    }
    if (!acctName || typeof acctName !== 'string' || !acctName.trim()) {
      return res.json({ success: false, error: 'Account title / recipient name is required.' });
    }
    if (!acctCode || typeof acctCode !== 'string' || !acctCode.trim()) {
      return res.json({ success: false, error: 'Payout channel / bank code is required.' });
    }
    if (!acctNo || typeof acctNo !== 'string' || !acctNo.trim()) {
      return res.json({ success: false, error: 'Account number / IBAN is required.' });
    }

    const cleanAcctName = acctName.trim();
    const cleanAcctCode = acctCode.trim();
    const cleanAcctNo   = acctNo.trim();
    const cleanMobile   = mobile ? String(mobile).trim() : null;

    const orderNo   = generatePayoutOrderNo();
    const notifyUrl = `${SITE_URL}/webhook/payout`;
    const amountStr = numAmount.toFixed(2);

    const params = {
      amount: amountStr,
      orderNo,
      merchNo: MERCH_NO,
      acctCode: cleanAcctCode,
      acctNo: cleanAcctNo,
      acctName: cleanAcctName,
      currency: 'PKR',
      notifyUrl,
    };
    if (cleanMobile) {
      params.mobile = cleanMobile;
    }

    const sign = generateSign(params, API_KEY);
    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payOut`, { ...params, sign });

    let initialStatus = '0';
    let errorMsg = null;
    let businessNo = null;

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      console.warn('[Admin Payout] Gateway timeout/network response during creation. Order treated as processing:', orderNo);
      errorMsg = 'Gateway response delayed (processing)';
    } else if (solipayRes.code === 0) {
      initialStatus = String(solipayRes.data?.orderState || '0');
      businessNo = solipayRes.data?.businessNo || null;
    } else {
      return res.json({
        success: false,
        error: solipayRes.msg || 'SoliPay payout rejected by gateway.',
      });
    }

    await pool.execute(
      `INSERT INTO payouts (order_no, amount, acct_name, acct_code, acct_no, mobile, currency, status, business_no, error_msg, admin_username)
       VALUES (?, ?, ?, ?, ?, ?, 'PKR', ?, ?, ?, ?)`,
      [orderNo, amountStr, cleanAcctName, cleanAcctCode, cleanAcctNo, cleanMobile, initialStatus, businessNo, errorMsg, req.admin.username]
    );

    console.log(`[Admin Payout] Withdrawal initiated: ${orderNo} | PKR ${amountStr} | ${cleanAcctCode} | ${cleanAcctName} (${cleanAcctNo})`);

    return res.json({
      success: true,
      orderNo,
      amount: amountStr,
      status: initialStatus,
      message: solipayRes.msg || 'Withdrawal request submitted successfully!',
    });
  } catch (err) {
    console.error('[Admin Payout] /create exception:', err);
    return res.json({ success: false, error: 'Server error processing withdrawal.' });
  }
}

// GET /api/admin/payouts
async function getPayouts(req, res) {
  try {
    const limit  = Math.min(parseInt(req.query.limit || '100'), 500);
    const offset = parseInt(req.query.offset || '0');
    const search = req.query.search ? `%${req.query.search}%` : null;

    let sql = `SELECT * FROM payouts`;
    const params = [];
    if (search) {
      sql += ` WHERE order_no LIKE ? OR acct_name LIKE ? OR acct_no LIKE ? OR acct_code LIKE ?`;
      params.push(search, search, search, search);
    }
    sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const [payouts] = await pool.execute(sql, params);

    const [[{ total }]] = await pool.execute('SELECT COUNT(*) AS total FROM payouts');
    const [[{ totalWithdrawn }]] = await pool.execute("SELECT COALESCE(SUM(amount), 0) AS totalWithdrawn FROM payouts WHERE status = '1'");
    const [[{ pendingCount }]] = await pool.execute("SELECT COUNT(*) AS pendingCount FROM payouts WHERE status IN ('0', '3', '6')");
    const [[{ failedCount }]] = await pool.execute("SELECT COUNT(*) AS failedCount FROM payouts WHERE status IN ('2', '4')");

    return res.json({
      success: true,
      payouts,
      total,
      stats: {
        totalWithdrawn: parseFloat(totalWithdrawn || '0'),
        pendingCount: parseInt(pendingCount || '0', 10),
        failedCount: parseInt(failedCount || '0', 10),
      }
    });
  } catch (err) {
    console.error('[Admin Payout] /payouts GET error:', err);
    return res.json({ success: false, error: 'Server error loading payouts.' });
  }
}

// POST /api/admin/payout/query
async function queryPayoutStatus(req, res) {
  try {
    const { orderNo } = req.body;
    if (!orderNo) return res.json({ success: false, error: 'Missing orderNo.' });

    const [rows] = await pool.execute('SELECT * FROM payouts WHERE order_no = ? LIMIT 1', [orderNo]);
    if (!rows.length) return res.json({ success: false, error: 'Payout order not found.' });

    const stored = rows[0];

    const params = { merchNo: MERCH_NO, orderNo };
    const sign = generateSign(params, API_KEY);
    const solipayRes = await httpPost(`${SOLIPAY_BASE}/api/payOut/query`, { ...params, sign });

    if (solipayRes._networkError || solipayRes._timeout || solipayRes._parseError) {
      return res.json({ success: true, status: stored.status, orderState: stored.status, message: 'Gateway query timed out, keeping current state.' });
    }

    if (solipayRes.code === 500 && typeof solipayRes.msg === 'string' && solipayRes.msg.includes('OrderNo not exist')) {
      return res.json({ success: false, error: 'Order not found on SoliPay gateway.' });
    }

    if (solipayRes.code !== 0) {
      return res.json({ success: false, error: solipayRes.msg || 'Query failed.' });
    }

    const { orderState, businessNo, msg } = solipayRes.data || {};
    const newStatus = String(orderState !== undefined ? orderState : stored.status);

    await pool.execute(
      `UPDATE payouts
       SET status = ?,
           business_no = COALESCE(?, business_no),
           error_msg = COALESCE(?, error_msg),
           confirmed_at = (CASE WHEN ? = '1' THEN NOW() ELSE confirmed_at END)
       WHERE order_no = ?`,
      [newStatus, businessNo || null, msg || null, newStatus, orderNo]
    );

    return res.json({
      success: true,
      orderNo,
      status: newStatus,
      orderState: newStatus,
      businessNo: businessNo || stored.business_no,
      errorMsg: msg || stored.error_msg,
    });
  } catch (err) {
    console.error('[Admin Payout] /query error:', err);
    return res.json({ success: false, error: 'Server error querying payout.' });
  }
}

// GET /api/debug-gateway
async function debugGateway(req, res) {
  const s = await getSettings().catch(() => ({}));
  return res.json({
    config: {
      SOLIPAY_BASE_URL:  SOLIPAY_BASE  || 'NOT SET',
      MERCH_NO:          MERCH_NO      || 'NOT SET',
      API_KEY:           API_KEY       ? `${API_KEY.slice(0,6)}...` : 'NOT SET',
      SITE_URL:          SITE_URL      || 'NOT SET',
      exchange_rate:     s.exchange_rate || 'NOT LOADED',
      price_30d_usd:     s.price_30d_usd || 'NOT LOADED',
    },
    timestamp: new Date().toISOString()
  });
}

// GET /api/admin/maintenance/config
async function getMaintenanceConfig(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      maintenanceMode: (s.maintenance_mode || '0') === '1',
      push_on_title:   s.maint_push_on_title   || MAINT_DEFAULTS.push_on_title,
      push_on_msg:     s.maint_push_on_msg     || MAINT_DEFAULTS.push_on_msg,
      push_off_title:  s.maint_push_off_title  || MAINT_DEFAULTS.push_off_title,
      push_off_msg:    s.maint_push_off_msg    || MAINT_DEFAULTS.push_off_msg,
      banner_on_title: s.maint_banner_on_title || MAINT_DEFAULTS.banner_on_title,
      banner_on_msg:   s.maint_banner_on_msg   || MAINT_DEFAULTS.banner_on_msg,
    });
  } catch (err) {
    return res.json({ success: false, error: 'Server error.' });
  }
}

// PUT /api/admin/maintenance/config
async function updateMaintenanceConfig(req, res) {
  try {
    const {
      push_on_title, push_on_msg,
      push_off_title, push_off_msg,
      banner_on_title, banner_on_msg,
    } = req.body;

    const upsert = (k, v) => pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      [k, String(v), String(v)]
    );

    if (push_on_title   !== undefined) await upsert('maint_push_on_title',   push_on_title.trim()   || MAINT_DEFAULTS.push_on_title);
    if (push_on_msg     !== undefined) await upsert('maint_push_on_msg',     push_on_msg.trim()     || MAINT_DEFAULTS.push_on_msg);
    if (push_off_title  !== undefined) await upsert('maint_push_off_title',  push_off_title.trim()  || MAINT_DEFAULTS.push_off_title);
    if (push_off_msg    !== undefined) await upsert('maint_push_off_msg',    push_off_msg.trim()    || MAINT_DEFAULTS.push_off_msg);
    if (banner_on_title !== undefined) await upsert('maint_banner_on_title', banner_on_title.trim() || MAINT_DEFAULTS.banner_on_title);
    if (banner_on_msg   !== undefined) await upsert('maint_banner_on_msg',   banner_on_msg.trim()   || MAINT_DEFAULTS.banner_on_msg);

    invalidateSettingsCache();
    console.log('[Maintenance] Message templates updated by Admin');
    return res.json({ success: true });
  } catch (err) {
    console.error('[Maintenance] Config PUT error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/maintenance/toggle
async function toggleMaintenance(req, res) {
  try {
    const { enable } = req.body;
    const isOn = enable === true;
    const flag = isOn ? '1' : '0';

    const upsert = (k, v) => pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?, updated_at=NOW()',
      [k, String(v), String(v)]
    );

    await upsert('maintenance_mode', flag);

    const s = await getSettings();
    const bannerTitle = s.maint_banner_on_title || MAINT_DEFAULTS.banner_on_title;
    const bannerMsg   = s.maint_banner_on_msg   || MAINT_DEFAULTS.banner_on_msg;
    const pushTitle   = isOn
      ? (s.maint_push_on_title  || MAINT_DEFAULTS.push_on_title)
      : (s.maint_push_off_title || MAINT_DEFAULTS.push_off_title);
    const pushMessage = isOn
      ? (s.maint_push_on_msg    || MAINT_DEFAULTS.push_on_msg)
      : (s.maint_push_off_msg   || MAINT_DEFAULTS.push_off_msg);

    if (isOn) {
      await upsert('announcement_enabled',     '1');
      await upsert('announcement_type',        'maintenance');
      await upsert('announcement_title',       bannerTitle);
      await upsert('announcement_message',     bannerMsg);
      await upsert('announcement_dismissible', '0');
    } else {
      await upsert('announcement_enabled',     '0');
      await upsert('announcement_type',        'info');
      await upsert('announcement_title',       '');
      await upsert('announcement_message',     '');
      await upsert('announcement_dismissible', '1');
    }

    invalidateSettingsCache();

    let pushSent = false;
    try {
      const s2 = await getSettings();
      const appId  = s2.onesignal_app_id      || process.env.ONESIGNAL_APP_ID;
      const apiKey = s2.onesignal_rest_api_key || process.env.ONESIGNAL_REST_API_KEY;

      if (appId && apiKey) {
        const cleanKey = apiKey.trim().replace(/^(Basic|Key|Bearer)\s+/i, '');
        const notifRes = await fetch('https://onesignal.com/api/v1/notifications', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': `Key ${cleanKey}`,
          },
          body: JSON.stringify({
            app_id: appId,
            included_segments: ['Subscribed Users', 'Total Subscriptions'],
            headings: { en: pushTitle },
            contents: { en: pushMessage },
            small_icon: 'ic_stat_onesignal_default',
          }),
        });
        const notifData = await notifRes.json();
        pushSent = !!(notifRes.ok && notifData.id);
        console.log(`[Maintenance] Push ${pushSent ? 'sent' : 'failed'}`, notifData);
      }
    } catch (pushErr) {
      console.error('[Maintenance] Push error:', pushErr.message);
    }

    console.log(`[Maintenance] Mode ${isOn ? 'ACTIVATED' : 'DEACTIVATED'} by Admin`);
    return res.json({ success: true, maintenanceMode: isOn, pushSent });
  } catch (err) {
    console.error('[Maintenance] Toggle error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /api/admin/maintenance/status
async function getMaintenanceStatus(req, res) {
  try {
    const s = await getSettings();
    return res.json({
      success: true,
      maintenanceMode: (s.maintenance_mode || '0') === '1',
    });
  } catch (err) {
    return res.json({ success: false, error: 'Server error.' });
  }
}

// POST /api/admin/set-vip-level
async function setVipLevel(req, res) {
  try {
    const { profile_id, key_code, game_name, vip_level } = req.body;
    const targetVip = vip_level === null || vip_level === '' || isNaN(parseInt(vip_level)) ? null : parseInt(vip_level);

    let targetUserId = null;
    let targetGame = game_name ? String(game_name).trim() : null;
    let targetKey = key_code ? String(key_code).trim().toUpperCase() : null;

    if (profile_id) {
      const [rows] = await pool.execute('SELECT game_user_id, game_name, key_code FROM game_user_profiles WHERE id = ? LIMIT 1', [profile_id]);
      if (rows.length) {
        targetUserId = rows[0].game_user_id ? String(rows[0].game_user_id).trim() : null;
        if (!targetGame) targetGame = rows[0].game_name ? String(rows[0].game_name).trim() : null;
        if (!targetKey) targetKey = rows[0].key_code ? String(rows[0].key_code).trim().toUpperCase() : null;
      }
      await pool.execute(
        'UPDATE game_user_profiles SET custom_vip_level = ? WHERE id = ?',
        [targetVip, profile_id]
      );
    }

    if (targetKey) {
      if (targetGame) {
        await pool.execute(
          `INSERT INTO game_user_profiles (key_code, game_name, game_user_id, custom_vip_level, first_synced_at, last_synced_at)
           VALUES (?, ?, ?, ?, NOW(), NOW())
           ON DUPLICATE KEY UPDATE custom_vip_level = ?`,
          [targetKey, targetGame, targetUserId, targetVip, targetVip]
        );
      }

      try {
        const [kRows] = await pool.execute('SELECT custom_vip_levels FROM auth_keys WHERE `key` = ? LIMIT 1', [targetKey]);
        if (kRows.length) {
          let map = {};
          try {
            if (kRows[0].custom_vip_levels) map = JSON.parse(kRows[0].custom_vip_levels);
          } catch (_) {}

          delete map['default'];

          if (targetGame) {
            if (targetVip !== null) {
              map[targetGame] = { vip: targetVip, user_id: targetUserId };
            } else {
              delete map[targetGame];
            }
          }
          await pool.execute('UPDATE auth_keys SET custom_vip_levels = ? WHERE `key` = ?', [JSON.stringify(map), targetKey]);
        }
      } catch (_) {}
    } else if (!profile_id) {
      return res.status(400).json({ success: false, error: 'Profile ID or Key + Game Name is required.' });
    }

    console.log(`[Admin] Set custom VIP level for ${targetGame || targetKey || profile_id} (UserID: ${targetUserId || 'all'}) to VIP ${targetVip}`);
    return res.json({ success: true, custom_vip_level: targetVip, target_user_id: targetUserId, game_name: targetGame });
  } catch (err) {
    console.error('[Admin] /set-vip-level error:', err);
    return res.status(500).json({ success: false, error: 'Server error updating VIP level.' });
  }
}

module.exports = {
  adminLogin,
  adminLogout,
  getAdminMe,
  getDashboard,
  getOrders,
  updateOrderStatus,
  getUsers,
  getAgents,
  createAgent,
  updateAgent,
  deleteAgent,
  getAgentStats,
  getSettingsAdmin,
  updateSettingsAdmin,
  getAnnouncement,
  updateAnnouncement,
  getGames,
  updateGames,
  getVersion,
  updateVersion,
  resetTrialDevice,
  resetTrialAccount,
  generateKeys,
  getKeys,
  deleteKey,
  createPaymentLink,
  getPaymentLinks,
  deletePaymentLink,
  getPushConfig,
  updatePushConfig,
  sendPush,
  getPushTemplates,
  createPushTemplate,
  deletePushTemplate,
  getPayoutBalance,
  createPayout,
  getPayouts,
  queryPayoutStatus,
  debugGateway,
  getMaintenanceConfig,
  updateMaintenanceConfig,
  toggleMaintenance,
  getMaintenanceStatus,
  setVipLevel,
};
