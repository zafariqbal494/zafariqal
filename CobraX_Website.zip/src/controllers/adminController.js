'use strict';

/**
 * CobraX Admin Controller
 * Decomposed into domain-specific sub-controllers in ./admin/
 * Re-exports the unified admin package for 100% backward compatibility.
 */
module.exports = require('./admin');
