'use strict';

const pool = require('../config/database');
const { API_KEY, PLAN_META } = require('../config/constants');
const { safeCompare, generateSign, generateKey } = require('../utils/crypto');
const { sendKeyDeliveryEmail } = require('../utils/email');

// POST /webhook/payin
async function handlePayinWebhook(req, res) {
  let conn = null;
  try {
    const payload = req.body;
    console.log('[CobraX] Webhook:', JSON.stringify(payload));

    if (payload.code !== 0 || !payload.data) return res.send('ok');

    const data         = payload.data;
    const receivedSign = (data.sign || '').toString().toLowerCase();
    const computedSign = generateSign(data, API_KEY).toLowerCase();

    if (!receivedSign || !safeCompare(receivedSign, computedSign)) {
      console.error('[CobraX] Webhook sig mismatch.');
      return res.send('ok');
    }

    const { orderNo, orderState } = data;
    if (orderState !== '1') return res.send('ok');

    // Database transaction with row lock to eliminate race conditions (SEC-03)
    conn = await pool.getConnection();
    await conn.beginTransaction();

    const [rows]   = await conn.execute('SELECT * FROM orders WHERE order_no = ? FOR UPDATE', [orderNo]);
    const existing = rows[0] || null;

    // Idempotent: already confirmed by another thread or prior webhook
    if (existing && existing.order_state === '1') {
      await conn.commit();
      return res.send('ok');
    }

    // In-game deposit order handling: Update status, DO NOT generate VIP key
    if (existing && existing.plan === 'deposit') {
      await conn.execute(
        "UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?",
        [orderNo]
      );
      await conn.execute(
        "UPDATE device_deposits SET status='1', confirmed_at=NOW() WHERE order_no=?",
        [orderNo]
      );
      await conn.commit();
      console.log(`[CobraX] In-game deposit confirmed (no VIP key generated): ${orderNo}`);
      return res.send('ok');
    }

    // Custom payment link order handling: Update status, DO NOT generate VIP key
    if (existing && existing.plan === 'custom') {
      await conn.execute(
        "UPDATE orders SET order_state='1', confirmed_at=NOW() WHERE order_no=?",
        [orderNo]
      );
      await conn.execute(
        "UPDATE custom_payment_links SET status='paid', paid_at=NOW() WHERE order_no=?",
        [orderNo]
      );
      await conn.commit();
      console.log(`[CobraX] Custom payment link confirmed (no VIP key generated): ${orderNo}`);
      return res.send('ok');
    }

    const days     = existing ? existing.duration_days : 30;
    const plan     = existing ? existing.plan : '30';
    const planInfo = PLAN_META[plan] || { packageType: 'basic' };
    const key      = (existing && existing.auth_key) ? existing.auth_key : generateKey(days);
    const gamesJson = existing && existing.selected_games ? (typeof existing.selected_games === 'string' ? existing.selected_games : JSON.stringify(existing.selected_games)) : null;

    if (existing) {
      await conn.execute(
        `UPDATE orders SET order_state='1', auth_key=?, confirmed_at=NOW() WHERE order_no=?`,
        [key, orderNo]
      );
    } else {
      await conn.execute(
        `INSERT INTO orders (order_no, plan, duration_days, amount, channel, order_state, auth_key, confirmed_at)
         VALUES (?, '30', ?, '0.00', 'unknown', '1', ?, NOW())`,
        [orderNo, days, key]
      );
    }

    await conn.execute(
      `INSERT IGNORE INTO auth_keys (\`key\`, package_type, duration_days, order_no, selected_games) VALUES (?, ?, ?, ?, ?)`,
      [key, planInfo.packageType, days, orderNo, gamesJson]
    );

    await conn.commit();
    console.log(`[CobraX] Webhook confirmed atomically: ${orderNo} -> ${key} (Games: ${gamesJson})`);

    // Trigger Key Delivery Email strictly after transaction commits
    try {
      const [uRows] = await pool.execute('SELECT u.email, u.username FROM orders o JOIN users u ON u.id = o.user_id WHERE o.order_no = ? LIMIT 1', [orderNo]);
      if (uRows.length && uRows[0].email) {
        sendKeyDeliveryEmail(uRows[0].email, uRows[0].username, orderNo, key, plan, days, gamesJson, existing ? existing.amount : 0).catch(() => {});
      }
    } catch (_) {}

    return res.send('ok');
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (_) {}
    }
    console.error('[CobraX] Webhook exception:', err);
    return res.send('ok');
  } finally {
    if (conn) {
      conn.release();
    }
  }
}

// POST /webhook/payout
async function handlePayoutWebhook(req, res) {
  try {
    const payload = req.body;
    console.log('[SoliPay Payout] Webhook received:', JSON.stringify(payload));

    if (!payload || !payload.data) return res.send('ok');

    const data = payload.data;
    const receivedSign = (data.sign || '').toString().toLowerCase();
    const computedSign = generateSign(data, API_KEY).toLowerCase();

    if (!receivedSign || !safeCompare(receivedSign, computedSign)) {
      console.error('[SoliPay Payout] Webhook signature mismatch.');
      return res.send('ok');
    }

    const { orderNo, orderState, businessNo, msg } = data;
    const finalStatus = String(orderState || '0');

    await pool.execute(
      `UPDATE payouts
       SET status = ?,
           business_no = COALESCE(?, business_no),
           error_msg = ?,
           confirmed_at = (CASE WHEN ? = '1' THEN NOW() ELSE confirmed_at END)
       WHERE order_no = ?`,
      [finalStatus, businessNo || null, msg || null, finalStatus, orderNo]
    );

    console.log(`[SoliPay Payout] Webhook updated order ${orderNo} -> status ${finalStatus}`);
    return res.send('ok');
  } catch (err) {
    console.error('[SoliPay Payout] Webhook exception:', err);
    return res.send('ok');
  }
}

module.exports = {
  handlePayinWebhook,
  handlePayoutWebhook,
};
