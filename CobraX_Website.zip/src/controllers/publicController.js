'use strict';

const pool = require('../config/database');
const { getSettings } = require('../config/settings');
const { DEFAULT_GAMES, SITE_URL } = require('../config/constants');
const { getLatestApkFile } = require('../utils/helpers');

// GET /api/app/download, /download/apk, /download-apk
async function downloadApk(req, res) {
  try {
    const latestApk = getLatestApkFile();
    if (latestApk) {
      console.log(`[Download] Serving local APK from downloads folder: ${latestApk.name}`);
      return res.download(latestApk.fullPath, latestApk.name);
    }

    // Fallback: If no APK found in /downloads folder, redirect to DB configured URL
    const s = await getSettings();
    const apkUrl = s.update_download_url || `${SITE_URL}/cobrax.apk`;
    console.log(`[Download] No local APK found in /downloads. Redirecting to: ${apkUrl}`);
    return res.redirect(302, apkUrl);
  } catch (err) {
    console.error('[Download] /api/app/download error:', err);
    return res.redirect(302, 'https://cobrax.sbs/cobrax.apk');
  }
}

// GET /api/settings/public
async function getPublicSettings(req, res) {
  try {
    const s = await getSettings();
    let gamesList = DEFAULT_GAMES;
    if (s.games_config) {
      try {
        const parsed = JSON.parse(s.games_config);
        if (Array.isArray(parsed) && parsed.length > 0) {
          gamesList = parsed;
        }
      } catch (e) {}
    }
    let tgLink = s.telegram_link;
    let tgAddr = s.telegram_address;
    if (!tgLink && tgAddr) {
      tgLink = tgAddr.startsWith('http') ? tgAddr : `https://${tgAddr}`;
    }
    if (!tgAddr && tgLink) {
      tgAddr = tgLink.replace(/^https?:\/\//i, '');
    }
    tgLink = tgLink || 'https://t.me/winXcobra';
    tgAddr = tgAddr || 't.me/winXcobra';

    const latestApk = getLatestApkFile();
    const effectiveApkUrl = latestApk ? `${SITE_URL}/api/app/download` : (s.update_download_url || `${SITE_URL}/cobrax.apk`);

    let depositCompleted = false;
    const devId = req.query.device_id || req.headers['x-device-id'];
    if (devId && typeof devId === 'string' && devId.trim().length > 0) {
      const cleanDevId = devId.trim().slice(0, 128);
      const clientVer = req.headers['x-app-version'] || req.query.app_version || '5.0.1';

      // Automatically register app install / update last active timestamp
      pool.execute(
        `INSERT INTO app_installs (device_id, app_version, first_seen, last_seen)
         VALUES (?, ?, NOW(), NOW())
         ON DUPLICATE KEY UPDATE app_version = VALUES(app_version), last_seen = NOW()`,
        [cleanDevId, String(clientVer).slice(0, 20)]
      ).catch(() => {});

      try {
        const [depRows] = await pool.execute(
          "SELECT id FROM device_deposits WHERE device_id = ? AND status = '1' LIMIT 1",
          [cleanDevId]
        );
        depositCompleted = depRows.length > 0;
      } catch (_) {}
    }

    return res.json({
      success: true,
      exchangeRate: parseFloat(s.exchange_rate || '280'),
      prices: {
        1:  { usd: parseFloat(s.price_1d_usd  || '20.00') },
        30: { usd: parseFloat(s.price_30d_usd || '80.00') },
      },
      telegramLink:    tgLink,
      telegramAddress: tgAddr,
      discountActive:  (s.discount_active || '1') === '1',
      games:           gamesList,
      minAppVersion:      s.min_app_version      || '5.0.1',
      latestAppVersion:   s.latest_app_version   || '5.0.1',
      updateUrl:          effectiveApkUrl,
      forceUpdateEnabled:   (s.force_update_enabled || '1') === '1',
      onesignalAppId:       s.onesignal_app_id     || '',
      requiredGameVipLevel: parseInt(s.required_game_vip_level || '3', 10),
      maintenanceMode:      (s.maintenance_mode || '0') === '1',
      minDepositAmount:     parseFloat(s.min_deposit_amount || '5000'),
      solipayDepositEnabled: (s.solipay_deposit_enabled || '1') === '1',
      depositCompleted:     depositCompleted,
      plan1Restricted:      (s.plan_1_restricted || '0') === '1',
      plan30Restricted:     (s.plan_30_restricted || '0') === '1',
    });
  } catch (err) {
    console.error('[Settings] public error:', err);
    return res.json({ success: false, error: 'Could not load settings.' });
  }
}

// GET /api/deposit/status
async function getDepositStatus(req, res) {
  try {
    const devId = req.query.device_id || req.headers['x-device-id'];
    if (!devId) {
      return res.json({ success: true, depositCompleted: false });
    }
    const [depRows] = await pool.execute(
      "SELECT id FROM device_deposits WHERE device_id = ? AND status = '1' LIMIT 1",
      [String(devId).trim()]
    );
    return res.json({ success: true, depositCompleted: depRows.length > 0 });
  } catch (err) {
    console.error('[Deposit] /status error:', err);
    return res.json({ success: false, depositCompleted: false, error: 'Server error' });
  }
}

// GET /api/announcements/active
async function getActiveAnnouncements(req, res) {
  try {
    const s = await getSettings();
    const enabled = (s.announcement_enabled || '0') === '1';
    if (!enabled) {
      return res.json({ success: true, active: false });
    }
    return res.json({
      success: true,
      active: true,
      title: s.announcement_title || '',
      message: s.announcement_message || 'System Notice: WinGo 30Sec engines fully operational.',
      type: s.announcement_type || 'info', // 'info', 'warning', 'maintenance'
      url: s.announcement_url || null,
      dismissible: (s.announcement_dismissible || '1') === '1',
    });
  } catch (err) {
    console.error('[Announcements] active error:', err);
    return res.json({ success: false, active: false });
  }
}

// POST /api/validate-referral
async function validateReferral(req, res) {
  try {
    const { code } = req.body;
    if (!code || typeof code !== 'string') return res.json({ success: false, error: 'Code required.' });

    const s = await getSettings();
    if ((s.discount_active || '1') !== '1') return res.json({ success: false, error: 'Referral discounts are currently disabled.' });

    const [rows] = await pool.execute(
      'SELECT id, name, discount_percent FROM agents WHERE code = ? AND is_active = 1 LIMIT 1',
      [code.trim().toUpperCase()]
    );
    if (!rows.length) return res.json({ success: false, error: 'Invalid or inactive referral code.' });

    return res.json({
      success: true,
      agentName:       rows[0].name,
      discountPercent: parseFloat(rows[0].discount_percent),
    });
  } catch (err) {
    console.error('[Referral] validate error:', err);
    return res.json({ success: false, error: 'Server error.' });
  }
}

// GET /ref/:code, /r/:code, /agent/:code
function handleReferralRedirect(req, res) {
  const code = encodeURIComponent(req.params.code ? req.params.code.trim().toUpperCase() : '');
  return res.redirect(`/buy-key?ref=${code}`);
}

module.exports = {
  downloadApk,
  getPublicSettings,
  getDepositStatus,
  getActiveAnnouncements,
  validateReferral,
  handleReferralRedirect,
};
