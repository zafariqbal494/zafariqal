'use strict';

const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { orderLimiter } = require('../middlewares/rateLimiters');

// VIP key purchase flow
router.post('/api/create-order', orderLimiter, orderController.createOrder);
router.post('/api/check-order', orderLimiter, orderController.checkOrder);
router.get('/api/get-key/:orderNo', orderController.getKey);

// Custom payment links
router.get('/api/payment-link/:linkId', orderController.getPaymentLink);
router.post('/api/payment-link/pay', orderLimiter, orderController.payPaymentLink);

// In-game device deposits
router.post('/api/deposit/create', orderController.createDeposit);

module.exports = router;
