'use strict';

const express = require('express');
const router = express.Router();
const appController = require('../controllers/appController');
const { pingLimiter, validateLimiter } = require('../middlewares/rateLimiters');

// Mobile App heartbeat & verification
router.post('/api/app/ping', pingLimiter, appController.ping);
router.post('/api/cobrax/verify-session', validateLimiter, appController.verifySession);
router.post('/api/cobrax/validate-key', validateLimiter, appController.validateKey);

// Telemetry & VIP profile synchronization
router.post(['/api/app/sync-game-profile', '/api/cobrax/sync-game-profile'], appController.syncGameProfile);
router.post(['/api/cobrax/get-game-vip', '/api/app/get-game-vip'], appController.getGameVip);

module.exports = router;
