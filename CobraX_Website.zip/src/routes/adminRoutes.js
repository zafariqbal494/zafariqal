'use strict';

const express = require('express');
const router  = express.Router();
const {
  auth,
  dashboard,
  orders,
  users,
  keys,
  paylinks,
  payouts,
  settings,
} = require('../controllers/admin');
const { requireAdmin } = require('../middlewares/auth');
const { adminLimiter } = require('../middlewares/rateLimiters');

// Admin Auth
router.post('/api/admin/login', adminLimiter, auth.adminLogin);
router.post('/api/admin/logout', requireAdmin, auth.adminLogout);
router.get('/api/admin/me', requireAdmin, auth.getAdminMe);

// Dashboard & Analytics
router.get('/api/admin/dashboard', requireAdmin, dashboard.getDashboard);

// Orders Management
router.get('/api/admin/orders', requireAdmin, orders.getOrders);
router.post('/api/admin/orders/:orderNo/status', requireAdmin, orders.updateOrderStatus);

// VIP Level Overrides
router.post('/api/admin/set-vip-level', requireAdmin, orders.setVipLevel);

// Users Management
router.get('/api/admin/users', requireAdmin, users.getUsers);

// Agents & Affiliates
router.get('/api/admin/agents', requireAdmin, users.getAgents);
router.post('/api/admin/agents', requireAdmin, users.createAgent);
router.put('/api/admin/agents/:id', requireAdmin, users.updateAgent);
router.post('/api/admin/agents/:id/toggle', requireAdmin, users.toggleAgent);
router.delete('/api/admin/agents/:id', requireAdmin, users.deleteAgent);
router.get('/api/admin/agents/:id/stats', requireAdmin, users.getAgentStats);

// Anti-Abuse & Trial Reset
router.post('/api/admin/reset-trial-device', requireAdmin, users.resetTrialDevice);
router.post('/api/admin/reset-trial-account', requireAdmin, users.resetTrialAccount);

// Key Generation
router.post('/api/admin/keys/generate', requireAdmin, keys.generateKeys);
router.get('/api/admin/keys', requireAdmin, keys.getKeys);
router.delete('/api/admin/keys/:id', requireAdmin, keys.deleteKey);

// Custom Payment Links
router.post('/api/admin/payment-links/create', requireAdmin, paylinks.createPaymentLink);
router.get('/api/admin/payment-links', requireAdmin, paylinks.getPaymentLinks);
router.post('/api/admin/payment-links/:id/cancel', requireAdmin, paylinks.cancelPaymentLink);
router.delete('/api/admin/payment-links/:id', requireAdmin, paylinks.deletePaymentLink);

// SoliPay Payouts & Disbursements
router.get('/api/admin/payout/balance', requireAdmin, payouts.getPayoutBalance);
router.post('/api/admin/payout/create', requireAdmin, payouts.createPayout);
router.get('/api/admin/payouts', requireAdmin, payouts.getPayouts);
router.post('/api/admin/payout/query', requireAdmin, payouts.queryPayoutStatus);
router.get('/api/debug-gateway', requireAdmin, payouts.debugGateway);

// Global Settings
router.get('/api/admin/settings', requireAdmin, settings.getSettingsAdmin);
router.put('/api/admin/settings', requireAdmin, settings.updateSettingsAdmin);

// Announcements
router.get('/api/admin/announcement', requireAdmin, settings.getAnnouncement);
router.put('/api/admin/announcement', requireAdmin, settings.updateAnnouncement);

// Games Manager
router.get('/api/admin/games', requireAdmin, settings.getGames);
router.put('/api/admin/games', requireAdmin, settings.updateGames);

// App Version Management
router.get('/api/admin/version', requireAdmin, settings.getVersion);
router.put('/api/admin/version', requireAdmin, settings.updateVersion);

// Push Notifications & Marketing
router.get('/api/admin/push/config', requireAdmin, settings.getPushConfig);
router.put('/api/admin/push/config', requireAdmin, settings.updatePushConfig);
router.post('/api/admin/push/send', requireAdmin, settings.sendPush);
router.get('/api/admin/push/templates', requireAdmin, settings.getPushTemplates);
router.post('/api/admin/push/templates', requireAdmin, settings.createPushTemplate);
router.delete('/api/admin/push/templates/:id', requireAdmin, settings.deletePushTemplate);

// Maintenance Mode
router.get('/api/admin/maintenance/config', requireAdmin, settings.getMaintenanceConfig);
router.put('/api/admin/maintenance/config', requireAdmin, settings.updateMaintenanceConfig);
router.post('/api/admin/maintenance/toggle', requireAdmin, settings.toggleMaintenance);
router.get('/api/admin/maintenance/status', requireAdmin, settings.getMaintenanceStatus);

module.exports = router;
