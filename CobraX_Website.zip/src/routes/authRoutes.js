'use strict';

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { requireAuth } = require('../middlewares/auth');
const { authLimiter } = require('../middlewares/rateLimiters');

// Authentication routes
router.post('/api/auth/register', authLimiter, authController.register);
router.post('/api/auth/login', authLimiter, authController.login);
router.post('/api/auth/logout', requireAuth, authController.logout);
router.get('/api/auth/me', requireAuth, authController.getMe);

// User account data routes
router.get('/api/user/orders', requireAuth, authController.getUserOrders);
router.get('/api/user/trial-eligibility', requireAuth, authController.getUserTrialEligibility);

module.exports = router;
