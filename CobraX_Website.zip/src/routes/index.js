'use strict';

const express = require('express');
const router = express.Router();

const publicRoutes  = require('./publicRoutes');
const authRoutes    = require('./authRoutes');
const orderRoutes   = require('./orderRoutes');
const webhookRoutes = require('./webhookRoutes');
const appRoutes     = require('./appRoutes');
const adminRoutes   = require('./adminRoutes');

// Mount all modular routes
router.use(publicRoutes);
router.use(authRoutes);
router.use(orderRoutes);
router.use(webhookRoutes);
router.use(appRoutes);
router.use(adminRoutes);

module.exports = router;
