'use strict';

const express = require('express');
const router = express.Router();
const webhookController = require('../controllers/webhookController');

// SoliPay payment callbacks
router.post('/webhook/payin', webhookController.handlePayinWebhook);
router.post('/webhook/payout', webhookController.handlePayoutWebhook);

module.exports = router;
