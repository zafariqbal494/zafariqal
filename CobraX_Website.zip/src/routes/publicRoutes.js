'use strict';

const express = require('express');
const router = express.Router();
const publicController = require('../controllers/publicController');

// APK direct download endpoints
router.get(['/api/app/download', '/download/apk', '/download-apk'], publicController.downloadApk);

// Public settings & status
router.get('/api/settings/public', publicController.getPublicSettings);
router.get('/api/deposit/status', publicController.getDepositStatus);
router.get('/api/announcements/active', publicController.getActiveAnnouncements);

// Referral validation & redirect shortcuts
router.post('/api/validate-referral', publicController.validateReferral);
router.get(['/ref/:code', '/r/:code', '/agent/:code'], publicController.handleReferralRedirect);

module.exports = router;
