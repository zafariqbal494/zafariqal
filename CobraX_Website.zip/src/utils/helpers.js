'use strict';

const fs    = require('fs');
const path  = require('path');
const url   = require('url');
const http  = require('http');
const https = require('https');
const { DOWNLOADS_DIR } = require('../config/constants');

function getLatestApkFile() {
  try {
    if (!fs.existsSync(DOWNLOADS_DIR)) return null;
    const files = fs.readdirSync(DOWNLOADS_DIR);
    const apkFiles = files.filter(f => f.toLowerCase().endsWith('.apk'));
    if (apkFiles.length === 0) return null;

    // Sort by last modified time (newest/latest file first)
    const sorted = apkFiles.map(f => {
      const fullPath = path.join(DOWNLOADS_DIR, f);
      const stat = fs.statSync(fullPath);
      return { name: f, fullPath, mtimeMs: stat.mtimeMs };
    }).sort((a, b) => b.mtimeMs - a.mtimeMs);

    return sorted[0];
  } catch (err) {
    console.error('[Download] Error scanning downloads directory:', err.message);
    return null;
  }
}

function isVersionOutdated(clientVer, minVer) {
  if (!minVer || typeof minVer !== 'string') return false;
  if (!clientVer || typeof clientVer !== 'string') return true;
  try {
    const parse = (v) => v.split('.').map((s) => parseInt(s.replace(/[^0-9]/g, ''), 10) || 0);
    const c = parse(clientVer);
    const m = parse(minVer);
    const maxLen = Math.max(c.length, m.length);
    for (let i = 0; i < maxLen; i++) {
      const cv = c[i] || 0;
      const mv = m[i] || 0;
      if (cv < mv) return true;
      if (cv > mv) return false;
    }
    return false;
  } catch (e) {
    return false;
  }
}

function httpPost(fullUrl, body) {
  return new Promise((resolve) => {
    const parsed   = new url.URL(fullUrl);
    const isHttps  = parsed.protocol === 'https:';
    const postData = JSON.stringify(body);
    const options  = {
      hostname: parsed.hostname,
      port:     parsed.port || (isHttps ? 443 : 80),
      path:     parsed.pathname + parsed.search,
      method:   'POST',
      headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) },
    };
    const lib = isHttps ? https : http;
    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve({ _raw: data, _parseError: true });
        }
      });
    });
    req.on('error', e => resolve({ _networkError: true, _message: e.message }));
    req.setTimeout(15000, () => { req.destroy(); resolve({ _timeout: true }); });
    req.write(postData);
    req.end();
  });
}

module.exports = {
  getLatestApkFile,
  isVersionOutdated,
  httpPost,
};
