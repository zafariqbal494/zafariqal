'use strict';

const crypto = require('crypto');

function safeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function generateSign(params, apiKey) {
  const filtered = Object.fromEntries(
    Object.entries(params).filter(([k, v]) => k !== 'sign' && v !== undefined && v !== null && v !== '')
  );
  const sorted = Object.keys(filtered).sort();
  const source = sorted.map(k => `${k}=${filtered[k]}`).join('&');
  return crypto.createHash('md5').update(source + apiKey).digest('hex');
}

function generateKey(days) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const seg   = () => Array.from({ length: 4 }, () => chars[crypto.randomInt(0, chars.length)]).join('');
  return `COBRAX-${seg()}-${seg()}-${seg()}-${days}`;
}

function generateOrderNo() {
  return `CBX${Date.now()}${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function generatePayoutOrderNo() {
  return `WD${Date.now()}${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function generateCustomLinkId() {
  return `PAY-CBX-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
}

function generateSessionToken() {
  return crypto.randomBytes(32).toString('hex');
}

module.exports = {
  safeCompare,
  generateSign,
  generateKey,
  generateOrderNo,
  generatePayoutOrderNo,
  generateCustomLinkId,
  generateSessionToken,
};
