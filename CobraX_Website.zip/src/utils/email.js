'use strict';

let nodemailer;
try { nodemailer = require('nodemailer'); } catch (_) { nodemailer = null; }

const { getSettings } = require('../config/settings');
const { SITE_URL } = require('../config/constants');

async function getSmtpTransporter() {
  try {
    if (!nodemailer) {
      try { nodemailer = require('nodemailer'); } catch (_) { return null; }
    }
    const s = await getSettings().catch(() => ({}));
    const host = s.smtp_host || process.env.SMTP_HOST || 'mail.cobrax.sbs';
    const port = parseInt(s.smtp_port || process.env.SMTP_PORT || '465', 10);
    const secure = (s.smtp_secure || process.env.SMTP_SECURE || 'true') === 'true' || port === 465;
    const user = s.smtp_user || process.env.SMTP_USER || 'info@cobrax.sbs';
    const pass = s.smtp_pass || process.env.SMTP_PASS || '';

    if (!pass) return null;

    return {
      transporter: nodemailer.createTransport({
        host,
        port,
        secure,
        auth: { user, pass },
        tls: { rejectUnauthorized: false }
      }),
      from: s.smtp_from || process.env.SMTP_FROM || `"CobraX" <${user}>`
    };
  } catch (err) {
    console.error('[SMTP] getSmtpTransporter error:', err.message);
    return null;
  }
}

async function sendWelcomeEmail(toEmail, username) {
  try {
    const smtp = await getSmtpTransporter();
    if (!smtp) return false;

    const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="background:#070a0f; color:#e0e6ed; font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif; margin:0; padding:20px;">
      <div style="max-width:560px; margin:0 auto; background:#0d131d; border:1px solid #1a2638; border-top:3px solid #00ff41; border-radius:8px; padding:30px; box-shadow:0 10px 30px rgba(0,0,0,0.5);">
        <div style="text-align:center; margin-bottom:20px;">
          <h1 style="color:#ffffff; font-size:28px; font-weight:900; letter-spacing:3px; margin:0;">Cobra<span style="color:#ff3366;">X</span></h1>
          <p style="color:#7a8b9e; font-size:11px; letter-spacing:2px; text-transform:uppercase; margin-top:4px;">RESTRICTED ACCESS PLATFORM</p>
        </div>
        <hr style="border:none; border-top:1px solid #1a2638; margin:20px 0;">
        <h2 style="color:#00ff41; font-size:20px; margin-bottom:12px;">Welcome to CobraX, ${username}!</h2>
        <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">Your official user registration is complete. You now have access to the CobraX prediction dashboard and VIP activation key portal.</p>
        <div style="background:rgba(0,255,65,0.05); border:1px solid rgba(0,255,65,0.2); border-radius:6px; padding:16px; margin:20px 0;">
          <p style="margin:0 0 8px 0; font-size:12px; color:#7a8b9e;">ACCOUNT DETAILS:</p>
          <p style="margin:4px 0; font-size:14px; color:#fff;"><strong>Username:</strong> ${username}</p>
          <p style="margin:4px 0; font-size:14px; color:#fff;"><strong>Email:</strong> ${toEmail}</p>
        </div>
        <div style="text-align:center; margin-top:25px;">
          <a href="${SITE_URL}/buy-key" style="background:linear-gradient(135deg,#00ff41,#00b32d); color:#000; font-weight:bold; padding:12px 28px; border-radius:6px; text-decoration:none; display:inline-block; font-size:14px; letter-spacing:1px;">GET ACCESS KEY</a>
        </div>
        <p style="color:#64748b; font-size:11px; text-align:center; margin-top:30px;">CobraX Security System • Official Automated Message</p>
      </div>
    </body>
    </html>`;

    await smtp.transporter.sendMail({
      from: smtp.from,
      to: toEmail,
      subject: '🐍 Welcome to CobraX — Account Registered Successfully',
      html
    });
    console.log(`[Email] Welcome email sent to ${toEmail}`);
    return true;
  } catch (err) {
    console.error('[Email] sendWelcomeEmail error:', err.message);
    return false;
  }
}

async function sendOrderPendingEmail(toEmail, username, orderNo, plan, pkrAmount, selectedGames, paymentUrl) {
  try {
    const smtp = await getSmtpTransporter();
    if (!smtp) return false;

    const planLabel = plan === '1' ? '24-Hour Access' : plan === '30' ? '30-Day Access' : 'VIP Plan';
    let gamesText = 'All Games';
    if (Array.isArray(selectedGames) && selectedGames.length > 0) {
      gamesText = selectedGames.join(', ');
    } else if (typeof selectedGames === 'string' && selectedGames) {
      try { gamesText = JSON.parse(selectedGames).join(', '); } catch (_) { gamesText = selectedGames; }
    }

    const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="background:#070a0f; color:#e0e6ed; font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif; margin:0; padding:20px;">
      <div style="max-width:560px; margin:0 auto; background:#0d131d; border:1px solid #1a2638; border-top:3px solid #ffc107; border-radius:8px; padding:30px; box-shadow:0 10px 30px rgba(0,0,0,0.5);">
        <div style="text-align:center; margin-bottom:20px;">
          <h1 style="color:#ffffff; font-size:28px; font-weight:900; letter-spacing:3px; margin:0;">Cobra<span style="color:#ff3366;">X</span></h1>
          <p style="color:#7a8b9e; font-size:11px; letter-spacing:2px; text-transform:uppercase; margin-top:4px;">ORDER PENDING CONFIRMATION</p>
        </div>
        <hr style="border:none; border-top:1px solid #1a2638; margin:20px 0;">
        <h2 style="color:#ffc107; font-size:18px; margin-bottom:12px;">Payment Pending — Order #${orderNo}</h2>
        <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">Hi <strong>${username || 'User'}</strong>, your VIP Access Order has been initiated. Complete payment via JazzCash or EasyPaisa to activate your key.</p>
        
        <div style="background:rgba(255,193,7,0.05); border:1px solid rgba(255,193,7,0.2); border-radius:6px; padding:16px; margin:20px 0;">
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Order Number:</strong> <span style="font-family:monospace; color:#00ff41;">${orderNo}</span></p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Selected Plan:</strong> ${planLabel}</p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Unlocked Games:</strong> ${gamesText}</p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Amount Due:</strong> <span style="color:#00ff41; font-weight:bold;">PKR ${parseFloat(pkrAmount).toLocaleString()}</span></p>
        </div>

        ${paymentUrl ? `
        <div style="text-align:center; margin-top:25px;">
          <a href="${paymentUrl}" style="background:linear-gradient(135deg,#00ff41,#00b32d); color:#000; font-weight:bold; padding:12px 28px; border-radius:6px; text-decoration:none; display:inline-block; font-size:14px; letter-spacing:1px;">COMPLETE PAYMENT NOW</a>
        </div>
        ` : ''}

        <p style="color:#64748b; font-size:11px; text-align:center; margin-top:30px;">If you already completed payment, your activation key will be delivered automatically.</p>
      </div>
    </body>
    </html>`;

    await smtp.transporter.sendMail({
      from: smtp.from,
      to: toEmail,
      subject: `⏳ Pending Payment — CobraX Order #${orderNo}`,
      html
    });
    console.log(`[Email] Order pending email sent to ${toEmail} for order ${orderNo}`);
    return true;
  } catch (err) {
    console.error('[Email] sendOrderPendingEmail error:', err.message);
    return false;
  }
}

async function sendKeyDeliveryEmail(toEmail, username, orderNo, key, plan, durationDays, selectedGames, pkrAmount) {
  try {
    const smtp = await getSmtpTransporter();
    if (!smtp) return false;

    let gamesText = 'All Games';
    if (Array.isArray(selectedGames) && selectedGames.length > 0) {
      gamesText = selectedGames.join(', ');
    } else if (typeof selectedGames === 'string' && selectedGames) {
      try { gamesText = JSON.parse(selectedGames).join(', '); } catch (_) { gamesText = selectedGames; }
    }

    const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="background:#070a0f; color:#e0e6ed; font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif; margin:0; padding:20px;">
      <div style="max-width:560px; margin:0 auto; background:#0d131d; border:1px solid #1a2638; border-top:3px solid #00ff41; border-radius:8px; padding:30px; box-shadow:0 10px 30px rgba(0,0,0,0.5);">
        <div style="text-align:center; margin-bottom:20px;">
          <h1 style="color:#ffffff; font-size:28px; font-weight:900; letter-spacing:3px; margin:0;">Cobra<span style="color:#ff3366;">X</span></h1>
          <p style="color:#7a8b9e; font-size:11px; letter-spacing:2px; text-transform:uppercase; margin-top:4px;">VIP ACCESS KEY DELIVERED</p>
        </div>
        <hr style="border:none; border-top:1px solid #1a2638; margin:20px 0;">
        <h2 style="color:#00ff41; font-size:20px; margin-bottom:12px;">✅ Payment Confirmed!</h2>
        <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">Hi <strong>${username || 'User'}</strong>, thank you for your purchase. Your payment for Order <strong>#${orderNo}</strong> has been verified. Here is your official activation key:</p>
        
        <!-- KEY DISPLAY BOX -->
        <div style="background:rgba(0,255,65,0.08); border:1px solid #00ff41; border-radius:8px; padding:20px; text-align:center; margin:24px 0;">
          <div style="font-size:11px; color:#7a8b9e; letter-spacing:2px; text-transform:uppercase; margin-bottom:8px;">YOUR COBRAX VIP ACTIVATION KEY:</div>
          <div style="font-family:monospace; font-size:20px; font-weight:bold; color:#00ff41; letter-spacing:2px; background:rgba(0,0,0,0.6); padding:12px; border-radius:4px; border:1px solid rgba(0,255,65,0.3); word-break:break-all;">
            ${key}
          </div>
        </div>

        <div style="background:rgba(255,255,255,0.03); border:1px solid #1a2638; border-radius:6px; padding:16px; margin-bottom:20px;">
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Order Number:</strong> ${orderNo}</p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Access Duration:</strong> ${durationDays || 30} Days</p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Unlocked Games:</strong> ${gamesText}</p>
          <p style="margin:4px 0; font-size:13px; color:#fff;"><strong>Amount Paid:</strong> PKR ${parseFloat(pkrAmount || 0).toLocaleString()}</p>
        </div>

        <div style="background:rgba(0,136,204,0.08); border-left:3px solid #0088cc; padding:12px 16px; border-radius:4px; margin-bottom:20px;">
          <p style="margin:0; font-size:12px; color:#00e5ff; line-height:1.5;"><strong>How to Activate:</strong> Open the CobraX Android App, paste your VIP key, and select your game to unlock WinGo 30Sec prediction engine.</p>
        </div>

        <div style="text-align:center; margin-top:25px;">
          <a href="${SITE_URL}/download" style="background:linear-gradient(135deg,#00ff41,#00b32d); color:#000; font-weight:bold; padding:12px 28px; border-radius:6px; text-decoration:none; display:inline-block; font-size:14px; letter-spacing:1px;">DOWNLOAD COBRAX APP</a>
        </div>

        <p style="color:#64748b; font-size:11px; text-align:center; margin-top:30px;">CobraX Security System • Keep your key private and do not share it.</p>
      </div>
    </body>
    </html>`;

    await smtp.transporter.sendMail({
      from: smtp.from,
      to: toEmail,
      subject: `🔑 Your CobraX VIP Access Key — Order #${orderNo}`,
      html
    });
    console.log(`[Email] Key delivery email sent to ${toEmail} for order ${orderNo}`);
    return true;
  } catch (err) {
    console.error('[Email] sendKeyDeliveryEmail error:', err.message);
    return false;
  }
}

module.exports = {
  getSmtpTransporter,
  sendWelcomeEmail,
  sendOrderPendingEmail,
  sendKeyDeliveryEmail,
};
