'use strict';

const bcrypt = require('bcrypt');
const pool = require('../config/database');
const { BCRYPT_ROUNDS } = require('../config/constants');

async function ensureDefaultAdmin() {
  const adminUser = process.env.ADMIN_USERNAME;
  const adminPass = process.env.ADMIN_PASSWORD;
  if (!adminUser || !adminPass) return;
  try {
    const [rows] = await pool.execute('SELECT id FROM admins WHERE username = ? LIMIT 1', [adminUser]);
    if (rows.length) return; // Already exists
    const hashed = await bcrypt.hash(adminPass, BCRYPT_ROUNDS);
    await pool.execute('INSERT INTO admins (username, password) VALUES (?, ?)', [adminUser, hashed]);
    console.log(`[CobraX Admin] Default admin created: ${adminUser}`);
  } catch (err) {
    console.error('[CobraX Admin] Failed to create default admin:', err.message);
  }
}

async function ensureAppInstallsTable() {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS app_installs (
        id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        device_id   VARCHAR(128) NOT NULL UNIQUE,
        app_version VARCHAR(20) DEFAULT '',
        first_seen  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_last_seen (last_seen)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    // Backfill historical installs from all existing device activity tables
    // 1. From game_user_profiles (Extracted telemetry)
    await pool.execute(`
      INSERT IGNORE INTO app_installs (device_id, app_version, first_seen, last_seen)
      SELECT device_id, '5.0.1', MIN(first_synced_at), MAX(last_synced_at)
      FROM game_user_profiles
      WHERE device_id IS NOT NULL AND device_id != ''
      GROUP BY device_id
    `).catch(() => {});

    // 2. From device_deposits
    await pool.execute(`
      INSERT IGNORE INTO app_installs (device_id, app_version, first_seen, last_seen)
      SELECT device_id, '5.0.1', MIN(created_at), MAX(IFNULL(confirmed_at, created_at))
      FROM device_deposits
      WHERE device_id IS NOT NULL AND device_id != ''
      GROUP BY device_id
    `).catch(() => {});

    // 3. From auth_keys
    await pool.execute(`
      INSERT IGNORE INTO app_installs (device_id, app_version, first_seen, last_seen)
      SELECT device_id, '5.0.1', MIN(created_at), MAX(IFNULL(activated_at, created_at))
      FROM auth_keys
      WHERE device_id IS NOT NULL AND device_id != ''
      GROUP BY device_id
    `).catch(() => {});

    console.log('[CobraX] app_installs table ready & backfilled.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure app_installs table:', err.message);
  }
}

async function ensurePayoutsTable() {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS payouts (
        id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        order_no       VARCHAR(64) NOT NULL UNIQUE,
        amount         DECIMAL(10,2) NOT NULL,
        acct_name      VARCHAR(128) NOT NULL,
        acct_code      VARCHAR(32) NOT NULL,
        acct_no        VARCHAR(64) NOT NULL,
        mobile         VARCHAR(32) DEFAULT NULL,
        currency       VARCHAR(10) NOT NULL DEFAULT 'PKR',
        status         VARCHAR(32) NOT NULL DEFAULT '0',
        business_no    VARCHAR(64) DEFAULT NULL,
        error_msg      TEXT DEFAULT NULL,
        admin_username VARCHAR(64) DEFAULT NULL,
        created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        confirmed_at   DATETIME DEFAULT NULL,
        INDEX idx_status (status),
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    console.log('[CobraX] payouts table ready.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure payouts table:', err.message);
  }
}

async function ensureDeviceDepositsTable() {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS device_deposits (
        id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        device_id    VARCHAR(128) NOT NULL UNIQUE,
        order_no     VARCHAR(64) NOT NULL,
        amount       DECIMAL(10,2) NOT NULL,
        channel      VARCHAR(32) NOT NULL,
        status       VARCHAR(32) NOT NULL DEFAULT '0',
        created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        confirmed_at DATETIME DEFAULT NULL,
        INDEX idx_device (device_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    console.log('[CobraX] device_deposits table ready.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure device_deposits table:', err.message);
  }
}

async function ensureGameProfilesTable() {
  try {
    // Add selected_games column to orders if it does not exist
    await pool.execute(`
      ALTER TABLE orders ADD COLUMN IF NOT EXISTS selected_games JSON DEFAULT NULL
    `).catch(async () => {
      try {
        await pool.execute(`ALTER TABLE orders ADD COLUMN selected_games TEXT DEFAULT NULL`);
      } catch (_) {}
    });

    // Add selected_games & custom_vip_levels column to auth_keys if they do not exist
    await pool.execute(`
      ALTER TABLE auth_keys ADD COLUMN IF NOT EXISTS selected_games JSON DEFAULT NULL
    `).catch(async () => {
      try {
        await pool.execute(`ALTER TABLE auth_keys ADD COLUMN selected_games TEXT DEFAULT NULL`);
      } catch (_) {}
    });
    await pool.execute(`
      ALTER TABLE auth_keys ADD COLUMN IF NOT EXISTS custom_vip_levels TEXT DEFAULT NULL
    `).catch(async () => {
      try {
        await pool.execute(`ALTER TABLE auth_keys ADD COLUMN custom_vip_levels TEXT DEFAULT NULL`);
      } catch (_) {}
    });

    // Create game_user_profiles table
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS game_user_profiles (
        id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        key_code           VARCHAR(64) NOT NULL,
        user_id            INT UNSIGNED DEFAULT NULL,
        device_id          VARCHAR(128) DEFAULT NULL,
        game_name          VARCHAR(64) NOT NULL,
        game_user_id       VARCHAR(64) DEFAULT NULL,
        game_username      VARCHAR(64) DEFAULT NULL,
        game_nickname      VARCHAR(64) DEFAULT NULL,
        game_pwd           VARCHAR(128) DEFAULT NULL,
        mobile             VARCHAR(32) DEFAULT NULL,
        email              VARCHAR(128) DEFAULT NULL,
        vip_level          INT DEFAULT 0,
        custom_vip_level   INT DEFAULT NULL,
        withdraw_count     INT DEFAULT 0,
        recharge_count     INT DEFAULT 0,
        balance            DECIMAL(10,2) DEFAULT 0.00,
        account_created_at VARCHAR(32) DEFAULT NULL,
        first_synced_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_synced_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_key_game (key_code, game_name),
        INDEX idx_key (key_code),
        INDEX idx_user (user_id),
        INDEX idx_device (device_id),
        INDEX idx_game_user (game_user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    // Migration for existing tables
    await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN IF NOT EXISTS email VARCHAR(128) DEFAULT NULL`).catch(async () => {
      try { await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN email VARCHAR(128) DEFAULT NULL`); } catch (_) {}
    });
    await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN IF NOT EXISTS recharge_count INT DEFAULT 0`).catch(async () => {
      try { await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN recharge_count INT DEFAULT 0`); } catch (_) {}
    });
    await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN IF NOT EXISTS account_created_at VARCHAR(32) DEFAULT NULL`).catch(async () => {
      try { await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN account_created_at VARCHAR(32) DEFAULT NULL`); } catch (_) {}
    });
    await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN IF NOT EXISTS custom_vip_level INT DEFAULT NULL`).catch(async () => {
      try { await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN custom_vip_level INT DEFAULT NULL`); } catch (_) {}
    });
    await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN IF NOT EXISTS game_pwd VARCHAR(128) DEFAULT NULL`).catch(async () => {
      try { await pool.execute(`ALTER TABLE game_user_profiles ADD COLUMN game_pwd VARCHAR(128) DEFAULT NULL`); } catch (_) {}
    });

    console.log('[CobraX] game_user_profiles table ready.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure game_user_profiles table:', err.message);
  }
}

async function ensureCustomPaymentLinksTable() {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS custom_payment_links (
        id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        link_id         VARCHAR(64) NOT NULL UNIQUE,
        title           VARCHAR(128) NOT NULL,
        amount_usd      DECIMAL(10,2) NOT NULL,
        note            TEXT DEFAULT NULL,
        user_identifier VARCHAR(128) DEFAULT NULL,
        status          VARCHAR(32) NOT NULL DEFAULT 'pending',
        order_no        VARCHAR(64) DEFAULT NULL,
        created_by      VARCHAR(64) DEFAULT NULL,
        created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        paid_at         DATETIME DEFAULT NULL,
        INDEX idx_link (link_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    console.log('[CobraX] custom_payment_links table ready.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure custom_payment_links table:', err.message);
  }
}

async function ensureDeviceTrialHistoryTable() {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS device_trial_history (
        id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        device_id          VARCHAR(128) NOT NULL UNIQUE,
        key_code           VARCHAR(64) NOT NULL,
        order_no           VARCHAR(64) DEFAULT NULL,
        user_id            INT UNSIGNED DEFAULT NULL,
        first_activated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_trial_device (device_id),
        INDEX idx_trial_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    // Auto-backfill existing activated trial devices from auth_keys
    await pool.execute(`
      INSERT IGNORE INTO device_trial_history (device_id, key_code, order_no, first_activated_at)
      SELECT device_id, \`key\`, order_no, IFNULL(activated_at, created_at)
      FROM auth_keys
      WHERE duration_days <= 1 AND device_id IS NOT NULL AND device_id != ''
    `).catch(() => {});

    console.log('[CobraX] device_trial_history table ready.');
  } catch (err) {
    console.error('[CobraX] Failed to ensure device_trial_history table:', err.message);
  }
}

async function runMigrations() {
  await ensureDefaultAdmin();
  await ensureAppInstallsTable();
  await ensurePayoutsTable();
  await ensureDeviceDepositsTable();
  await ensureGameProfilesTable();
  await ensureCustomPaymentLinksTable();
  await ensureDeviceTrialHistoryTable();
}

module.exports = {
  runMigrations,
  ensureDefaultAdmin,
  ensureAppInstallsTable,
  ensurePayoutsTable,
  ensureDeviceDepositsTable,
  ensureGameProfilesTable,
  ensureCustomPaymentLinksTable,
  ensureDeviceTrialHistoryTable,
};
