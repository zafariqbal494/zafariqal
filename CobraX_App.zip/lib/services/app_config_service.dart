import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import 'device_id_service.dart';
import 'integrity_service.dart';
import 'push_notification_service.dart';
import 'secure_storage_service.dart';

/// Service to dynamically fetch public app configuration from the backend server
/// (Telegram handle, dynamic Game Cards list, mandatory version checks, and one-time deposit state).
class AppConfigService {
  AppConfigService._();

  static String _cachedTelegramAddress = kTelegramAddress;
  static List<Map<String, String>> _cachedGames = kGames;
  static String _cachedMinAppVersion = kAppVersion;
  static String _cachedLatestAppVersion = kAppVersion;
  static String _cachedUpdateUrl = kOfficialDownloadUrl;
  static bool _isUpdateRequired = false;
  static bool _isUpdateCheckCompleted = false;
  static int _cachedRequiredGameVipLevel = 3;
  static bool _cachedMaintenanceMode = false;
  static bool _cachedDepositCompleted = false;
  static double _cachedMinDepositAmount = 5000.0;
  static bool _cachedSolipayDepositEnabled = true;
  static bool _isTamperedApp = false;

  /// Checks whether the device has an active internet connection.
  /// Uses raw TCP socket handshakes to public DNS IPs (8.8.8.8:53, 1.1.1.1:53)
  /// and direct HTTP check to cobrax.sbs.
  /// Bypasses DNS hostname resolution entirely to avoid ISP/telecom DNS blocks.
  static Future<bool> checkInternetConnection() async {
    try {
      // 1. Ultra-fast TCP socket connect directly to IP addresses on DNS port 53
      // Bypasses local DNS resolution and carrier proxy blocks.
      final socketProbe = await Future.any<bool>([
        Socket.connect('8.8.8.8', 53, timeout: const Duration(seconds: 2))
            .then((s) { s.destroy(); return true; })
            .catchError((_) => false),
        Socket.connect('1.1.1.1', 53, timeout: const Duration(seconds: 2))
            .then((s) { s.destroy(); return true; })
            .catchError((_) => false),
        Socket.connect('208.67.222.222', 53, timeout: const Duration(seconds: 2))
            .then((s) { s.destroy(); return true; })
            .catchError((_) => false),
      ]);

      if (socketProbe == true) return true;

      // 2. Fallback: Direct HTTP request to CobraX public endpoint
      final client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 3);
      client.badCertificateCallback = (cert, host, port) => true;
      final request = await client.getUrl(Uri.parse('https://cobrax.sbs/api/settings/public'));
      final response = await request.close().timeout(const Duration(seconds: 3));
      client.close();
      return response.statusCode == 200;
    } catch (_) {
      // Secondary fallback: standard DNS lookup in case outbound port 53 TCP is filtered
      try {
        final res = await InternetAddress.lookup('google.com')
            .timeout(const Duration(seconds: 2));
        return res.isNotEmpty && res[0].rawAddress.isNotEmpty;
      } catch (_) {
        return false;
      }
    }
  }

  /// Returns current cached or default Telegram address handle.
  static String get telegramAddress => _cachedTelegramAddress;

  /// Returns current cached or default games list.
  static List<Map<String, String>> get games => _cachedGames;

  /// Returns minimum required app version.
  static String get minAppVersion => _cachedMinAppVersion;

  /// Returns latest published app version.
  static String get latestAppVersion => _cachedLatestAppVersion;

  /// Returns update download URL (official website).
  static String get updateUrl => _cachedUpdateUrl;

  /// Returns whether a mandatory version update is required to use the app.
  static bool get isUpdateRequired => _isUpdateRequired;

  /// Returns whether the initial update check from the server has completed.
  static bool get isUpdateCheckCompleted => _isUpdateCheckCompleted;

  /// Returns required in-game VIP level to place bets (default 3).
  static int get requiredGameVipLevel => _cachedRequiredGameVipLevel;

  /// Returns true when admin has activated maintenance mode.
  /// Floating bubble is hidden and game cards show red dot + "Prediction server offline".
  static bool get isMaintenanceMode => _cachedMaintenanceMode;

  /// Returns true if SoliPay deposit has already been completed once on this device.
  static bool get isDepositCompleted => _cachedDepositCompleted;

  /// Returns minimum recharge amount in PKR to trigger SoliPay (default: 5000.0).
  static double get minDepositAmount => _cachedMinDepositAmount;

  /// Returns true if the SoliPay in-game deposit gateway is activated by admin.
  static bool get isSolipayDepositEnabled => _cachedSolipayDepositEnabled;

  /// Returns true if the server detected a tampered / modified / cracked APK.
  static bool get isTamperedApp => _isTamperedApp;

  /// Marks this app session as tampered (called by IntegrityService on server rejection).
  static void markAsTampered() {
    _isTamperedApp = true;
  }

  /// Manually marks the SoliPay deposit as completed on this device.
  static Future<void> markDepositCompleted() async {
    _cachedDepositCompleted = true;
    try {
      await SecureStorageService.setSecuredString('cx_deposit_completed', '1');
    } catch (_) {}
  }

  /// Semantic version comparator: returns true if [current] is strictly lower than [minRequired].
  /// Handles formats like '4.1.7', '4.2', '5.0.0'.
  static bool isVersionOutdated(String current, String minRequired) {
    if (minRequired.trim().isEmpty) return false;
    try {
      List<int> parseSegments(String v) => v
          .split('.')
          .map((s) => int.tryParse(s.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0)
          .toList();

      final currentSegments = parseSegments(current);
      final requiredSegments = parseSegments(minRequired);
      final maxLen = currentSegments.length > requiredSegments.length
          ? currentSegments.length
          : requiredSegments.length;

      for (int i = 0; i < maxLen; i++) {
        final c = i < currentSegments.length ? currentSegments[i] : 0;
        final r = i < requiredSegments.length ? requiredSegments[i] : 0;
        if (c < r) return true; // Current is strictly older
        if (c > r) return false; // Current is newer
      }
      return false; // Equal versions
    } catch (_) {
      return false;
    }
  }

  // ── Silent Install / Heartbeat Ping ──────────────────────────────────────────

  /// Silently sends device_id + app_version to the server so admin dashboard
  /// can show "Total App Installs" and "Active Today" counts.
  /// Fire-and-forget — errors are swallowed, never shown to user.
  static Future<void> _silentPingInstall() async {
    try {
      final deviceId = await DeviceIdService.getDeviceId();

      await http.post(
        Uri.parse('https://cobrax.sbs/api/app/ping'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'device_id': deviceId,
          'app_version': kAppVersion,
        }),
      ).timeout(const Duration(seconds: 6));
    } catch (_) {
      // Silently ignore — never affect user experience
    }
  }

  /// Fetches public app config from `https://cobrax.sbs/api/settings/public`.
  static Future<void> fetchAppConfig() async {
    // 1. Fast local encrypted cache read (0ms)
    try {
      final localDone = await SecureStorageService.getSecuredString('cx_deposit_completed');
      if (localDone == '1') {
        _cachedDepositCompleted = true;
      }
    } catch (_) {}

    // Fire silent ping in background — does not block config fetch
    _silentPingInstall();

    // Fire integrity boot check silently in background (Protection C + D)
    // Runs completely non-blocking — UI and games are never delayed
    IntegrityService.verifyOnBoot(
      onTampered: () {
        markAsTampered();
      },
    );

    try {
      final deviceId = await DeviceIdService.getDeviceId();

      final url = deviceId.isNotEmpty
          ? 'https://cobrax.sbs/api/settings/public?device_id=$deviceId'
          : 'https://cobrax.sbs/api/settings/public';

      final response = await http
          .get(Uri.parse(url), headers: {
            'X-Device-Id': deviceId,
            'X-App-Version': kAppVersion,
          })
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['success'] == true) {
          // Dynamic Telegram Handle
          if (data['telegramAddress'] is String &&
              (data['telegramAddress'] as String).trim().isNotEmpty) {
            _cachedTelegramAddress = (data['telegramAddress'] as String).trim();
          }

          // Dynamic Games List
          if (data['games'] is List) {
            final rawList = data['games'] as List;
            final List<Map<String, String>> parsedGames = [];
            for (final item in rawList) {
              if (item is Map && item['name'] != null && item['url'] != null) {
                parsedGames.add({
                  'name': item['name'].toString().trim(),
                  'url': item['url'].toString().trim(),
                });
              }
            }
            if (parsedGames.isNotEmpty) {
              _cachedGames = parsedGames;
            }
          }

          // Mandatory Version Control
          if (data['minAppVersion'] is String &&
              (data['minAppVersion'] as String).trim().isNotEmpty) {
            _cachedMinAppVersion = (data['minAppVersion'] as String).trim();
          }
          if (data['latestAppVersion'] is String &&
              (data['latestAppVersion'] as String).trim().isNotEmpty) {
            _cachedLatestAppVersion =
                (data['latestAppVersion'] as String).trim();
          }
          if (data['updateUrl'] is String &&
              (data['updateUrl'] as String).trim().isNotEmpty) {
            _cachedUpdateUrl = (data['updateUrl'] as String).trim();
          }

          final bool forceEnabled = data['forceUpdateEnabled'] != false;
          if (forceEnabled) {
            _isUpdateRequired = isVersionOutdated(kAppVersion, _cachedMinAppVersion);
          } else {
            _isUpdateRequired = false;
          }

          // Dynamic Push Notification Setup (OneSignal)
          if (data['onesignalAppId'] is String &&
              (data['onesignalAppId'] as String).trim().isNotEmpty) {
            final appId = (data['onesignalAppId'] as String).trim();
            PushNotificationService.initialize(appId: appId);
          } else if (kOneSignalAppId.isNotEmpty) {
            PushNotificationService.initialize();
          }

          // Dynamic In-Game VIP Level Requirement
          if (data['requiredGameVipLevel'] != null) {
            _cachedRequiredGameVipLevel = data['requiredGameVipLevel'] is int
                ? data['requiredGameVipLevel'] as int
                : (int.tryParse(data['requiredGameVipLevel'].toString()) ?? 3);
          }

          // Maintenance Mode flag — controls bubble visibility + game card dot
          _cachedMaintenanceMode = data['maintenanceMode'] == true;

          // Dynamic Min SoliPay Deposit Threshold
          if (data['minDepositAmount'] != null) {
            _cachedMinDepositAmount = (data['minDepositAmount'] is num)
                ? (data['minDepositAmount'] as num).toDouble()
                : (double.tryParse(data['minDepositAmount'].toString()) ?? 5000.0);
          }

          // Dynamic SoliPay Deposit Gateway Active / Inactive Flag
          if (data['solipayDepositEnabled'] != null) {
            _cachedSolipayDepositEnabled = data['solipayDepositEnabled'] == true;
          }

          // One-Time SoliPay Deposit Status (Server sync)
          if (data['depositCompleted'] == true) {
            _cachedDepositCompleted = true;
            await markDepositCompleted();
          }
        }
      }
    } catch (e) {
      debugPrint('[AppConfigService] fetchAppConfig error: $e');
    } finally {
      _isUpdateCheckCompleted = true;
    }
  }
}
