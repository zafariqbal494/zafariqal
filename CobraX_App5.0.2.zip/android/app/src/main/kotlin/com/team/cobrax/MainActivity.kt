package com.team.cobrax

import android.media.MediaDrm
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.security.MessageDigest
import java.util.UUID

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.team.cobrax/device_identity"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getPermanentHardwareId") {
                try {
                    val hardwareId = getPermanentHardwareId()
                    result.success(hardwareId)
                } catch (e: Exception) {
                    result.error("HARDWARE_ID_ERROR", e.localizedMessage, null)
                }
            } else {
                result.notImplemented()
            }
        }
    }

    private fun getPermanentHardwareId(): String {
        var drmIdBytes: ByteArray? = null
        var mediaDrm: MediaDrm? = null

        // 1. Tier 1: Widevine Hardware DRM Device Unique ID (Silicon / TEE TrustZone chip identifier)
        try {
            val widevineUuid = UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")
            mediaDrm = MediaDrm(widevineUuid)
            val id = mediaDrm.getPropertyByteArray(MediaDrm.PROPERTY_DEVICE_UNIQUE_ID)
            if (id != null && id.isNotEmpty()) {
                drmIdBytes = id
            }
        } catch (_: Throwable) {
            // Graceful fallback if MediaDrm is not supported on rare emulators
        } finally {
            try {
                if (mediaDrm != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        mediaDrm.close()
                    } else {
                        @Suppress("DEPRECATION")
                        mediaDrm.release()
                    }
                }
            } catch (_: Throwable) {}
        }

        // 2. Tier 2: Settings.Secure.ANDROID_ID (OS SSAID, persistent across clear storage and reinstallations)
        var androidId: String? = null
        try {
            val rawAndroidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            if (!rawAndroidId.isNullOrEmpty() && rawAndroidId != "9774d56d682e549c") {
                androidId = rawAndroidId.trim()
            }
        } catch (_: Throwable) {}

        // 3. Tier 3: Immutable Hardware Specs Matrix
        val rawModel = (Build.MODEL ?: "").replace(Regex("[^a-zA-Z0-9]"), "").uppercase()
        val modelPrefix = if (rawModel.isNotEmpty()) {
            if (rawModel.length > 8) rawModel.substring(0, 8) else rawModel
        } else {
            "AND"
        }

        val hwSpecs = "${Build.BOARD}|${Build.BRAND}|${Build.DEVICE}|${Build.HARDWARE}|${Build.MANUFACTURER}|${Build.MODEL}|${Build.PRODUCT}"

        // 4. Compute deterministic SHA-256 hash combining all hardware entropy sources
        val md = MessageDigest.getInstance("SHA-256")
        if (drmIdBytes != null && drmIdBytes.isNotEmpty()) {
            md.update(drmIdBytes)
        }
        if (!androidId.isNullOrEmpty()) {
            md.update(androidId.toByteArray(Charsets.UTF_8))
        }
        md.update(hwSpecs.toByteArray(Charsets.UTF_8))

        val digest = md.digest()
        val hex = digest.joinToString("") { "%02X".format(it) }

        return "CX-$modelPrefix-${hex.take(16)}"
    }
}
