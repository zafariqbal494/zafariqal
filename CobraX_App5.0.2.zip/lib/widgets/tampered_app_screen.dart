import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../config/app_config.dart';

/// Full-screen, un-dismissible blocking screen shown when server detects
/// an unauthorized or tampered (modified/cracked) APK.
///
/// The user cannot dismiss this screen or access any game features.
/// They are directed to download the official app from cobrax.sbs.
class TamperedAppScreen extends StatelessWidget {
  const TamperedAppScreen({super.key});

  Future<void> _launchOfficialSite(BuildContext context) async {
    try {
      await InAppBrowser.openWithSystemBrowser(url: WebUri(kOfficialDownloadUrl));
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open browser: $kOfficialDownloadUrl'),
            backgroundColor: Color(0xFF1E0A0A),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF07080C),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0, -0.3),
              radius: 1.3,
              colors: [
                Color(0xFF1A0808),
                Color(0xFF0A0A0E),
                Color(0xFF050507),
              ],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(flex: 2),

                  // ── Warning Icon ───────────────────────────────────────────
                  Container(
                    width: 90,
                    height: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF2A0808),
                      border: Border.all(
                        color: const Color(0xFFFF3A1A).withValues(alpha: 0.7),
                        width: 2.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF3A1A).withValues(alpha: 0.4),
                          blurRadius: 35,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.gpp_bad_rounded,
                      color: Color(0xFFFF3A1A),
                      size: 46,
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── Warning Badge ──────────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF3B0A0A),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFFF3A1A).withValues(alpha: 0.5),
                        width: 1,
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.shield_outlined, color: Color(0xFFFF5533), size: 16),
                        SizedBox(width: 6),
                        Text(
                          'UNAUTHORIZED APP DETECTED',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            color: Color(0xFFFF5533),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── Title ──────────────────────────────────────────────────
                  const Text(
                    'INVALID APP BUILD',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),

                  const SizedBox(height: 14),

                  // ── Message ────────────────────────────────────────────────
                  const Text(
                    'You are using an unofficial or modified version of CobraX that has been flagged by our security system. Please download the official app to continue.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFB0B7C3),
                      fontSize: 14.5,
                      height: 1.55,
                      fontWeight: FontWeight.w400,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ── Warning Info Card ──────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F0D14),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFF2A1F1F),
                        width: 1,
                      ),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline_rounded, color: Color(0xFF8892B0), size: 20),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Anti-Scam: Only purchase CobraX keys from cobrax.sbs. Modified apps may steal your data.',
                            style: TextStyle(
                              color: Color(0xFF8892B0),
                              fontSize: 12,
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(flex: 3),

                  // ── Download Button ────────────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () => _launchOfficialSite(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF3A1A),
                        foregroundColor: Colors.white,
                        elevation: 8,
                        shadowColor: const Color(0xFFFF3A1A).withValues(alpha: 0.6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.download_rounded, size: 22),
                          SizedBox(width: 10),
                          Text(
                            'DOWNLOAD OFFICIAL APP',
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 14.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── Footer ─────────────────────────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.verified_user_outlined,
                          size: 14, color: Color(0xFF6B7280)),
                      const SizedBox(width: 6),
                      Text(
                        'Official Website: ${kOfficialDownloadUrl.replaceAll('https://', '')}',
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          color: Color(0xFF6B7280),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
