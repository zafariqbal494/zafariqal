import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../config/app_config.dart';

/// Displays either the compact Cyber VIP-active status card (without revealing raw key)
/// or the unauthenticated 'key required' card.
class AuthStatusCard extends StatelessWidget {
  final bool isVipMode;
  final DateTime? vipExpiry;
  final String? vipKey;
  final String? vipPackage;
  final int? vipDays;
  final VoidCallback onEnterKey;

  const AuthStatusCard({
    super.key,
    required this.isVipMode,
    required this.vipExpiry,
    required this.vipKey,
    required this.vipPackage,
    required this.vipDays,
    required this.onEnterKey,
  });

  @override
  Widget build(BuildContext context) {
    if (isVipMode && vipExpiry != null) {
      return _buildActiveCard(context);
    }
    return _buildInactiveCard(context);
  }

  // ── Compact Cyber VIP Active Card (Key Hidden) ──────────────────────────────
  Widget _buildActiveCard(BuildContext context) {
    final diff = vipExpiry!.difference(DateTime.now());
    final daysLeft = diff.inDays;
    final hoursLeft = diff.inHours;

    final isExpiringSoon = diff.inMilliseconds > 0 && hoursLeft <= 24;

    final timeStr = daysLeft > 0
        ? '$daysLeft Days Left'
        : (hoursLeft > 0 ? '$hoursLeft Hours Left' : 'Expiring Soon');

    final dateStr =
        '${vipExpiry!.day}/${vipExpiry!.month}/${vipExpiry!.year}';

    final primaryColor = isExpiringSoon ? const Color(0xFFFF3355) : const Color(0xFF00FF88);
    final accentGlow   = isExpiringSoon ? const Color(0xFFFF0044) : const Color(0xFF00FF88);

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isExpiringSoon
              ? const [Color(0xFF280B0F), Color(0xFF1E080B), Color(0xFF140507)]
              : const [Color(0xFF061E12), Color(0xFF0A291A), Color(0xFF04140C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: primaryColor.withValues(alpha: isExpiringSoon ? 0.8 : 0.45),
          width: 1.1,
        ),
        boxShadow: [
          BoxShadow(
            color: accentGlow.withValues(alpha: isExpiringSoon ? 0.2 : 0.1),
            blurRadius: 10,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Top Header Row ───────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              color: isExpiringSoon
                  ? const Color(0xFF3B0F15).withValues(alpha: 0.5)
                  : const Color(0xFF0D3320).withValues(alpha: 0.5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: primaryColor,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: primaryColor.withValues(alpha: 0.6),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(
                        isExpiringSoon ? 'VIP EXPIRING SOON' : 'AUTHENTICATION ACTIVE',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: primaryColor,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),

                  // Compact Gold Badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2.5),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isExpiringSoon
                            ? const [Color(0xFFFF3355), Color(0xFF990022)]
                            : const [Color(0xFFFFD700), Color(0xFFFFA500)],
                      ),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isExpiringSoon ? Icons.timer_outlined : Icons.verified_rounded,
                          color: isExpiringSoon ? Colors.white : const Color(0xFF1A1A2E),
                          size: 11,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          isExpiringSoon ? 'RENEW' : 'VIP',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            color: isExpiringSoon ? Colors.white : const Color(0xFF1A1A2E),
                            fontWeight: FontWeight.w900,
                            fontSize: 9.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ── Main Compact Info Grid (Key Hidden) ─────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              child: Column(
                children: [
                  // Row 1: Plan + Time Remaining
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            const Text('PLAN: ',
                                style: TextStyle(
                                    color: Color(0xFF668877),
                                    fontSize: 9.5,
                                    fontFamily: 'monospace',
                                    fontWeight: FontWeight.bold)),
                            Text(
                              '${vipPackage?.toUpperCase() ?? "BASIC"} (${vipDays ?? 30}D)',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'monospace'),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          const Text('REMAINING: ',
                              style: TextStyle(
                                  color: Color(0xFF668877),
                                  fontSize: 9.5,
                                  fontFamily: 'monospace',
                                  fontWeight: FontWeight.bold)),
                          Text(
                            timeStr,
                            style: TextStyle(
                                color: primaryColor,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'monospace'),
                          ),
                        ],
                      ),
                    ],
                  ),

                  const SizedBox(height: 6),
                  Container(height: 1, color: const Color(0xFF163322)),
                  const SizedBox(height: 6),

                  // Row 2: Status + Expiry Date
                  Row(
                    children: [
                      const Expanded(
                        child: Row(
                          children: [
                            Text('STATUS: ',
                                style: TextStyle(
                                    color: Color(0xFF668877),
                                    fontSize: 9.5,
                                    fontFamily: 'monospace',
                                    fontWeight: FontWeight.bold)),
                            Text(
                              'UNLOCKED 🔒',
                              style: TextStyle(
                                  color: Color(0xFF00FF88),
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'monospace'),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          const Text('EXPIRY: ',
                              style: TextStyle(
                                  color: Color(0xFF668877),
                                  fontSize: 9.5,
                                  fontFamily: 'monospace',
                                  fontWeight: FontWeight.bold)),
                          Text(
                            dateStr,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace'),
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Urgent <24h Renew Bar (if expiring soon)
                  if (isExpiringSoon) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '⚠️ Expiring in $hoursLeft hour(s)!',
                            style: const TextStyle(
                                color: Color(0xFFFF6677),
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace'),
                          ),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFF0044),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          onPressed: () => InAppBrowser.openWithSystemBrowser(
                              url: WebUri(kBuyKeyUrl)),
                          child: const Text(
                            'RENEW NOW',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 9.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Key Inactive Card ───────────────────────────────────────────────────────
  Widget _buildInactiveCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E0A0A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF3333).withValues(alpha: 0.4),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF3333).withValues(alpha: 0.08),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: Color(0xFFFF3333),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'KEY AUTHENTICATION REQUIRED',
                style: TextStyle(
                  fontFamily: 'monospace',
                  color: Color(0xFFFF5555),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'No active key found. Please enter your authentication key to unlock WinGo 30Sec full access.',
            style: TextStyle(
                color: Color(0xFFCCCCCC), fontSize: 11.5, height: 1.3),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCC0000),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: onEnterKey,
                  icon: const Icon(Icons.key, size: 16),
                  label: const Text('ENTER KEY',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFFF6666),
                    side: const BorderSide(color: Color(0xFFFF4444)),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () => InAppBrowser.openWithSystemBrowser(
                      url: WebUri(kBuyKeyUrl)),
                  icon: const Icon(Icons.shopping_cart_outlined, size: 16),
                  label: const Text('BUY KEY',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
