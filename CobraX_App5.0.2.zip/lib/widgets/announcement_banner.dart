import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../models/announcement.dart';

/// Floating cyber broadcast announcement banner widget.
/// Renders server maintenance notices, system alerts, or feature updates with emoji support.
class AnnouncementBanner extends StatefulWidget {
  final Announcement announcement;
  final VoidCallback? onDismissed;

  const AnnouncementBanner({
    super.key,
    required this.announcement,
    this.onDismissed,
  });

  @override
  State<AnnouncementBanner> createState() => _AnnouncementBannerState();
}

class _AnnouncementBannerState extends State<AnnouncementBanner> {
  bool _dismissed = false;

  static const List<String> _emojiFontFallback = [
    'Roboto',
    'Apple Color Emoji',
    'Segoe UI Emoji',
    'Noto Color Emoji',
  ];

  Color get _primaryColor {
    switch (widget.announcement.type) {
      case 'warning':
        return const Color(0xFFFF9900);
      case 'maintenance':
        return const Color(0xFFFF3366);
      case 'info':
      default:
        return const Color(0xFF00F0FF); // Cyber Cyan / Electric Blue
    }
  }

  Color get _bgColor {
    switch (widget.announcement.type) {
      case 'warning':
        return const Color(0xFF1E1405);
      case 'maintenance':
        return const Color(0xFF1E050A);
      case 'info':
      default:
        return const Color(0xFF031720); // Deep Cyber Blue Glass
    }
  }

  IconData get _icon {
    switch (widget.announcement.type) {
      case 'warning':
        return Icons.warning_amber_rounded;
      case 'maintenance':
        return Icons.build_circle_outlined;
      case 'info':
      default:
        return Icons.notifications_active_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.announcement.active || _dismissed) {
      return const SizedBox.shrink();
    }

    final accentColor = _primaryColor;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _bgColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: accentColor.withValues(alpha: 0.6),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: accentColor.withValues(alpha: 0.18),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentColor.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(_icon, color: accentColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.announcement.title,
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontFamilyFallback: _emojiFontFallback,
                      color: accentColor,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.announcement.message,
                    style: const TextStyle(
                      fontFamilyFallback: _emojiFontFallback,
                      color: Colors.white,
                      fontSize: 11.5,
                      height: 1.3,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (widget.announcement.url != null && widget.announcement.url!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: GestureDetector(
                        onTap: () {
                          InAppBrowser.openWithSystemBrowser(
                            url: WebUri(widget.announcement.url!),
                          );
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'LEARN MORE',
                              style: TextStyle(
                                fontFamily: 'monospace',
                                color: accentColor,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Icon(Icons.open_in_new_rounded, color: accentColor, size: 11),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
            if (widget.announcement.dismissible)
              IconButton(
                onPressed: () {
                  setState(() => _dismissed = true);
                  widget.onDismissed?.call();
                },
                icon: const Icon(Icons.close_rounded, color: Color(0xFF888899), size: 18),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
          ],
        ),
      ),
    );
  }
}
