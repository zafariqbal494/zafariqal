import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/app_config_service.dart';
import '../services/auth_service.dart';

/// App-launch cyber terminal boot screen shown once when the app starts.
/// Performs real dynamic background checks (network latency, version validation, VIP state)
/// and streams realistic terminal telemetry logs (~4.2 seconds).
class AppLaunchSplash extends StatefulWidget {
  final VoidCallback onComplete;
  const AppLaunchSplash({super.key, required this.onComplete});

  @override
  State<AppLaunchSplash> createState() => _AppLaunchSplashState();
}

class _LogEntry {
  final String timestamp;
  final String prefix;
  final String text;
  final String? statusTag;
  final Color? statusColor;

  const _LogEntry({
    required this.timestamp,
    required this.prefix,
    required this.text,
    this.statusTag,
    this.statusColor,
  });
}

class _AppLaunchSplashState extends State<AppLaunchSplash>
    with TickerProviderStateMixin {
  final List<_LogEntry> _completedEntries = [];
  String _currentTyping = '';
  int _currentLineIdx = 0;
  int _currentCharIdx = 0;

  Timer? _typeTimer;
  Timer? _glitchTimer;
  Timer? _glitchResetTimer;
  Timer? _cursorTimer;
  Timer? _progressTimer;

  bool _cursorVisible = true;
  double _progress = 0.0;

  // Glitch animation state
  bool _glitchActive = false;
  double _glitchX = 0;
  double _glitchY = 0;
  final Random _rand = Random();

  // Fade out controller
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // Dynamic system telemetry
  int _measuredLatencyMs = 38;
  bool _isNetworkOnline = true;
  bool _isVipActive = false;
  bool _showOfflineError = false;
  bool _isRetrying = false;

  late List<_LogEntry> _bootEntries;

  Future<void>? _dynamicChecksFuture;

  @override
  void initState() {
    super.initState();

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut),
    );

    // Initial placeholder boot entries (will be enriched dynamically)
    _bootEntries = [
      const _LogEntry(
        timestamp: '0.08s',
        prefix: 'SYS',
        text: 'Bootstrapping CobraX Neural Engine v$kAppVersion...',
        statusTag: '[OK]',
        statusColor: Color(0xFF00FF88),
      ),
      const _LogEntry(
        timestamp: '0.42s',
        prefix: 'NET',
        text: 'Probing network connectivity...',
        statusTag: '[CHECKING]',
        statusColor: Color(0xFF00E5FF),
      ),
      const _LogEntry(
        timestamp: '0.98s',
        prefix: 'AUTH',
        text: 'Verifying client version manifest...',
        statusTag: '[v$kAppVersion • LATEST]',
        statusColor: Color(0xFFFFD700),
      ),
      const _LogEntry(
        timestamp: '1.65s',
        prefix: 'VIP',
        text: 'Querying local VIP authentication token...',
        statusTag: '[SCANNING]',
        statusColor: Color(0xFF00E5FF),
      ),
      const _LogEntry(
        timestamp: '2.30s',
        prefix: 'SYNC',
        text: 'Mounting WinGo 30Sec prediction matrices...',
        statusTag: '[ACTIVE]',
        statusColor: Color(0xFF00FF88),
      ),
      const _LogEntry(
        timestamp: '3.10s',
        prefix: 'GATE',
        text: 'Synchronizing real-time telemetry gateway...',
        statusTag: '[STABLE]',
        statusColor: Color(0xFF00FF88),
      ),
      const _LogEntry(
        timestamp: '3.80s',
        prefix: 'CORE',
        text: 'Environment integrity verified. System ready.',
        statusTag: '[UNLOCKED]',
        statusColor: Color(0xFFFF0044),
      ),
    ];

    // Cursor blinking timer
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 450), (_) {
      if (mounted) setState(() => _cursorVisible = !_cursorVisible);
    });

    // Start progress bar timer
    _startProgressTimer();

    // Execute real dynamic background tasks
    _dynamicChecksFuture = _runDynamicChecks();

    // Start typing boot sequence
    Future.delayed(const Duration(milliseconds: 250), _startNextEntry);
    _scheduleGlitch();
  }

  void _startProgressTimer() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(milliseconds: 42), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        _progress += 0.01;
        if (_progress >= 1.0) {
          _progress = 1.0;
          t.cancel();
        }
      });
    });
  }

  void _pauseProgressTimer() {
    _progressTimer?.cancel();
  }

  /// Performs real background checks (network probe, latency, VIP status)
  Future<void> _runDynamicChecks() async {
    final sw = Stopwatch()..start();
    try {
      final isConnected = await AppConfigService.checkInternetConnection();
      sw.stop();
      _measuredLatencyMs = sw.elapsedMilliseconds.clamp(12, 500);
      _isNetworkOnline = isConnected;
    } catch (_) {
      sw.stop();
      _measuredLatencyMs = 0;
      _isNetworkOnline = false;
    }

    try {
      final vipStatus = await AuthService.loadVipStatus();
      _isVipActive = vipStatus.isVip;
    } catch (_) {
      _isVipActive = false;
    }

    if (!mounted) return;

    // Dynamically update log entries with real live metrics
    setState(() {
      _bootEntries[1] = _LogEntry(
        timestamp: '0.45s',
        prefix: 'NET',
        text: 'Probing network gateway & link latency...',
        statusTag: _isNetworkOnline
            ? '[ONLINE • ${_measuredLatencyMs}ms]'
            : '[FAILED • OFFLINE]',
        statusColor: _isNetworkOnline ? const Color(0xFF00FF88) : const Color(0xFFFF0044),
      );

      _bootEntries[3] = _LogEntry(
        timestamp: '1.70s',
        prefix: 'VIP',
        text: 'Validating security handshake & VIP engine...',
        statusTag: _isVipActive ? '[VIP ACTIVE • UNLOCKED]' : '[DEMO MODE • READY]',
        statusColor: _isVipActive ? const Color(0xFF00FF88) : const Color(0xFFFFD700),
      );
    });
  }

  Future<void> _retryConnection() async {
    if (_isRetrying) return;
    setState(() => _isRetrying = true);

    _dynamicChecksFuture = _runDynamicChecks();
    await _dynamicChecksFuture;

    if (!mounted) return;
    setState(() => _isRetrying = false);

    if (_isNetworkOnline) {
      setState(() {
        if (_completedEntries.length > 1) {
          _completedEntries[1] = _bootEntries[1];
        }
        _showOfflineError = false;
      });
      _startProgressTimer();
      // Resume typing remaining entries from where it stopped!
      Future.delayed(const Duration(milliseconds: 120), _startNextEntry);
    }
  }

  void _scheduleGlitch() {
    _glitchTimer = Timer(
      Duration(milliseconds: 350 + _rand.nextInt(700)),
      () {
        if (!mounted) return;
        setState(() {
          _glitchActive = true;
          _glitchX = (_rand.nextDouble() - 0.5) * 12;
          _glitchY = (_rand.nextDouble() - 0.5) * 4;
        });
        _glitchResetTimer = Timer(
          Duration(milliseconds: 50 + _rand.nextInt(100)),
          () {
            if (!mounted) return;
            setState(() => _glitchActive = false);
            _scheduleGlitch();
          },
        );
      },
    );
  }

  void _startNextEntry() {
    if (!mounted) return;
    if (_currentLineIdx >= _bootEntries.length) {
      // Completed all lines -> wait until progress finishes then fade out
      Future.delayed(const Duration(milliseconds: 600), () {
        if (!mounted) return;
        _fadeCtrl.forward().then((_) => widget.onComplete());
      });
      return;
    }

    _currentCharIdx = 0;
    _currentTyping = '';
    final entry = _bootEntries[_currentLineIdx];
    final fullRawText = '> [${entry.timestamp}] ${entry.text}';

    _typeTimer = Timer.periodic(const Duration(milliseconds: 14), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (_currentCharIdx < fullRawText.length) {
        setState(() {
          _currentTyping = fullRawText.substring(0, _currentCharIdx + 1);
          _currentCharIdx++;
        });
      } else {
        t.cancel();
        setState(() {
          _completedEntries.add(entry);
          _currentTyping = '';
          _currentLineIdx++;
        });

        // ── IMMEDIATE INTERNET CHECK GATE (After Line 1: NET probe) ──
        // If device has no internet, HALT immediately. Do NOT type subsequent logs!
        if (_currentLineIdx == 2) {
          _handlePostNetProbeGate();
          return;
        }

        Future.delayed(const Duration(milliseconds: 120), _startNextEntry);
      }
    });
  }

  Future<void> _handlePostNetProbeGate() async {
    if (_dynamicChecksFuture != null) {
      await _dynamicChecksFuture;
    }
    if (!mounted) return;

    if (!_isNetworkOnline) {
      // HALT IMMEDIATELY! Stop progress bar and do NOT type lines 2, 3, 4, 5, 6!
      _pauseProgressTimer();
      setState(() {
        if (_completedEntries.length > 1) {
          _completedEntries[1] = _bootEntries[1];
        }
        _showOfflineError = true;
      });
      return;
    }

    // Network is confirmed online: update badge if needed and proceed to next entry!
    if (_completedEntries.length > 1) {
      setState(() {
        _completedEntries[1] = _bootEntries[1];
      });
    }
    Future.delayed(const Duration(milliseconds: 120), _startNextEntry);
  }

  @override
  void dispose() {
    _typeTimer?.cancel();
    _glitchTimer?.cancel();
    _glitchResetTimer?.cancel();
    _cursorTimer?.cancel();
    _progressTimer?.cancel();
    _fadeCtrl.dispose();
    super.dispose();
  }

  Widget _buildGlitchHeader() {
    const style = TextStyle(
      fontFamily: 'Orbitron',
      fontSize: 36,
      fontWeight: FontWeight.w900,
      letterSpacing: 8,
    );

    return SizedBox(
      height: 52,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Red Glitch Layer
          Transform.translate(
            offset: Offset(_glitchActive ? -_glitchX : 0, _glitchActive ? _glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFFFF0044)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),

          // Cyan Glitch Layer
          Transform.translate(
            offset: Offset(_glitchActive ? _glitchX : 0, _glitchActive ? -_glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFF00F0FF)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),

          // Main Text Layer
          Text.rich(
            TextSpan(
              children: [
                TextSpan(text: 'Cobra', style: style.copyWith(color: Colors.white)),
                TextSpan(text: 'X', style: style.copyWith(color: const Color(0xFFFF0044))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Container(
        color: const Color(0xFF050505),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Spacer(),

                // ── Cyber Glitch Title ───────────────────────────
                _buildGlitchHeader(),

                const SizedBox(height: 4),

                const Text(
                  'ELITE PREDICTION PLATFORM',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'monospace',
                    color: Color(0xFFCC0000),
                    fontSize: 7.5,
                    letterSpacing: 2.2,
                    fontWeight: FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 28),

                // ── Realistic Terminal Window ────────────────────
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A0E),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: const Color(0xFFCC0000).withValues(alpha: 0.35),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.8),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Terminal Titlebar
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: const Color(0xFF14141A),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(9)),
                          border: Border(
                            bottom: BorderSide(
                              color: Colors.white.withValues(alpha: 0.08),
                              width: 1,
                            ),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFFFF5F56), shape: BoxShape.circle)),
                            const SizedBox(width: 6),
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFFFFBD2E), shape: BoxShape.circle)),
                            const SizedBox(width: 6),
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF27C93F), shape: BoxShape.circle)),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Text(
                                'COBRAX-SECURE-TERMINAL // BOOT-V4.1.7',
                                style: TextStyle(
                                  fontFamily: 'monospace',
                                  fontSize: 9.5,
                                  color: Color(0xFF888888),
                                  letterSpacing: 1,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Terminal Output Logs
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final entry in _completedEntries)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 6.5),
                                child: Text.rich(
                                  TextSpan(
                                    style: const TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 11.2,
                                      height: 1.35,
                                    ),
                                    children: [
                                      const TextSpan(
                                        text: '> ',
                                        style: TextStyle(color: Color(0xFFFF0044), fontWeight: FontWeight.bold),
                                      ),
                                      TextSpan(
                                        text: '[${entry.timestamp}] ',
                                        style: const TextStyle(color: Color(0xFF666666)),
                                      ),
                                      TextSpan(
                                        text: '${entry.text} ',
                                        style: const TextStyle(color: Color(0xFFE0E0E0)),
                                      ),
                                      if (entry.statusTag != null)
                                        TextSpan(
                                          text: entry.statusTag!,
                                          style: TextStyle(
                                            color: entry.statusColor ?? const Color(0xFF00FF88),
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),

                            // Active Typing Line
                            if (_currentTyping.isNotEmpty ||
                                (_currentLineIdx < _bootEntries.length &&
                                    _completedEntries.length == _currentLineIdx))
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      _currentTyping,
                                      style: const TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 11.2,
                                        color: Color(0xFFFFFFFF),
                                        height: 1.35,
                                      ),
                                    ),
                                  ),
                                  AnimatedOpacity(
                                    opacity: _cursorVisible ? 1.0 : 0.0,
                                    duration: const Duration(milliseconds: 100),
                                    child: const Text(
                                      '_',
                                      style: TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 12,
                                        color: Color(0xFFFF0044),
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // ── Progress Bar & Telemetry Status ───────────────
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: _isNetworkOnline ? const Color(0xFF00FF88) : const Color(0xFFFF9900),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: (_isNetworkOnline ? const Color(0xFF00FF88) : const Color(0xFFFF9900)).withValues(alpha: 0.6),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _progress < 1.0 ? 'INITIALIZING PROTOCOLS...' : 'BOOT SEQUENCE COMPLETE',
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 9.5,
                                color: Color(0xFF888888),
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          '${(_progress * 100).toInt()}%',
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 10.5,
                            color: Color(0xFF00FF88),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _progress,
                        minHeight: 4,
                        backgroundColor: const Color(0xFF1A1A1A),
                        valueColor: const AlwaysStoppedAnimation<Color>(
                          Color(0xFFCC0000),
                        ),
                      ),
                    ),
                  ],
                ),

                if (_showOfflineError) ...[
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E080C),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFFF0044), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF0044).withValues(alpha: 0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.wifi_off_rounded, color: Color(0xFFFF0044), size: 18),
                            SizedBox(width: 8),
                            Text(
                              'INTERNET CONNECTION REQUIRED',
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 11.5,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFFFF0044),
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'No active internet connection. Connect to Mobile Data or Wi-Fi to start CobraX.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 10.5,
                            color: Color(0xFFCCCCCC),
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 12),
                        InkWell(
                          onTap: _retryConnection,
                          borderRadius: BorderRadius.circular(6),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFFF0044), Color(0xFFCC0033)],
                              ),
                              borderRadius: BorderRadius.circular(6),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFFF0044).withValues(alpha: 0.4),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            child: _isRetrying
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  )
                                : const Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.refresh_rounded, color: Colors.white, size: 15),
                                      SizedBox(width: 6),
                                      Text(
                                        'RETRY CONNECTION',
                                        style: TextStyle(
                                          fontFamily: 'monospace',
                                          fontSize: 11,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
