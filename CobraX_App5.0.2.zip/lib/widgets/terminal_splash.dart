import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../services/app_config_service.dart';

/// Per-game terminal splash screen displayed when entering a WebView game.
/// Shows realistic dynamic telemetry logs with live connection handshake, then fades out.
/// If device is offline, halts and prompts for reconnection before opening game.
class TerminalSplash extends StatefulWidget {
  final String gameName;
  final VoidCallback onComplete;
  const TerminalSplash({super.key, required this.gameName, required this.onComplete});

  @override
  State<TerminalSplash> createState() => _TerminalSplashState();
}

class _GameLogEntry {
  final String timestamp;
  final String text;
  final String? statusTag;
  final Color? statusColor;

  const _GameLogEntry({
    required this.timestamp,
    required this.text,
    this.statusTag,
    this.statusColor,
  });
}

class _TerminalSplashState extends State<TerminalSplash>
    with TickerProviderStateMixin {
  late List<_GameLogEntry> _lines;
  final List<_GameLogEntry> _completedLines = [];
  int _currentLine = 0;
  String _currentTyping = '';
  int _currentChar = 0;

  Timer? _typeTimer;
  Timer? _glitchTimer;
  Timer? _glitchResetTimer;
  Timer? _cursorTimer;
  bool _cursorVisible = true;

  // Glitch state
  bool _glitchActive = false;
  double _glitchX = 0;
  double _glitchY = 0;
  final _rand = Random();

  // Fade out
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // Dynamic connectivity state
  bool _isNetworkOnline = true;
  int _measuredLatencyMs = 35;
  bool _showOfflineError = false;
  bool _isRetrying = false;
  Future<void>? _dynamicChecksFuture;

  @override
  void initState() {
    super.initState();

    _lines = [
      _GameLogEntry(
        timestamp: '0.08s',
        text: 'Routing target gateway: [${widget.gameName}]...',
        statusTag: '[CONNECTING]',
        statusColor: const Color(0xFF00E5FF),
      ),
      const _GameLogEntry(
        timestamp: '0.42s',
        text: 'Establishing encrypted SSL/TLS session...',
        statusTag: '[PROBING]',
        statusColor: Color(0xFF00E5FF),
      ),
      const _GameLogEntry(
        timestamp: '0.85s',
        text: 'Injecting WinGo 30Sec analysis telemetry...',
        statusTag: '[INJECTED]',
        statusColor: Color(0xFF00FF88),
      ),
      const _GameLogEntry(
        timestamp: '1.25s',
        text: 'Synchronizing real-time prediction bubble...',
        statusTag: '[CALIBRATED]',
        statusColor: Color(0xFFFFD700),
      ),
      const _GameLogEntry(
        timestamp: '1.65s',
        text: 'Handshake complete. Launching game viewport.',
        statusTag: '[READY]',
        statusColor: Color(0xFFFF0044),
      ),
    ];

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnim = Tween(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn),
    );

    // Cursor blink
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 450), (_) {
      if (mounted) setState(() => _cursorVisible = !_cursorVisible);
    });

    // Run dynamic connection check
    _dynamicChecksFuture = _runDynamicChecks();

    // Start typing after brief pause
    Future.delayed(const Duration(milliseconds: 200), _startNextLine);
    _scheduleGlitch();
  }

  Future<void> _runDynamicChecks() async {
    final sw = Stopwatch()..start();
    try {
      final isConnected = await AppConfigService.checkInternetConnection();
      sw.stop();
      _measuredLatencyMs = sw.elapsedMilliseconds.clamp(12, 500);
      _isNetworkOnline = isConnected;
    } catch (_) {
      sw.stop();
      _measuredLatencyMs = 0;
      _isNetworkOnline = false;
    }

    if (!mounted) return;

    setState(() {
      _lines[1] = _GameLogEntry(
        timestamp: '0.42s',
        text: 'Establishing encrypted SSL/TLS session...',
        statusTag: _isNetworkOnline
            ? '[SECURE • ${_measuredLatencyMs}ms]'
            : '[FAILED • OFFLINE]',
        statusColor: _isNetworkOnline
            ? const Color(0xFF00FF88)
            : const Color(0xFFFF0044),
      );
    });
  }

  Future<void> _retryConnection() async {
    if (_isRetrying) return;
    setState(() => _isRetrying = true);

    _dynamicChecksFuture = _runDynamicChecks();
    await _dynamicChecksFuture;

    if (!mounted) return;
    setState(() => _isRetrying = false);

    if (_isNetworkOnline) {
      setState(() {
        if (_completedLines.length > 1) {
          _completedLines[1] = _lines[1];
        }
        _showOfflineError = false;
      });
      // Resume typing remaining lines from where it stopped!
      Future.delayed(const Duration(milliseconds: 120), _startNextLine);
    }
  }

  // Random glitch trigger
  void _scheduleGlitch() {
    _glitchTimer = Timer(
      Duration(milliseconds: 400 + _rand.nextInt(800)),
      () {
        if (!mounted) return;
        setState(() {
          _glitchActive = true;
          _glitchX = (_rand.nextDouble() - 0.5) * 10;
          _glitchY = (_rand.nextDouble() - 0.5) * 3;
        });
        _glitchResetTimer = Timer(
          Duration(milliseconds: 40 + _rand.nextInt(120)),
          () {
            if (!mounted) return;
            setState(() => _glitchActive = false);
            _scheduleGlitch();
          },
        );
      },
    );
  }

  void _startNextLine() {
    if (!mounted) return;
    if (_currentLine >= _lines.length) {
      // All done — wait then fade out
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted) return;
        _fadeCtrl.forward().then((_) => widget.onComplete());
      });
      return;
    }

    _currentChar = 0;
    _currentTyping = '';
    final entry = _lines[_currentLine];
    final fullRaw = '> [${entry.timestamp}] ${entry.text}';

    _typeTimer = Timer.periodic(const Duration(milliseconds: 14), (t) {
      if (!mounted) { t.cancel(); return; }
      if (_currentChar < fullRaw.length) {
        setState(() {
          _currentTyping = fullRaw.substring(0, _currentChar + 1);
          _currentChar++;
        });
      } else {
        t.cancel();
        setState(() {
          _completedLines.add(entry);
          _currentTyping = '';
          _currentLine++;
        });

        // ── IMMEDIATE INTERNET CHECK GATE (After Line 1: SSL/TLS session) ──
        // If device has no internet, HALT immediately. Do NOT type subsequent logs!
        if (_currentLine == 2) {
          _handlePostNetProbeGate();
          return;
        }

        Future.delayed(const Duration(milliseconds: 120), _startNextLine);
      }
    });
  }

  Future<void> _handlePostNetProbeGate() async {
    if (_dynamicChecksFuture != null) {
      await _dynamicChecksFuture;
    }
    if (!mounted) return;

    if (!_isNetworkOnline) {
      // HALT IMMEDIATELY! Do NOT type lines 2, 3, 4!
      setState(() {
        if (_completedLines.length > 1) {
          _completedLines[1] = _lines[1];
        }
        _showOfflineError = true;
      });
      return;
    }

    if (_completedLines.length > 1) {
      setState(() {
        _completedLines[1] = _lines[1];
      });
    }
    Future.delayed(const Duration(milliseconds: 120), _startNextLine);
  }

  @override
  void dispose() {
    _typeTimer?.cancel();
    _glitchTimer?.cancel();
    _glitchResetTimer?.cancel();
    _cursorTimer?.cancel();
    _fadeCtrl.dispose();
    super.dispose();
  }

  // Glitch header builder
  Widget _buildGlitchTitle() {
    const style = TextStyle(
      fontFamily: 'Orbitron',
      fontSize: 34,
      fontWeight: FontWeight.w900,
      letterSpacing: 6,
    );
    return SizedBox(
      height: 48,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Red shadow
          Transform.translate(
            offset: Offset(_glitchActive ? -_glitchX : 0, _glitchActive ? _glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFFFF0044)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),
          // Cyan shadow
          Transform.translate(
            offset: Offset(_glitchActive ? _glitchX : 0, _glitchActive ? -_glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFF00F0FF)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),
          // Main text
          Text.rich(
            TextSpan(
              children: [
                TextSpan(text: 'Cobra', style: style.copyWith(color: Colors.white)),
                TextSpan(text: 'X', style: style.copyWith(color: const Color(0xFFFF0044))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: Container(
        color: const Color(0xFF050505),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Spacer(),

                // Title
                _buildGlitchTitle(),
                const SizedBox(height: 4),
                Text(
                  'GATEWAY // ${widget.gameName.toUpperCase()}',
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    color: Color(0xFFCC0000),
                    fontSize: 8.5,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 28),

                // Terminal Box
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0A0E),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: const Color(0xFFCC0000).withValues(alpha: 0.35),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.8),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Terminal Header
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: const Color(0xFF14141A),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(9)),
                          border: Border(
                            bottom: BorderSide(
                              color: Colors.white.withValues(alpha: 0.08),
                              width: 1,
                            ),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFFFF5F56), shape: BoxShape.circle)),
                            const SizedBox(width: 6),
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFFFFBD2E), shape: BoxShape.circle)),
                            const SizedBox(width: 6),
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: Color(0xFF27C93F), shape: BoxShape.circle)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'SESSION-ROUTE // ${widget.gameName.toUpperCase()}',
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  fontSize: 9.5,
                                  color: Color(0xFF888888),
                                  letterSpacing: 1,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Logs
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final entry in _completedLines)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 6.5),
                                child: Text.rich(
                                  TextSpan(
                                    style: const TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 11.2,
                                      height: 1.35,
                                    ),
                                    children: [
                                      const TextSpan(
                                        text: '> ',
                                        style: TextStyle(color: Color(0xFFFF0044), fontWeight: FontWeight.bold),
                                      ),
                                      TextSpan(
                                        text: '[${entry.timestamp}] ',
                                        style: const TextStyle(color: Color(0xFF666666)),
                                      ),
                                      TextSpan(
                                        text: '${entry.text} ',
                                        style: const TextStyle(color: Color(0xFFE0E0E0)),
                                      ),
                                      if (entry.statusTag != null)
                                        TextSpan(
                                          text: entry.statusTag!,
                                          style: TextStyle(
                                            color: entry.statusColor ?? const Color(0xFF00FF88),
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),

                            // Active Typing
                            if (_currentTyping.isNotEmpty ||
                                (_currentLine < _lines.length &&
                                    _completedLines.length == _currentLine))
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      _currentTyping,
                                      style: const TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 11.2,
                                        color: Color(0xFFFFFFFF),
                                        height: 1.35,
                                      ),
                                    ),
                                  ),
                                  AnimatedOpacity(
                                    opacity: _cursorVisible ? 1.0 : 0.0,
                                    duration: const Duration(milliseconds: 100),
                                    child: const Text(
                                      '_',
                                      style: TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 12,
                                        color: Color(0xFFFF0044),
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                if (_showOfflineError) ...[
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E080C),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFFF0044), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF0044).withValues(alpha: 0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.wifi_off_rounded, color: Color(0xFFFF0044), size: 18),
                            SizedBox(width: 8),
                            Text(
                              'INTERNET CONNECTION REQUIRED',
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 11.5,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFFFF0044),
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Cannot establish secure gateway. Connect to Mobile Data or Wi-Fi to enter game.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 10.5,
                            color: Color(0xFFCCCCCC),
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 12),
                        InkWell(
                          onTap: _retryConnection,
                          borderRadius: BorderRadius.circular(6),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFFF0044), Color(0xFFCC0033)],
                              ),
                              borderRadius: BorderRadius.circular(6),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFFF0044).withValues(alpha: 0.4),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            child: _isRetrying
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  )
                                : const Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.refresh_rounded, color: Colors.white, size: 15),
                                      SizedBox(width: 6),
                                      Text(
                                        'RETRY CONNECTION',
                                        style: TextStyle(
                                          fontFamily: 'monospace',
                                          fontSize: 11,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const Spacer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
