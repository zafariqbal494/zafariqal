import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

/// Animated CobraX logo with chromatic-aberration glitch effect.
/// Red and cyan shadow layers shift randomly, giving a hacker aesthetic.
class CobraXGlitchHeader extends StatefulWidget {
  final double fontSize;
  final double letterSpacing;
  final double height;
  final Alignment alignment;

  const CobraXGlitchHeader({
    super.key,
    this.fontSize = 28,
    this.letterSpacing = 4,
    this.height = 42,
    this.alignment = Alignment.centerLeft,
  });

  @override
  State<CobraXGlitchHeader> createState() => _CobraXGlitchHeaderState();
}

class _CobraXGlitchHeaderState extends State<CobraXGlitchHeader> {
  Timer? _glitchTimer;
  Timer? _glitchResetTimer;
  bool _glitchActive = false;
  double _glitchX = 0;
  double _glitchY = 0;
  final Random _rand = Random();

  @override
  void initState() {
    super.initState();
    _scheduleGlitch();
  }

  void _scheduleGlitch() {
    _glitchTimer = Timer(
      Duration(milliseconds: 300 + _rand.nextInt(600)),
      () {
        if (!mounted) return;
        setState(() {
          _glitchActive = true;
          _glitchX = (_rand.nextDouble() - 0.5) * 10;
          _glitchY = (_rand.nextDouble() - 0.5) * 3;
        });
        _glitchResetTimer = Timer(
          Duration(milliseconds: 50 + _rand.nextInt(100)),
          () {
            if (!mounted) return;
            setState(() => _glitchActive = false);
            _scheduleGlitch();
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _glitchTimer?.cancel();
    _glitchResetTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      fontFamily: 'Orbitron',
      fontSize: widget.fontSize,
      fontWeight: FontWeight.w900,
      letterSpacing: widget.letterSpacing,
    );

    return SizedBox(
      height: widget.height,
      child: Stack(
        alignment: widget.alignment,
        children: [
          Transform.translate(
            offset: Offset(_glitchActive ? -_glitchX : 0, _glitchActive ? _glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFFFF0044)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(_glitchActive ? _glitchX : 0, _glitchActive ? -_glitchY : 0),
            child: Text(
              'CobraX',
              style: style.copyWith(
                foreground: Paint()
                  ..color = const Color(0xFF00F0FF)
                  ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
              ),
            ),
          ),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(text: 'Cobra', style: style.copyWith(color: Colors.white)),
                TextSpan(text: 'X', style: style.copyWith(color: const Color(0xFFFF0044))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
