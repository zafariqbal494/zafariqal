import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../config/app_config.dart';
import '../services/app_config_service.dart';

/// Full-screen, un-dismissible mandatory update blocking screen.
/// Displayed whenever the installed app version is below the minimum required version.
class MandatoryUpdateScreen extends StatelessWidget {
  const MandatoryUpdateScreen({super.key});

  Future<void> _launchUpdateUrl(BuildContext context) async {
    final urlStr = AppConfigService.updateUrl.isNotEmpty
        ? AppConfigService.updateUrl
        : kOfficialDownloadUrl;
    try {
      final uri = WebUri(urlStr);
      await InAppBrowser.openWithSystemBrowser(url: uri);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open browser: $urlStr'),
            backgroundColor: const Color(0xFF1E0A0A),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final minVer = AppConfigService.minAppVersion;
    final latestVer = AppConfigService.latestAppVersion;

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF070B12),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0, -0.3),
              radius: 1.2,
              colors: [
                Color(0xFF1F0D15),
                Color(0xFF0A0E17),
                Color(0xFF05070B),
              ],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(flex: 2),

                  // ── Warning Icon with Glow ────────────────────────────────
                  Container(
                    width: 90,
                    height: 90,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF2A0D15),
                      border: Border.all(
                        color: const Color(0xFFFF2A55).withValues(alpha: 0.7),
                        width: 2.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF2A55).withValues(alpha: 0.35),
                          blurRadius: 30,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.system_security_update_rounded,
                      color: Color(0xFFFF2A55),
                      size: 46,
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── Pill Badge ────────────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF3B101B),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFFF2A55).withValues(alpha: 0.5),
                        width: 1,
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.warning_amber_rounded,
                            color: Color(0xFFFF4D6D), size: 16),
                        SizedBox(width: 6),
                        Text(
                          'MANDATORY UPDATE REQUIRED',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            color: Color(0xFFFF4D6D),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── Title ─────────────────────────────────────────────────
                  const Text(
                    'UPDATE REQUIRED',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),

                  const SizedBox(height: 14),

                  // ── Exact Required Message ────────────────────────────────
                  const Text(
                    'You are using an outdated version of CobraX. Please install the latest version from our official website.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFB0B7C3),
                      fontSize: 14.5,
                      height: 1.5,
                      fontWeight: FontWeight.w400,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ── Version Info Card ─────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F1522),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFF222F45),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildVersionColumn('Your Version', 'v$kAppVersion',
                            const Color(0xFFFF5252)),
                        Container(
                          width: 1,
                          height: 28,
                          color: const Color(0xFF222F45),
                        ),
                        _buildVersionColumn('Required', 'v$minVer',
                            const Color(0xFF00E676)),
                        if (latestVer != minVer && latestVer.isNotEmpty) ...[
                          Container(
                            width: 1,
                            height: 28,
                            color: const Color(0xFF222F45),
                          ),
                          _buildVersionColumn('Latest', 'v$latestVer',
                              const Color(0xFF40C4FF)),
                        ],
                      ],
                    ),
                  ),

                  const Spacer(flex: 3),

                  // ── Update Action Button ──────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () => _launchUpdateUrl(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF2A55),
                        foregroundColor: Colors.white,
                        elevation: 8,
                        shadowColor: const Color(0xFFFF2A55).withValues(alpha: 0.6),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.download_rounded, size: 22),
                          SizedBox(width: 10),
                          Text(
                            'INSTALL LATEST VERSION',
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 14.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── Official Website Security Footer ──────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.verified_user_outlined,
                          size: 14, color: Color(0xFF6B7280)),
                      const SizedBox(width: 6),
                      Text(
                        'Official Website: ${kOfficialDownloadUrl.replaceAll('https://', '')}',
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          color: Color(0xFF6B7280),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static Widget _buildVersionColumn(String label, String value, Color valueColor) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF8892B0),
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(
            fontFamily: 'monospace',
            color: valueColor,
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}
