import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../config/app_config.dart';
import '../services/app_config_service.dart';

/// Floating Telegram button displayed on the Home Screen above the footer.
/// Renders the official Telegram icon and launches the live Telegram channel.
class FloatingTelegramButton extends StatefulWidget {
  final double size;

  const FloatingTelegramButton({
    super.key,
    this.size = 54.0,
  });

  @override
  State<FloatingTelegramButton> createState() => _FloatingTelegramButtonState();
}

class _FloatingTelegramButtonState extends State<FloatingTelegramButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.90).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<void> _launchTelegram() async {
    String rawAddress = AppConfigService.telegramAddress.isNotEmpty
        ? AppConfigService.telegramAddress
        : kTelegramAddress;

    rawAddress = rawAddress.trim();
    String urlStr;
    if (rawAddress.startsWith('http://') || rawAddress.startsWith('https://')) {
      urlStr = rawAddress;
    } else if (rawAddress.startsWith('t.me/')) {
      urlStr = 'https://$rawAddress';
    } else if (rawAddress.startsWith('@')) {
      urlStr = 'https://t.me/${rawAddress.substring(1)}';
    } else {
      urlStr = 'https://t.me/$rawAddress';
    }

    try {
      final uri = WebUri(urlStr);
      await InAppBrowser.openWithSystemBrowser(url: uri);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open Telegram: $urlStr'),
            backgroundColor: const Color(0xFF1E0A0A),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: Container(
        width: widget.size,
        height: widget.size,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.black45,
              blurRadius: 6,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          shape: const CircleBorder(),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTapDown: (_) => _animController.forward(),
            onTapUp: (_) => _animController.reverse(),
            onTapCancel: () => _animController.reverse(),
            onTap: _launchTelegram,
            child: CustomPaint(
              size: Size(widget.size, widget.size),
              painter: const _TelegramIconPainter(),
            ),
          ),
        ),
      ),
    );
  }
}

/// Custom painter for the official Telegram icon SVG path
class _TelegramIconPainter extends CustomPainter {
  const _TelegramIconPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;

    // 1. Draw circular background with official Telegram gradient
    final Paint circlePaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF2AABEE),
          Color(0xFF229ED9),
        ],
      ).createShader(rect);

    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2),
      size.width / 2,
      circlePaint,
    );

    // 2. Scale coordinate space from SVG (512x512) to widget size
    canvas.save();
    canvas.scale(size.width / 512.0, size.height / 512.0);

    // 3. Draw Telegram Paper Airplane path
    final Path planePath = Path();
    planePath.moveTo(115.88, 253.3);
    planePath.relativeCubicTo(74.63, -32.52, 124.39, -53.95, 149.29, -64.31);
    planePath.relativeCubicTo(71.1, -29.57, 85.87, -34.71, 95.5, -34.88);
    planePath.relativeCubicTo(2.12, -0.03, 6.85, 0.49, 9.92, 2.98);
    planePath.relativeCubicTo(2.59, 2.1, 3.3, 4.94, 3.64, 6.93);
    planePath.relativeCubicTo(0.34, 2.0, 0.77, 6.53, 0.43, 10.08);
    planePath.relativeCubicTo(-3.85, 40.48, -20.52, 138.71, -29.0, 184.05);
    planePath.relativeCubicTo(-3.59, 19.19, -10.66, 25.62, -17.5, 26.25);
    planePath.relativeCubicTo(-14.86, 1.37, -26.15, -9.83, -40.55, -19.27);
    planePath.relativeCubicTo(-22.53, -14.76, -35.26, -23.96, -57.13, -38.37);
    planePath.relativeCubicTo(-25.28, -16.66, -8.89, -25.81, 5.51, -40.77);
    planePath.relativeCubicTo(3.77, -3.92, 69.27, -63.5, 70.54, -68.9);
    planePath.relativeCubicTo(0.16, -0.68, 0.31, -3.2, -1.19, -4.53);
    planePath.relativeCubicTo(-2.69, -1.33, -3.71, -0.87, -5.3, -0.51);
    planePath.relativeCubicTo(-2.26, 0.51, -38.25, 24.3, -107.98, 71.37);
    planePath.relativeCubicTo(-10.22, 7.02, -19.48, 10.43, -27.77, 10.26);
    planePath.relativeCubicTo(-9.14, -0.2, -26.72, -5.17, -39.79, -9.42);
    planePath.relativeCubicTo(-16.03, -5.21, -28.77, -7.97, -27.66, -16.82);
    planePath.relativeCubicTo(0.57, -4.61, 6.92, -9.32, 19.04, -14.14);
    planePath.close();

    final Paint planePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawPath(planePath, planePaint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
