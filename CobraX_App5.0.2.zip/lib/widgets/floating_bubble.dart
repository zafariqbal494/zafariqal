import 'dart:async';

import 'package:flutter/material.dart';

import '../services/app_config_service.dart';

/// Shows the decrypted result (BIG / SMALL) for the current WinGo 30Sec period.
class ResultBubble extends StatelessWidget {
  final String sizeLabel;
  final String issueShort;
  final Color bubbleColor;
  final Color glowColor;
  final String? telegramAddress;

  const ResultBubble({
    super.key,
    required this.sizeLabel,
    required this.issueShort,
    required this.bubbleColor,
    required this.glowColor,
    this.telegramAddress,
  });

  @override
  Widget build(BuildContext context) {
    final handle = telegramAddress ?? AppConfigService.telegramAddress;

    return Container(
      width: 130,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF546E7A), width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 16,
            spreadRadius: 3,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 5),
              color: const Color(0xFF263238),
              child: Text(
                issueShort.isNotEmpty ? '#$issueShort' : '---',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF90A4AE),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                sizeLabel,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: bubbleColor,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
              color: const Color(0xFF0D1B2A),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.telegram, color: Color(0xFF29B6F6), size: 15),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      handle,
                      style: const TextStyle(
                        color: Color(0xFF29B6F6),
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              height: 6,
              color: const Color(0xFF37474F),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/// Animated 'Decrypting...' state shown while awaiting the draw result.
class DecryptingBubble extends StatefulWidget {
  final String issueShort;
  final String? telegramAddress;

  const DecryptingBubble({
    super.key,
    required this.issueShort,
    this.telegramAddress,
  });

  @override
  State<DecryptingBubble> createState() => _DecryptingBubbleState();
}

class _DecryptingBubbleState extends State<DecryptingBubble> {
  int _dotCount = 1;
  Timer? _dotTimer;

  @override
  void initState() {
    super.initState();
    _dotTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (mounted) setState(() => _dotCount = (_dotCount % 3) + 1);
    });
  }

  @override
  void dispose() {
    _dotTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dots = '.' * _dotCount;
    final handle = widget.telegramAddress ?? AppConfigService.telegramAddress;

    return Container(
      width: 130,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF546E7A), width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 16,
            spreadRadius: 3,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 5),
              color: const Color(0xFF263238),
              child: Text(
                widget.issueShort.isNotEmpty
                    ? '#${widget.issueShort}'
                    : '---',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF90A4AE),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                children: [
                  const Icon(Icons.lock_clock_rounded,
                      color: Color(0xFF78909C), size: 22),
                  const SizedBox(height: 4),
                  Text(
                    'Decrypting$dots',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF90A4AE),
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
              color: const Color(0xFF0D1B2A),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.telegram, color: Color(0xFF29B6F6), size: 15),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      handle,
                      style: const TextStyle(
                        color: Color(0xFF29B6F6),
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              height: 6,
              color: const Color(0xFF37474F),
            ),
          ],
        ),
      ),
    );
  }
}
