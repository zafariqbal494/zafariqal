import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../config/app_config.dart';

/// The VIP key authentication dialog.
/// Shows key input form, AUTHENTICATE button, BUY KEY button and anti-scam notice.
/// On success, switches to a 'VIP ACCESS ACTIVATED' success view for 3 seconds.
class AuthDialog extends StatefulWidget {
  // Returns null on success, or an error message string on failure.
  final Future<String?> Function(String key) onAuthenticate;

  const AuthDialog({super.key, required this.onAuthenticate});

  @override
  State<AuthDialog> createState() => _AuthDialogState();
}

class _AuthDialogState extends State<AuthDialog> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _errorMsg;
  bool _success = false;

  Future<void> _handleAuthenticate() async {
    final key = _controller.text.trim();
    if (key.isEmpty) {
      setState(() => _errorMsg = 'Please enter your key.');
      return;
    }
    setState(() {
      _loading = true;
      _errorMsg = null;
    });

    // null = success, non-null = specific error from server
    final errorMsg = await widget.onAuthenticate(key);

    if (!mounted) return;
    if (errorMsg == null) {
      setState(() {
        _success = true;
        _loading = false;
      });
      await Future.delayed(const Duration(seconds: 3));
      if (mounted) Navigator.of(context).pop();
    } else {
      setState(() {
        _loading = false;
        _errorMsg = errorMsg; // Show exact server error message
      });
    }
  }

  Future<void> _handleBuyKey() async {
    await InAppBrowser.openWithSystemBrowser(url: WebUri(kBuyKeyUrl));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 390),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _success
                  ? const [Color(0xFF041C12), Color(0xFF0A0A14)]
                  : const [Color(0xFF160608), Color(0xFF0A0A12)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _success
                  ? const Color(0xFF00FF88).withValues(alpha: 0.8)
                  : const Color(0xFFCC0000).withValues(alpha: 0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _success
                    ? const Color(0xFF00FF88).withValues(alpha: 0.3)
                    : const Color(0xFFFF0044).withValues(alpha: 0.25),
                blurRadius: 20,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.8),
                blurRadius: 15,
                spreadRadius: 4,
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: _success ? _buildSuccessView() : _buildInputView(),
            ),
          ),
        ),
      ),
    );
  }

  // ── Success State ─────────────────────────────────────────────────────────
  Widget _buildSuccessView() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Cyber Verified Glowing Icon Badge
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF00FF88).withValues(alpha: 0.15),
            border: Border.all(
              color: const Color(0xFF00FF88),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00FF88).withValues(alpha: 0.4),
                blurRadius: 20,
                spreadRadius: 3,
              ),
            ],
          ),
          child: const Icon(
            Icons.verified_rounded,
            color: Color(0xFF00FF88),
            size: 36,
          ),
        ),
        const SizedBox(height: 16),

        const Text(
          'VIP ACCESS ACTIVATED',
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: Color(0xFF00FF88),
            fontSize: 15,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'WinGo 30Sec predictions unlocked successfully!',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFB0BEC5),
            fontSize: 11.5,
            height: 1.3,
          ),
        ),
        const SizedBox(height: 18),

        // Cyber Status Box
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF02120B),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: const Color(0xFF00FF88).withValues(alpha: 0.4),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF00FF88).withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.bolt_rounded,
                  color: Color(0xFF00FF88),
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'LICENSE KEY ACTIVE',
                      style: TextStyle(
                        fontFamily: 'monospace',
                        color: Color(0xFF66BB6A),
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _controller.text.trim().isNotEmpty
                          ? _controller.text.trim().toUpperCase()
                          : 'COBRAX VIP UNLOCKED',
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        color: Colors.white,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 18),

        // Action / Close Button
        SizedBox(
          width: double.infinity,
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF00FF88), Color(0xFF00B060)],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00FF88).withValues(alpha: 0.35),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                foregroundColor: const Color(0xFF0A0A12),
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'START PREDICTIONS',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Input State ──────────────────────────────────────────────────────────
  Widget _buildInputView() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Top Row with Cyber Icon & Close Button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFCC0000).withValues(alpha: 0.15),
                border: Border.all(
                  color: const Color(0xFFFF0044).withValues(alpha: 0.6),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.vpn_key_rounded,
                color: Color(0xFFFF0044),
                size: 22,
              ),
            ),
            IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close_rounded,
                  color: Color(0xFF888899), size: 22),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ),

        const SizedBox(height: 12),

        // Title & Subtitle
        const Text(
          'AUTHENTICATION KEY',
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Enter your key to unlock WinGo 30Sec full access',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFF9999AA),
            fontSize: 11.5,
            height: 1.3,
          ),
        ),

        const SizedBox(height: 20),

        // Key Input Field
        TextField(
          controller: _controller,
          enabled: !_loading && !_success,
          style: const TextStyle(
            fontFamily: 'monospace',
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
          textCapitalization: TextCapitalization.characters,
          decoration: InputDecoration(
            hintText: 'COBRAX-XXXX-XXXX-XXXX-30',
            hintStyle: TextStyle(
              fontFamily: 'monospace',
              color: Colors.white.withValues(alpha: 0.25),
              fontSize: 11,
              letterSpacing: 1,
            ),
            filled: true,
            fillColor: const Color(0xFF06060B),
            prefixIcon: const Icon(
              Icons.key_outlined,
              color: Color(0xFFFF0044),
              size: 18,
            ),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: _errorMsg != null
                    ? const Color(0xFFFF0044)
                    : const Color(0xFFCC0000).withValues(alpha: 0.4),
                width: _errorMsg != null ? 1.5 : 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFFF0044),
                width: 1.5,
              ),
            ),
          ),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9\-]')),
          ],
          onSubmitted: (_) => _handleAuthenticate(),
        ),

        // Dedicated Cyber Error Alert Box (Full Multiline Display)
        if (_errorMsg != null) ...[
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: const Color(0xFFFF0044).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: const Color(0xFFFF0044).withValues(alpha: 0.5),
                width: 1,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 1),
                  child: Icon(
                    Icons.error_outline_rounded,
                    color: Color(0xFFFF4466),
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _errorMsg!,
                    style: const TextStyle(
                      color: Color(0xFFFF6688),
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],

        const SizedBox(height: 16),

        // Authenticate Button
        SizedBox(
          width: double.infinity,
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF0044), Color(0xFF990022)],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF0044).withValues(alpha: 0.35),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _loading ? null : _handleAuthenticate,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      'AUTHENTICATE',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 1.5,
                      ),
                    ),
            ),
          ),
        ),

        const SizedBox(height: 10),

        // Buy Key Button
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _loading ? null : _handleBuyKey,
            icon: const Icon(Icons.shopping_cart_outlined,
                size: 16, color: Color(0xFF00FF88)),
            label: const Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: 'BUY KEY ('),
                  TextSpan(
                    text: 'COBRAX.SBS',
                    style: TextStyle(
                      color: Color(0xFF29B6F6),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  TextSpan(text: ')'),
                ],
              ),
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF00FF88),
              side: BorderSide(
                color: const Color(0xFF00FF88).withValues(alpha: 0.6),
                width: 1,
              ),
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),

        const SizedBox(height: 14),

        // Anti-Scam Notice Card
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF1E080C),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: const Color(0xFFFF3355).withValues(alpha: 0.4),
              width: 0.8,
            ),
          ),
          child: const Row(
            children: [
              Icon(Icons.shield_outlined,
                  color: Color(0xFFFF5555), size: 16),
              SizedBox(width: 8),
              Expanded(
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                          text:
                              'Anti-Scam Notice: Buy keys ONLY from official site '),
                      TextSpan(
                        text: 'cobrax.sbs',
                        style: TextStyle(
                          color: Color(0xFF29B6F6),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextSpan(
                          text:
                              '. Never pay private agents to avoid fraud/scams.'),
                    ],
                  ),
                  style: TextStyle(
                    color: Color(0xFFFF99AA),
                    fontSize: 9.5,
                    height: 1.25,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
