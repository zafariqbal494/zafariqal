/// Immutable snapshot of the user's current VIP key status.
class VipStatus {
  final bool isVip;
  final DateTime? expiry;
  final String? key;
  final String? package;
  final int? days;
  final List<String> allowedGames;
  final Map<String, int> customVipLevels;

  const VipStatus({
    this.isVip = false,
    this.expiry,
    this.key,
    this.package,
    this.days,
    this.allowedGames = const [],
    this.customVipLevels = const {},
  });

  /// A convenience constructor for the "not authenticated" state.
  const VipStatus.inactive()
      : isVip = false,
        expiry = null,
        key = null,
        package = null,
        days = null,
        allowedGames = const [],
        customVipLevels = const {};

  /// Returns custom VIP level assigned by admin for this game if set.
  int? getCustomVipLevel(String? gameName) {
    if (!isVip || gameName == null || gameName.isEmpty) return null;
    for (final entry in customVipLevels.entries) {
      if (entry.key.trim().toLowerCase() == gameName.trim().toLowerCase()) {
        return entry.value;
      }
    }
    return null;
  }

  /// Returns true if the given game name is unlocked for this VIP key.
  /// If [allowedGames] is empty, all games are considered unlocked (all-access / legacy keys).
  bool isGameAllowed(String? gameName) {
    if (!isVip) return false;
    if (allowedGames.isEmpty) return true;
    if (gameName == null || gameName.isEmpty) return false;
    return allowedGames.any(
      (g) => g.trim().toLowerCase() == gameName.trim().toLowerCase(),
    );
  }

  /// Whether the VIP key will expire within the next 24 hours.
  bool get isExpiringSoon {
    if (!isVip || expiry == null) return false;
    final diff = expiry!.difference(DateTime.now());
    return diff.inMilliseconds > 0 && diff.inHours <= 24;
  }

  /// Number of hours remaining before key expiration.
  int get hoursRemaining {
    if (expiry == null) return 0;
    final diff = expiry!.difference(DateTime.now());
    return diff.inHours < 0 ? 0 : diff.inHours;
  }
}
