/// Represents an active broadcast announcement received from the backend server.
class Announcement {
  final bool active;
  final String title;
  final String message;
  final String type; // 'info', 'warning', 'maintenance'
  final String? url;
  final bool dismissible;

  const Announcement({
    required this.active,
    this.title = '',
    required this.message,
    this.type = 'info',
    this.url,
    this.dismissible = true,
  });

  const Announcement.inactive()
      : active = false,
        title = '',
        message = '',
        type = 'info',
        url = null,
        dismissible = true;

  factory Announcement.fromJson(Map<String, dynamic> json) {
    if (json['active'] != true) {
      return const Announcement.inactive();
    }

    final rawTitle = (json['title'] as String?)?.trim() ?? '';
    final type = (json['type'] as String?) ?? 'info';

    String defaultTitle;
    switch (type) {
      case 'warning':
        defaultTitle = 'SYSTEM WARNING';
        break;
      case 'maintenance':
        defaultTitle = 'MAINTENANCE ALERT';
        break;
      case 'info':
      default:
        defaultTitle = 'ANNOUNCEMENT';
        break;
    }

    return Announcement(
      active: true,
      title: rawTitle.isNotEmpty ? rawTitle : defaultTitle,
      message: (json['message'] as String?) ?? 'System Notice: Operations nominal.',
      type: type,
      url: json['url'] as String?,
      dismissible: (json['dismissible'] as bool?) ?? true,
    );
  }
}
