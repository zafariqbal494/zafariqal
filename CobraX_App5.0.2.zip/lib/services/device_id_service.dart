import 'dart:io';
import 'dart:math';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'secure_storage_service.dart';

/// Centralized service for retrieving a permanent, hardware-backed,
/// globally unique hardware identifier for this physical installation.
///
/// Guaranteed to persist across app cache clears, storage wipes, and reinstallations.
class DeviceIdService {
  DeviceIdService._();

  static const MethodChannel _channel = MethodChannel('com.team.cobrax/device_identity');
  static const String _kStorageKey = 'cx_unique_hardware_uuid';
  static String? _cachedDeviceId;

  /// Returns the persistent, unique device identifier for this installation.
  /// Uses native Widevine DRM and Android SSAID on Android, and identifierForVendor on iOS.
  static Future<String> getDeviceId() async {
    // 0. High-performance memory cache (0ms lookup)
    if (_cachedDeviceId != null && _cachedDeviceId!.isNotEmpty) {
      return _cachedDeviceId!;
    }

    // 1. Native Hardware Identity extraction (Android)
    if (Platform.isAndroid) {
      try {
        final String? nativeId = await _channel.invokeMethod<String>('getPermanentHardwareId');
        if (nativeId != null && nativeId.trim().isNotEmpty) {
          _cachedDeviceId = nativeId.trim();
          _persistLocally(_cachedDeviceId!);
          return _cachedDeviceId!;
        }
      } catch (_) {}
    }

    // 2. iOS Hardware / Vendor Identity
    if (Platform.isIOS) {
      try {
        final deviceInfo = DeviceInfoPlugin();
        final ios = await deviceInfo.iosInfo;
        if (ios.identifierForVendor != null && ios.identifierForVendor!.trim().isNotEmpty) {
          _cachedDeviceId = 'CX-IOS-${ios.identifierForVendor!.trim()}';
          _persistLocally(_cachedDeviceId!);
          return _cachedDeviceId!;
        }
      } catch (_) {}
    }

    // 3. Fallback: Check local secure storage
    try {
      final saved = await SecureStorageService.getSecuredString(_kStorageKey);
      if (saved != null && saved.trim().isNotEmpty) {
        _cachedDeviceId = saved.trim();
        return _cachedDeviceId!;
      }
    } catch (_) {}

    // 4. Fallback: SharedPreferences
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedPrefs = prefs.getString(_kStorageKey);
      if (savedPrefs != null && savedPrefs.trim().isNotEmpty) {
        _cachedDeviceId = savedPrefs.trim();
        return _cachedDeviceId!;
      }
    } catch (_) {}

    // 5. Final fallback
    String newId = '';
    try {
      final deviceInfo = DeviceInfoPlugin();
      String modelPrefix = 'AND';

      if (Platform.isAndroid) {
        final android = await deviceInfo.androidInfo;
        final rawModel = android.model.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toUpperCase();
        modelPrefix = rawModel.isNotEmpty ? (rawModel.length > 8 ? rawModel.substring(0, 8) : rawModel) : 'AND';
      }

      final rand = Random.secure();
      final bytes = List<int>.generate(16, (_) => rand.nextInt(256));
      final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join().toUpperCase();
      newId = 'CX-$modelPrefix-${hex.substring(0, 16)}';
    } catch (_) {
      final rand = Random.secure();
      final bytes = List<int>.generate(16, (_) => rand.nextInt(256));
      final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join().toUpperCase();
      newId = 'CX-DEV-${hex.substring(0, 16)}';
    }

    _cachedDeviceId = newId;
    _persistLocally(_cachedDeviceId!);
    return _cachedDeviceId!;
  }

  static void _persistLocally(String id) {
    try {
      SecureStorageService.setSecuredString(_kStorageKey, id);
    } catch (_) {}
    try {
      SharedPreferences.getInstance().then((prefs) => prefs.setString(_kStorageKey, id));
    } catch (_) {}
  }
}

