import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

/// Autonomous prediction engine for WinGo 30Sec.
/// Intercepts official draw responses, calculates early time-shift offsets,
/// and schedules high-frequency polling 5 seconds before the period draw completes.
class WinGoPredictionEngine {
  final http.Client _httpClient;

  final void Function(String issueNumber)? onPeriodStarted;
  final void Function({
    required String numberStr,
    required String issueNumber,
    String? nextIssueNumber,
    int? nextEndTimeMs,
  }) onResultFound;

  bool _isActive = false;
  bool _isMaintenanceMode = false;

  String? _timedIssueNumber;
  Timer? _realEndTimer;
  Timer? _retryTimer;
  int _retryCount = 0;
  bool _isPollInFlight = false;

  static const Duration _retryInterval = Duration(milliseconds: 250);
  static const int _maxRetries = 40; // 40 attempts * 250ms = 10s window

  WinGoPredictionEngine({
    required http.Client httpClient,
    this.onPeriodStarted,
    required this.onResultFound,
  }) : _httpClient = httpClient;

  bool get isActive => _isActive;

  void setActive(bool active) {
    _isActive = active;
    if (!active) {
      cancelTimers();
      _timedIssueNumber = null;
    }
  }

  void setMaintenanceMode(bool isMaintenance) {
    _isMaintenanceMode = isMaintenance;
    if (isMaintenance) {
      cancelTimers();
    }
  }

  void cancelTimers() {
    _realEndTimer?.cancel();
    _retryTimer?.cancel();
  }

  void dispose() {
    cancelTimers();
    _isActive = false;
  }

  // ── WinGo_30S.json: Direct +6s time shift (Natural official flow) ─────────
  ({String body, int? realEndTime, String? issueNumber}) processWinGoResponse(
      String rawBody) {
    try {
      final Map<String, dynamic> json = jsonDecode(rawBody);
      const int timeShift = 6000; // 6 seconds early result advantage

      final current = json['current'] as Map<String, dynamic>?;
      final int? realEndTime = current?['endTime'] as int?;
      final String? realIssueNumber = current?['issueNumber']?.toString();

      for (final key in ['previous', 'current', 'next']) {
        final block = json[key] as Map<String, dynamic>?;
        if (block == null) continue;
        if (block.containsKey('startTime')) {
          block['startTime'] = (block['startTime'] as int) + timeShift;
        }
        if (block.containsKey('endTime')) {
          block['endTime'] = (block['endTime'] as int) + timeShift;
        }
      }

      return (
        body: jsonEncode(json),
        realEndTime: realEndTime,
        issueNumber: realIssueNumber,
      );
    } catch (e) {
      debugPrint('[WinGo Engine] Process error: $e');
      return (body: rawBody, realEndTime: null, issueNumber: null);
    }
  }

  // ── Completely Autonomous WinGo Prediction Engine ────────────────────────

  /// Fetches state directly from `https://draw.ar-lottery01.com/WinGo/WinGo_30S.json`
  /// Sets up issue numbers and schedules polling 5 seconds before the real draw end.
  Future<void> syncAndScheduleWinGo({Map<String, dynamic>? preloadedJson}) async {
    if (_isMaintenanceMode || !_isActive) return;

    try {
      Map<String, dynamic>? data = preloadedJson;
      if (data == null) {
        final ts = DateTime.now().toUtc().millisecondsSinceEpoch;
        final response = await _httpClient
            .get(
              Uri.parse('https://draw.ar-lottery01.com/WinGo/WinGo_30S.json?ts=$ts'),
              headers: {'User-Agent': 'Mozilla/5.0'},
            )
            .timeout(const Duration(seconds: 4));

        if (response.statusCode == 200) {
          data = jsonDecode(response.body) as Map<String, dynamic>;
        }
      }

      if (data == null) return;

      final current = data['current'] as Map<String, dynamic>?;
      final next = data['next'] as Map<String, dynamic>?;

      final int? realEndTime = current?['endTime'] as int?;
      final String? issueNumber = current?['issueNumber']?.toString();
      final String? nextIssue = next?['issueNumber']?.toString();
      final int? nextEndTime = next?['endTime'] as int?;

      if (issueNumber == null || realEndTime == null) return;

      onPeriodStarted?.call(issueNumber);

      // Schedule early polling: 5s before real period end
      schedulePeriodPoll(
        realEndTimeMs: realEndTime,
        issueNumber: issueNumber,
        nextIssueNumber: nextIssue,
        nextEndTimeMs: nextEndTime,
      );
    } catch (e) {
      debugPrint('[WinGo Engine] Sync error: $e');
    }
  }

  void schedulePeriodPoll({
    required int realEndTimeMs,
    required String issueNumber,
    String? nextIssueNumber,
    int? nextEndTimeMs,
  }) {
    if (_isMaintenanceMode || !_isActive) return;
    if (issueNumber == _timedIssueNumber && _retryTimer != null) return;

    _timedIssueNumber = issueNumber;
    _realEndTimer?.cancel();
    _retryTimer?.cancel();

    final int nowMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    // Wake up 5s before real period end
    final int delayMs = (realEndTimeMs - 5000) - nowMs;

    debugPrint('[WinGo Engine] Period $issueNumber scheduled to poll in ${delayMs}ms');

    if (delayMs <= 0) {
      _startPollingDrawResult(
        targetIssue: issueNumber,
        nextIssueNumber: nextIssueNumber,
        nextEndTimeMs: nextEndTimeMs,
      );
    } else {
      _realEndTimer = Timer(
        Duration(milliseconds: delayMs),
        () => _startPollingDrawResult(
          targetIssue: issueNumber,
          nextIssueNumber: nextIssueNumber,
          nextEndTimeMs: nextEndTimeMs,
        ),
      );
    }
  }

  void _startPollingDrawResult({
    required String targetIssue,
    String? nextIssueNumber,
    int? nextEndTimeMs,
  }) {
    if (_isMaintenanceMode || !_isActive) return;
    _retryTimer?.cancel();
    _retryCount = 0;
    _pollDrawResultLoop(
      targetIssue: targetIssue,
      nextIssueNumber: nextIssueNumber,
      nextEndTimeMs: nextEndTimeMs,
    );
  }

  Future<void> _pollDrawResultLoop({
    required String targetIssue,
    String? nextIssueNumber,
    int? nextEndTimeMs,
  }) async {
    if (_isMaintenanceMode || !_isActive) return;

    // Skip this poll cycle if a request is already in-flight
    if (_isPollInFlight) return;

    _isPollInFlight = true;
    try {
      final ts = DateTime.now().toUtc().millisecondsSinceEpoch;
      final url =
          'https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?ts=$ts';
      final response = await _httpClient
          .get(Uri.parse(url), headers: {'User-Agent': 'Mozilla/5.0'})
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body) as Map<String, dynamic>;
        final list =
            (json['data'] as Map<String, dynamic>?)?['list'] as List<dynamic>?;

        if (list != null && list.isNotEmpty) {
          for (final item in list) {
            if (item is Map<String, dynamic>) {
              final String itemIssue = item['issueNumber']?.toString() ?? '';
              final String numberStr = item['number']?.toString() ?? '';

              // Support both exact string match and numeric equality
              final bool matches = (itemIssue == targetIssue) ||
                  (BigInt.tryParse(itemIssue) != null &&
                      BigInt.tryParse(itemIssue) == BigInt.tryParse(targetIssue));

              if (matches) {
                _isPollInFlight = false;
                onResultFound(
                  numberStr: numberStr,
                  issueNumber: targetIssue,
                  nextIssueNumber: nextIssueNumber,
                  nextEndTimeMs: nextEndTimeMs,
                );
                return;
              }
            }
          }
        }
      }
    } catch (e) {
      debugPrint('[WinGo Engine] Poll error (attempt $_retryCount): $e');
    } finally {
      _isPollInFlight = false;
    }

    // Continue high-frequency polling every 250ms (up to 40 attempts = 10s window)
    if (_retryCount < _maxRetries && _isActive) {
      _retryCount++;
      _retryTimer = Timer(_retryInterval, () {
        _pollDrawResultLoop(
          targetIssue: targetIssue,
          nextIssueNumber: nextIssueNumber,
          nextEndTimeMs: nextEndTimeMs,
        );
      });
    } else if (_retryCount >= _maxRetries && _isActive) {
      // Self-healing: if period was missed or delayed, resync directly from official source
      debugPrint(
          '[WinGo Engine] Max retries reached for $targetIssue. Auto-resyncing...');
      syncAndScheduleWinGo();
    }
  }
}
