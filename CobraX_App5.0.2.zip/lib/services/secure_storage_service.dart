import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:shared_preferences/shared_preferences.dart';

/// Cryptographic storage wrapper over SharedPreferences.
/// Uses a self-contained SHA-256 derived keystream cipher with random 128-bit IVs to encrypt
/// sensitive local state (VIP key, package details, expiration timestamps).
class SecureStorageService {
  SecureStorageService._();

  static const String _kStorageKeyPrefix = 'sec_v1_';
  static const String _kMasterSeedKey = '_cx_sec_seed_v1';

  static Uint8List? _cachedMasterSeed;

  /// Retrieves or initializes the persistent device master seed.
  static Future<Uint8List> _getMasterSeed(SharedPreferences prefs) async {
    if (_cachedMasterSeed != null) return _cachedMasterSeed!;

    String? seedBase64 = prefs.getString(_kMasterSeedKey);
    if (seedBase64 == null) {
      final Random rng = Random.secure();
      final Uint8List seedBytes = Uint8List(32);
      for (int i = 0; i < seedBytes.length; i++) {
        seedBytes[i] = rng.nextInt(256);
      }
      seedBase64 = base64Encode(seedBytes);
      await prefs.setString(_kMasterSeedKey, seedBase64);
      _cachedMasterSeed = seedBytes;
    } else {
      _cachedMasterSeed = base64Decode(seedBase64);
    }
    return _cachedMasterSeed!;
  }

  /// Encrypts and saves a string value under [key].
  static Future<bool> setSecuredString(String key, String value) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final seed = await _getMasterSeed(prefs);

      final Random rng = Random.secure();
      final Uint8List iv = Uint8List(16);
      for (int i = 0; i < iv.length; i++) {
        iv[i] = rng.nextInt(256);
      }

      final Uint8List plainBytes = Uint8List.fromList(utf8.encode(value));
      final Uint8List cipherText = _transformBytes(plainBytes, seed, iv);

      // Payload structure: [16 bytes IV] + [Ciphertext]
      final Uint8List payload = Uint8List(iv.length + cipherText.length);
      payload.setRange(0, iv.length, iv);
      payload.setRange(iv.length, payload.length, cipherText);

      return await prefs.setString('$_kStorageKeyPrefix$key', base64Encode(payload));
    } catch (_) {
      return false;
    }
  }

  /// Decrypts and retrieves a string value for [key]. Returns `null` if not found or corrupted.
  static Future<String?> getSecuredString(String key) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? encBase64 = prefs.getString('$_kStorageKeyPrefix$key');
      if (encBase64 == null) return null;

      final seed = await _getMasterSeed(prefs);
      final Uint8List payload = base64Decode(encBase64);
      if (payload.length < 17) return null; // Minimum 16 bytes IV + 1 byte data

      final Uint8List iv = payload.sublist(0, 16);
      final Uint8List cipherText = payload.sublist(16);

      final Uint8List plainBytes = _transformBytes(cipherText, seed, iv);
      return utf8.decode(plainBytes);
    } catch (_) {
      return null;
    }
  }

  /// Encrypts and saves an integer value under [key].
  static Future<bool> setSecuredInt(String key, int value) async {
    return await setSecuredString(key, value.toString());
  }

  /// Decrypts and retrieves an integer value for [key].
  static Future<int?> getSecuredInt(String key) async {
    final str = await getSecuredString(key);
    if (str == null) return null;
    return int.tryParse(str);
  }

  /// Removes an encrypted key from storage.
  static Future<bool> removeSecured(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return await prefs.remove('$_kStorageKeyPrefix$key');
  }

  /// Derives keystream block using SHA-256(MasterSeed + IV + Counter) and XORs input.
  static Uint8List _transformBytes(Uint8List input, Uint8List seed, Uint8List iv) {
    final Uint8List result = Uint8List(input.length);
    int blockCounter = 0;
    int offset = 0;

    while (offset < input.length) {
      final List<int> blockHeader = [];
      blockHeader.addAll(seed);
      blockHeader.addAll(iv);
      blockHeader.add((blockCounter >> 24) & 0xFF);
      blockHeader.add((blockCounter >> 16) & 0xFF);
      blockHeader.add((blockCounter >> 8) & 0xFF);
      blockHeader.add(blockCounter & 0xFF);

      final List<int> keystream = _Sha256.hash(blockHeader);

      for (int i = 0; i < keystream.length && offset < input.length; i++) {
        result[offset] = input[offset] ^ keystream[i];
        offset++;
      }
      blockCounter++;
    }
    return result;
  }
}

/// Pure Dart SHA-256 Implementation for zero-dependency keystream generation.
class _Sha256 {
  static const List<int> _k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  static List<int> hash(List<int> bytes) {
    int h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
    int h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

    final int len = bytes.length;
    final int bitLen = len * 8;
    final List<int> padded = List.from(bytes)..add(0x80);
    while ((padded.length % 64) != 56) {
      padded.add(0);
    }
    padded.addAll([
      (bitLen >> 56) & 0xFF, (bitLen >> 48) & 0xFF, (bitLen >> 40) & 0xFF, (bitLen >> 32) & 0xFF,
      (bitLen >> 24) & 0xFF, (bitLen >> 16) & 0xFF, (bitLen >> 8) & 0xFF, bitLen & 0xFF
    ]);

    final List<int> w = List<int>.filled(64, 0);
    for (int i = 0; i < padded.length; i += 64) {
      for (int t = 0; t < 16; t++) {
        w[t] = (padded[i + t * 4] << 24) | (padded[i + t * 4 + 1] << 16) | (padded[i + t * 4 + 2] << 8) | padded[i + t * 4 + 3];
      }
      for (int t = 16; t < 64; t++) {
        final int s0 = _rotr(w[t - 15], 7) ^ _rotr(w[t - 15], 18) ^ (w[t - 15] >> 3);
        final int s1 = _rotr(w[t - 2], 17) ^ _rotr(w[t - 2], 19) ^ (w[t - 2] >> 10);
        w[t] = (w[t - 16] + s0 + w[t - 7] + s1) & 0xFFFFFFFF;
      }

      int a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (int t = 0; t < 64; t++) {
        final int sum1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25);
        final int ch = (e & f) ^ ((~e) & g);
        final int temp1 = (h + sum1 + ch + _k[t] + w[t]) & 0xFFFFFFFF;
        final int sum0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22);
        final int maj = (a & b) ^ (a & c) ^ (b & c);
        final int temp2 = (sum0 + maj) & 0xFFFFFFFF;

        h = g; g = f; f = e; e = (d + temp1) & 0xFFFFFFFF;
        d = c; c = b; b = a; a = (temp1 + temp2) & 0xFFFFFFFF;
      }

      h0 = (h0 + a) & 0xFFFFFFFF; h1 = (h1 + b) & 0xFFFFFFFF;
      h2 = (h2 + c) & 0xFFFFFFFF; h3 = (h3 + d) & 0xFFFFFFFF;
      h4 = (h4 + e) & 0xFFFFFFFF; h5 = (h5 + f) & 0xFFFFFFFF;
      h6 = (h6 + g) & 0xFFFFFFFF; h7 = (h7 + h) & 0xFFFFFFFF;
    }

    return [
      (h0 >> 24) & 0xFF, (h0 >> 16) & 0xFF, (h0 >> 8) & 0xFF, h0 & 0xFF,
      (h1 >> 24) & 0xFF, (h1 >> 16) & 0xFF, (h1 >> 8) & 0xFF, h1 & 0xFF,
      (h2 >> 24) & 0xFF, (h2 >> 16) & 0xFF, (h2 >> 8) & 0xFF, h2 & 0xFF,
      (h3 >> 24) & 0xFF, (h3 >> 16) & 0xFF, (h3 >> 8) & 0xFF, h3 & 0xFF,
      (h4 >> 24) & 0xFF, (h4 >> 16) & 0xFF, (h4 >> 8) & 0xFF, h4 & 0xFF,
      (h5 >> 24) & 0xFF, (h5 >> 16) & 0xFF, (h5 >> 8) & 0xFF, h5 & 0xFF,
      (h6 >> 24) & 0xFF, (h6 >> 16) & 0xFF, (h6 >> 8) & 0xFF, h6 & 0xFF,
      (h7 >> 24) & 0xFF, (h7 >> 16) & 0xFF, (h7 >> 8) & 0xFF, h7 & 0xFF,
    ];
  }

  static int _rotr(int x, int n) => ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF;
}
