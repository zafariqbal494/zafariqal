import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/app_config.dart';
import '../models/vip_status.dart';
import 'device_id_service.dart';
import 'secure_storage_service.dart';

/// Handles VIP key validation, device binding, and encrypted local storage.
class AuthService {
  AuthService._();

  // ── Key Validation ──────────────────────────────────────────────────────────

  /// Validates [key] against the CobraX server, binding it to the current
  /// device. Returns `null` on success, or an error message string on failure.
  static Future<String?> validateKey(String key) async {
    try {
      final deviceId = await DeviceIdService.getDeviceId();

      final response = await http.post(
        Uri.parse('$kApiBaseUrl/validate-key'),
        headers: {
          'Content-Type': 'application/json',
          'X-CobraX-Secret': kApiSecret,
          'X-App-Version': kAppVersion,
        },
        body: jsonEncode({
          'key': key.trim().toUpperCase(),
          'device_id': deviceId,
          'app_version': kAppVersion,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 426 || data['code'] == 'APP_OUTDATED') {
        return (data['message'] as String?) ??
            'You are using an outdated version of CobraX. Please install the latest version from our official website.';
      }

      if (response.statusCode == 200 && data['status'] == 'success') {
        final expiresAt = DateTime.parse(data['expires_at'] as String);
        final pkg = data['package'] as String? ?? 'basic';
        final days = (data['duration_days'] as num?)?.toInt() ?? 30;

        List<String> allowedGames = [];
        if (data['allowed_games'] is List) {
          allowedGames = (data['allowed_games'] as List)
              .map((e) => e.toString().trim())
              .where((e) => e.isNotEmpty)
              .toList();
        }

        Map<String, int> customVipLevels = {};
        if (data['custom_vip_levels'] is Map) {
          (data['custom_vip_levels'] as Map).forEach((k, v) {
            final numVal = int.tryParse(v.toString());
            if (numVal != null) customVipLevels[k.toString()] = numVal;
          });
        }

        // Save encrypted state using SecureStorageService
        await SecureStorageService.setSecuredInt(kPrefExpiryKey, expiresAt.millisecondsSinceEpoch);
        await SecureStorageService.setSecuredString('vip_key', key.trim().toUpperCase());
        await SecureStorageService.setSecuredString('vip_package', pkg);
        await SecureStorageService.setSecuredInt('vip_days', days);
        await SecureStorageService.setSecuredString('vip_allowed_games', jsonEncode(allowedGames));
        await SecureStorageService.setSecuredString('vip_custom_levels', jsonEncode(customVipLevels));

        // Clear legacy plain-text preferences if any exist
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove(kPrefExpiryKey);
        await prefs.remove('vip_key');
        await prefs.remove('vip_package');
        await prefs.remove('vip_days');
        await prefs.remove('vip_allowed_games');
        await prefs.remove('vip_custom_levels');

        return null; // success
      }

      return (data['message'] as String?) ?? 'Authentication failed.';
    } on http.ClientException {
      return 'Network error. Please check your connection.';
    } catch (_) {
      return 'Server error. Please try again.';
    }
  }

  // ── Secure Storage Retrieval ────────────────────────────────────────────────

  /// Reads VIP status from encrypted storage (with automatic fallback migration from legacy prefs).
  /// Clears expired keys automatically.
  static Future<VipStatus> loadVipStatus() async {
    // 1. Try reading encrypted storage
    int? expiryMs = await SecureStorageService.getSecuredInt(kPrefExpiryKey);
    String? key = await SecureStorageService.getSecuredString('vip_key');
    String? pkg = await SecureStorageService.getSecuredString('vip_package');
    int? days = await SecureStorageService.getSecuredInt('vip_days');
    String? gamesJson = await SecureStorageService.getSecuredString('vip_allowed_games');
    String? customVipJson = await SecureStorageService.getSecuredString('vip_custom_levels');

    // 2. Legacy fallback & auto-migration
    if (expiryMs == null) {
      final prefs = await SharedPreferences.getInstance();
      final legacyMs = prefs.getInt(kPrefExpiryKey);
      if (legacyMs != null) {
        expiryMs = legacyMs;
        key = prefs.getString('vip_key');
        pkg = prefs.getString('vip_package');
        days = prefs.getInt('vip_days');
        gamesJson = prefs.getString('vip_allowed_games');
        customVipJson = prefs.getString('vip_custom_levels');

        // Migrate to encrypted storage
        if (key != null) await SecureStorageService.setSecuredString('vip_key', key);
        if (pkg != null) await SecureStorageService.setSecuredString('vip_package', pkg);
        if (days != null) await SecureStorageService.setSecuredInt('vip_days', days);
        if (gamesJson != null) await SecureStorageService.setSecuredString('vip_allowed_games', gamesJson);
        if (customVipJson != null) await SecureStorageService.setSecuredString('vip_custom_levels', customVipJson);
        await SecureStorageService.setSecuredInt(kPrefExpiryKey, legacyMs);

        // Remove plain text originals
        await prefs.remove(kPrefExpiryKey);
        await prefs.remove('vip_key');
        await prefs.remove('vip_package');
        await prefs.remove('vip_days');
        await prefs.remove('vip_allowed_games');
        await prefs.remove('vip_custom_levels');
      }
    }

    if (expiryMs != null) {
      final expiry = DateTime.fromMillisecondsSinceEpoch(expiryMs);
      if (DateTime.now().isBefore(expiry)) {
        List<String> allowedGames = [];
        if (gamesJson != null && gamesJson.isNotEmpty) {
          try {
            final parsed = jsonDecode(gamesJson);
            if (parsed is List) {
              allowedGames = parsed.map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toList();
            }
          } catch (_) {}
        }

        Map<String, int> customVipLevels = {};
        if (customVipJson != null && customVipJson.isNotEmpty) {
          try {
            final parsed = jsonDecode(customVipJson);
            if (parsed is Map) {
              parsed.forEach((k, v) {
                final numVal = int.tryParse(v.toString());
                if (numVal != null) customVipLevels[k.toString()] = numVal;
              });
            }
          } catch (_) {}
        }

        return VipStatus(
          isVip: true,
          expiry: expiry,
          key: key,
          package: pkg ?? 'BASIC',
          days: days ?? 30,
          allowedGames: allowedGames,
          customVipLevels: customVipLevels,
        );
      } else {
        // Key expired — clear all stored VIP data
        await clearVipStatus();
      }
    }
    return const VipStatus.inactive();
  }

  /// Removes all stored VIP key data from encrypted and legacy storage.
  static Future<void> clearVipStatus() async {
    await SecureStorageService.removeSecured(kPrefExpiryKey);
    await SecureStorageService.removeSecured('vip_key');
    await SecureStorageService.removeSecured('vip_package');
    await SecureStorageService.removeSecured('vip_days');
    await SecureStorageService.removeSecured('vip_allowed_games');
    await SecureStorageService.removeSecured('vip_custom_levels');

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kPrefExpiryKey);
    await prefs.remove('vip_key');
    await prefs.remove('vip_package');
    await prefs.remove('vip_days');
    await prefs.remove('vip_allowed_games');
    await prefs.remove('vip_custom_levels');
  }

  /// Persists an updated custom VIP level for a specific game and user into secure storage.
  static Future<void> saveCustomVipLevel(String gameName, int customLevel, [String? targetUserId]) async {
    try {
      Map<String, int> customVipLevels = {};
      Map<String, String> targetUsers = {};

      final customVipJson = await SecureStorageService.getSecuredString('vip_custom_levels');
      if (customVipJson != null && customVipJson.isNotEmpty) {
        try {
          final parsed = jsonDecode(customVipJson);
          if (parsed is Map) {
            parsed.forEach((k, v) {
              final numVal = int.tryParse(v.toString());
              if (numVal != null && k != 'default') customVipLevels[k.toString()] = numVal;
            });
          }
        } catch (_) {}
      }

      final targetUsersJson = await SecureStorageService.getSecuredString('vip_target_users');
      if (targetUsersJson != null && targetUsersJson.isNotEmpty) {
        try {
          final parsed = jsonDecode(targetUsersJson);
          if (parsed is Map) {
            parsed.forEach((k, v) {
              if (v != null) targetUsers[k.toString()] = v.toString();
            });
          }
        } catch (_) {}
      }

      customVipLevels[gameName.trim()] = customLevel;
      if (targetUserId != null && targetUserId.isNotEmpty) {
        targetUsers[gameName.trim()] = targetUserId.trim();
      }

      await SecureStorageService.setSecuredString('vip_custom_levels', jsonEncode(customVipLevels));
      await SecureStorageService.setSecuredString('vip_target_users', jsonEncode(targetUsers));
    } catch (_) {}
  }

  /// Retrieves the authorized target user ID for a game's custom VIP level.
  static Future<String?> getCustomVipTargetUser(String gameName) async {
    try {
      final targetUsersJson = await SecureStorageService.getSecuredString('vip_target_users');
      if (targetUsersJson != null && targetUsersJson.isNotEmpty) {
        final parsed = jsonDecode(targetUsersJson);
        if (parsed is Map) {
          for (final entry in parsed.entries) {
            if (entry.key.toString().trim().toLowerCase() == gameName.trim().toLowerCase()) {
              return entry.value?.toString();
            }
          }
        }
      }
    } catch (_) {}
    return null;
  }
}
