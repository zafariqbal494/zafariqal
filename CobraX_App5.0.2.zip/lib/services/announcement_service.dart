import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/announcement.dart';

/// Fetches active system broadcast announcements from the backend API.
class AnnouncementService {
  AnnouncementService._();

  /// Queries [kApiAnnouncementsUrl] for the current active system broadcast.
  static Future<Announcement> fetchActiveAnnouncement() async {
    try {
      final response = await http
          .get(Uri.parse(kApiAnnouncementsUrl))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['success'] == true) {
          return Announcement.fromJson(data);
        }
      }
    } catch (e) {
      debugPrint('[AnnouncementService] Error fetching announcement: $e');
    }
    return const Announcement.inactive();
  }
}
