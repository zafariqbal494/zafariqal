import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import 'device_id_service.dart';
import 'secure_storage_service.dart';

/// Silent boot-time integrity verifier.
///
/// Computes a runtime HMAC-SHA256 fingerprint from:
///   device_id + '|' + kAppVersion
/// keyed with kApiSecret, and posts it to the server for cross-verification.
///
/// If the server determines the fingerprint is invalid (tampered APK),
/// it returns `{ valid: false, reason: 'TAMPERED' }` and the app
/// displays the TamperedAppScreen blocking overlay.
///
/// Design rules:
///   - Runs in background AFTER HomeScreen first render (0ms UI delay).
///   - On network error / server unreachable → silently pass (offline grace).
///   - Only blocks on explicit server-side TAMPERED rejection.
class IntegrityService {
  IntegrityService._();

  static bool _verified = false;

  /// Returns true if this session has already been verified (avoids redundant calls).
  static bool get isVerified => _verified;

  /// Runs once per app session at boot. Contacts the server to verify that
  /// the app fingerprint matches what the server expects (tamper detection).
  ///
  /// Calls [onTampered] if server explicitly rejects with reason=TAMPERED.
  static Future<bool> verifyOnBoot({
    required void Function() onTampered,
  }) async {
    if (_verified) return true;

    try {
      // ── 1. Get device ID ──────────────────────────────────────────────
      final deviceId = await DeviceIdService.getDeviceId();
      if (deviceId.isEmpty) {
        _verified = true;
        return true;
      }

      // ── 2. Read stored VIP key (may be null for free users) ──────────
      final storedKey = await SecureStorageService.getSecuredString('vip_key');

      // ── 3. Compute HMAC-SHA256 fingerprint ───────────────────────────
      //   fingerprint = HMAC-SHA256(message: device_id|kAppVersion, key: kApiSecret)
      final fingerprint = _computeHmac(
        message: '$deviceId|$kAppVersion',
        secret: kApiSecret,
      );

      // ── 4. Post to server verify-session endpoint ────────────────────
      final response = await http.post(
        Uri.parse('$kApiBaseUrl/verify-session'),
        headers: {
          'Content-Type': 'application/json',
          'X-CobraX-Secret': kApiSecret,
          'X-App-Version': kAppVersion,
        },
        body: jsonEncode({
          'device_id': deviceId,
          'app_version': kAppVersion,
          'app_fingerprint': fingerprint,
          if (storedKey != null && storedKey.isNotEmpty) 'vip_key': storedKey,
        }),
      ).timeout(const Duration(seconds: 8));

      _verified = true;

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final bool valid = data['valid'] == true;

        if (!valid) {
          final reason = data['reason']?.toString() ?? 'UNKNOWN';
          // Only flag as tampered on explicit fingerprint rejection
          if (reason == 'TAMPERED') {
            onTampered();
            return false;
          }
        }
      }

      return true;
    } on SocketException {
      // Offline — silently pass, never punish offline users
      _verified = true;
      return true;
    } on http.ClientException {
      _verified = true;
      return true;
    } catch (_) {
      // Any unexpected error — silently pass (benefit of doubt)
      _verified = true;
      return true;
    }
  }

  /// Pure-Dart HMAC-SHA256 (zero external dependencies).
  static String _computeHmac({
    required String message,
    required String secret,
  }) {
    final keyBytes = utf8.encode(secret);
    final msgBytes = utf8.encode(message);

    final Uint8List paddedKey = Uint8List(64);
    if (keyBytes.length > 64) {
      final hashed = _sha256(keyBytes);
      paddedKey.setRange(0, hashed.length, hashed);
    } else {
      paddedKey.setRange(0, keyBytes.length, keyBytes);
    }

    final Uint8List ipad = Uint8List(64 + msgBytes.length);
    final Uint8List opad = Uint8List(64);

    for (int i = 0; i < 64; i++) {
      ipad[i] = paddedKey[i] ^ 0x36;
      opad[i] = paddedKey[i] ^ 0x5C;
    }
    ipad.setRange(64, 64 + msgBytes.length, msgBytes);

    final innerHash = _sha256(ipad);
    final Uint8List outerInput = Uint8List(64 + innerHash.length);
    outerInput.setRange(0, 64, opad);
    outerInput.setRange(64, 64 + innerHash.length, innerHash);

    final result = _sha256(outerInput);
    return result.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// Pure-Dart SHA-256 implementation (consistent with SecureStorageService).
  static List<int> _sha256(List<int> bytes) {
    const List<int> k = [
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
      0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
      0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
      0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
      0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
      0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
      0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
      0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
      0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
      0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
      0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ];

    int h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
    int h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

    final int len = bytes.length;
    final int bitLen = len * 8;
    final List<int> padded = List.from(bytes)..add(0x80);
    while ((padded.length % 64) != 56) {
      padded.add(0);
    }
    padded.addAll([
      (bitLen >> 56) & 0xFF, (bitLen >> 48) & 0xFF,
      (bitLen >> 40) & 0xFF, (bitLen >> 32) & 0xFF,
      (bitLen >> 24) & 0xFF, (bitLen >> 16) & 0xFF,
      (bitLen >> 8) & 0xFF,  bitLen & 0xFF,
    ]);

    int rotr(int x, int n) => ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF;

    final List<int> w = List<int>.filled(64, 0);
    for (int i = 0; i < padded.length; i += 64) {
      for (int t = 0; t < 16; t++) {
        w[t] = (padded[i + t * 4] << 24) | (padded[i + t * 4 + 1] << 16) |
               (padded[i + t * 4 + 2] << 8) | padded[i + t * 4 + 3];
      }
      for (int t = 16; t < 64; t++) {
        final s0 = rotr(w[t-15], 7) ^ rotr(w[t-15], 18) ^ (w[t-15] >> 3);
        final s1 = rotr(w[t-2], 17) ^ rotr(w[t-2], 19) ^ (w[t-2] >> 10);
        w[t] = (w[t-16] + s0 + w[t-7] + s1) & 0xFFFFFFFF;
      }
      int a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (int t = 0; t < 64; t++) {
        final sum1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        final ch   = (e & f) ^ ((~e) & g);
        final temp1 = (h + sum1 + ch + k[t] + w[t]) & 0xFFFFFFFF;
        final sum0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        final maj  = (a & b) ^ (a & c) ^ (b & c);
        final temp2 = (sum0 + maj) & 0xFFFFFFFF;
        h = g; g = f; f = e; e = (d + temp1) & 0xFFFFFFFF;
        d = c; c = b; b = a; a = (temp1 + temp2) & 0xFFFFFFFF;
      }
      h0 = (h0 + a) & 0xFFFFFFFF; h1 = (h1 + b) & 0xFFFFFFFF;
      h2 = (h2 + c) & 0xFFFFFFFF; h3 = (h3 + d) & 0xFFFFFFFF;
      h4 = (h4 + e) & 0xFFFFFFFF; h5 = (h5 + f) & 0xFFFFFFFF;
      h6 = (h6 + g) & 0xFFFFFFFF; h7 = (h7 + h) & 0xFFFFFFFF;
    }

    return [
      (h0>>24)&0xFF,(h0>>16)&0xFF,(h0>>8)&0xFF, h0&0xFF,
      (h1>>24)&0xFF,(h1>>16)&0xFF,(h1>>8)&0xFF, h1&0xFF,
      (h2>>24)&0xFF,(h2>>16)&0xFF,(h2>>8)&0xFF, h2&0xFF,
      (h3>>24)&0xFF,(h3>>16)&0xFF,(h3>>8)&0xFF, h3&0xFF,
      (h4>>24)&0xFF,(h4>>16)&0xFF,(h4>>8)&0xFF, h4&0xFF,
      (h5>>24)&0xFF,(h5>>16)&0xFF,(h5>>8)&0xFF, h5&0xFF,
      (h6>>24)&0xFF,(h6>>16)&0xFF,(h6>>8)&0xFF, h6&0xFF,
      (h7>>24)&0xFF,(h7>>16)&0xFF,(h7>>8)&0xFF, h7&0xFF,
    ];
  }
}
