import 'dart:io';

/// Lightweight service that detects whether CobraX VPN is currently active.
///
/// CobraX VPN (D:\GameApp\CobraX_Vpn) runs a Netty MITM proxy on
/// 127.0.0.1:8877 when the VPN service is connected. This service
/// performs a TCP socket connection probe to confirm that
/// the proxy port is open and accepting connections.
///
/// Detection method:
///   - TCP connect to 127.0.0.1:8877 with 150ms timeout.
///   - If the socket opens successfully -> VPN is active.
///   - If the connection is refused or times out -> VPN is disconnected.
class VpnCheckService {
  VpnCheckService._();

  static const String _vpnProxyHost = '127.0.0.1';
  static const int _vpnProxyPort = 8877;
  static const Duration _probeTimeout = Duration(milliseconds: 150);

  /// Probes the CobraX VPN local Netty proxy port (127.0.0.1:8877).
  ///
  /// Returns `true` if the CobraX VPN is connected and the Netty proxy
  /// is accepting connections. Returns `false` in ALL other cases
  /// (VPN off, socket refused, timeout, any exception).
  static Future<bool> isCobraxVpnActive() async {
    try {
      final socket = await Socket.connect(
        _vpnProxyHost,
        _vpnProxyPort,
        timeout: _probeTimeout,
      );
      socket.destroy();
      return true;
    } catch (_) {
      // Connection refused, timeout, or any I/O error -> VPN not active
      return false;
    }
  }
}
