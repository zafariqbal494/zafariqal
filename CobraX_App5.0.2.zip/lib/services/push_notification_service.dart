import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';

import '../config/app_config.dart';

/// Push Notification Service utilizing OneSignal v5 SDK.
/// Manages device registration, permission requests, and notification click handling.
class PushNotificationService {
  PushNotificationService._();

  static bool _isInitialized = false;

  /// Initializes OneSignal with the provided [appId] or fallback [kOneSignalAppId].
  static Future<void> initialize({String? appId}) async {
    final targetAppId = (appId != null && appId.trim().isNotEmpty)
        ? appId.trim()
        : kOneSignalAppId.trim();

    if (targetAppId.isEmpty || targetAppId == 'YOUR_ONESIGNAL_APP_ID') {
      debugPrint('[PushNotificationService] OneSignal App ID is not configured yet. Skipping.');
      return;
    }

    if (_isInitialized) return;

    try {
      if (kDebugMode) {
        OneSignal.Debug.setLogLevel(OSLogLevel.verbose);
      } else {
        OneSignal.Debug.setLogLevel(OSLogLevel.none);
      }

      // 1. Initialize SDK
      OneSignal.initialize(targetAppId);

      // 2. Request user permission for notifications (Android 13+ / iOS)
      await OneSignal.Notifications.requestPermission(true);

      // 3. Handle notification click / opened event
      OneSignal.Notifications.addClickListener((event) {
        debugPrint('[PushNotificationService] Notification clicked: ${event.notification.title}');
        final customData = event.notification.additionalData;
        final targetUrl = customData?['url']?.toString();

        if (targetUrl != null && targetUrl.isNotEmpty) {
          try {
            InAppBrowser.openWithSystemBrowser(url: WebUri(targetUrl));
          } catch (e) {
            debugPrint('[PushNotificationService] Could not open target URL: $e');
          }
        }
      });

      _isInitialized = true;
      debugPrint('[PushNotificationService] OneSignal initialized successfully with App ID: $targetAppId');
    } catch (e) {
      debugPrint('[PushNotificationService] Initialization error: $e');
    }
  }
}
