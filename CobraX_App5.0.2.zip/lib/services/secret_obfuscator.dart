import 'dart:convert';
import 'dart:typed_data';

/// Runtime obfuscation and deobfuscation helper for sensitive API secrets.
/// Hides raw string literals from static binary inspection (e.g. `strings`, decompilers).
class SecretObfuscator {
  SecretObfuscator._();

  // Multi-byte key sequence for dynamic XOR decoding
  static const List<int> _kMask = [0x5A, 0xA5, 0x3C, 0xC3];

  // XOR-encoded byte sequence for '21ffb5ler16256R9LJ2eht'
  static const List<int> _encodedSecretBytes = [
    0x68, 0x94, 0x5A, 0xA5, 0x38, 0x90, 0x50, 0xA6, 
    0x28, 0x94, 0x0A, 0xF1, 0x6F, 0x93, 0x6E, 0xFA, 
    0x16, 0xEF, 0x0E, 0xA6, 0x32, 0xD1
  ];

  /// Deobfuscates and returns the API Secret at runtime.
  static String get apiSecret {
    return _deobfuscate(_encodedSecretBytes);
  }

  /// Generic XOR mask deobfuscator
  static String _deobfuscate(List<int> bytes) {
    final Uint8List result = Uint8List(bytes.length);
    for (int i = 0; i < bytes.length; i++) {
      result[i] = bytes[i] ^ _kMask[i % _kMask.length];
    }
    return utf8.decode(result);
  }
}
