import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:http/http.dart' as http;

import 'app_config_service.dart';
import 'device_id_service.dart';

/// Handles SoliPay recharge gateway API calls and browser redirection.
class GameDepositService {
  GameDepositService._();

  /// Processes SoliPay deposit initiation and opens the gateway in system browser.
  static Future<void> processDeposit({
    required String channel,
    required dynamic amount,
    required InAppWebViewController? webViewController,
  }) async {
    final double numAmount = (amount is num)
        ? amount.toDouble()
        : (double.tryParse(amount.toString()) ?? 500.0);

    try {
      final deviceId = await DeviceIdService.getDeviceId();

      final response = await http.post(
        Uri.parse('https://cobrax.sbs/api/deposit/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'channel': channel,
          'amount': numAmount,
          'device_id': deviceId,
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;

        // If device has already completed a deposit, disable SoliPay interceptor immediately
        if (data['alreadyUsed'] == true) {
          await AppConfigService.markDepositCompleted();
          await webViewController?.evaluateJavascript(
              source: 'window.__solipayDepositActive = false;');
          return;
        }

        if (data['success'] == true && data['paymentUrl'] != null) {
          final String paymentUrl = data['paymentUrl'] as String;
          debugPrint(
              '[SoliPay Deposit] Launching SoliPay payment in external browser: $paymentUrl');
          await InAppBrowser.openWithSystemBrowser(url: WebUri(paymentUrl));
        }
      }
    } catch (e) {
      debugPrint('[SoliPay Deposit] Error handling deposit: $e');
    }
  }
}
