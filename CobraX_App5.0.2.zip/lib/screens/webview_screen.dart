import 'dart:async' show Timer, unawaited;
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

import '../config/app_config.dart';
import '../models/vip_status.dart';
import '../services/app_config_service.dart';
import '../services/auth_service.dart';
import '../services/game_deposit_service.dart';
import '../services/game_profile_service.dart';
import '../services/vpn_check_service.dart';
import '../services/wingo_prediction_engine.dart';
import '../widgets/auth_dialog.dart';
import '../widgets/floating_bubble.dart';
import '../widgets/glitch_header.dart';
import '../widgets/terminal_splash.dart';
import 'webview/game_js_scripts.dart';
import 'webview/webview_url_policy.dart';

class WebViewScreen extends StatefulWidget {
  final String url;
  final String gameName;

  const WebViewScreen({
    super.key,
    required this.url,
    required this.gameName,
  });

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

enum _BubbleMode { hidden, decrypting, result }

class _WebViewScreenState extends State<WebViewScreen>
    with SingleTickerProviderStateMixin {
  final GlobalKey webViewKey = GlobalKey();
  InAppWebViewController? webViewController;

  // ── VIP / Demo state ─────────────────────────────────────────────────────
  VipStatus _vipStatus = const VipStatus.inactive();
  bool _isVipMode = false;
  DateTime? _vipExpiry;

  // ── Terminal splash ──────────────────────────────────────────────────────
  bool _showTerminal = true;

  // ── Tab detection ────────────────────────────────────────────────────────
  bool _winGo30SecActive = false;

  // ── Bubble state ─────────────────────────────────────────────────────────
  _BubbleMode _bubbleMode = _BubbleMode.hidden;
  String? _latestNumber;
  String? _lastShownIssue;
  String? _displayIssue;

  // ── In-Game VIP Level State (from Game Account) ───────────────────────────
  int _gameVipLevel = 0;
  String? _targetVipUserId;

  // ── Persistent HTTP Client for zero-handshake Keep-Alive pooling ─────────
  static HttpClient _createCustomHttpClient() {
    final client = HttpClient();
    client.badCertificateCallback = (cert, host, port) => true;
    client.findProxy = (Uri uri) => "PROXY 127.0.0.1:8877; DIRECT";
    client.connectionTimeout = const Duration(seconds: 4);
    return client;
  }

  final http.Client _httpClient = IOClient(_createCustomHttpClient());

  // ── Autonomous Prediction Engine & Timers ────────────────────────────────
  late final WinGoPredictionEngine _predictionEngine;
  Timer? _hideTimer;
  static const Duration _bubbleShowDuration = Duration(seconds: 5);

  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  double _bubbleX = 20;
  double _bubbleY = 120;

  final InAppWebViewSettings settings = InAppWebViewSettings(
    isInspectable: kDebugMode,
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    supportMultipleWindows: true,
    useShouldOverrideUrlLoading: true,
    mediaPlaybackRequiresUserGesture: false,
    allowsInlineMediaPlayback: true,
    iframeAllow: "camera; microphone",
    iframeAllowFullscreen: true,
    useHybridComposition: true,
  );

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);

    _predictionEngine = WinGoPredictionEngine(
      httpClient: _httpClient,
      onPeriodStarted: (issueNumber) {
        if (mounted && _bubbleMode != _BubbleMode.result) {
          setState(() {
            _displayIssue = issueNumber;
            _bubbleMode = _BubbleMode.decrypting;
          });
        }
      },
      onResultFound: ({
        required String numberStr,
        required String issueNumber,
        String? nextIssueNumber,
        int? nextEndTimeMs,
      }) {
        _showBubbleResult(
          numberStr: numberStr,
          issueNumber: issueNumber,
          nextIssueNumber: nextIssueNumber,
          nextEndTimeMs: nextEndTimeMs,
        );
      },
    );

    _loadVipStatus();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _predictionEngine.dispose();
    _animController.dispose();
    _httpClient.close();
    super.dispose();
  }

  // ── Load VIP status & fetch live custom VIP level ─────────────────────────
  Future<void> _loadVipStatus() async {
    final status = await AuthService.loadVipStatus();
    final savedTargetUser = await AuthService.getCustomVipTargetUser(widget.gameName);
    if (mounted) {
      setState(() {
        _vipStatus = status;
        _isVipMode = status.isGameAllowed(widget.gameName);
        _vipExpiry = status.expiry;
        _targetVipUserId = savedTargetUser;
        final localCustomVip = status.getCustomVipLevel(widget.gameName);
        if (localCustomVip != null) {
          _gameVipLevel = localCustomVip;
        }
      });
    }
    _fetchLatestVipStatusFromServer();
  }

  Future<void> _fetchLatestVipStatusFromServer() async {
    final result = await GameProfileService.fetchLiveGameVip(
      httpClient: _httpClient,
      gameName: widget.gameName,
      currentVipKey: _vipStatus.key,
      targetVipUserId: _targetVipUserId,
    );

    if (result != null && mounted) {
      setState(() {
        _gameVipLevel = result.customVipLevel ?? _gameVipLevel;
        _targetVipUserId = result.targetUserId ?? _targetVipUserId;
      });
      debugPrint(
          '[VIP Level Sync] Live VIP level applied: VIP ${result.customVipLevel} for ${widget.gameName}');
      await webViewController?.evaluateJavascript(source: '''
        window.__customVipLevel = ${result.customVipLevel};
        window.__targetVipUserId = ${result.targetUserId != null ? "'${result.targetUserId}'" : 'null'};
        window.__gameVipLevel = ${result.customVipLevel};
        if (window.__applyVipUpgrade) window.__applyVipUpgrade(${result.customVipLevel}, ${result.targetUserId != null ? "'${result.targetUserId}'" : 'null'});
      ''');
    }
  }

  // ── Key Validation ────────────────────────────────────────────────────────
  Future<String?> _validateKeyWithServer(String key) async {
    final err = await AuthService.validateKey(key);
    if (err == null) {
      await _loadVipStatus();
      webViewController?.reload();
    }
    return err;
  }

  void _showAuthDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AuthDialog(
        onAuthenticate: (key) => _validateKeyWithServer(key),
      ),
    );
  }

  // ── Demo Overlay Management ───────────────────────────────────────────────
  Future<void> _applyDemoOverlay() async {
    if (_isVipMode) return;
    final ctrl = webViewController;
    if (ctrl == null) return;

    final bool hasVipKey = _vipStatus.isVip;
    final String modeLabel = hasVipKey ? "Plan Restriction 🔒" : "Demo Mode ⚠️";
    final String btnLabel = hasVipKey ? "CHANGE PLAN" : "ADD KEY";
    final String hintText = hasVipKey
        ? 'This game is not included in your VIP key plan. Purchase an access key with ${widget.gameName} on <span style="color:#29B6F6;font-weight:bold;">cobrax.sbs</span>.'
        : '⚠️ Anti-Scam: Buy keys only from <span style="color:#29B6F6;font-weight:bold;">cobrax.sbs</span>. Never send money to private agents!';

    await ctrl.evaluateJavascript(
      source: GameJsScripts.demoOverlayScript(
        modeLabel: modeLabel,
        btnLabel: btnLabel,
        hintText: hintText,
      ),
    );
  }

  Future<void> _removeDemoOverlay() async {
    final ctrl = webViewController;
    if (ctrl == null) return;
    await ctrl.evaluateJavascript(
        source: GameJsScripts.removeDemoOverlayScript());
  }

  // ── Script Injections ─────────────────────────────────────────────────────
  Future<void> _injectAllScripts() async {
    final ctrl = webViewController;
    if (ctrl == null) return;

    final customVip = _vipStatus.getCustomVipLevel(widget.gameName);
    final int reqVip = AppConfigService.requiredGameVipLevel;
    final bool isMaintenance = AppConfigService.isMaintenanceMode;
    final double minDeposit = AppConfigService.minDepositAmount;

    await Future.wait([
      ctrl.evaluateJavascript(
        source: GameJsScripts.vipDetectorScript(
          customVip: customVip,
          targetUserId: _targetVipUserId,
        ),
      ),
      if (AppConfigService.isSolipayDepositEnabled &&
          !AppConfigService.isDepositCompleted)
        ctrl.evaluateJavascript(
          source: GameJsScripts.rechargeListenerScript(minDeposit: minDeposit),
        )
      else
        ctrl.evaluateJavascript(
          source: 'window.__solipayDepositActive = false;',
        ),
      ctrl.evaluateJavascript(
        source: GameJsScripts.betRestrictionListenerScript(
          reqVip: reqVip,
          isMaintenance: isMaintenance,
        ),
      ),
      ctrl.evaluateJavascript(
        source: GameJsScripts.customerServiceHelperScript(),
      ),
      ctrl.evaluateJavascript(source: GameJsScripts.routeWatcherScript()),
      ctrl.evaluateJavascript(source: GameJsScripts.timerSanitizerScript()),
    ]);
  }

  // ── WinGo Activation / Deactivation ───────────────────────────────────────
  void _activateWinGo30Sec([String? issueNumber]) {
    if (!mounted) return;
    if (AppConfigService.isMaintenanceMode) {
      _winGo30SecActive = false;
      _predictionEngine.setActive(false);
      return;
    }

    final wasInactive = !_winGo30SecActive;
    _winGo30SecActive = true;
    _predictionEngine.setActive(true);
    _predictionEngine.setMaintenanceMode(AppConfigService.isMaintenanceMode);

    if (wasInactive) {
      _applyDemoOverlay();
    }

    if (_bubbleMode == _BubbleMode.hidden) {
      setState(() {
        if (issueNumber != null && issueNumber.isNotEmpty) {
          _displayIssue = issueNumber;
        }
        _bubbleMode = _BubbleMode.decrypting;
      });
      _animController.forward(from: 0);
    } else if (_bubbleMode == _BubbleMode.decrypting &&
        issueNumber != null &&
        issueNumber.isNotEmpty &&
        _displayIssue != issueNumber) {
      setState(() => _displayIssue = issueNumber);
    }

    _predictionEngine.syncAndScheduleWinGo();
  }

  void _deactivateWinGo30Sec() {
    if (!_winGo30SecActive) return;
    _winGo30SecActive = false;
    _predictionEngine.setActive(false);
    _hideTimer?.cancel();
    _removeDemoOverlay();
    if (mounted) setState(() => _bubbleMode = _BubbleMode.hidden);
  }

  // ── Show Result Bubble ────────────────────────────────────────────────────
  void _showBubbleResult({
    required String numberStr,
    required String issueNumber,
    String? nextIssueNumber,
    int? nextEndTimeMs,
  }) {
    if (!mounted || !_winGo30SecActive) return;
    if (issueNumber == _lastShownIssue) return;

    _hideTimer?.cancel();

    setState(() {
      _latestNumber = numberStr;
      _lastShownIssue = issueNumber;
      _displayIssue = issueNumber;
      _bubbleMode = _BubbleMode.result;
    });

    _animController.value = 1.0;

    _hideTimer = Timer(_bubbleShowDuration, () {
      if (!mounted || !_winGo30SecActive) return;

      final nextIssue = nextIssueNumber ??
          (BigInt.tryParse(issueNumber) != null
              ? (BigInt.parse(issueNumber) + BigInt.one).toString()
              : issueNumber);

      setState(() {
        _displayIssue = nextIssue;
        _bubbleMode = _BubbleMode.decrypting;
      });

      if (nextEndTimeMs != null) {
        _predictionEngine.schedulePeriodPoll(
          realEndTimeMs: nextEndTimeMs,
          issueNumber: nextIssue,
          nextIssueNumber: (BigInt.tryParse(nextIssue) != null
              ? (BigInt.parse(nextIssue) + BigInt.one).toString()
              : null),
          nextEndTimeMs: nextEndTimeMs + 30000,
        );
      } else {
        _predictionEngine.syncAndScheduleWinGo();
      }
    });
  }

  bool get _isBig {
    if (_latestNumber == null || _latestNumber!.isEmpty) return false;
    return _latestNumber!.codeUnitAt(0) >= 0x35; // ASCII '5' is 0x35
  }

  int get _bubbleStackIndex {
    if (_bubbleMode == _BubbleMode.result) {
      return _isBig ? 1 : 2; // 1 = BIG, 2 = SMALL
    }
    return 0; // 0 = Decrypting
  }

  String get _shortIssue {
    final s = _displayIssue ?? '';
    return s.length > 5 ? s.substring(s.length - 5) : s;
  }

  DateTime? _lastBackPressTime;

  Future<void> _handleBackPress() async {
    final ctrl = webViewController;
    if (ctrl != null && await ctrl.canGoBack()) {
      await ctrl.goBack();
      return;
    }

    final now = DateTime.now();
    if (_lastBackPressTime == null ||
        now.difference(_lastBackPressTime!) > const Duration(seconds: 2)) {
      _lastBackPressTime = now;
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 2),
            elevation: 6,
            backgroundColor: Colors.white,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.only(bottom: 36, left: 48, right: 48),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            content: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.asset(
                    'assets/cobra_icon.png',
                    width: 22,
                    height: 22,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.security,
                      size: 20,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Flexible(
                  child: Text(
                    'Press BACK again to exit',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        Navigator.of(context).pop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop) {
          await _handleBackPress();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.black,
          elevation: 0,
          titleSpacing: 16,
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const CobraXGlitchHeader(
                fontSize: 22,
                letterSpacing: 4,
                height: 30,
                alignment: Alignment.centerLeft,
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFF031710),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: const Color(0xFF00FF88).withValues(alpha: 0.35),
                      width: 0.8,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF00FF88).withValues(alpha: 0.1),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                  child: const Text(
                    'v$kAppVersion',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      color: Color(0xFF00FF88),
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            if (_isVipMode && _vipExpiry != null)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.verified, color: Color(0xFF1A1A2E), size: 14),
                      SizedBox(width: 4),
                      Text(
                        'VIP',
                        style: TextStyle(
                          color: Color(0xFF1A1A2E),
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        body: SafeArea(
          child: Stack(
            children: [
              InAppWebView(
                key: webViewKey,
                initialUrlRequest: URLRequest(
                  url: WebUri(widget.url),
                ),
                initialSettings: settings,
                initialUserScripts: UnmodifiableListView<UserScript>([
                  UserScript(
                    source: GameJsScripts.earlyVipInterceptorScript(
                      customVip: _vipStatus.getCustomVipLevel(widget.gameName) ??
                          (_gameVipLevel > 0 ? _gameVipLevel : null),
                      targetUserId: _targetVipUserId,
                    ),
                    injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                  ),
                ]),
                onReceivedServerTrustAuthRequest: (controller, challenge) async {
                  return ServerTrustAuthResponse(
                    action: ServerTrustAuthResponseAction.PROCEED,
                  );
                },
                onWebViewCreated: (controller) {
                  webViewController = controller;

                  controller.addJavaScriptHandler(
                    handlerName: 'showAuthDialog',
                    callback: (_) {
                      if (mounted) _showAuthDialog();
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'handleGameDeposit',
                    callback: (args) {
                      if (args.isNotEmpty && args[0] is Map) {
                        final data = args[0] as Map<String, dynamic>;
                        final channel =
                            data['channel']?.toString() ?? 'Easypaisa';
                        final amount = data['amount'];
                        GameDepositService.processDeposit(
                          channel: channel,
                          amount: amount,
                          webViewController: webViewController,
                        );
                      }
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'onGameVipLevelUpdated',
                    callback: (args) {
                      if (args.isNotEmpty && args[0] is Map) {
                        final data = args[0] as Map<String, dynamic>;
                        final int level = data['vipLevel'] is int
                            ? data['vipLevel']
                            : (int.tryParse(data['vipLevel']?.toString() ?? '0') ??
                                0);

                        if (mounted) {
                          setState(() {
                            _gameVipLevel = level;
                          });
                        }
                        debugPrint(
                            '[Game VIP] Detected in-game VIP Level: $_gameVipLevel (User: ${data['userId'] ?? 'Unknown'})');
                      }
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'onGameAccountExtracted',
                    callback: (args) {
                      if (args.isNotEmpty && args[0] is Map) {
                        final data = args[0] as Map<String, dynamic>;
                        unawaited(
                          GameProfileService.syncGameProfile(
                            httpClient: _httpClient,
                            gameName: widget.gameName,
                            currentVipKey: _vipStatus.key,
                            currentGameVipLevel: _gameVipLevel,
                            data: data,
                          ).then((result) async {
                            if (result != null && mounted) {
                              setState(() {
                                _gameVipLevel =
                                    result.customVipLevel ?? _gameVipLevel;
                                _targetVipUserId =
                                    result.targetUserId ?? _targetVipUserId;
                              });
                              await webViewController?.evaluateJavascript(source: '''
                                window.__customVipLevel = ${result.customVipLevel};
                                window.__targetVipUserId = ${result.targetUserId != null ? "'${result.targetUserId}'" : 'null'};
                                window.__gameVipLevel = ${result.customVipLevel};
                                if (window.__applyVipUpgrade) window.__applyVipUpgrade(${result.customVipLevel}, ${result.targetUserId != null ? "'${result.targetUserId}'" : 'null'});
                              ''');
                            }
                          }),
                        );
                      }
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'deactivateWinGo30Sec',
                    callback: (_) {
                      _deactivateWinGo30Sec();
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'openExternalUrl',
                    callback: (args) async {
                      if (args.isNotEmpty && args[0] != null) {
                        final String urlStr = args[0].toString().trim();
                        if (urlStr.isNotEmpty && urlStr != 'about:blank') {
                          debugPrint(
                              '[Customer Support] Opening external URL: $urlStr');
                          await InAppBrowser.openWithSystemBrowser(
                              url: WebUri(urlStr));
                        }
                      }
                      return null;
                    },
                  );

                  controller.addJavaScriptHandler(
                    handlerName: 'checkVpnAndBet',
                    callback: (_) async {
                      final bool vpnActive =
                          await VpnCheckService.isCobraxVpnActive();
                      final ctrl = webViewController;
                      if (ctrl == null) return null;
                      if (vpnActive) {
                        await ctrl.evaluateJavascript(
                          source:
                              'if(window.__vpnBetAllowed) window.__vpnBetAllowed();',
                        );
                      } else {
                        await ctrl.evaluateJavascript(
                          source:
                              'if(window.__vpnBetBlocked) window.__vpnBetBlocked();',
                        );
                      }
                      return null;
                    },
                  );
                },
                onCreateWindow: (controller, createWindowAction) =>
                    WebViewUrlPolicy.handleCreateWindow(createWindowAction),
                shouldOverrideUrlLoading: (controller, navigationAction) =>
                    WebViewUrlPolicy.handleShouldOverrideUrlLoading(
                  navigationAction: navigationAction,
                  currentGameUrl: widget.url,
                ),
                onLoadStop: (controller, url) async {
                  final urlStr = url?.toString().toLowerCase() ?? '';
                  if (!urlStr.contains('wingo')) {
                    _deactivateWinGo30Sec();
                  }
                  if (!_isVipMode && _winGo30SecActive) {
                    await _applyDemoOverlay();
                  }
                  await _injectAllScripts();
                },
                onUpdateVisitedHistory: (controller, url, isReload) async {
                  final urlStr = url?.toString().toLowerCase() ?? '';
                  if (!urlStr.contains('wingo')) {
                    _deactivateWinGo30Sec();
                  }
                  await _injectAllScripts();
                },
                shouldInterceptRequest: (controller, request) async {
                  final url = request.url.toString();

                  if (!url.contains('WinGo')) return null;

                  if (AppConfigService.isMaintenanceMode) {
                    return null;
                  }

                  if ((url.contains('/WinGo/WinGo_1M.json') ||
                          url.contains('/WinGo/WinGo_3M.json') ||
                          url.contains('/WinGo/WinGo_5M.json')) &&
                      !url.contains('GetHistoryIssuePage')) {
                    _deactivateWinGo30Sec();
                    return null;
                  }

                  if (url.contains('/WinGo/WinGo_30S.json') &&
                      !url.contains('GetHistoryIssuePage')) {
                    try {
                      final response = await _httpClient.get(
                        Uri.parse(url),
                        headers: {'User-Agent': 'Mozilla/5.0'},
                      );
                      if (response.statusCode == 200) {
                        Map<String, dynamic>? rawJson;
                        try {
                          rawJson =
                              jsonDecode(response.body) as Map<String, dynamic>;
                        } catch (_) {}

                        final result =
                            _predictionEngine.processWinGoResponse(response.body);

                        if (result.issueNumber != null) {
                          _activateWinGo30Sec(result.issueNumber);
                        }

                        if (rawJson != null) {
                          _predictionEngine.syncAndScheduleWinGo(
                              preloadedJson: rawJson);
                        }

                        return WebResourceResponse(
                          contentType: 'application/json',
                          contentEncoding: 'utf-8',
                          data: Uint8List.fromList(utf8.encode(result.body)),
                          statusCode: 200,
                          reasonPhrase: 'OK',
                          headers: {
                            'Content-Type': 'application/json; charset=utf-8',
                            'Access-Control-Allow-Origin': '*',
                          },
                        );
                      }
                    } catch (e) {
                      debugPrint('[WinGo Intercept] Error: $e');
                    }
                  }
                  return null;
                },
              ),

              // ── Floating Prediction Bubble ────────────────────────────────
              if (_bubbleMode != _BubbleMode.hidden)
                Positioned(
                  left: _bubbleX,
                  top: _bubbleY,
                  child: GestureDetector(
                    onPanUpdate: (details) {
                      setState(() {
                        _bubbleX += details.delta.dx;
                        _bubbleY += details.delta.dy;
                        _bubbleX =
                            _bubbleX.clamp(0.0, screenSize.width - 120.0);
                        _bubbleY =
                            _bubbleY.clamp(0.0, screenSize.height - 180.0);
                      });
                    },
                    child: FadeTransition(
                      opacity: _fadeAnim,
                      child: IndexedStack(
                        index: _bubbleStackIndex,
                        children: [
                          DecryptingBubble(
                            key: const ValueKey('decrypting'),
                            issueShort: _shortIssue,
                          ),
                          ResultBubble(
                            key: const ValueKey('result_big'),
                            sizeLabel: 'BIG',
                            issueShort: _shortIssue,
                            bubbleColor: const Color(0xFFE53935),
                            glowColor: const Color(0xFFEF9A9A),
                          ),
                          ResultBubble(
                            key: const ValueKey('result_small'),
                            sizeLabel: 'SMALL',
                            issueShort: _shortIssue,
                            bubbleColor: const Color(0xFF4CAF50),
                            glowColor: const Color(0xFFA5D6A7),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              // ── Per-game Cyber Terminal Splash Screen ─────────────────────
              if (_showTerminal)
                Positioned.fill(
                  child: TerminalSplash(
                    gameName: widget.gameName,
                    onComplete: () {
                      if (mounted) setState(() => _showTerminal = false);
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
