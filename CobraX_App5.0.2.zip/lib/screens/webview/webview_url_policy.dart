import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

/// URL interception and external browser routing policy for game WebView.
class WebViewUrlPolicy {
  WebViewUrlPolicy._();

  /// Evaluates URL navigation requests, intercepting app schemes, support tickets,
  /// and external payment gateways to open in the system browser.
  static Future<NavigationActionPolicy> handleShouldOverrideUrlLoading({
    required NavigationAction navigationAction,
    required String currentGameUrl,
  }) async {
    final uri = navigationAction.request.url;
    final urlStr = uri?.toString().toLowerCase() ?? '';

    // 1. Intercept custom app schemes (e.g. intent://, easypaisa://, jazzcash://, etc.)
    if (uri != null &&
        uri.scheme != 'http' &&
        uri.scheme != 'https' &&
        uri.scheme != 'about') {
      debugPrint('[App Scheme] Launching external app scheme: $uri');
      await InAppBrowser.openWithSystemBrowser(url: uri);
      return NavigationActionPolicy.CANCEL;
    }

    // 2. Intercept customer support, workorder, livechat, and messaging links
    if (urlStr.contains('workorder.support') ||
        urlStr.contains('livechat') ||
        urlStr.contains('chat') ||
        urlStr.contains('customer') ||
        urlStr.contains('telegram.me') ||
        urlStr.contains('t.me') ||
        urlStr.contains('wa.me') ||
        urlStr.contains('whatsapp.com')) {
      if (uri != null) {
        debugPrint('[Customer Support] shouldOverrideUrlLoading: $uri');
        await InAppBrowser.openWithSystemBrowser(url: uri);
        return NavigationActionPolicy.CANCEL;
      }
    }

    // 3. Intercept default game payment gateways & wallet approval pages to open in External Browser
    if (urlStr.contains('novapayment') ||
        urlStr.contains('onelink.me') ||
        urlStr.contains('easypaisa') ||
        urlStr.contains('jazzcash') ||
        urlStr.contains('arbpay') ||
        urlStr.contains('solipay') ||
        urlStr.contains('payment') ||
        urlStr.contains('gateway') ||
        urlStr.contains('cashier') ||
        urlStr.contains('checkout') ||
        urlStr.contains('epgreen') ||
        urlStr.contains('jazzgreen') ||
        urlStr.contains('/pay.') ||
        urlStr.contains('/pay/') ||
        urlStr.contains('pay.html') ||
        urlStr.contains('deposit')) {
      final gameHost = Uri.tryParse(currentGameUrl)?.host.toLowerCase() ?? '';
      final targetHost = uri?.host.toLowerCase() ?? '';
      final rootGameHost = gameHost.replaceAll('www.', '');

      // Open in external browser if target host is outside the core game domain
      if (rootGameHost.isNotEmpty && !targetHost.contains(rootGameHost)) {
        if (uri != null) {
          debugPrint(
              '[Payment Gateway] Opening default game payment in external browser: $uri');
          await InAppBrowser.openWithSystemBrowser(url: uri);
          return NavigationActionPolicy.CANCEL;
        }
      }
    }

    // Prevent navigation to about:blank from wiping out the game screen
    if (urlStr == 'about:blank' && navigationAction.isForMainFrame) {
      return NavigationActionPolicy.CANCEL;
    }

    return NavigationActionPolicy.ALLOW;
  }

  /// Handles popup window requests (`window.open`), routing external URLs to the system browser.
  static Future<bool> handleCreateWindow(
      CreateWindowAction createWindowAction) async {
    final uri = createWindowAction.request.url;
    if (uri != null &&
        uri.toString().isNotEmpty &&
        uri.toString() != 'about:blank') {
      debugPrint('[Customer Support] onCreateWindow: $uri');
      await InAppBrowser.openWithSystemBrowser(url: uri);
      return true;
    }
    return false;
  }
}
