import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../models/announcement.dart';
import '../models/vip_status.dart';
import '../services/announcement_service.dart';
import '../services/app_config_service.dart';
import '../services/auth_service.dart';
import '../widgets/announcement_banner.dart';
import '../widgets/app_launch_splash.dart';
import '../widgets/auth_dialog.dart';
import '../widgets/auth_status_card.dart';
import '../widgets/floating_telegram_button.dart';
import '../widgets/glitch_header.dart';
import '../widgets/mandatory_update_screen.dart';
import '../widgets/tampered_app_screen.dart';
import 'webview_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _showAppSplash = true;

  // VIP Key status on Home Screen
  VipStatus _vipStatus = const VipStatus.inactive();
  bool _isVipMode = false;
  DateTime? _vipExpiry;
  String? _vipKey;
  String? _vipPackage;
  int? _vipDays;

  // System Broadcast Announcement
  Announcement _announcement = const Announcement.inactive();

  @override
  void initState() {
    super.initState();
    _loadVipStatus();
    _loadAnnouncement();
    _loadAppConfig();
  }

  Future<void> _loadAppConfig() async {
    await AppConfigService.fetchAppConfig();
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _loadVipStatus() async {
    final status = await AuthService.loadVipStatus();
    if (mounted) {
      setState(() {
        _vipStatus = status;
        _isVipMode = status.isVip;
        _vipExpiry = status.expiry;
        _vipKey = status.key;
        _vipPackage = status.package;
        _vipDays = status.days;
      });
    }
  }

  Future<void> _loadAnnouncement() async {
    final ann = await AnnouncementService.fetchActiveAnnouncement();
    if (mounted) {
      setState(() => _announcement = ann);
    }
  }

  void _showAuthDialog() {
    if (AppConfigService.isUpdateRequired) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AuthDialog(
        onAuthenticate: (key) async {
          final err = await AuthService.validateKey(key);
          if (err == null) {
            await _loadVipStatus();
          }
          return err;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dynamicGames = AppConfigService.games;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              children: [
            // ── Header ──────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF1A0000), Color(0xFF0A0A0A)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 1. CobraX Cyber Glitch Header Title & Centered Tagline Block
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CobraXGlitchHeader(
                        fontSize: 30,
                        letterSpacing: 6,
                        height: 44,
                        alignment: Alignment.center,
                      ),
                      SizedBox(height: 2),
                      Text(
                        'ELITE PREDICTION PLATFORM',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'monospace',
                          color: Color(0xFFCC0000),
                          fontSize: 7.1,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // 2. Active Broadcast Announcement Banner (if any)
                  if (_announcement.active)
                    AnnouncementBanner(announcement: _announcement),

                  // 3. Authentication Key Status Card (Active vs Inactive vs Renewal Warning)
                  AuthStatusCard(
                    isVipMode: _isVipMode,
                    vipExpiry: _vipExpiry,
                    vipKey: _vipKey,
                    vipPackage: _vipPackage,
                    vipDays: _vipDays,
                    onEnterKey: _showAuthDialog,
                  ),

                  const SizedBox(height: 18),

                  // 4. Subtitle Note
                  const Text(
                    'WinGo 30Sec results available on all platforms',
                    style: TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),

            // ── Dynamic Games List ─────────────────────────
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: dynamicGames.length,
                itemBuilder: (context, index) {
                  final game = dynamicGames[index];
                  // Alternate accent colors for variety
                  final List<List<Color>> gradients = [
                    [const Color(0xFF8B0000), const Color(0xFF3D0000)],
                    [const Color(0xFF1A1A2E), const Color(0xFF16213E)],
                    [const Color(0xFF0D3B1E), const Color(0xFF0A0A0A)],
                    [const Color(0xFF2D1B4E), const Color(0xFF0A0A0A)],
                    [const Color(0xFF1A2744), const Color(0xFF0A0A0A)],
                    [const Color(0xFF3B1A00), const Color(0xFF0A0A0A)],
                    [const Color(0xFF1A003B), const Color(0xFF0A0A0A)],
                    [const Color(0xFF003B1A), const Color(0xFF0A0A0A)],
                  ];
                  final List<Color> accent = [
                    const Color(0xFFFF2222),
                    const Color(0xFF4488FF),
                    const Color(0xFF22CC66),
                    const Color(0xFF9944FF),
                    const Color(0xFF2299FF),
                    const Color(0xFFFF8800),
                    const Color(0xFFBB44FF),
                    const Color(0xFF00CC88),
                  ];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () async {
                          if (AppConfigService.isUpdateRequired) return;

                          // Verify active internet connection before launching game
                          final isOnline = await AppConfigService.checkInternetConnection();
                          if (!isOnline) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: const Color(0xFF1E080C),
                                  behavior: SnackBarBehavior.floating,
                                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    side: const BorderSide(color: Color(0xFFFF0044), width: 1.2),
                                  ),
                                  content: const Row(
                                    children: [
                                      Icon(Icons.wifi_off_rounded, color: Color(0xFFFF0044), size: 20),
                                      SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          'No internet connection. Please connect to a network to launch games.',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12.5,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }
                            return;
                          }

                          if (!context.mounted) return;
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => WebViewScreen(
                                url: game['url']!,
                                gameName: game['name']!,
                              ),
                            ),
                          );
                          // Auto-refresh when returning back to Home Screen
                          _loadVipStatus();
                          _loadAnnouncement();
                          _loadAppConfig();
                        },
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: gradients[index % gradients.length],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: accent[index % accent.length].withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Builder(
                                    builder: (context) {
                                      final isAllowed = _vipStatus.isGameAllowed(game['name']!);
                                      return Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                game['name']!,
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              if (_vipStatus.isVip) ...[
                                                const SizedBox(width: 8),
                                                Container(
                                                  padding: EdgeInsets.symmetric(
                                                    horizontal: isAllowed ? 6 : 5,
                                                    vertical: isAllowed ? 2 : 2.5,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color: isAllowed
                                                        ? const Color(0xFF00FF88).withValues(alpha: 0.15)
                                                        : const Color(0xFFFFB800).withValues(alpha: 0.12),
                                                    borderRadius: BorderRadius.circular(6),
                                                    border: Border.all(
                                                      color: isAllowed
                                                          ? const Color(0xFF00FF88).withValues(alpha: 0.6)
                                                          : const Color(0xFFFFB800).withValues(alpha: 0.5),
                                                      width: 0.8,
                                                    ),
                                                  ),
                                                  child: isAllowed
                                                      ? const Text(
                                                          '👑 VIP',
                                                          style: TextStyle(
                                                            fontFamily: 'monospace',
                                                            color: Color(0xFF00FF88),
                                                            fontSize: 9,
                                                            fontWeight: FontWeight.w900,
                                                          ),
                                                        )
                                                      : const Icon(
                                                          Icons.lock_rounded,
                                                          size: 11.5,
                                                          color: Color(0xFFFFB800),
                                                        ),
                                                ),
                                              ],
                                            ],
                                          ),
                                          const SizedBox(height: 6),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                                            decoration: BoxDecoration(
                                              color: AppConfigService.isMaintenanceMode
                                                  ? const Color(0xFFFF3333).withValues(alpha: 0.12)
                                                  : const Color(0xFF00FF88).withValues(alpha: 0.10),
                                              borderRadius: BorderRadius.circular(20),
                                              border: Border.all(
                                                color: AppConfigService.isMaintenanceMode
                                                    ? const Color(0xFFFF3333).withValues(alpha: 0.4)
                                                    : const Color(0xFF00FF88).withValues(alpha: 0.35),
                                                width: 0.8,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 6,
                                                  height: 6,
                                                  decoration: BoxDecoration(
                                                    color: AppConfigService.isMaintenanceMode
                                                        ? const Color(0xFFFF3333)
                                                        : const Color(0xFF00FF88),
                                                    shape: BoxShape.circle,
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: AppConfigService.isMaintenanceMode
                                                            ? const Color(0xFFFF3333).withValues(alpha: 0.8)
                                                            : const Color(0xFF00FF88).withValues(alpha: 0.7),
                                                        blurRadius: 5,
                                                        spreadRadius: 0.5,
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                Text(
                                                  AppConfigService.isMaintenanceMode
                                                      ? 'SERVER OFFLINE'
                                                      : 'WINGO 30S • LIVE',
                                                  style: TextStyle(
                                                    fontFamily: 'monospace',
                                                    color: AppConfigService.isMaintenanceMode
                                                        ? const Color(0xFFFF5555)
                                                        : const Color(0xFF00FF88),
                                                    fontSize: 9.5,
                                                    fontWeight: FontWeight.w800,
                                                    letterSpacing: 0.6,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                                Icon(
                                  Icons.arrow_forward_ios,
                                  color: accent[index % accent.length].withValues(alpha: 0.7),
                                  size: 16,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // ── Footer ─────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: const Text(
                'CobraX v$kAppVersion • Elite Prediction Platform',
                style: TextStyle(color: Color(0xFF444444), fontSize: 11),
              ),
            ),
          ],
        ),
      ),

          // ── Floating Telegram Support Button (Above Footer Right) ──
          const Positioned(
            right: 20,
            bottom: 60,
            child: FloatingTelegramButton(size: 60),
          ),

          // ── Cyber App Launch Splash Overlay ─────────────────────
          if (_showAppSplash)
            Positioned.fill(
              child: AppLaunchSplash(
                onComplete: () {
                  if (mounted) setState(() => _showAppSplash = false);
                },
              ),
            ),

          // ── Mandatory Version Update Blocking Overlay ───────────
          if (AppConfigService.isUpdateRequired)
            const Positioned.fill(
              child: MandatoryUpdateScreen(),
            ),

          // ── Tampered / Unauthorized APK Blocking Overlay ────────
          // Protection C+D: Server-side fingerprint mismatch detected
          if (AppConfigService.isTamperedApp)
            const Positioned.fill(
              child: TamperedAppScreen(),
            ),
        ],
      ),
    );
  }
}
